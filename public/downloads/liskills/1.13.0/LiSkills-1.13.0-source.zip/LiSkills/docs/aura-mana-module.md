# LiSkills 主动能力模块

对照上游旧版2.3.12：`api/.../mana/ManaAbilities.java` 与 `common/src/main/resources/mana_abilities.yml` 默认只有8项：REPLENISH、TREECAPITATOR、SPEED_MINE、SHARP_HOOK、TERRAFORM、CHARGED_SHOT、ABSORPTION、LIGHTNING_BLADE。敏捷、炼金、附魔没有原版mana能力；LiSkills已有的这些技能通用药水能力保留。

| 原版能力 | 原版具体规则 | 本模块 |
|---|---|---|
| LIGHTNING_BLADE | 剑；攻速+5%，每阶再+5%；持续5秒，每阶+4秒 | 独立ATTACK_SPEED倍率modifier，默认上限50%；不是闪电伤害 |
| SHARP_HOOK | 已抛出的本人鱼钩附近目标；左键鱼竿造成0.5+每阶0.5伤害；33格；耗魔5+每阶2，冷却2秒起 | 只认标准API实际钩住的目标，真实玩家伤害与最终扣血检查；默认伤害上限5、关闭PvP；不冒充快速咬钩 |
| ABSORPTION | 盾；持续2秒、每阶+3秒；每抵消1伤害另耗2魔力且须有余量；全额吸收 | 独立全额吸收窗口，默认只近战/投射物、单次伤害上限20；支持主/副手盾；旧部分减伤MANA_SHIELD保留 |
| SPEED_MINE | 镐；持续10秒、每阶+5秒；默认急迫X | 专用持镐入口，默认生存服急迫III，可配置I-X；保留更强已有药水，原版药水阻止时不扣费 |
| CHARGED_SHOT逐箭模式 | 左键弓开关；每箭按满弓耗魔×力度，余额不足用剩余值；额外伤害百分比=实耗魔力×(0.5+每阶0.1) | 新类型AURA_CHARGED_SHOT；切换免费，射击晚取消/替换箭退款；旧CHARGED_SHOT窗口完全保留 |

首次施放权限、等级、冷却、魔力和失败退款仍统一使用AbilityManager；持续时间/激活耗魔/冷却仍由skills.yml及active-growth配置。本模块的攻速/锐钩伤害按同一主动等级计算，超上限停止增长。锐钩的原版左键施放另外接入同一AbilityManager，不自行绕过冷却和扣费。

`mana_abilities.yml` 默认配置：

```yaml
# 原版主动能力独立数值；修改后使用 /lsk reload。已有旧主动类型不受此文件替换。
lightning-blade:
  # 第一阶攻速增加百分比；有限数字0.1-100。5表示提高5%，不增加攻击伤害。
  base-attack-speed-percent: 5.0
  # 每提升一阶追加的攻速百分点；有限数字0-100。
  attack-speed-per-level: 5.0
  # 攻速增加总上限；有限数字0.1-200。生存服默认50%。
  maximum-attack-speed-percent: 50.0
sharp-hook:
  # 第一阶锐钩基础伤害；有限数字0.1-20，1点等于半颗心，仍经过原生伤害保护链。
  base-damage: 0.5
  # 每阶追加伤害；有限数字0-20。
  damage-per-level: 0.5
  # 单次基础伤害上限；有限数字0.1-100。
  maximum-damage: 5.0
  # 玩家到实际挂钩目标的最大距离；有限数字1-64，单位方块；原版33。
  maximum-distance: 33.0
  # 是否允许锐钩攻击玩家；true/false，仍遵守世界PvP开关及保护插件。
  allow-pvp: false
absorption:
  # 交互模式；AURA_READY为原版左键盾准备、下次受击启动；SHIELD_RIGHT_CLICK右键持盾即开；MANUAL仅指令/菜单/既有快捷施放。
  activation-mode: AURA_READY
  # 原版准备窗口；整数1-10秒，默认4。准备本身不扣魔力、不启动冷却。
  ready-seconds: 4
  # 完整抵消每1点基础伤害所需魔力；有限数字0.1-100。余额不足或将归零时完全不吸收。
  mana-per-damage: 2.0
  # 允许完整吸收的单次基础伤害上限；有限数字0.1-100。超过此值正常受伤且不收本次抵消费。
  maximum-damage-per-hit: 20.0
  # 是否兼顾火焰、摔落等环境伤害；true/false。虚空、强制击杀、自定义和反伤始终不吸收。
  allow-environmental-damage: false
speed-mine:
  # 急迫的游戏内等级；整数1-10。生存服默认III；设10可使用旧版默认急迫X。
  haste-level: 3
charged-shot:
  # 原版逐箭模式第一阶满弓魔力费用；有限数字0.1-1000。与旧窗口类型激活mana-cost无关。
  base-mana-cost: 10.0
  # 每阶满弓费用增加；有限数字0-1000，最终满弓费用最高100000。
  mana-cost-per-level: 5.0
  # 第一阶每消耗1魔力增加的伤害百分点；有限数字0.01-10。
  base-damage-percent-per-mana: 0.5
  # 每阶增加的“每魔力伤害百分点”；有限数字0-10。
  damage-percent-per-mana-per-level: 0.1
  # 总伤害增加百分比上限；有限数字0.1-200，默认25%。达到上限不再增加伤害。
  maximum-bonus-percent: 25.0
  # 最低拉弓力度；有限数字0.01-1。低于阈值完全原版射击且不耗魔。
  minimum-force: 0.1
  # 是否不经左键切换始终启用；true/false。开启后左键不改变开关状态。
  always-enabled: false
  # 是否逐箭显示实耗魔力和伤害增幅；true/false，默认false防刷屏。
  show-shot-message: false
  # 全服最多追踪箭矢；整数1-8192，超过时新射击保持原版且不耗魔。
  max-projectiles: 512
  # 追踪箭矢最长时间；整数1-60秒。
  projectile-lifetime-seconds: 30
  # 每支箭最多强化多少次未取消的实际命中；整数1-32。默认1防穿透叠加，旧版会对同支箭多次命中都加成。
  maximum-boosted-hits: 1
```

新增消息键，合并到现有messages.yml的ability节：

```yaml
ability:
  # 攻速主动要求主手持剑时发送。
  lightning-blade-tool: '<yellow>请主手持剑后施放闪电之刃。</yellow>'
  # 专用极速矿工入口要求持镐时发送。
  speed-mine-tool: '<yellow>请主手持镐后施放极速矿工。</yellow>'
  # 全额吸收要求实际持盾时发送。
  absorption-tool: '<yellow>请主手或副手持盾后施放吸收。</yellow>'
  # 锐钩要求主手持竿时发送。
  sharp-hook-tool: '<yellow>请主手持鱼竿后施放锐钩。</yellow>'
  # 无真实挂钩目标、目标过远、鱼钩取消或由CustomFishing接管时发送。
  sharp-hook-no-target: '<yellow>请先用原版鱼钩钩住有效目标。</yellow>'
  # 配置或世界PvP禁止攻击玩家时发送。
  sharp-hook-pvp-disabled: '<yellow>当前不允许锐钩攻击玩家。</yellow>'
  # 原生伤害被取消、目标无敌或没有实际损失生命时发送，不收魔力或冷却。
  sharp-hook-blocked: '<gray>目标未受到锐钩伤害，本次不消耗魔力。</gray>'
  # 瞬发锐钩成功后发送，不显示持续占位；MiniMessage文本，{ability}能力名称。
  sharp-hook-activated: '<green>已使用 {ability}。</green>'
  # 原版准备动作成功；此时还没有扣费和启动冷却。
  absorption-ready: '<aqua>吸收已准备：下次有效受击时启动。</aqua>'
  # 逐箭模式需要实际魔力可用，系统关闭时不提供免费增幅。
  aura-charged-mana-disabled: '<yellow>魔力系统未启用，无法开启逐箭蓄力模式。</yellow>'
  # 管理员开启always-enabled时提示。
  aura-charged-always-enabled: '<gray>逐箭蓄力当前设置为始终启用。</gray>'
  # 开关动作最短间隔2秒，防止左右键重复触发刷屏。
  aura-charged-toggle-wait: '<gray>请稍后再切换逐箭蓄力模式。</gray>'
  # 左键或施放指令打开逐箭开关；不消耗魔力。
  aura-charged-enabled: '<aqua>逐箭蓄力已开启：射击时按力度消耗魔力。</aqua>'
  # 左键或施放指令关闭逐箭开关；已正常发出的箭保留其已付费资格。
  aura-charged-disabled: '<gray>逐箭蓄力已关闭。</gray>'
  # 成功射击后可选发送；{mana}实际费用、{percent}最终加成百分比。
  aura-charged-shot: '<aqua>本箭消耗 {mana} 魔力，伤害 +{percent}%。</aqua>'
```

接线契约：

1. 同一 `manaAbilitiesYaml` 分别交给 `AuraManaSettings.parse(...)`、`AuraChargedShotSettings.parse(...)`、`AbsorptionActivationSettings.parse(...)`；通过三个Supplier传给模块，重载后读取新快照。
2. 构造 `AuraManaAbilityModule(plugin,config,profiles,skills,windows,enchantments,text,settingsSupplier,chargedSettingsSupplier,absorptionActivationSupplier,customFishing::owns)`。原9参数构造仍保留，额外两项使用默认值。
3. 将 `module.handlers()` 的5项合并进原有handler Map，旧POTION/QUICK_FISH/MANA_SHIELD/CHARGED_SHOT等条目原样保留；创建AbilityManager后调用 `module.register(abilities)`。
4. 主动类型白名单按技能加入 mining=SPEED_MINE、fishing=SHARP_HOOK、defense=ABSORPTION、fighting=LIGHTNING_BLADE、archery=AURA_CHARGED_SHOT；不要覆盖管理员原有类型。
5. 旧ManaShieldManager仅响应MANA_SHIELD类型，不能按同一个defense窗口误处理ABSORPTION；退出存档前可统一 `module.settleFor(uuid)`，模块也注册了LOWEST退服退款保障。
6. 关闭时 `module.close()` 先于共享windows.close()。潜行右键工具映射补 `*_SWORD -> fighting`；锐钩左键由模块监听，同样延至下一tick确认最终交互许可。

安全边界：闪电之刃不修改基础攻速、不碰装备附魔，只撤销自己仍持有的modifier；下线、死亡、换工具、换世界、重载或窗口结束后撤销。吸收仅改同一原生伤害事件，预留魔力至最终取消结果可见，晚取消或后续恢复伤害会退款；不把免伤当作自身取消。锐钩不重置目标无敌帧，不调用setHealth，不改鱼钩归属，不使用Paper专有接口；自有二次伤害上下文使技能伤害倍率与流血不重复进入。主手必须保持鱼竿，避免LiRealEnchant普通剑/斧/矛增幅被套用；目标的合法保护和防御回调保留。CustomFishing接管的鱼钩不被锐钩处理。

极速矿工的急迫与原版SpeedMine一样由原生剩余时长管理，放下镐不强删药水；停止插件也不误删其他来源的同类效果。锐钩是瞬时能力，其skills.yml持续时间仅保留现有配置验证所需的正值，不作为额外攻击窗口。

原版准备吸收：默认左键持盾准备4秒，第一次符合伤害类型的受击启动主动窗口并吸收该次攻击。首次受击被更晚的保护监听取消时，次tick退还激活费和抵消费，只撤销仍属于这次激活的窗口和冷却；其他插件后续改动的冷却不被覆盖。同tick第二次未取消攻击确实使用了此窗口，则保留激活费，只退还被取消那次伤害的抵消费。右键便捷模式先确认最终物品交互许可再通过统一AbilityManager施放，不抢占箱子等交互方块。

逐箭模式：`ActiveAbilityHandler` 的 consumesActivationMana/startsActivationCooldown/usesStandardActivationMessage 三项默认策略保持true；AURA_CHARGED_SHOT全部false，SHARP_HOOK仅关闭通用持续提示并发送独立瞬发成功消息。逐箭切换只改变当前在线会话开关，不启动旧窗口，不读skills.yml的激活mana-cost作为逐箭费用。真正射击时按上述独立配置计算；最终射击取消或插件替换箭实体会退款，已成功射出但未命中或命中被保护的箭不退款。后者已发生一次有效射击，符合原版逐箭付费语义。箭命中被取消时不消耗可强化命中次数；武器换手后已经发出的正常箭仍按已付费资格处理，退出、死亡、换世界、重载、实体移除、追踪到期会清理资格。无魔力或关闭魔力系统时不会得到免费加成。

第二轮默认模板与升级：`skills.yml` 模板版本为4。以下五项保留既有5级解锁，不重置玩家等级；其余技能与旧类型继续可配置使用。

| 技能 | 新默认类型 | 第一阶持续 | 第一阶冷却 | 激活魔力 |
|---|---|---|---|---|
| 采矿 | SPEED_MINE | 10秒 | 120秒 | 20 |
| 钓鱼 | SHARP_HOOK | 瞬发，配置1秒仅占位 | 2秒 | 5 |
| 箭术 | AURA_CHARGED_SHOT | 开关，配置1秒仅占位 | 无激活冷却，2秒防连点 | 0，另按每次射击扣费 |
| 防御 | ABSORPTION | 2秒 | 120秒 | 10，另收实际吸收伤害费用 |
| 战斗 | LIGHTNING_BLADE | 5秒 | 120秒 | 20 |

`AuraTemplateUpgrade` 只接受数字版本3，并逐技能检查旧主动块的全部9个键和值。类型、名称、效果、强度、持续、冷却、解锁、费用、启用开关任意一项被修改，缺少字段、增加未知字段或技能被禁用时，都保留该技能整个主动块。成功处理版本3后标记为4，即使全部是自定义块也不会下次重跑。只逐项设置改变的字段，保留注释和其余技能配置。`SkillConfigUpgrade` 原样保留；配置加载依次运行旧迁移与此迁移，版本校验允许1-4。

`balance.yml` 的 `active` 三项为独立生存限制：`maximum-duration-seconds: 20`（1-120）、`minimum-cooldown-seconds: 120`（1-86400）、`maximum-rank: 10`（1-1000）。只有总开关 `enabled: true` 时生效；缺少整个active节的旧文件使用同样默认值，现有配置补全逻辑只补缺失节点。关闭总开关恢复原始成长与上限，不改写skills.yml、abilities.yml或管理员数值。

主动阶级先取技能解锁/成长/技能等级上限，再限制为balance最高阶级，之后所有耗魔、持续、冷却、攻速、锐钩伤害和逐箭费用按同一阶级计算。常规能力最后套持续上限和冷却下限，即使关闭成长也生效；只关闭成长不会关闭生存限制。锐钩完全不增长持续占位，其短冷却继续按active-growth计算且至少1秒；逐箭模式完全不增长占位持续、不收激活费用或启动激活冷却。这两种类型豁免常规时间限制，但其伤害与逐箭费用仍受最高阶级限制。旧CHARGED_SHOT/QUICK_FISH/MANA_SHIELD仍是持续窗口，并正常应用时间限制。菜单和实际施放均调用ActiveSkillProgression，避免看到20秒却实际执行更长窗口。

`tools/verification/LiSkillsAuraManaProbe.java` 使用真实Java协议玩家，覆盖原生攻速属性、原生药水拒绝与锐钩真正扣血；吸收攻击、抛钩、左键与射箭事件为明确注入的服务端契约探针。默认准备、首击取消双退款、逐箭力度/余额/取消退款/替换箭/命中次数均有独立断言。仅通过javac或单测不等于服务器探针通过，最终验证结果由主任务执行后记录。
