# 魔力与自家附魔兼容提示

```yaml
custom-content:
  # 可选内容插件的连接结果；MiniMessage文本，保留plugin/version/error/state占位符。
  ready: '<green>{plugin} {version} 公开API已连接。</green>'
  failed: '<yellow>{plugin} 兼容接口异常：{error}。已停止额外奖励，请核对版本；其他技能继续可用。</yellow>'
  status: '<gray>{plugin}：</gray><aqua>{state}</aqua>'
  connected: '公开API已连接'
  absent: '未安装或未启用'
  disabled: '额外经验已关闭，安全避让仍生效'
  failed-state: '接口不匹配或运行失败，额外奖励已停止'
  default-source: '未单独配置ID的默认奖励'
mana:
  usage: '/lsk mana [玩家]'
  disabled: '<gray>当前服务器已关闭魔力消耗与恢复。</gray>'
  status: '<aqua>{player}</aqua> <gray>魔力：</gray><blue>{mana} / {maximum}</blue> <gray>在线每秒恢复 {regen}</gray>'
compatibility:
  disabled: '额外经验已关闭；安全避让仍生效'
  full: '成功事件与上下文接口已连接'
  legacy: '旧版基础共存；升级配套附魔启用完整桥接'
  absent: '未安装或API未连接'
  lre-ready: '<green>LiRealEnchant2 {version} 兼容已连接：次级方块成功结算、基岩附魔经验和二次伤害保护。</green>'
  lre-legacy: '<yellow>检测到旧版 LiRealEnchant2 API；请使用配套新版附魔，旧版缺少成功事件，不能保证连锁/基岩经验完整结算。</yellow>'
  lre-failed: '<yellow>LiRealEnchant2 API 连接异常：{error}。请使用配套版本并检查启动顺序；普通技能功能继续可用。</yellow>'
  lre-status: '<gray>LiRealEnchant2：</gray><aqua>{state}</aqua>'
ability-guide:
  # 主动能力按钮追加说明；MiniMessage 文本列表，[]可关闭该类说明。
  potion:
    - '<gray>施加原生效果，已有更强效果时不消耗资源。</gray>'
  # 伐木能力说明；MiniMessage 文本列表。
  treecapitator:
    - '<gray>持斧破坏自然树干，范围内同木种连锁。</gray>'
    - '<gray>有连锁附魔的工具由附魔接管。</gray>'
  # 挖掘能力说明；MiniMessage 文本列表。
  terraform:
    - '<gray>持锹破坏泥土/沙砾，同高度四邻连锁。</gray>'
    - '<gray>遵循领地保护，每格消耗正常工具耐久。</gray>'
  # 农耕能力说明；MiniMessage 文本列表，种子消耗规则见config.yml。
  replenish:
    - '<gray>持锄收获成熟作物，延迟补种幼苗。</gray>'
    - '<gray>默认需背包内对应的普通种子。</gray>'
    - '<gray>带自家补种/收割/播种附魔时由附魔接管。</gray>'
  # 箭术能力说明；阈值和增伤按当前配置显示，MiniMessage文本列表。
  charged_shot:
    - '<gray>主手持弓，潜行右键开启；拉弓至少 {charged_force}%。</gray>'
    - '<gray>窗口内射出箭的首次有效命中增伤 {charged_bonus}%。</gray>'
    - '<gray>换工具或窗口结束后，未命中的箭恢复普通伤害。</gray>'
  # 钓鱼能力说明；仅新抛竿等待范围，不复制奖励，MiniMessage文本列表。
  quick_fish:
    - '<gray>主手持鱼竿潜行右键开启，然后正常垂钓。</gray>'
    - '<gray>新鱼钩等待区间缩短为原来的 {fish_wait}%。</gray>'
    - '<gray>不改变渔获、宝藏概率与经验。</gray>'
  # 护盾说明；激活成本外另按抵消基础伤害扣魔力，MiniMessage文本列表。
  mana_shield:
    - '<gray>主手持盾潜行右键开启；抵消近战/箭矢伤害。</gray>'
    - '<gray>最多抵消 {shield_ratio}%，每点需 {shield_mana} 魔力。</gray>'
    - '<gray>余额不足时减弱；不抵消摔落、火焰或虚空。</gray>'
# 技能详情成长摘要追加的实际被动数值；不覆盖已有summary-lore。
passive-guide:
  # 当前等级基础加成，实际应用仍受世界/权限/攻击条件限制；MiniMessage列表。
  fighting:
    - '<gold>等级被动：</gold><gray>近战伤害 +{passive_percent}%</gray>'
  # 箭术每级增伤的当前合计；MiniMessage列表。
  archery:
    - '<gold>等级被动：</gold><gray>远程伤害 +{passive_percent}%</gray>'
  # 防御每级减伤的当前合计；MiniMessage列表。
  defense:
    - '<gold>等级被动：</gold><gray>攻击伤害减免 {passive_percent}%</gray>'
feedback:
  # 自然经验反馈标题；MiniMessage文本；gain为本轮连续实际新增经验，xp/required为本级进度。
  experience: '<aqua>{skill}</aqua> <green>+{gain}</green> <white>Lv.{level} {xp}/{required}</white>'
  # 刚达到等级上限时的反馈标题；MiniMessage文本；不显示被上限丢弃的经验。
  maximum: '<aqua>{skill}</aqua> <green>+{gain}</green> <gold>Lv.{level} 已达上限</gold>'
```
