# 自家附魔兼容

当前验证组合为本次发布的 LiSkills 与既有 LiRealEnchant2 2.0.0-dev201-paper26，精确版本/哈希见VERIFICATION；目标 Paper 26.1.2 / Java25。本轮扩展技能、采集防刷、装备与管理，保留CustomCrops/CustomFishing兼容，没有修改附魔代码或Jar；以下dev201补种修复属于此前交付。技能也可在无附魔的独立服运行。宠物插件只作架构与中文菜单参考，没有改动宠物源码或数据。

技能开发和交互验收以 Java 版客户端为范围，不开发基岩专用技能界面或操作适配，也不安排基岩技能验收。下文涉及 `BEDROCK` 的内容仅描述仍然保留的 LiRealEnchant 既有公开事件桥接，不表示新增基岩技能功能。兼容附魔也不意味着已经实现旧技能插件的全部玩法或 API。

## 安装与保留数据

停服并备份插件和玩家数据。此次只替换LiSkills Jar，已有LiRealEnchant dev201不需要替换，不要同时保留同插件的多个版本。API Jar只供开发编译，不放进`plugins/`。所有数据目录及已有附魔装备保留；LiSkills与原有技能插件不同时启用，需要迁移时另见[数据迁移说明](MIGRATION.md)。新增第三方兼容分别见[CustomCrops](customcrops-notes.md)与[CustomFishing](customfishing-notes.md)，商业插件不随本包分发。

默认开启额外经验时，启动后 `/lsk validate` 应显示“成功事件与上下文接口已连接”。关闭奖励时会显示“额外经验已关闭；安全避让仍生效”。未安装附魔时技能仍可独立运行；dev199 等缺少新接口的版本会收到中文升级提示，不声称其具备完整经验兼容。

## 公开桥接与结算

- `LiRealEnchantApi.isCheckingSecondaryBreak()` 标识附魔为领地兼容发出的次级破坏预检。预检不清除人工方块标记，也不授予采集经验。
- `LiSecondaryBlockBreakEvent` 只在次级操作成功且方块实际改变后发布，带破坏前材质和 BlockData 快照。技能还要求同玩家/位置有效预检凭据，最终状态改变、未取消且原方块非人工；裸完成事件、重复完成不能领经验。取消、失败、无变化不发布正常完成，正常成功最多结算一次。
- LiRealEnchant 既有 `LiEnchantTableCompleteEvent` 带来源、前后物品快照和实际等级/青金石消耗。现有经验桥接只接受 `BEDROCK` 且两种费用都大于0的成功事件；LiSkills 不负责该附魔菜单或其客户端交互。Java 原生附魔通过 Bukkit `EnchantItemEvent` 结算。
- `LiRealEnchantApi.isSecondaryDamage()` 标识附魔反弹等二次伤害，避免被动增伤/减伤再放大。不会永久改写角色属性。
- 工具公开附魔等级包含 `yunmengze:lumberjack`、`veinminer`、`excavation` 或 `digging` 时，LiSkills 的 `TREECAPITATOR` 伐木和 `TERRAFORM` 水平挖掘都会让位，不叠加第二套连锁任务。
- 工具公开附魔等级包含 `yunmengze:replenish`、`harvest` 或 `planter` 时，LiSkills 的 `REPLENISH` 补种让位，避免两套种植/收获机制争用同一把锄头。以上拒绝不会消耗本次魔力或写入冷却。

桥接通过插件公开的 API 服务与事件实现，不读取附魔内部私有字段，不改玩家装备附魔或 NBT。公开 API Jar 位于 `lib/`；反射仅用于兼容不同 API 版本与插件类加载，不代表依赖内部实现。上述公开上下文与完成事件从 LRE dev200 提供，dev201 保留 API v1 契约。

## LRE dev201 补种修复

dev201 修复的是 LiRealEnchant 自己的 `replenish` 附魔。旧流程在破坏事件中提前扣种子，再无条件延时写回作物；新版下一 tick 先确认原事件最终未取消、地块真实为空气、土壤仍适用、原工具和玩家状态有效，再提交标准 `BlockPlaceEvent`。放置保护批准且世界状态仍符合条件后才消耗一个普通种子。

取消、权限失效或回调移走种子时，只撤回本次未被改动的幼苗；其他插件替换的方块不会被旧快照覆盖。带名称、Lore、附魔或 PDC 的自定义种子不作为费用。新增 `lirealenchant.enchant.replenish` 权限，默认所有玩家拥有；要求在线存活的生存/冒险玩家持原锄头、同世界且在目标八格内。

两套补种延迟独立：LRE 附魔沿用下一 tick；LiSkills 技能默认 `replenish.delay-ticks: 4`，有魔力、冷却和生效窗口，默认消耗普通种子且保护未熟作物。它们都支持小麦、胡萝卜、马铃薯、甜菜和下界疣，按工具避让规则选择一套执行。新版未调整 LRE 的范围收割、主动播种、战斗或其他附魔费用。

## 配置开关

`compatibility.lirealenchant.enabled` **只控制额外经验桥接**。其下的 `secondary-block-xp` 控制附魔次级采集经验，保留的 `bedrock-enchanting-xp` 控制上述既有附魔付费事件的经验读取；总开关关闭时两类额外经验都关闭。保留该配置键不新增基岩技能适配范围。

公开接口可用时，保护预检识别、成功后的来源标记清理，以及同工具伐木/水平挖掘/补种避让始终保留，不受上述经验开关影响。关闭奖励不能使同一把工具启动两套连锁或补种机制。`skip-secondary-damage-bonus` 独立控制二次伤害加成跳过，也不依赖经验总开关。

配置升级补充缺失键与注释，保留管理员自定义值。`feedback.enabled` 仅影响经验 BossBar 显示，不影响实际入账或附魔避让。

## 经验显示与扩展事件

自然玩法经验成功入账后，LiSkills 发布只读 `SkillExperienceGainEvent`，提供玩家、技能 ID 和实际入账经验；超过等级上限而未入账的部分不会显示为获得，管理员指令及 API 直接写入不发布这个自然奖励通知。事件用于观察，不是可取消的奖励审批事件，监听器不应据此再次重复加经验。

内置 BossBar 按该事件合并同技能短时奖励，每两 tick 刷新，默认最后一次入账后显示四秒。切换技能后显示新技能进度；重载、离线或显示失效时移除。文本、颜色、样式和时长可配置，显示关闭不改变奖励数值。

## 验证边界

独立 Bukkit 定向断言检查附魔 API 合约；隔离 Paper 服联合探针检查两个实际成品的启动、服务发现、经验桥接和防重复处理。代理玩家、人工发出的公开完成事件仅用于验证服务端路径；它们不能替代真人 Java 版客户端点击、领地插件组合、网络延迟及大型树林压力测试。基岩技能交互及真人基岩验收明确排除在本项目范围之外，不作为后续待办。具体证据见 [验证记录](VERIFICATION.md)。
