# 属性与能力指令文本

下方首个 YAML 块合并到 `messages.yml`。全部文本支持 MiniMessage；保留花括号占位符。已有自定义文本和注释不覆盖。

```yaml
rpg-commands:
  # 属性指令格式；非空文本。
  usage-attributes: '/lsk attributes [玩家]'
  # 能力目录格式；非空文本，技能为 farming 等内置 ID。
  usage-abilities: '/lsk abilities <技能>'
  # RPG 总开关关闭时的提示；文本可设为空隐藏。
  disabled: '<gray>当前已关闭属性与被动成长系统。</gray>'
  # 九属性标题；保留 {player}。
  attributes-title: '<gradient:#57d5ff:#ae8aff>{player} · 九大属性</gradient>'
  # 一行属性信息；保留 {name}、{value}、{effect}。
  attribute-line: '<aqua>{name}</aqua> <white>{value}</white> <dark_gray>｜</dark_gray> <gray>{effect}</gray>'
  # 属性列表末尾说明；文本可设为空隐藏。
  attributes-footer: '<dark_gray>属性来自技能成长；当前装备与药水加成会自动更新。禁用世界或无技能权限时不生效。</dark_gray>'
  # 追加到玩家帮助的指令列表；文本列表，保留合法指令名。
  help-player:
    - '<aqua>/lsk attributes [玩家]</aqua> <gray>查看九属性和实际效果</gray>'
    - '<aqua>/lsk abilities <技能></aqua> <gray>查看被动阶级、解锁等级和成长数值</gray>'
  # 各属性效果说明；以下全部是文本，可自由调整措辞并保留所需占位符。
  effects:
    # 力量效果；{attack_damage} 为额外伤害百分数。
    strength: '额外伤害 +{attack_damage}%'
    # 生命效果；{hp} 为本插件增加的最大生命值，2 点为一颗心。
    health: '最大生命 +{hp}'
    # 再生效果；前两项是额外生命，最后一项是含 config.yml 基础值的每秒魔力回复。
    regeneration: '饱和回血 +{saturation_regen}；饥饿回血 +{hunger_regen}；魔力 {mana_regen_total}/秒'
    # 幸运效果；{gathering_luck} 为属性提供的采集幸运，不含各技能独立被动。
    luck: '五类采集幸运 +{gathering_luck}'
    # 智慧效果；{experience_bonus}/{anvil_discount} 为百分数，{mana_total} 为完整魔力上限。
    wisdom: '原版经验 +{experience_bonus}%；铁砧折扣 {anvil_discount}%；魔力上限 {mana_total}'
    # 韧性效果；{damage_reduction} 为应用递减公式后的实际减伤百分数。
    toughness: '战斗减伤 {damage_reduction}%'
    # 暴击几率效果；{crit_chance} 为限制在 0～100 的概率百分数。
    crit_chance: '技能暴击概率 {crit_chance}%'
    # 暴击伤害效果；{crit_damage} 为技能暴击时额外伤害百分数。
    crit_damage: '技能暴击额外伤害 +{crit_damage}%'
    # 速度效果；{movement_speed} 为本插件额外速度点，100 点对应移动属性 0.1。
    speed: '额外移动速度点 +{movement_speed}'
```

`/lsk attributes [玩家]` 沿用 `liskills.use`。查询其他在线玩家需要 `liskills.stats.others`，控制台必须给出玩家名。

`/lsk abilities <技能>` 是玩家菜单入口，需要 `liskills.use` 和对应 `liskills.skill.<技能>`；支持当前启用技能 ID 的 Tab 补全。

新增 PlaceholderAPI 占位符：

- `%liskills_stat_strength%` 等 `stat_<九属性ID>`：读取当前会话安全快照，包含最近一次刷新时的装备/药水加成；每秒刷新，属性查询会立即刷新。
- `%liskills_ability_bountiful_harvest%`：读取该被动的已解锁阶级。
- `%liskills_ability_value_bountiful_harvest%`：读取该阶级的主数值。

占位符不加载离线档案、不进行磁盘读写，也不从请求线程读取 Bukkit 玩家装备或药水。能力占位符是档案成长值，不是当前世界/权限下“能否触发”的判断；未知 ID 返回未解析，档案未加载或总开关关闭时返回 0。
