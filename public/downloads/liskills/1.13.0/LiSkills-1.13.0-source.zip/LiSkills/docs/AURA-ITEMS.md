# 装备属性与物品等级要求

本轮对照上游旧版 2.3.12 的 `ItemStateManager`、`BukkitModifierManager`、`SkillsItem.meetsRequirements`、`RequirementListener` 和 `wiki/skills/item-requirements.md` 实现。原版区分手持物品与护甲；主手、副手、头、胸、腿、脚分别结算，未满足技能要求的物品不提供属性。本实现沿用这些原则，使用标准 Bukkit 公开接口，不加载原版 NBT 库。

`items.yml` 总开关及三条示例默认全部关闭。配置示例见 [items-defaults.yml](items-defaults.yml)：只在测试服确认规则后，打开总开关及需要的规则。属性、规则和门槛在同一次配置重载中发布；不会覆盖其他插件或管理员的物品数据。

## 匹配与属性

- `match.materials` 按材质匹配，包括同材质的附魔物品；需要只匹配自家定制物品时，再添加公开 PDC `STRING` 键值。
- 材质与 PDC 同时填写时使用 AND；PDC 精确比较且区分大小写，类型不符不匹配。名称、Lore 和堆叠数量不参与识别。
- `slots` 指定六个装备位。背包、容器和光标里的物品不加属性；主副手各持一件可以各生效一次，64件堆叠也只算该槽一件。
- 九属性支持固定加法、乘法与百分数加法：`(成长+动态加成+永久加成+装备ADD之和) × 装备MULTIPLY之积 × (1+装备ADD_PERCENT之和/100)`。配置分别使用 `attributes`、`stat-multipliers`、`stat-percent-additions`，最终仍受 `stats.yml` 的属性开关与0至maximum范围约束。
- `traits` 支持原版19项实际效果及兼容的 `gathering-luck`，使用横线命名，如 `attack-damage`、`farming-luck`、`double-drop`。数字等于ADD；对象支持 `add`、`multiply`、`add-percent`。以属性换算后的效果值为基础进行三种运算，再执行减伤/铁砧非线性公式、暴击100%及生命/速度上限；不是绕过效果开关。
- `skill-xp-multipliers` 填百分数，`all: 10` 加指定 `mining: 25` 为挖矿1.35倍，其他技能1.10倍。多件物品的百分数相加，不相乘；技能经验在自然奖励入口计算一次，管理员直接设置/赠送经验不会被重复放大。玩家原版经验珠仍由 `experience-bonus` 控制。
- 同一槽位任一配置或PDC规则的要求不满足，这件物品的全部 LiSkills 属性、trait、倍率都不生效；不能只领取另一条宽松规则的奖励。未加载档案不发加成。
- 物品加成进入现有九属性快照，PAPI、生命、速度、战斗、经验、铁砧与魔力使用同一结果。换装备后在下次属性查询或最多一秒内刷新；不写进玩家永久属性存档，不改 ItemMeta 或别人的 AttributeModifier。

## 使用要求

`requirements` 可以引用已注册的内置或自定义技能。多项要求必须全部达到；技能不存在、停用、缺少 `liskills.use`／对应技能权限或档案还没加载时均不放行。`uses` 可选择攻击、破坏、放置、交互、射击、食用、抛竿和穿甲。留空只控制属性资格，不拦使用。

检查按本次使用的实际手和物品执行，射击检查 `EntityShootBowEvent` 的弓，消耗检查事件给出的物品；不在箭命中后猜测玩家当前武器。常规护甲点击、Shift、数字键、副手交换、拖拽、右键与发射器穿戴，以及受限鞘翅起飞均有入口。脱下、丢弃、携带及普通容器转移不被主动限制。若配置 `interact`，未达标时持该物品的交互会被取消，可先换到其他栏位再使用容器。

禁用世界、配置排除的游戏模式、NPC、死亡状态和关闭成长系统时整套物品规则停用；属性系统会清理本插件的生命/速度/原版幸运修饰符。`liskills.items.bypass` 应默认 `false`，管理员显式授予才绕过等级与技能权限要求；不会给未加载档案或无技能系统使用资格的人发属性。物品规则本身不自动赠送此权限给 OP。

LRE 的领地预检与二次伤害不被当成另一轮原始工具使用。正常攻击/破坏尽早检查；已被其他插件取消的事件不重新放行，不移除附魔、不改私有 NBT。其他插件在后续优先级刻意撤销取消、直接调用自己物品逻辑的情况，需要对方通过公开 `canUse` 查询接入。

## 公开身份和业务接入

可以在自家物品创建逻辑中给克隆后的物品写入自己的身份，不需要接触其他插件数据：

```java
ItemStack tagged = original.clone();
ItemMeta meta = tagged.getItemMeta();
meta.getPersistentDataContainer().set(
        new NamespacedKey("liskills", "item_id"), PersistentDataType.STRING, "guardian_blade");
tagged.setItemMeta(meta);
```

上述片段只说明 PDC 合同，不会由匹配器自动执行。管理指令可复用 `ItemModule.rules()` 的 `matching(item, slot)`、`canUse(player, item, slot, use)`、`denial(...)`。`ItemModule.attributes().effects(player)`返回全部效果；`bonuses(player)`仅返回固定ADD，不能用它再次应用倍率。自然技能经验调用 `skillExperienceMultiplier(player, skill)`。

`ItemModule.metadata()` 提供命名物品管理服务：`identify(item,id)`、`putRule(item,rule)`、`removeRule(item,name)`、`clearRules(item)`、`appendRules(item,rules)`全部返回克隆物品。只写 `liskills:item_id` 或 `liskills:item_rules`，不重写其他PDC、Lore、附魔和原生属性。`read(item)`返回 `present/valid/rules`；错误类型或损坏规则会拒绝危险使用及所有加成，可由管理员显式clear修复。读写上限32条命名规则、65536字符；缓存有界。

```java
ItemRule rune = ItemRuleEditor.named("guardian", Set.of(ItemSlot.MAIN_HAND));
rune = ItemRuleEditor.stat(rune, "strength", ItemModifierOperation.ADD, 5);
rune = ItemRuleEditor.stat(rune, "strength", ItemModifierOperation.MULTIPLY, 1.2);
rune = ItemRuleEditor.trait(rune, "max-mana", ItemModifierOperation.ADD, 20);
rune = ItemRuleEditor.experience(rune, "all", 10); // +10%，不是10倍
rune = ItemRuleEditor.requirement(rune, "fighting", 15);
ItemStack changed = itemModule.metadata().putRule(original, rune);
```

规则编辑器保留同名规则其余字段；必须把最终结果交给metadata服务写入时严格校验。传入自定义技能ID在使用时检查是否注册/启用，不能借错误技能ID跳过要求。上述接口须在Bukkit主线程使用，是LiSkills业务接口，不是旧技能插件的二进制兼容API。

## 旧技能物品预览与迁移

`AuraItemReader.preview(item)`只读上游旧版2.3.12源码实际使用的 `auraskills:item_/armor_` 下 modifiers、trait_modifiers、multipliers、requirements。支持新LIST容器、1.20.4之前的容器数组及更早的ADD容器；解析 `auraskills/strength` 形式ID、ADD/MULTIPLY/ADD_PERCENT、global技能经验及19项原版trait。只读取经过验证的公开PDC格式，不解析私有旧NBT。

预览返回 `recognized/complete/rules/problems`；未知命名空间、额外字段、错误类型、不能确定护甲槽位或超出安全边界时，`complete=false`。`migrate(original, metadata)`仅允许完整预览，生成副本并追加命名LiSkills规则；遇到已有同名规则拒绝，不覆盖，不删除原有旧技能标签。迁移物品不能同时在启用旧技能同类属性效果的环境重复结算，管理员应先备份并明确由哪个插件负责效果。启动和普通物品匹配不会自动迁移。

## 数值边界和幸运语义

单条ADD为-100000至100000、MULTIPLY为0至10、ADD_PERCENT与技能经验百分数为-100至1000；最终装备倍率限制0至100倍，计算结果绝对值不超过十亿，技能经验倍率0至10倍。0乘数或累计百分数≤-100使该属性/效果归零，负ADD随后按效果安全下界归零。最终玩家属性仍受更严格的stats.yml上限约束。

五项 `<skill>-luck` 默认使用兼容 `gathering-luck` 作为共同基底，再加入对应被动，最后应用本项物品trait。新增系数默认0，旧合并系数不会重复加一次；要五项独立控制，可禁用合并trait并各设modifier=0.5。`luck`直接增加本插件的Bukkit幸运修饰符，默认无属性系数；不修改别人的基值。`double-drop`也默认无属性系数，物品可授予0至100%的九类原版天然基础方块翻倍概率，不放大幸运/宝藏结果，不向CustomCrops/CustomFishing自定义掉落额外塞物品。

## 清楚保留的边界

保留边界是旧私有NBT自动转换、原版ItemStack序列化和 `ItemManager` 二进制API；并非原版Jar的无缝二进制替换。公开PDC提供显式迁移，trait、经验倍率和三种运算已进入对应业务计算。玩家永久modifier由独立管理器接入StatManager，不与物品规则混存。

不强行脱下玩家已经穿着的装备，也不覆盖其原生护甲值。玩家在启用新规则前就已穿着、被外部命令直接装备、重载或被管理员降级后，LiSkills 属性会停止，但该装备本身的原版护甲／附魔效果仍归 Minecraft 和对应插件管理；正常新穿戴及受限鞘翅起飞会阻止。没有声称阻断所有外部脚本、小游戏或强行物品写入。

测试覆盖配置、匹配、资格、三种运算、经验边界、trait快照以及旧技能PDC格式读取；实际Paper行为及真人客户端操作是否验收，以本次最终发行验证记录为准。服务端探针不等于真人鼠标操作、所有容器组合、第三方Equippable模型与压力验证。
