```yaml
# 合并到messages.yml现有extended节，只补缺项，不覆盖管理员文本。
extended:
  # 奖励账本无法读取或提交；同玩家每分钟最多显示一次。
  ledger-unavailable: '<red>奖励账本暂不可用，本次收入或奖励未发放，请联系管理员。'
  # 控制台限频警告；player为UUID，error为不含堆栈的故障原因。
  ledger-failed-log: '玩家 {player} 的奖励账本不可用，已停止本次发放：{error}'
  # 插件关闭时释放账本目录锁失败；不表示已付款记录被回滚。
  ledger-close-failed: '奖励账本目录锁释放失败：{error}'
```
