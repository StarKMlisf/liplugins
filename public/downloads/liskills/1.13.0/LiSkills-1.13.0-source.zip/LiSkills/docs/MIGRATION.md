# 旧技能档案迁移

LiSkills 保留旧技能系统默认技能及 Legacy 预设的完整 15 个技能 ID、参考经验来源和默认等级公式，但不是旧系统的完整替换实现。迁移工具仅处理旧版 `userdata/*.yml` 的技能等级和本级经验，不直接读取 MySQL，也不迁移 Mana、属性点、装备/物品标签、旧技能冷却、权限、任务、奖励或第三方插件数据。九属性与70项被动按迁移后的等级和新配置计算，不读取旧能力阶级；法术 `sorcery` 沿用上游 legacy 预设，没有内置主动或被动能力。

**先停服，再完整备份旧技能与 LiSkills 目录。** 迁移工具无法替你确认所有服务器进程已停止；运行中迁移可能被服务器内存中的旧数据覆盖。不要把两个插件同时放在同一台服务器启动。

## 支持范围

- 源文件名必须是标准 `UUID.yml`，文件内必须有匹配的 `uuid`。
- 支持 `skills` 下的 `auraskills/mining` 和 `auraskills:mining` 两种命名空间格式。
- 支持 farming、foraging、mining、fishing、excavation、archery、defense、fighting、agility、alchemy、enchanting、endurance、healing、forging、sorcery。
- 耐力、治疗、锻造、法术分别保存自己的等级与经验，不合并到敏捷、炼金或附魔。上游2.x默认11技能曾合并前三项来源；旧版迁移或 legacy 预设保留15技能，见[上游迁移说明](https://wiki.aurelium.dev/auraskills/migration)。
- 等级必须是 1 至 1000 的整数；经验必须是非负有限数字。0 级、小数等级、溢出、NaN、无穷大均明确拒绝，不会自动改为 1 或 0。
- 上述15项以外的自定义旧技能逐项列出后忽略。同一技能同时使用两种 ID 写法时拒绝猜测优先级。
- 等级和本级经验保持原值，不按新配置最大等级裁剪；降低最大等级后，超限玩家保留原档案并停止继续成长。修改经验曲线可能改变下一次获得经验后的升级结果。
- 炼金保留成功酿造来源，药水消费、投掷和金苹果来源归治疗；附魔台经验归附魔，铁砧与砂轮归锻造；行走、疾跑和游泳归耐力，跳跃与摔落归敏捷。成功酿造仍需确认最终事件与实际库存结果，自动酿造不凭空认领玩家。

给定上游项目的测试样例包含 0 级档案，因此不能假定所有旧档案都能直接导入。如果预检发现 0 级，请先评估旧服是否采用不同初始等级设计，再在备份副本或旧服管理流程中处理；工具不会擅自改变数据。

若此前已用旧 LiSkills 导入器迁移，它可能在报告中忽略了这四项技能。更新插件不会从已经缺失的 LiSkills 档案还原原等级。请保留旧技能源备份，先导入到新的空目录核对15项进度；不要覆盖已有 LiSkills 目标，也不要清空已经继续游玩的档案。

## 预检与执行

先在开发项目目录运行 `./build.ps1`，准备 Jar 与 `lib/api/`。迁移工具需要 Java 25。

```powershell
# 默认预检：不创建目标目录，不写入任何档案。
.\tools\migrate-auraskills.ps1 `
  -SourceUserdata 'D:\Minecraft\plugins\AuraSkills\userdata' `
  -TargetPlayers 'D:\Minecraft\plugins\LiSkills\players'

# 逐项确认预检结果，确认停服和备份后，才加 -Apply。
.\tools\migrate-auraskills.ps1 `
  -SourceUserdata 'D:\Minecraft\plugins\AuraSkills\userdata' `
  -TargetPlayers 'D:\Minecraft\plugins\LiSkills\players' `
  -Apply
```

可加 `-JavaHome 'C:\path\to\jdk-25'` 指定 Java。脚本使用当前构建的 `target/LiSkills-<版本>.jar` 与 `lib/api/*`；不要用 `java -jar`，此 Jar 的主入口是 Bukkit 插件。

## 安全行为与失败处理

工具先读取并验证整个批次。任何源档案损坏、UUID 不符、重复技能、目标同名文件已存在等问题都会拒绝整个批次，返回非零退出码，且不写入任何玩家档案。源目录与目标目录相同或互相包含时也会拒绝。

预检通过后，执行阶段再次检查目标，并使用操作系统 `CREATE_NEW` 逐个新建，绝不覆盖已有文件；源档案始终只读。没有旧名称的玩家暂用 UUID 作为名称，上线后更新。

这不是跨多个文件的数据库事务。如果写入途中发生磁盘故障、空间不足或另一个进程创建同名文件，工具停止后续写入并报告此前已经创建的文件数量；可能留下本次未完成的新文件。请结合逐文件报告检查目标，恢复此次迁移前的备份后再处理，不能直接反复加 `-Apply` 覆盖。工具没有覆盖或自动删除原档案的选项。

迁移成功后只启动 LiSkills，先检查 `/lsk stats`、技能菜单和玩家文件。旧技能插件API、物品 NBT、旧命令、复杂被动/主动能力以及第三方扩展不会因等级迁移而自动兼容。

## 回归验证

`AuraSkillsImporterTest` 使用独立 YAML fixture 与临时档案覆盖两种命名空间的全部15项独立进度、源文件内容不变、预检不写、0 级/整数溢出/非有限经验/重复技能整批拒绝、UUID 不符、已有目标不覆盖、计划后目标竞争以及源目标目录重叠。耐力、治疗、锻造、法术的非法进度也必须拒绝整个批次，不能作为未知技能跳过。迁移输出通过 LiSkills 的 `ProfileStore` 重新读取，验证等级和经验没有改变；实际执行结果以对应版本验证报告为准。
