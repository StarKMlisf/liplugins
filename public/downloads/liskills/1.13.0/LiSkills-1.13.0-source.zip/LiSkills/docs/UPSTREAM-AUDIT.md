# 上游旧版 2.3.12 审计与 LiSkills 处理

审计对象是用户本次提供的完整源码，不是任意其他版本；准确来源与原作者署名见 [NOTICE](../NOTICE.md)。以下是静态代码证据；没有把未复现的客户端现象称为已修复。

| 上游路径 | 确认问题 | LiSkills 处理 |
| --- | --- | --- |
| `common/.../skill/SkillLoader.java:52-59,90-93` | 先注销注册内容，再读 YAML；非法 YAML 失败时没有还原 | 临时解析七份配置，全部合法才替换快照；真实 Paper 故障注入验证 |
| `bukkit/.../commands/XpCommand.java:50-75`、`common/.../level/LevelManager.java` | 部分经验入口未拒绝负数与非有限数，可能污染经验 | 管理入口、API、自然经验和纯数值结算统一校验；负数/NaN/Infinity/溢出回归 |
| `common/.../storage/file/FileStorageProvider.java:405-422` | 自动保存重复追加完整会话反挂机日志 | 新版不继承原日志存储，档案写完整不可变快照；重复保存回归 |
| `common/.../storage/sql/SqlStorageProvider.java:524-541` | 被动 ability map 为空时提前返回，跳过独立主动冷却 | 冷却独立序列化，不依赖技能/被动数据是否为空；空技能+冷却回归 |
| `bukkit/.../AuraSkills.java:onDisable` | 提前启用失败可能在停用阶段访问未初始化管理器 | 空安全生命周期，启动失败只关闭已装配服务 |

本版并未移植原版全部功能，因此不能声称修复了上游全部 bug。用户具体遭遇的错误还需要日志、复现操作和对应运行环境进一步核对。
