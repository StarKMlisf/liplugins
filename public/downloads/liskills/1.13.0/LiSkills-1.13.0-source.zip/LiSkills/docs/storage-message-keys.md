# 存储消息增补

将首个YAML块按缺项合并到messages.yml；已有管理员文本不覆盖。SQL密码不会写入异常文本；请不要公开包含账户或主机的管理日志。

```yaml
# 存储和固定摘要驱动提示；全部经过统一MiniMessage/TextService处理。
storage:
  # 正在下载固定版本驱动；{library}为文件名。
  driver-downloading: '正在下载技能存储依赖 {library}，完成SHA-256校验后才加载。'
  # 已缓存文件摘要不符；会重新下载，不直接加载未知Jar。
  driver-invalid: '技能存储依赖 {library} 的摘要不符，正在重新下载。'
  # 初始化失败；{error}为不含密码的诊断，技能系统必须拒绝启动，不回退空YAML。
  initialization-failed: '技能存储初始化失败：{error}。未切换后端、未覆盖原玩家数据，请修复配置或连接后重启。'
  # 启动时发现旧会话未确认写入的恢复快照；{count}为需要人工检查的人数。
  recovery-pending: '发现 {count} 份未处理的技能恢复快照；这些玩家暂不加载，请检查recovery目录。'
  # 乐观版本冲突；{player}为UUID，{error}为原因，不会自动覆盖数据库。
  version-conflict: '玩家 {player} 的技能存档发生版本冲突：{error}；已停止使用该档案并保留recovery，必须人工核对。'
  # 待恢复数据也无法落盘；必须修复磁盘/权限，不要立刻杀掉Java进程。
  recovery-write-failed: '玩家 {player} 的技能恢复快照写入失败：{error}；请立即检查磁盘和权限，暂勿强制停止Java。'
  # SQL会话重新获得独占权且一次版本核对保存已成功。
  connection-restored: '技能存储连接已恢复并完成版本核对；无冲突的档案恢复使用。'
  # 连接或驱动关闭失败；{error}为原因。
  close-failed: '技能存储资源关闭失败：{error}。'
  # 完整停服等待超时；{seconds}来自storage.yml，待保存快照已尽可能先保全到recovery。
  shutdown-timeout: '技能数据保存超过 {seconds} 秒，请检查recovery与存储连接，不要立即强制终止Java进程。'
```
