# 准备隔离验证环境

这份说明用于开发验收，不是正式服安装教程。源码包能按[依赖与构建说明](DEPENDENCIES.md)构建插件，但完整Paper/SQL探针还需要下面的外部环境。脚本保留本次开发机的路径，**不是下载源码后一键可用的通用安装器**；换机器后须先检查路径和依赖，不得直接针对正式服运行。

## 工具与本机路径

本次环境为Windows、JDK 25、Python 3、Node.js及`minecraft-protocol` 1.66.2。实际协议库的Node要求为22或以上。插件构建不需要Node；协议客户端验收才需要它。PowerShell测试脚本使用`Get-NetTCPConnection`和Windows可执行文件名，不能不作调整直接在Linux运行。

| 文件/设置 | 当前本机值或行为 | 换机时需要处理 |
| --- | --- | --- |
| `build.ps1` | 支持`-JavaHome`和`-MavenHome`，无Maven时可联网下载固定版本 | 先按构建文档准备JDK 25；首次不能假定已有离线缓存 |
| `tools/run-verification.ps1`的`$verificationJava` | `C:/Program Files/Eclipse Adoptium/jdk-25.0.3.9-hotspot/bin/java.exe` | 改为本机JDK 25的`java.exe` |
| 同文件的`$verificationPython` | `C:/Users/kmian/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe` | 改为本机Python 3解释器 |
| `tools/prepare-probe.ps1`的`$jdk` | 上述JDK的`bin`目录 | 改为本机同一JDK，需含`javac.exe`与`jar.exe` |
| `tools/runtime-smoke.py`首个位置参数 | 显式Java路径；省略时仍使用上述开发机默认 | 单独调用时传入自己的Java路径 |
| `LISKILLS_QA_NODE` | 未设置时指向开发机Codex缓存中的Node | 设置为本机Node 22或以上可执行文件的绝对路径 |
| `LISKILLS_QA_PACKAGE` | 默认指向`C:/Users/kmian/Desktop/LiRealEnchant/qa/package.json` | 设置为专用QA目录的`package.json`绝对路径，不是`node_modules`目录或依赖包的`package.json` |
| `tools/run-verification.ps1`中的LRE `Copy-Item`源路径 | 开发机`Desktop/LiRealEnchant/build/libs/` | 改为自己合法取得的dev201插件Jar；不要改成正式服数据目录 |

在一个独立QA目录按自己的Node/npm环境安装**精确版本**`minecraft-protocol@1.66.2`，保留生成的`package.json`、锁文件及对应`node_modules`。客户端以该`package.json`建立模块查找路径。源码包不附带这份外部QA目录、锁文件或Node依赖，也不自动安装它们；本次用的QA目录来自自家附魔项目。

例如先安装并确认依赖后，在运行验证的同一个PowerShell会话设置自己的路径：

```powershell
$env:LISKILLS_QA_NODE = 'C:\verification-tools\node\node.exe'
$env:LISKILLS_QA_PACKAGE = 'C:\verification-tools\liskills-qa\package.json'
$env:LISKILLS_QA_HOST = '127.0.0.1'
$env:LISKILLS_QA_PORT = '25681'
```

这是环境变量示例，不会替你安装Node或协议依赖。只有回环主机可被客户端接受。端口需与隔离服一致；完整验证入口还有固定25681端口检查，不能只改客户端变量就假定整个工具链已切换端口。

## Paper目录与EULA

1. 使用一个没有正式玩家数据的项目副本。在项目`target/runtime-paper/`准备全新的测试服务端，主Jar命名为`paper.jar`。本次验收基准为**Paper 26.1.2 build74**，实际API交叉检查也默认查找该版本生成的库目录。
2. 从合法官方渠道取得Paper及其启动依赖。首次启动可能需要网络准备库；文档和源码包不包含服务端Jar、世界、账号、插件运行目录或下载缓存。
3. **由运行者本人阅读并决定是否接受Minecraft EULA。** 只有接受后才自行配置测试目录的`eula.txt`。本项目不替你接受协议，也不把本机已有的接受状态作为你的授权。
4. 准备`target/runtime-paper/plugins/`并让测试服生成自己的配置与新世界。确认服务端已停止、25681没有被其他进程占用，再运行探针工具。不要把该目录链接或映射到正式服。

下面是本次隔离服使用的相关`server.properties`值，仅供核对。**离线认证只允许用于回环隔离测试，不能对外开放、端口转发或放到公网主机上直接复用。**

```properties
# 只绑定本机回环地址；验证端口不可被其他服务占用。
server-ip=127.0.0.1
server-port=25681
# 协议测试账号LiSkillsQa使用离线认证；绝不能用于对外开放的服务器。
online-mode=false
enforce-secure-profile=true
# 不启用额外远程管理或查询入口。
enable-rcon=false
enable-query=false
# 本次探针使用生存/简单难度和独立世界，出生保护设为0。
gamemode=survival
difficulty=easy
level-name=world
spawn-protection=0
white-list=false
# 较小测试视距；来源探针会显式加载自己的测试区块。
view-distance=2
simulation-distance=2
```

不要同时安装重复加经验、加属性的旧技能插件；LiSkills检测到冲突会拒绝启动。不要添加与本轮验收无关的正式服插件、生产数据库配置、玩家存档或资源包。部分探针会临时修改本隔离服配置、库存、方块与测试资料，并在结束时关闭该测试服；不能把它们放进玩家服务器。

## 第三方验证依赖

编译和运行两类依赖要分开。正常插件构建会把公共API复制到项目`lib/api/`；附魔公开API位于`lib/LiRealEnchantAPI-2.0.0-dev201.jar`。**API Jar不能当成服务端附魔插件安装。**

| 验证对象 | 需要的文件/位置 |
| --- | --- |
| 自家附魔共存 | 合法取得的`LiRealEnchant2-2.0.0-dev201-paper26.jar`；调整验证脚本的复制源路径 |
| 自定义作物 | `lib/verification-dependencies/CustomCrops-3.6.54.jar` |
| 自定义钓鱼 | `lib/verification-dependencies/CustomFishing-2.3.26.jar` |

CC/CF商业插件和附魔实现不随本次LiSkills源码/安装包分发，不由LiSkills自动下载。运行者需自行取得许可、依赖与必要的合法测试配置，并按这些插件的说明确认能在隔离服正常加载。发行验证会核对本次使用的精确Jar摘要；同版本名称但内容不同也不能冒充原证据。具体摘要见最终结果JSON。

`run-verification.ps1`会按组把上述测试插件复制到隔离服，并把暂不使用的测试Jar移至项目`target/probes/inactive/`。`prepare-probe.ps1`只负责编译探针与放置测试Jar，不替你准备Paper、EULA、世界或商业插件环境。

准备完成后才运行`tools/run-verification.ps1`。这些步骤是当前脚本的运行前提，不保证任意机器、任意依赖组合无需调整即可通过。运行结果以该次实际生成的JSON、日志及最终Jar哈希为准；协议客户端验收也不等于真人完整操作或视觉验收。

## HUD 与停用后生命恢复验证

1.12.0 新增 `tools/run-hud-health-verification.py`，使用上面已准备的同一个回环隔离服，不能与其他探针同时运行。先构建目标 Jar，再调用：

```text
python tools/run-hud-health-verification.py --java-home <JDK25目录> --node <Node可执行文件>
```

脚本独立编译只引用 Bukkit 的探针。第一阶段加载目标 LiSkills Jar，协议玩家检查 HUD、个人偏好、真实退出重连和停用后的属性；在 `disablePlugin` 返回时立即复制已经落盘的玩家存档，探针不额外替插件保存这次清理结果。第二阶段移走 LiSkills Jar，用这个即时快照启动同一隔离服，验证没有插件时的生命上限与外部加成。

运行会临时移动这个测试目录中的 LiSkills 开发 Jar，备份并恢复测试玩家和配置；结束后原 Jar 恢复。不会启动正式服、批量改离线玩家或自动接受 EULA。输出在 `target/hud-health-版本-时间-标识/result.json`，包含两个阶段的检查、协议连接退出码和被测 Jar SHA-256。此验证不覆盖崩溃/断电，也不替代真人 HUD 视觉验收。

1.12.0 打包命令为 `python tools/package-legacy-release.py --hud-health-result <上述result.json>`；1.13.0 还必须提供下面的 Folia 结果。打包同时要求五组常规探针、单元测试与 Paper API 交叉编译通过，且全部运行证据指向同一 Jar。安装包只收录 JSON 检查，不携带测试玩家 NBT。

## Folia 双区域与无插件重启验证

1.13.0 使用 `target/runtime-folia-26.2/` 全新隔离世界，只监听 `127.0.0.1:28763`。不要复制正式世界、角色、插件配置或凭据。先从本机已经合法取得、明确接受 EULA 的 Folia 26.2 测试运行目录准备二进制依赖：

```text
python tools/prepare-folia-runtime.py --source <已准备的Folia26.2运行目录>
```

准备器只复制核心、依赖库和已有 EULA 文件，不自动接受协议，也不修改源目录。目标已经存在则拒绝覆盖。本次使用 Folia 26.2 build 1 e48800d，Shiroha 同构建没有取得，不能将此结果写成 Shiroha 精确构建验收。

使用本次服务端 API 及其配套 Adventure 5.2.0 再编译生产源码，附加 API 同样复制到项目 `lib/verification-api/`，不会打进成品：

```powershell
$foliaExtraApis = @(Get-ChildItem target/runtime-folia-26.2/libraries/net/kyori -Recurse -Filter '*.jar' -File |
    Where-Object { $_.Directory.Name -eq '5.2.0' } | ForEach-Object FullName)
.\tools\check-paper-api.ps1 -PaperApiSource 'target/runtime-folia-26.2/libraries/dev/folia/folia-api/26.2.build.1-beta/folia-api-26.2.build.1-beta.jar' -AdditionalApiJars $foliaExtraApis -AuditName folia-api-audit
python tools/run-folia-verification.py
```

运行器从实际核心生成协议包编号，使用只允许本机 28763 端口及两个固定 QA 用户的 26.2 协议客户端。两名玩家相隔 4096 格，验证实体线程、全局/跨区 API 拒绝、菜单、HUD、自然经验、主动技能和真实退出重连。读取启用时保存的原生 NBT，确认本插件临时属性未持久化；随后移走 LiSkills，用启用时的原始快照重启，检查基础 30 + 外部 4 = 34 的生命上限。

第二阶段不会通过调用插件清理来修正快照。运行器在退出后恢复测试 Jar 和原始玩家数据；探针、协议提取器使用的 NMS 仅属于验证工具，不进入生产源码或插件 Jar。真人 HUD 视觉、长期多人和商业插件的 Folia 组合另行验收。

```text
python tools/package-legacy-release.py --hud-health-result <Paper两阶段result.json> --folia-result <Folia两阶段result.json>
```

输出位于 `target/folia-版本-时间-标识/`。最终打包必须同时核对两个平台结果与 API 交叉编译记录都指向当前 Jar SHA-256；不得把先前试验的通过记录用于后来重新构建的 Jar。

## 独立SQL与迁移验证

SQL探针不启动Minecraft，但需要已构建的目标Jar、项目`lib/api/`、JDK 25，以及`lib/storage-api/`中的固定版本驱动。驱动文件名、来源策略与SHA-256见[存储说明](AURA-STORAGE.md)。探针先从该开发目录复制驱动，**不会替你准备缺失的开发驱动缓存**。

MySQL需由运行者另行准备全新隔离实例及数据库。本次使用MySQL 8.0.45、`127.0.0.1:33317`、专用`liskills_probe`数据库；探针固定回环地址并拒绝3306，使用随机测试表前缀。脚本不启动/停止MySQL服务，也不为你创建数据库，绝不能指向生产实例。隔离夹具使用root账户，空密码是本机临时测试配置；若该隔离账户设了密码，通过`LISKILLS_PROBE_MYSQL_PASSWORD`传入，不能据此为生产root配置空密码或对外开放。

环境准备并核对后，使用本机Python 3调用：

```text
python tools/run-storage-verification.py <JDK25的java.exe绝对路径> 33317 liskills_probe
```

脚本会编译两份验证探针，依次运行Storage/Migration在SQLite/MySQL的四组检查；每组创建新的`target/storage-verification/...`目录。Storage驱动缓存位于该组目录的`lib/`，Migration位于`drivers/`。结果JSON同时记录实际驱动目录、文件SHA-256、期望摘要和校验结果；缺少必需驱动或摘要不同，即使探针打印PASS也不能让该组通过。

输出包括`target/Storage-*-result.json`、`target/Migration-*-result.json`、console日志以及各组目录中的PASS/FAIL与CLI日志。不要手动把旧证据复制成新版本结果；最终发行脚本还会核对每组记录指向同一个目标Jar。测试数据只属于这些明确的隔离目录，源码交付不会携带它们。
