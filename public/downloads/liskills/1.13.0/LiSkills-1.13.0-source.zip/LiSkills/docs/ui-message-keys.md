# 命令与菜单消息键

以下键由命令与菜单模块读取；所有显示文本均支持 MiniMessage。列表键由 `TextService` 的列表接口渲染。占位符只放入插件自身数字、配置名称或 Bukkit 玩家名称。

```yml
command:
  no-permission: '<red>你没有权限执行此操作。</red>'
  player-only: '<yellow>此指令只能由游戏内玩家执行。</yellow>'
  player-not-found: '<red>没有找到在线玩家：{player}。</red>'
  profile-loading: '<yellow>玩家数据尚未载入，请稍后重试。</yellow>'
  unknown-skill: '<red>未知技能：{skill}。可输入 /lsk sources 后按 Tab 查看技能。</red>'
  unknown-subcommand: '<yellow>未知指令，请输入 /lsk help 查看帮助。</yellow>'
  invalid-number: '<red>请输入范围内的有效数字；不能为负数、NaN 或 Infinity。</red>'
  invalid-set-xp: '<red>设置的本级经验必须小于升往下一级所需经验；满级时只能设为 0。需要增加经验并自动升级请使用 xp add。</red>'
  usage: '<yellow>用法：{usage}</yellow>'
  usage-stats: '/lsk stats [玩家]'
  usage-sources: '/lsk sources [技能]'
  usage-cast: '/lsk cast [技能]'
  usage-reload: '/lsk reload'
  usage-validate: '/lsk validate'
  usage-xp: '/lsk xp add|set [在线玩家] [技能] [数量]'
  usage-level: '/lsk level set [在线玩家] [技能] [等级]'
  registration-failed: '<red>无法注册 liskills 指令，请检查 plugin.yml。</red>'
  help-title: '<gradient:#67E8F9:#A78BFA>LiSkills 技能帮助</gradient>'
  help-player:
    - '<gray>/lsk <white>打开技能面板</white></gray>'
    - '<gray>/lsk stats [玩家] <white>查看技能等级和经验</white></gray>'
    - '<gray>/lsk mana [玩家] <white>查看当前魔力与上限</white></gray>'
    - '<gray>/lsk sources <技能> <white>查看经验来源</white></gray>'
    - '<gray>/lsk cast <技能> <white>释放该技能的主动能力</white></gray>'
  help-admin:
    - '<gray>/lsk reload <white>重载配置</white></gray>'
    - '<gray>/lsk validate <white>检查配置与依赖状态</white></gray>'
    - '<gray>/lsk xp add [玩家] [技能] [数量] <white>增加经验并自动升级</white></gray>'
    - '<gray>/lsk xp set [玩家] [技能] [数量] <white>设置本级经验，不改变等级</white></gray>'
    - '<gray>/lsk level set [玩家] [技能] [等级] <white>设置技能等级，本级经验归零</white></gray>'
  stats-title: '<aqua>{player}</aqua><gray> 的技能 · 总等级 </gray><yellow>{total}</yellow>'
  stats-line: '<aqua>{skill}</aqua><gray>：等级 </gray><yellow>{level}</yellow><gray> / {max} · 本级经验 {xp} / {required}</gray>'
  sources-title: '{skill}<gray> 的经验来源</gray>'
  sources-line: '<gray>• </gray><white>{source}</white><gray>：</gray><green>+{xp} 经验</green>'
  sources-empty: '<gray>此技能尚未配置经验来源。</gray>'
  sources-note: '<gray>经验受权限、游戏模式、世界和防刷配置限制；多人服务器请保留默认防刷选项。</gray>'
  reload-success: '<green>配置已重载。</green>'
  reload-failed: '<red>配置重载失败；请查看控制台中的配置检查结果。</red>'
  validate-title: '<aqua>LiSkills 配置与运行状态检查</aqua>'
  validate-ok: '<green>未发现配置问题。</green>'
  validate-line: '<gray>• </gray>{detail}'
  xp-updated: '<green>已更新 {player} 的 {skill}：等级 {level}，本级经验 {xp} / {required}。</green>'
  level-updated: '<green>已设置 {player} 的 {skill} 等级为 {level}，本级经验已归零。</green>'
menu:
  title: '<dark_aqua>技能面板</dark_aqua><gray> · {player}</gray>'
  skill-name: '<aqua>{skill}</aqua> <gray>·</gray> <yellow>等级 {level}</yellow>'
  skill-lore:
    - '<gray>{description}</gray>'
    - ''
    - '<gray>本级经验：</gray><green>{xp}</green><gray> / {required}</gray>'
    - '<gray>最高等级：</gray><white>{max}</white>'
    - '<gray>主动技能：</gray><aqua>{ability}</aqua>'
    - '<gray>当前状态：</gray><white>{ability_status}</white>'
    - ''
    - '<gray>魔力消耗：</gray><aqua>{mana_cost}</aqua>'
    - '<yellow>左键：打开技能详情与经验来源</yellow>'
    - '<green>右键：释放主动技能</green>'
  info-name: '<aqua>我的技能概况</aqua>'
  info-lore:
    - '<gray>玩家：</gray><white>{player}</white>'
    - '<gray>总等级：</gray><yellow>{total}</yellow>'
    - '<gray>魔力：</gray><aqua>{mana}</aqua><gray> / {max_mana}</gray>'
    - '<dark_gray>{mana_state}</dark_gray>'
    - '<gray>数据自动保存；管理员可用 /lsk validate 检查配置。</gray>'
  close-name: '<red>关闭面板</red>'
  close-lore:
    - '<gray>点击关闭此界面。</gray>'
  filler-name: ' '
  no-ability: '无主动技能'
  ability-locked: '等级 {level} 解锁'
  ability-cooldown: '冷却剩余 {seconds} 秒'
  ability-ready: '可释放，效果持续 {seconds} 秒'
  ability-active: '生效中，剩余 {seconds} 秒'
  ability-needs-mana: '需先开启服务器魔力系统'
  ability-mana: '魔力不足：当前 {mana}，需要 {cost}'
  mana-enabled: '魔力会自动恢复；炼金与附魔成长可提高上限。'
  mana-disabled: '服务器已关闭魔力系统，释放技能不消耗魔力。'
  sound-invalid: '<yellow>菜单音效 {sound} 无效，已跳过播放；请检查 menu.yml。</yellow>'
  details:
    title: '<dark_aqua>{skill}</dark_aqua><gray> · 技能详情 {page}/{pages}</gray>'
    summary-name: '<gradient:#67E8F9:#A78BFA>{skill}</gradient> <yellow>等级 {level}</yellow>'
    summary-lore:
      - '<gray>{description}</gray>'
      - ''
      - '<gray>等级：</gray><yellow>{level}</yellow><gray> / {max}</gray>'
      - '<gray>本级经验：</gray><green>{xp}</green><gray> / {required}</gray>'
      - '<gray>魔力：</gray><aqua>{mana}</aqua><gray> / {max_mana}</gray>'
      - '<dark_gray>{mana_state}</dark_gray>'
      - ''
      - '<gray>下方图标展示本技能的全部经验来源。</gray>'
    ability-name: '<aqua>主动能力</aqua><gray> · </gray><white>{ability}</white>'
    ability-lore:
      - '<gray>状态：</gray><white>{ability_status}</white>'
      - '<gray>解锁等级：</gray><yellow>{unlock_level}</yellow>'
      - '<gray>魔力消耗：</gray><aqua>{mana_cost}</aqua>'
      - '<gray>当前魔力：</gray><aqua>{mana}</aqua><gray> / {max_mana}</gray>'
      - '<dark_gray>{mana_state}</dark_gray>'
      - '<gray>持续时间：</gray><white>{duration} 秒</white>'
      - '<gray>释放间隔：</gray><white>{cooldown} 秒</white>'
      - ''
      - '<green>点击尝试释放；失败不会扣除魔力。</green>'
      - '<dark_gray>魔力和冷却每秒自动更新。</dark_gray>'
    source-name: '<white>{source}</white><gray> · </gray><green>+{xp} 经验</green>'
    source-lore:
      - '<gray>来源类型：</gray><aqua>{source_kind}</aqua>'
      - '<gray>每次基础经验：</gray><green>{xp}</green>'
      - '<dark_gray>经验倍率、权限、世界与防刷限制仍会生效。</dark_gray>'
    kind-block: '采集方块'
    kind-item: '钓鱼物品'
    kind-mob: '生物击杀'
    kind-event: '有效事件'
    kind-custom-crop: 'CustomCrops成熟收获'
    kind-custom-fish: 'CustomFishing成功钓获'
    empty-name: '<gray>暂无经验来源</gray>'
    empty-lore:
      - '<gray>该技能尚未配置可用的经验来源。</gray>'
      - '<gray>管理员可检查 skills.yml 中对应技能。</gray>'
    previous-name: '<yellow>上一页</yellow>'
    previous-lore:
      - '<gray>查看前一页经验来源。</gray>'
    no-previous-name: '<dark_gray>已经是第一页</dark_gray>'
    no-previous-lore:
      - '<gray>当前页 {page} / {pages}。</gray>'
    next-name: '<yellow>下一页</yellow>'
    next-lore:
      - '<gray>查看后一页经验来源。</gray>'
    no-next-name: '<dark_gray>已经是最后一页</dark_gray>'
    no-next-lore:
      - '<gray>当前页 {page} / {pages}。</gray>'
    page-name: '<aqua>经验来源</aqua><gray> · 第 {page} / {pages} 页</gray>'
    page-lore:
      - '<gray>本技能共有 </gray><white>{sources}</white><gray> 条经验来源。</gray>'
      - '<gray>使用两侧箭头浏览，不会改变技能数据。</gray>'
    back-name: '<aqua>返回技能总览</aqua>'
    back-lore:
      - '<gray>继续查看其他技能及成长进度。</gray>'
      - '<yellow>点击返回上一级。</yellow>'
    refresh-name: '<green>刷新当前页面</green>'
    refresh-lore:
      - '<gray>重新读取经验、魔力、冷却及来源配置。</gray>'
      - '<dark_gray>魔力和冷却无需关闭界面即可自动更新。</dark_gray>'
hook:
  available: '可用'
  detected: '插件已启用（扩展状态见启动日志）'
  unavailable: '未安装或未启用'
  failed: '连接失败'
  vault-status: '<gray>Vault：{state}；经济奖励未启用。</gray>'
  placeholderapi-status: '<gray>PlaceholderAPI：{state}。</gray>'
  placeholderapi-failed: '<yellow>PlaceholderAPI 扩展连接失败，技能功能仍可继续使用。</yellow>'
  placeholderapi-unregister-failed: '<yellow>PlaceholderAPI 扩展注销失败，请完整重启服务器后再次检查。</yellow>'
```

## PAPI 占位符

* `%liskills_level_<技能ID>%`：技能等级。
* `%liskills_xp_<技能ID>%`：本级已获得经验。
* `%liskills_progress_<技能ID>%`：本级已获得经验。
* `%liskills_total_xp_<技能ID>%`：按当前经验曲线折算的累计经验，不代表历史实际获得经验；修改经验曲线后数值会随之改变。
* `%liskills_required_<技能ID>%`：本级升往下一级所需经验。
* `%liskills_total_level%`：总技能等级。

仅查询已载入的在线玩家档案；档案未加载、离线或技能不存在时返回 `0`，未知占位符返回 `null` 交还 PAPI。不触发同步磁盘读取。

## menu.yml 默认布局与来源名称

下面是 `menu.yml`，与 `messages.yml` 的 `menu:` 文本节不同。槽位均从 0 开始；技能槽位不得与信息或关闭按钮重叠，尺寸取 `27/36/45/54`。使用者新增材料或生物经验来源时，可在来源名称映射中新增其中文名称；没有映射则显示 Bukkit ID，方便对照配置。菜单信息、关闭图标依次为玩家头颅和屏障。

```yml
# 菜单格数；取 27、36、45、54。
size: 54
# 技能按钮位置；0 到 size-1 的不重复整数列表，按 skills.yml 的技能顺序排列。
skill-slots: [10, 11, 12, 13, 14, 15, 16, 20, 21, 23, 24]
# 信息按钮位置；0 到 size-1，不得与其他按钮重叠。
info-slot: 49
# 关闭按钮位置；0 到 size-1，不得与其他按钮重叠。
close-slot: 53
# 是否填充其他空格；true/false。
fill: true
# 填充材料；任意非空气 Bukkit 物品材料 ID。
filler-material: GRAY_STAINED_GLASS_PANE
# 主面板固定按钮的图标；每项为非空气 Bukkit 物品材料 ID。
icons:
  # 我的概况按钮；可使用 PLAYER_HEAD、BOOK 等物品材料。
  info: PLAYER_HEAD
  # 关闭按钮；可使用 BARRIER 等物品材料。
  close: BARRIER
# 独立技能详情页；所有槽位从 0 开始，按钮之间及来源格之间不得重叠。
details:
  # 详情页格数；取 27、36、45、54。
  size: 54
  # 成长摘要图标位置；0 至 size-1，图标沿用 skills.yml 的技能 icon。
  summary-slot: 4
  # 主动能力按钮位置；0 至 size-1。
  ability-slot: 49
  # 每页来源格；非空且不重复的整数列表，0 至 size-1，数量决定分页大小。
  source-slots: [19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34, 37, 38, 39, 40, 41, 42, 43]
  # 上一页按钮位置；0 至 size-1。
  previous-slot: 45
  # 页码与来源数量位置；0 至 size-1。
  page-slot: 46
  # 返回总览按钮位置；0 至 size-1。
  back-slot: 48
  # 刷新当前页按钮位置；0 至 size-1。
  refresh-slot: 50
  # 下一页按钮位置；0 至 size-1。
  next-slot: 53
  # 详情页按钮及来源备用图标；每项为非空气 Bukkit 物品材料 ID。
  icons:
    # 主动能力图标；可用 BLAZE_POWDER 等物品材料。
    ability: BLAZE_POWDER
    # 上一页图标；可用 ARROW 等物品材料。
    previous: ARROW
    # 页码图标；可用 PAPER 等物品材料。
    page: PAPER
    # 返回总览图标；可用 OAK_DOOR 等物品材料。
    back: OAK_DOOR
    # 刷新图标；可用 CLOCK 等物品材料。
    refresh: CLOCK
    # 下一页图标；可用 ARROW 等物品材料。
    next: ARROW
    # 空来源提示图标；可用 BARRIER 等物品材料。
    empty: BARRIER
    # 通用事件来源图标；可用 EXPERIENCE_BOTTLE 等物品材料。
    event: EXPERIENCE_BOTTLE
    # 没有对应刷怪蛋的生物来源备用图标；可用 BONE 等物品材料。
    mob-fallback: BONE
    # 没有对应物品形态的材料来源备用图标；可用 PAPER 等物品材料。
    source-fallback: PAPER
# 统一界面音效；每次导航仅播放一个反馈，不叠加页面切换产生的关闭音。
sounds:
  # 全局音效开关；true 播放，false 静音。
  enabled: true
  # 首次打开总览的反馈音。
  open:
    # Bukkit Sound 名称；须为服务器支持的音效。
    sound: BLOCK_ENDER_CHEST_OPEN
    # 音量；有限数字 0-2，0 为静音。
    volume: 0.3
    # 音调；有限数字 0.5-2。
    pitch: 1.3
  # 打开详情、返回和手动刷新的反馈音。
  click:
    # Bukkit Sound 名称；须为服务器支持的音效。
    sound: UI_BUTTON_CLICK
    # 音量；有限数字 0-2，0 为静音。
    volume: 0.3
    # 音调；有限数字 0.5-2。
    pitch: 1.2
  # 来源翻页的反馈音。
  page:
    # Bukkit Sound 名称；须为服务器支持的音效。
    sound: ITEM_BOOK_PAGE_TURN
    # 音量；有限数字 0-2，0 为静音。
    volume: 0.35
    # 音调；有限数字 0.5-2。
    pitch: 1.1
  # 玩家关闭界面的反馈音；内部页面切换不播放。
  close:
    # Bukkit Sound 名称；须为服务器支持的音效。
    sound: BLOCK_ENDER_CHEST_CLOSE
    # 音量；有限数字 0-2，0 为静音。
    volume: 0.25
    # 音调；有限数字 0.5-2。
    pitch: 1.3
  # 从界面成功释放主动能力的反馈音。
  success:
    # Bukkit Sound 名称；须为服务器支持的音效。
    sound: ENTITY_EXPERIENCE_ORB_PICKUP
    # 音量；有限数字 0-2，0 为静音。
    volume: 0.4
    # 音调；有限数字 0.5-2。
    pitch: 1.2
  # 界面操作因等级、冷却或魔力等原因失败的反馈音。
  deny:
    # Bukkit Sound 名称；须为服务器支持的音效。
    sound: BLOCK_NOTE_BLOCK_BASS
    # 音量；有限数字 0-2，0 为静音。
    volume: 0.3
    # 音调；有限数字 0.5-2。
    pitch: 0.8
# 经验来源中文名称；键为 Bukkit ID，值为支持 MiniMessage 的名称文本。
source-names:
  # 材料显示名；钓鱼技能表示钓起的物品，其他技能表示破坏的方块。
  materials:
    WHEAT: 小麦
    CARROTS: 胡萝卜
    POTATOES: 马铃薯
    BEETROOTS: 甜菜
    NETHER_WART: 下界疣
    COCOA: 可可豆
    MELON: 西瓜
    PUMPKIN: 南瓜
    SUGAR_CANE: 甘蔗
    CACTUS: 仙人掌
    BAMBOO: 竹子
    SWEET_BERRY_BUSH: 甜浆果丛
    OAK_LOG: 橡木原木
    SPRUCE_LOG: 云杉原木
    BIRCH_LOG: 白桦原木
    JUNGLE_LOG: 丛林原木
    ACACIA_LOG: 金合欢原木
    DARK_OAK_LOG: 深色橡木原木
    MANGROVE_LOG: 红树原木
    CHERRY_LOG: 樱花原木
    PALE_OAK_LOG: 苍白橡木原木
    CRIMSON_STEM: 绯红菌柄
    WARPED_STEM: 诡异菌柄
    STONE: 石头
    DEEPSLATE: 深板岩
    COAL_ORE: 煤矿石
    DEEPSLATE_COAL_ORE: 深层煤矿石
    COPPER_ORE: 铜矿石
    DEEPSLATE_COPPER_ORE: 深层铜矿石
    IRON_ORE: 铁矿石
    DEEPSLATE_IRON_ORE: 深层铁矿石
    GOLD_ORE: 金矿石
    DEEPSLATE_GOLD_ORE: 深层金矿石
    REDSTONE_ORE: 红石矿石
    DEEPSLATE_REDSTONE_ORE: 深层红石矿石
    LAPIS_ORE: 青金石矿石
    DEEPSLATE_LAPIS_ORE: 深层青金石矿石
    DIAMOND_ORE: 钻石矿石
    DEEPSLATE_DIAMOND_ORE: 深层钻石矿石
    EMERALD_ORE: 绿宝石矿石
    DEEPSLATE_EMERALD_ORE: 深层绿宝石矿石
    NETHER_QUARTZ_ORE: 下界石英矿石
    NETHER_GOLD_ORE: 下界金矿石
    ANCIENT_DEBRIS: 远古残骸
    DIRT: 泥土
    GRASS_BLOCK: 草方块
    COARSE_DIRT: 砂土
    ROOTED_DIRT: 缠根泥土
    SAND: 沙子
    RED_SAND: 红沙
    GRAVEL: 沙砾
    CLAY: 黏土
    SOUL_SAND: 灵魂沙
    SOUL_SOIL: 灵魂土
    SNOW_BLOCK: 雪块
    COD: 生鳕鱼
    SALMON: 生鲑鱼
    TROPICAL_FISH: 热带鱼
    PUFFERFISH: 河豚
    ENCHANTED_BOOK: 附魔书
    BOW: 弓
    FISHING_ROD: 钓鱼竿
    NAUTILUS_SHELL: 鹦鹉螺壳
    NAME_TAG: 命名牌
    SADDLE: 鞍
    # ACACIA_LEAVES 的来源显示名；可自定义中文文本。
    ACACIA_LEAVES: 金合欢树叶
    # AMETHYST_BLOCK 的来源显示名；可自定义中文文本。
    AMETHYST_BLOCK: 紫水晶块
    # AMETHYST_CLUSTER 的来源显示名；可自定义中文文本。
    AMETHYST_CLUSTER: 紫水晶簇
    # ANDESITE 的来源显示名；可自定义中文文本。
    ANDESITE: 安山岩
    # AZALEA 的来源显示名；可自定义中文文本。
    AZALEA: 杜鹃花丛
    # AZALEA_LEAVES 的来源显示名；可自定义中文文本。
    AZALEA_LEAVES: 杜鹃树叶
    # BASALT 的来源显示名；可自定义中文文本。
    BASALT: 玄武岩
    # BIRCH_LEAVES 的来源显示名；可自定义中文文本。
    BIRCH_LEAVES: 白桦树叶
    # BLACKSTONE 的来源显示名；可自定义中文文本。
    BLACKSTONE: 黑石
    # BLUE_ICE 的来源显示名；可自定义中文文本。
    BLUE_ICE: 蓝冰
    # BROWN_MUSHROOM 的来源显示名；可自定义中文文本。
    BROWN_MUSHROOM: 棕色蘑菇
    # BROWN_MUSHROOM_BLOCK 的来源显示名；可自定义中文文本。
    BROWN_MUSHROOM_BLOCK: 棕色蘑菇方块
    # BROWN_TERRACOTTA 的来源显示名；可自定义中文文本。
    BROWN_TERRACOTTA: 棕色陶瓦
    # CALCITE 的来源显示名；可自定义中文文本。
    CALCITE: 方解石
    # CAVE_VINES 的来源显示名；可自定义中文文本。
    CAVE_VINES: 洞穴藤蔓
    # CAVE_VINES_PLANT 的来源显示名；可自定义中文文本。
    CAVE_VINES_PLANT: 洞穴藤蔓植株
    # CHERRY_LEAVES 的来源显示名；可自定义中文文本。
    CHERRY_LEAVES: 樱花树叶
    # COBBLESTONE 的来源显示名；可自定义中文文本。
    COBBLESTONE: 圆石
    # CREAKING_HEART 的来源显示名；可自定义中文文本。
    CREAKING_HEART: 嘎枝之心
    # DARK_OAK_LEAVES 的来源显示名；可自定义中文文本。
    DARK_OAK_LEAVES: 深色橡树树叶
    # DIORITE 的来源显示名；可自定义中文文本。
    DIORITE: 闪长岩
    # DRIPSTONE_BLOCK 的来源显示名；可自定义中文文本。
    DRIPSTONE_BLOCK: 滴水石块
    # END_STONE 的来源显示名；可自定义中文文本。
    END_STONE: 末地石
    # FLOWERING_AZALEA 的来源显示名；可自定义中文文本。
    FLOWERING_AZALEA: 盛开的杜鹃花丛
    # FLOWERING_AZALEA_LEAVES 的来源显示名；可自定义中文文本。
    FLOWERING_AZALEA_LEAVES: 盛开的杜鹃树叶
    # GRANITE 的来源显示名；可自定义中文文本。
    GRANITE: 花岗岩
    # ICE 的来源显示名；可自定义中文文本。
    ICE: 冰
    # JUNGLE_LEAVES 的来源显示名；可自定义中文文本。
    JUNGLE_LEAVES: 丛林树叶
    # KELP 的来源显示名；可自定义中文文本。
    KELP: 海带
    # KELP_PLANT 的来源显示名；可自定义中文文本。
    KELP_PLANT: 海带植株
    # LIGHT_GRAY_TERRACOTTA 的来源显示名；可自定义中文文本。
    LIGHT_GRAY_TERRACOTTA: 淡灰色陶瓦
    # MAGMA_BLOCK 的来源显示名；可自定义中文文本。
    MAGMA_BLOCK: 岩浆块
    # MANGROVE_LEAVES 的来源显示名；可自定义中文文本。
    MANGROVE_LEAVES: 红树树叶
    # MANGROVE_ROOTS 的来源显示名；可自定义中文文本。
    MANGROVE_ROOTS: 红树根
    # MOSS_BLOCK 的来源显示名；可自定义中文文本。
    MOSS_BLOCK: 苔藓块
    # MOSS_CARPET 的来源显示名；可自定义中文文本。
    MOSS_CARPET: 苔藓地毯
    # MUD 的来源显示名；可自定义中文文本。
    MUD: 泥巴
    # MUDDY_MANGROVE_ROOTS 的来源显示名；可自定义中文文本。
    MUDDY_MANGROVE_ROOTS: 沾泥的红树根
    # MUSHROOM_STEM 的来源显示名；可自定义中文文本。
    MUSHROOM_STEM: 蘑菇柄
    # MYCELIUM 的来源显示名；可自定义中文文本。
    MYCELIUM: 菌丝体
    # NETHER_WART_BLOCK 的来源显示名；可自定义中文文本。
    NETHER_WART_BLOCK: 下界疣块
    # NETHERRACK 的来源显示名；可自定义中文文本。
    NETHERRACK: 下界岩
    # OAK_LEAVES 的来源显示名；可自定义中文文本。
    OAK_LEAVES: 橡树树叶
    # OBSIDIAN 的来源显示名；可自定义中文文本。
    OBSIDIAN: 黑曜石
    # ORANGE_TERRACOTTA 的来源显示名；可自定义中文文本。
    ORANGE_TERRACOTTA: 橙色陶瓦
    # PACKED_ICE 的来源显示名；可自定义中文文本。
    PACKED_ICE: 浮冰
    # PALE_MOSS_BLOCK 的来源显示名；可自定义中文文本。
    PALE_MOSS_BLOCK: 苍白苔藓块
    # PALE_MOSS_CARPET 的来源显示名；可自定义中文文本。
    PALE_MOSS_CARPET: 苍白苔藓地毯
    # PALE_OAK_LEAVES 的来源显示名；可自定义中文文本。
    PALE_OAK_LEAVES: 苍白橡树树叶
    # PINK_PETALS 的来源显示名；可自定义中文文本。
    PINK_PETALS: 粉红色花簇
    # PITCHER_CROP 的来源显示名；可自定义中文文本。
    PITCHER_CROP: 瓶子草植株
    # PODZOL 的来源显示名；可自定义中文文本。
    PODZOL: 灰化土
    # RED_MUSHROOM 的来源显示名；可自定义中文文本。
    RED_MUSHROOM: 红色蘑菇
    # RED_MUSHROOM_BLOCK 的来源显示名；可自定义中文文本。
    RED_MUSHROOM_BLOCK: 红色蘑菇方块
    # RED_TERRACOTTA 的来源显示名；可自定义中文文本。
    RED_TERRACOTTA: 红色陶瓦
    # REINFORCED_DEEPSLATE 的来源显示名；可自定义中文文本。
    REINFORCED_DEEPSLATE: 强化深板岩
    # SANDSTONE 的来源显示名；可自定义中文文本。
    SANDSTONE: 砂岩
    # SEA_PICKLE 的来源显示名；可自定义中文文本。
    SEA_PICKLE: 海泡菜
    # SMOOTH_BASALT 的来源显示名；可自定义中文文本。
    SMOOTH_BASALT: 平滑玄武岩
    # SPRUCE_LEAVES 的来源显示名；可自定义中文文本。
    SPRUCE_LEAVES: 云杉树叶
    # TERRACOTTA 的来源显示名；可自定义中文文本。
    TERRACOTTA: 陶瓦
    # TORCHFLOWER 的来源显示名；可自定义中文文本。
    TORCHFLOWER: 火把花
    # TUFF 的来源显示名；可自定义中文文本。
    TUFF: 凝灰岩
    # WARPED_WART_BLOCK 的来源显示名；可自定义中文文本。
    WARPED_WART_BLOCK: 诡异疣块
    # WHITE_TERRACOTTA 的来源显示名；可自定义中文文本。
    WHITE_TERRACOTTA: 白色陶瓦
    # YELLOW_TERRACOTTA 的来源显示名；可自定义中文文本。
    YELLOW_TERRACOTTA: 黄色陶瓦
  # 生物显示名；与 skills.yml 中 mobs 的键对应。
  entities:
    ZOMBIE: 僵尸
    SKELETON: 骷髅
    CREEPER: 苦力怕
    SPIDER: 蜘蛛
    CAVE_SPIDER: 洞穴蜘蛛
    HUSK: 尸壳
    DROWNED: 溺尸
    STRAY: 流浪者
    BOGGED: 沼骸
    ENDERMAN: 末影人
    WITCH: 女巫
    SLIME: 史莱姆
    MAGMA_CUBE: 岩浆怪
    BLAZE: 烈焰人
    GHAST: 恶魂
    PHANTOM: 幻翼
    PIGLIN: 猪灵
    PIGLIN_BRUTE: 猪灵蛮兵
    ZOMBIFIED_PIGLIN: 僵尸猪灵
    HOGLIN: 疣猪兽
    ZOGLIN: 僵尸疣猪兽
    WITHER_SKELETON: 凋灵骷髅
    GUARDIAN: 守卫者
    ELDER_GUARDIAN: 远古守卫者
    SHULKER: 潜影贝
    PILLAGER: 掠夺者
    VINDICATOR: 卫道士
    EVOKER: 唤魔者
    RAVAGER: 劫掠兽
    BREEZE: 旋风人
    COW: 牛
    PIG: 猪
    SHEEP: 绵羊
    CHICKEN: 鸡
    RABBIT: 兔子
    # ALLAY 的来源显示名；可自定义中文文本。
    ALLAY: 悦灵
    # ARMADILLO 的来源显示名；可自定义中文文本。
    ARMADILLO: 犰狳
    # AXOLOTL 的来源显示名；可自定义中文文本。
    AXOLOTL: 美西螈
    # BAT 的来源显示名；可自定义中文文本。
    BAT: 蝙蝠
    # BEE 的来源显示名；可自定义中文文本。
    BEE: 蜜蜂
    # CAMEL 的来源显示名；可自定义中文文本。
    CAMEL: 骆驼
    # CAMEL_HUSK 的来源显示名；可自定义中文文本。
    CAMEL_HUSK: 骆驼尸壳
    # CAT 的来源显示名；可自定义中文文本。
    CAT: 猫
    # COD 的来源显示名；可自定义中文文本。
    COD: 鳕鱼
    # DOLPHIN 的来源显示名；可自定义中文文本。
    DOLPHIN: 海豚
    # DONKEY 的来源显示名；可自定义中文文本。
    DONKEY: 驴
    # ENDER_DRAGON 的来源显示名；可自定义中文文本。
    ENDER_DRAGON: 末影龙
    # ENDERMITE 的来源显示名；可自定义中文文本。
    ENDERMITE: 末影螨
    # FOX 的来源显示名；可自定义中文文本。
    FOX: 狐狸
    # FROG 的来源显示名；可自定义中文文本。
    FROG: 青蛙
    # GIANT 的来源显示名；可自定义中文文本。
    GIANT: 巨人
    # GLOW_SQUID 的来源显示名；可自定义中文文本。
    GLOW_SQUID: 发光鱿鱼
    # GOAT 的来源显示名；可自定义中文文本。
    GOAT: 山羊
    # HORSE 的来源显示名；可自定义中文文本。
    HORSE: 马
    # ILLUSIONER 的来源显示名；可自定义中文文本。
    ILLUSIONER: 幻术师
    # IRON_GOLEM 的来源显示名；可自定义中文文本。
    IRON_GOLEM: 铁傀儡
    # LLAMA 的来源显示名；可自定义中文文本。
    LLAMA: 羊驼
    # MOOSHROOM 的来源显示名；可自定义中文文本。
    MOOSHROOM: 哞菇
    # MULE 的来源显示名；可自定义中文文本。
    MULE: 骡
    # NAUTILUS 的来源显示名；可自定义中文文本。
    NAUTILUS: 鹦鹉螺
    # OCELOT 的来源显示名；可自定义中文文本。
    OCELOT: 豹猫
    # PANDA 的来源显示名；可自定义中文文本。
    PANDA: 熊猫
    # PARCHED 的来源显示名；可自定义中文文本。
    PARCHED: 焦骸
    # PARROT 的来源显示名；可自定义中文文本。
    PARROT: 鹦鹉
    # POLAR_BEAR 的来源显示名；可自定义中文文本。
    POLAR_BEAR: 北极熊
    # PUFFERFISH 的来源显示名；可自定义中文文本。
    PUFFERFISH: 河豚
    # SALMON 的来源显示名；可自定义中文文本。
    SALMON: 鲑鱼
    # SILVERFISH 的来源显示名；可自定义中文文本。
    SILVERFISH: 蠹虫
    # SKELETON_HORSE 的来源显示名；可自定义中文文本。
    SKELETON_HORSE: 骷髅马
    # SNOW_GOLEM 的来源显示名；可自定义中文文本。
    SNOW_GOLEM: 雪傀儡
    # SQUID 的来源显示名；可自定义中文文本。
    SQUID: 鱿鱼
    # STRIDER 的来源显示名；可自定义中文文本。
    STRIDER: 炽足兽
    # TADPOLE 的来源显示名；可自定义中文文本。
    TADPOLE: 蝌蚪
    # TROPICAL_FISH 的来源显示名；可自定义中文文本。
    TROPICAL_FISH: 热带鱼
    # TURTLE 的来源显示名；可自定义中文文本。
    TURTLE: 海龟
    # VEX 的来源显示名；可自定义中文文本。
    VEX: 恼鬼
    # VILLAGER 的来源显示名；可自定义中文文本。
    VILLAGER: 村民
    # WANDERING_TRADER 的来源显示名；可自定义中文文本。
    WANDERING_TRADER: 流浪商人
    # WARDEN 的来源显示名；可自定义中文文本。
    WARDEN: 监守者
    # WITHER 的来源显示名；可自定义中文文本。
    WITHER: 凋灵
    # WOLF 的来源显示名；可自定义中文文本。
    WOLF: 狼
    # ZOMBIE_NAUTILUS 的来源显示名；可自定义中文文本。
    ZOMBIE_NAUTILUS: 僵尸鹦鹉螺
    # ZOMBIE_VILLAGER 的来源显示名；可自定义中文文本。
    ZOMBIE_VILLAGER: 僵尸村民
  # 通用事件来源名称；值是来源条件简述，具体限制见 config.yml 和技能描述。
  events:
    fishing: 钓起未单独配置经验的物品
    defense: 承受生物攻击（有冷却）
    agility: 承受有效摔落伤害（有冷却）
    alchemy: 饮用具有药效的药水
    enchanting: 完成一次附魔台附魔
```

