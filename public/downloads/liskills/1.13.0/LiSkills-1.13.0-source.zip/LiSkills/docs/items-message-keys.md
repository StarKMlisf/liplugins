# 物品要求提示

将首个 YAML 块合并到 `messages.yml`。所有提示通过现有 MiniMessage/TextService 输出，已有自定义值不覆盖。

```yaml
# 装备属性和使用要求提示；均为MiniMessage文本，留空可关闭对应提示。
items:
  # 自有物品规则PDC损坏或类型错误时拒绝危险使用；只能由管理员显式清理自有规则修复。
  invalid-data: '<red>这件物品的技能规则数据损坏，请联系管理员检查。'
  # 条件不足时提示；{item}为规则显示名、{rule}为规则ID、{skill}为技能名、{required}为门槛、{current}为当前等级、{reason}为下方原因。
  denied: '<red>暂时不能使用 {item}：{skill} 需要 {required} 级（当前 {current} 级）。{reason}'
  # 附加原因；键名固定，各项可自定义MiniMessage文本。
  reason:
    # 正常等级不足的额外说明；可留空。
    level: ''
    # 档案尚未加载完成时拒绝受限使用，避免登录期间绕过条件。
    profile_loading: '角色资料尚未准备好，请稍后重试。'
    # 配置引用不存在或已停用的技能时保守拒绝。
    skill_unavailable: '要求中的技能不可用，请联系管理员。'
    # 玩家缺少技能系统或对应技能权限时提示。
    permission: '你没有使用该技能的权限。'
```
