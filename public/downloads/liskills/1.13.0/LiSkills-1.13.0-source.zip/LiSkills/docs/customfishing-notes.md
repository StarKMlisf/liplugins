# CustomFishing 兼容说明

对应官方 CustomFishing 2.3.26 公开 API；本地 2.3.23、2.3.23.1 的本次相关成功事件和渔获 ID 签名也已核对。本轮运行验收范围见 `VERIFICATION.md`，API 签名一致不等于所有旧版本均完成游戏内验收。

安装 CustomFishing 后自动连接，不需要把它的 Jar 或依赖打入 LiSkills。未安装时继续使用原版钓鱼经验和原版快速咬钩。公共 API 不匹配时显示一次可配置中文提示，停用额外桥接奖励并暂时避让鱼钩，避免争夺第三方计时器。通过技能诊断指令查看连接状态。

## 钓鱼经验

监听官方 `FishingResultEvent`，只在 `SUCCESS`、数量大于零且渔获 ID 非空时奖励钓鱼技能经验。下一 tick 再检查最终取消状态、玩家在线情况、世界、配置版本和档案实例，因此领地或其他插件在后续监听器取消成功结果时不会提前发经验。

按 `Loot.id()` 精确匹配渔获 ID，未单独配置的 ID 使用默认经验；大小写不自动转换。一次成功钓获只发一次经验，不乘鱼饵多掉落数量，也不改掉落、鱼袋、小游戏、图鉴、排行榜、积分或原版经验球。默认经验设为零可以只启用显式列出的 ID，单个 ID 设为零可以关闭该渔获的技能经验。

`FishingLootSpawnEvent` 不是主奖励入口，因为 CustomFishing 的直接入背包路径不必生成掉落实体。此桥以成功结果为结算依据：后续物品被其他插件移除、改为不生成实体或改变掉落表现，不撤回已经确认的成功结果。

CustomFishing 的 `other-settings.trigger-fish-event` 无论开关都不需要修改。它额外发送的 `CustomPlayerFishEvent` 不走 LiSkills 原版钓鱼经验；已受管鱼钩还保留有界的短期记录，避免 CustomFishing 提前移除自身映射造成重复经验。关闭额外经验开关不会关闭这层去重保护。

## 快速咬钩

启用快速咬钩窗口后，用主手鱼竿抛钩；此桥在 `RodCastEvent` 捕获原抛钩事件与能力窗口编号，确认 CustomFishing 接管后，在 `FishingEffectApplyEvent` 的 `FISHING` 阶段乘上 LiSkills 的等待倍率。默认倍率为 0.5，例如 CustomFishing 已计算出 0.8 的等待倍率，组合后为 0.4。

只处理同一次抛钩和同一个仍有效的能力窗口；副手抛钩、抛钩取消、窗口结束、换工具或槽位、死亡、换世界、退出、重载后不继续施加。重复发出同一效果实例不会再次叠乘。窗口结束时只恢复仍等于我方写入值的效果倍率，保留其他插件稍后写入的值；已经抽取的当前等待倒计时不强制重置。

CustomFishing 接管的鱼钩不再由 LiSkills 修改 Bukkit `FishHook` 的最小/最大等待值，防止两个计时系统互相覆盖。第三方鱼饵、钓竿和渔获的效果仍由 CustomFishing 计算，LiSkills 只组合等待倍率，不触碰小游戏难度、成功率、鱼大小、掉落数量或等待加数。

最终最短/最长等待时间仍由 CustomFishing 决定。它关闭 `fishing-wait-time.override-vanilla` 时还有自身至少 100 tick 的限制，开启时使用它的 `final-min-wait-time` / `final-max-wait-time`；因此实际等待时间不保证精确减半。LiSkills 的 `minimum-wait-ticks` 只限制原版等待区间，不覆盖 CustomFishing 的限制。岩浆与虚空机制如果触发同一个公开 FISHING 效果阶段，也只组合倍率，规则仍归 CustomFishing 管理。

## 官方依据

- [CustomFishing 中文文档](https://momi.gtemc.cn/customfishing)
- [成功结果事件](https://github.com/Xiao-MoMi/Custom-Fishing/blob/main/api/src/main/java/net/momirealms/customfishing/api/event/FishingResultEvent.java)
- [效果应用阶段](https://github.com/Xiao-MoMi/Custom-Fishing/blob/main/api/src/main/java/net/momirealms/customfishing/api/event/FishingEffectApplyEvent.java)
- [成功流程、背包与分批掉落路径](https://github.com/Xiao-MoMi/Custom-Fishing/blob/main/api/src/main/java/net/momirealms/customfishing/api/mechanic/fishing/CustomFishingHook.java)
- [原版机制等待限制](https://github.com/Xiao-MoMi/Custom-Fishing/blob/main/api/src/main/java/net/momirealms/customfishing/api/mechanic/fishing/hook/VanillaMechanic.java)

探针中的成功事件和效果事件验证不等同于真人完整游玩小游戏或自然垂钓手感验收；以发布验收报告明确列出的运行步骤为准。
