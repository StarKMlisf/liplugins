# 箭术蓄力射击 CHARGED_SHOT

本轮以旧版 `skills/archery/ChargedShot.java` 的蓄力增伤玩法为参考，使用独立标准 Bukkit 实现。没有移植原版左键开关、逐箭按蓄力比例扣魔力及 Metadata 乘数；本插件沿用统一主动窗口、魔力事务和配置冷却。

## 整合接口

- 构造器：`ChargedShotManager(JavaPlugin, ConfigManager, SkillAbilityWindows, TextService, LiRealEnchantHook)`；实现 `ActiveAbilityHandler`、`Listener`、`AutoCloseable`。
- `config.chargedShot()` 返回 `ChargedShotSettings(minimumForce, damageMultiplier, maxProjectiles, projectileLifetimeSeconds)`。
- 共享窗口调用 `open(player,"archery","CHARGED_SHOT",active,Set.of(Material.BOW))`；箭保存 `token(player,"archery")`，过期或重开窗口不会继承旧箭。`remainingMillis(Player)` 供菜单显示当前生效时间。
- 注册本管理器事件，并在运行时关闭时调用 `close()`。共享窗口由运行时单独管理关闭。

## 中文消息与配置片段

第一个片段只包含 `ability` 下的子键，由合并器放入已有配置节，不创建重复根节点。

```yaml
# 主手不是弓时的释放提示；MiniMessage字符串，失败不消耗魔力或冷却。
charged-shot-tool: '<yellow>请在主手持弓释放蓄力射击；弩和烟花不适用。</yellow>'
# 本次技能窗口尚未结束时的提示；MiniMessage字符串，不重复扣费。
charged-shot-already-active: '<yellow>蓄力射击仍在生效中，请蓄力后射箭。</yellow>'
# 全服箭矢追踪已满时的释放提示；MiniMessage字符串，本次激活失败不扣费。
charged-shot-capacity: '<yellow>当前强化箭矢较多，请稍后再释放蓄力射击。</yellow>'
```

以下第二片段由配置层合并到 `config.yml`；仍只补缺少节点，不覆盖管理员自定义值。

```yaml
# 箭术蓄力射击；仅主手弓的普通箭/光灵箭，不增强弩、三叉戟或烟花。
charged-shot:
  # 最低蓄力比例；有限数字0.1-1.0，0.9表示至少90%，1.0要求完全蓄力。
  minimum-force: 0.9
  # 首次有效命中的伤害倍率；有限数字1.0-5.0，1.5表示原伤害150%（增加50%）。
  damage-multiplier: 1.5
  # 全服最多同时追踪箭矢数；整数1-8192。达到上限后新箭仍按原版飞行，不额外强化。
  max-projectiles: 1024
  # 单支箭最多保留强化资格的秒数；整数1-60，同时不得超出本次技能窗口剩余时间。
  projectile-lifetime-seconds: 10
```

## 行为和保护边界

- 在箭术主动窗口内，主手 `BOW` 射出且达到阈值的 `Arrow` / `SpectralArrow` 获得一次强化资格。药水箭属于 `Arrow`，原有药水效果不改变。阈值与 Bukkit 的 `float` 使用同精度比较，因此 `0.9f` 不会误判低于配置 `0.9`。
- 使用 `EntityShootBowEvent` 的 `MONITOR` 阶段只登记；取消的射击、副手射击、弩、烟花、三叉戟和未充分蓄力的箭不登记。保留原射击事件引用，后续优先级取消或替换弹射物也会使旧箭失效。
- 只修改 `EntityDamageByEntityEvent` 中 `PROJECTILE` 的原始基础伤害，护甲和其他原生减免仍由 Bukkit 计算。不会创建额外箭、修改箭本体伤害或模拟 `damage()`，不会直接追加经验。
- 每支箭仅第一次有效正伤害命中可强化。写入倍率时先锁定该箭的资格，下一主线程 tick 读取完整事件派发后的取消状态和最终伤害：未取消且正伤害才正式消费；后置取消、后置减为零或无效数值则恢复资格。结算前的嵌套回调以及同 tick 后续命中保守跳过，不能重复放大；取消后的资格从下一 tick 开始恢复。本插件不回写或还原第三方对事件伤害的修改。
- 被护盾完全吸收/最终伤害为零、非有限数值及溢出不开始强化事务。已取消的碰撞引用不允许随后伤害追加倍率，下一次正常碰撞可以重新成为首个有效命中。成功命中后的穿透目标不再获得倍率。
- 使用现有 `LiRealEnchantHook.isSecondaryDamage()` 跳过附魔二次伤害，不修改自家附魔规则。此轮不包含任何基岩专项改动。
- 射手必须仍持本次窗口工具，并满足共享窗口权限、等级、世界、在线状态、玩家资料身份和配置版本要求。退出、死亡、换世界、换工具栏、主副手交换或弓损坏清除该玩家登记；仅普通耐久变化不视作换物。窗口结束、配置重载或新窗口不能继续强化旧箭。
- 箭落地清除登记；全服单个任务每 tick 仅结算待定命中集合，每10tick再清理已失效、已移除、过期或窗口失效的箭。两个集合都受箭记录硬上限限制，不按箭创建任务，不写永久 PDC。每次成功激活只按 `active.mana-cost` 消费一次，窗口内可以射出多支合格箭；登记满后新箭不增强，也不再扣魔力。
- 非标准插件在本监听器执行之后才取消或改写事件时，仍由服务端最终取消决定是否造成伤害；不宣称能预测任意后置回调。

## 验收范围

单元测试覆盖90%精度边界、主手/武器/弹射物组合、非法蓄力、基础伤害倍率、零最终伤害与溢出、追踪/时间配置上限，以及后置取消后恢复、嵌套/穿透不重复消费、重复结算不能复活已消费资格。Paper隔离服探针已通过真实箭实体配合标准事件注入的验证：10伤害变15、成功后不再强化、后置MONITOR取消后下一tick恢复资格、同tick不重复强化、蓄力阈值、取消射击/命中、换物与重载、追踪上限，以及菜单中的生效时间。具体范围和证据见 [验证记录](VERIFICATION.md)，射击事件注入不代表真人客户端实际拉弓操作。

代码与算法测试不等于真人客户端手感验收；声音、粒子和网络延迟下的视觉效果应另行确认。
