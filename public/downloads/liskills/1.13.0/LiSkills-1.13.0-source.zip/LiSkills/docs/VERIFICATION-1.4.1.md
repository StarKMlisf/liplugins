# LiSkills 1.4.1 验证记录

日期：2026-08-31。目标：Paper 26.1.2 build 74、Java 25.0.3、Windows。生产代码以Spigot 26.1.2 API编译，使用标准Bukkit API；不声明Folia或基岩专项支持。

本轮新增CustomCrops与CustomFishing兼容。测试仅运行在`target/runtime-paper`，绑定127.0.0.1:25681；未连接、修改或替换正式服务器。第三方Jar来自用户本机Downloads，外部依赖缓存只读复制；原插件工程、配置、模型和玩家数据未修改。

## 成品与版本

- LiSkills-1.4.1.jar：`E10914591D68B5BF3CE84AF65A7FA95D0C3B3A0E51D683AF8A08882F24C35C86`。
- CustomCrops-3.6.54.jar：`7A1747F38632693B0BAB44E7A777E5385C31ED98D3A2DF6A246255A25F4F2CAA`。
- CustomFishing-2.3.26.jar：`100F703CADBF65D94580D3911DBA0377595B9794EFC5D046B76384CE29F8E9BF`。
- 既有LiRealEnchant dev201未变：`2DBBD87B69DDA542913EAA444F080E12CCE42BD3EE27CD81DA1DFAF663EE2E45`。

版本1.4.0为首次开发构建；1.4.1加入同作物位置跨玩家争用保护及原版钓鱼取消后放行处理。下列回归必须与上述最终LiSkills Jar摘要一致，发行脚本拒绝失败、版本不一致或协议客户端异常的结果。

## 单元回归

`./build.ps1 -Offline`通过125项测试，失败0、错误0、跳过0。保留上一版101项；新增13项作物成熟/产出/竞争与提交时序、8项渔获去重及等待倍率边界、3项自定义ID配置解析与非法经验拒绝测试。按ID映射支持命名空间、点号和精确大小写，0可禁用指定ID。

构建检查安装Jar只包含LiSkills自身类，不包含外部依赖实现、测试或探针。商业插件Jar仅在本机`lib/verification-dependencies`用于验收，不放入成品、源码包或安装包。构建LiSkills自身不需要这两款插件Jar。

## Paper运行回归

各组依次运行，禁止并发修改测试配置；通过Java协议登录的探针使用真实服务端玩家对象，没有伪造在线玩家映射。断言数不含末尾范围说明。

| 探针 | 断言数 | 覆盖 |
| --- | ---: | --- |
| LiSkillsSmoke | 10 | 无外部内容插件独立启用、十一技能、配置/命令/文本、有效重载与错误回滚 |
| LiSkillsMenuProbe | 93 | 原有菜单、来源分页、能力与魔力、中文文本和配置保留 |
| LiSkillsCompatibilityProbe | 69 | 既有dev201附魔成功事件、预检识别、去重及次级伤害 |
| LiSkillsGatheringProbe | 100 | 采集队列、补种事务、保护取消、魔力与工具互斥 |
| LiSkillsPlayerProbe | 80 | Java真实在线玩家、实际9格挖掘、预算与XP、补种及反馈 |
| LiSkillsAbilitiesProbe | 178 | 无附魔/无内容插件的新三项技能、菜单、原生受伤和退出保存退款 |
| LiSkillsCustomContentProbe | 155 | 真实CC/CF插件、Java玩家、ID经验、取消/去重、受管避让和等待倍率 |

七组共685项检查全部通过，三个Java协议客户端均以0正常退出；结果JSON与三个客户端日志随发行包提供，技能Jar摘要均与本成品一致。旧版本详细测试方法保留于[1.3.1记录](VERIFICATION-1.3.1.md)。

## 内容兼容验收方式

真实CustomCrops 3.6.54和CustomFishing 2.3.26均在Paper26.1.2正常启用，LiSkills连接双方公开API；测试服同时保留原LiRealEnchant dev201，检查共存。CustomCrops默认tomato配置已加载；未安装CraftEngine/ItemsAdder等模型插件，因此没有宣称资源模型或自然手动收获已验收。

- 配置：默认开关与经验、作物ID和渔获ID映射、点号ID、单项0经验、非法负数/非数字不替换内存快照、管理员注释保留。
- CustomFishing：使用真实公开Loot/Context/Result事件，验证SUCCESS一次经验、失败/取消/零数量不发、同事件及同钩不重复、多掉落不倍增、额外CustomPlayerFishEvent不走原版经验、重载和关闭额外经验生效。
- 原版钓鱼：调用实际注册的LiSkills监听入口，分别验证非CF钩正常奖励、晚期取消不奖励、先取消后最终允许仍奖励。该部分是监听入口注入，不称为自然钓获。
- 快速咬钩：真实FishHook、官方RodCast与CustomFishingHook/Effect对象，在CAST确认后测试FISHING阶段倍率组合、同效果不叠加、副手和取消不生效、关闭开关/重载/窗口结束失效、恢复不覆盖外部改值，以及原生等待区间不叠改。为了避免CF主监听器重复构造鱼钩，原生观察入口由探针直接调用。
- CustomCrops：使用实际加载的CropConfig与公开BuiltIn crop状态，临时写入独立测试坐标。通过真实CropBreak/CropInteract和品质/单项产出事件测试成熟收获、未熟/空产出/取消/无状态变化拒绝、同次多产出不叠加、主副手和ACTION归属、重载/开关失效。品质产出与仅普通掉落分别验证可奖励，普通掉落后置取消也确认不奖励。
- 归属：真实CC世界状态可拥有外观为原版小麦的位置，原版方块/采摘经验和补种队列避让，不扣普通种子。连锁伐木/范围挖掘的起点及实际执行前也检查同一归属谓词。

测试使用真实插件和实体，但部分事件由探针派发；未通过私有服务端字段跳过保护，不伪造第三方插件/API。测试后原样恢复LiSkills配置、玩家档案、装备、权限、位置及方块，移除临时CC状态和实体，再主动停服。失败的夹具构造修复不算插件兼容通过，必须重新运行到PASS。

## 使用边界

未完成真人Java客户端鼠标收获/抛竿/小游戏、自然生长和自然垂钓计时、CraftEngine模型视觉、多领地插件组合、多人高并发负载验收。CustomCrops永久成熟且不改变状态、命令发物品、多上下文或超过8tick延迟的特殊动作保守不给经验。CustomFishing最终等待下限由它自身控制，不保证实际倒计时精确减半。技能仍是AuraSkills精简派生版，不是其全部能力/API等价移植。

备份并停服后只替换一个LiSkills Jar；已有CustomCrops、CustomFishing和LRE的Jar、配置及数据保留。默认配置仅供参考，不覆盖已有文件。升级自动补缺失节点，`/lsk validate`显示连接状态，`/lsk reload`生效配置。探针Jar禁止放入正式服务器。
