# 成长菜单文本与布局

以下第一段由构建维护脚本合入 messages.yml，第二段合入 menu.yml；已有服务器只补缺失项。

```yaml
rpg:
  brewing-source: '本人认领的酿造台完成一瓶有效药水'
  passives-title: '<dark_gray>{skill} · 能力成长'
  stats-title: '<dark_gray>{player} · 角色属性'
  maximum: '已达上限'
  disabled: '已关闭'
  inactive: '当前环境或权限不满足'
  locked: '尚未解锁'
  unlocked: '已启用'
  stats-entry:
    - ''
    - '<aqua>点击查看九项角色属性'
  passives-entry:
    - ''
    - '<yellow>本技能有 {passive_count} 项等级被动'
    - '<aqua>点击查看能力树与下次提升'
  back-detail-name: '<yellow>返回技能详情'
  back-detail-lore:
    - '<gray>查看经验来源与技能进度'
  passive-name: '<gold>{name} <gray>· 第 {level} 阶'
  passive-lore:
    - '<gray>ID：<white>{id}'
    - '<gray>当前状态：<yellow>{state}'
    - '<gray>技能等级：<white>{skill_level}'
    - '<gray>解锁等级：<white>{unlock}'
    - '<gray>每 <white>{interval} <gray>个技能等级提升一阶'
    - '<gray>下次提升需要技能等级：<aqua>{next}'
    - '<gray>当前主数值：<green>{value} <gray>／次值：<green>{secondary}'
    - ''
  summary-name: '<gold>{skill} <gray>· Lv.{level}'
  summary-lore:
    - '<gray>技能经验：<white>{xp} / {required}'
    - '<gray>能力按技能等级自动解锁，无须花点购买。'
    - '<gray>下方列出此技能的五项被动能力。'
    - '<gray>数值单位见每项说明；几率最终限制0%-100%。'
  active-name: '<aqua>{ability} <gray>· 第 {ability_level} 阶'
  active-lore:
    - '<gray>状态：<yellow>{ability_status}'
    - '<gray>解锁等级：<white>{unlock_level}'
    - '<gray>本阶持续：<green>{duration} 秒'
    - '<gray>本阶冷却：<green>{cooldown} 秒'
    - '<gray>本阶魔力：<aqua>{mana_cost}'
    - '<gray>当前魔力：<aqua>{mana} / {max_mana}'
    - ''
    - '<yellow>点击施放；成长规则在 abilities.yml'
  stat-name: '<gold>{name} <gray>· <white>{value}'
  stat-lore:
    - '<gray>属性ID：<white>{id}'
    - '<gray>当前值包含技能成长及有效装备／药水加成。'
    - '<gray>属性公式和成长分配可在 stats.yml 调整。'
    - ''
  stats-summary-name: '<aqua>{player} 的角色属性'
  stats-summary-lore:
    - '<gray>成长系统：<yellow>{state}'
    - '<gray>十一项技能分别提供主属性和副属性。'
    - '<gray>默认从技能2级开始发放属性，不重置旧档。'
    - '<gray>默认速度无技能成长，可由服主管理配置。'
  stat-guide:
    strength:
      - '<gray>力量增加近战攻击伤害。'
      - '<gray>默认每点力量增加0.4%攻击伤害。'
    health:
      - '<gray>生命增加最大生命；默认每点增加1点生命。'
      - '<gray>只管理本插件修饰符，保留附魔与宠物加成。'
    regeneration:
      - '<gray>再生增加饱食回血、饥饿回血与魔力恢复。'
      - '<gray>与基础魔力恢复相加，不替换原有配置。'
    luck:
      - '<gray>幸运增加原版采集掉落的额外物品机会。'
      - '<gray>自定义作物和渔获仍由对应插件管理掉落。'
    wisdom:
      - '<gray>智慧增加原版经验获取和最大魔力。'
      - '<gray>同时降低铁砧经验花费。'
    toughness:
      - '<gray>韧性按递减收益公式减少承受的伤害。'
    crit_chance:
      - '<gray>提高技能暴击概率。'
    crit_damage:
      - '<gray>提高技能暴击的额外伤害百分比。'
    speed:
      - '<gray>增加移动速度；只修改本插件的属性修饰符。'
```

```yaml
# 成长页面布局；所有数字槽位从0开始，按钮及内容槽位不得重复。
rpg:
  # 每个技能的五项被动与一个主动；布局可改，不改变已有详情页。
  passives:
    # 箱子大小；27、36、45或54。
    size: 54
    # 五项被动展示槽位；恰好5个不同整数，范围0至size-1。
    item-slots: [20, 21, 22, 23, 24]
    # 技能摘要槽位；0至size-1。
    summary-slot: 4
    # 主动施放按钮槽位；0至size-1。
    active-slot: 40
    # 返回详情按钮槽位；0至size-1。
    back-slot: 49
  # 九项角色属性的总览。
  stats:
    # 箱子大小；27、36、45或54。
    size: 45
    # 属性展示槽位；恰好9个不同整数，范围0至size-1，顺序见stats.yml。
    item-slots: [10, 11, 12, 13, 14, 15, 16, 21, 23]
    # 玩家摘要槽位；0至size-1。
    summary-slot: 4
    # 返回总览按钮槽位；0至size-1。
    back-slot: 40
```
