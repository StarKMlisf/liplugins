# 依赖与构建说明（LiSkills 1.13.0）

LiSkills 使用 Spigot `26.1.2-R0.1-SNAPSHOT` 编译，普通服务器业务使用标准 Bukkit API；运行基准是 Paper 26.1.2 / Java 25。1.13.0 新增 Folia 26.2 区域线程兼容层，调度和临时属性接口通过 `lib/scheduler/` 内的公开 API 反射适配，不要求将 Folia 专属类直接引入业务或打入成品。Maven 版本为 3.9.15。

Shiroha 26.2 属于本次兼容目标，但未取得用户截图中的同一构建 Jar；不能把 Folia 测试等同于该构建的实测。具体范围及跨区域限制见 [Folia 与 Shiroha 说明](FOLIA-COMPATIBILITY.md)。

## 构建

在项目根目录运行 `./build.ps1`。可用 `-JavaHome`、`-MavenHome` 指定工具目录；首次依赖下载完成后可用 `-Offline`。`-SkipTests` 仅跳过测试，不应作为正式交付的验证命令。

前置 API 和编译依赖统一复制到 `lib/api/`。Maven 所有公共依赖都声明为 `provided`；使用普通 Jar 插件，没有 shade、嵌套依赖或依赖解包。构建脚本检查成品必要入口/配置，并拒绝含 `net/liplugins/liskills/` 以外的 `.class`。

## 服务器启动

1. 先读取 `messages.yml` 的 `boot` 中文消息。此时公共文本库可能不存在，因此启动消息用纯文本。
2. 发现冲突的旧技能插件同时被加载时拒绝启动，避免两套技能同时加经验和属性；迁移时停用旧插件，保留原数据备份。
3. 检测区域线程运行环境。普通 Bukkit/Paper 使用标准调度器；Folia 使用全局、区域、实体调度器，并预检临时属性接口。接口缺失时中文提示并安全停止，不绕过线程检查或回退为永久属性。
4. 实际调用 MiniMessage 解析与 LegacyComponentSerializer 序列化探测服务器现有库。
5. 只有现有库不可用时才下载下表固定工件到 `plugins/LiSkills/lib/`。不支持配置任意下载地址或版本。
6. 下载全部通过校验后才初始化业务。业务入口通过独立类加载器加载；Bukkit 和插件公开 API 仍由父加载器提供，关闭时关闭补充加载器。

| 工件 | 版本 |
| --- | --- |
| adventure-api、adventure-key | 4.26.1 |
| adventure-text-minimessage、adventure-text-serializer-legacy | 4.26.1 |
| examination-api、examination-string | 1.3.0 |
| JetBrains annotations | 26.0.2-1 |

所有下载固定使用 Maven Central HTTPS，连接超时 10 秒、读取超时 15 秒，单文件上限 16 MiB，不跟随重定向。代码中固定每个工件的 SHA-256；现有缓存也重新校验。下载先写随机 `.part` 文件，校验后原子替换（文件系统不支持时使用普通替换）；失败时清理临时文件，启动器输出中文说明并停用插件，不直接打印异常堆栈。

PlaceholderAPI 2.11.6 只作为可选前置 API 编译，不自动下载安装其他服务器插件。Vault通过公开Economy服务为主动开启的职业/奖励发钱；默认职业关闭、奖励示例关闭，没有Vault时安全拒绝付款。

可选SQL后端独立下载固定驱动：MySQL Connector/J9.7.0、protobuf-java4.31.1、sqlite-jdbc3.53.2.0。只下载所选后端必需工件，同样校验固定SHA-256并缓存到lib；不打进成品Jar，不使用管理员提供的任意URL。连接失败不会切回空YAML。驱动明细见[存储与迁移](AURA-STORAGE.md)，旧版独立验证仅作历史证据；本轮实际重跑范围以 [1.13.0 验证记录](VERIFICATION-1.13.0.md) 为准。

## 历史独立依赖验证

以下是 2026-08-30 对 `lib/verification/RuntimeLibrariesProbe.java` 的既有记录，不表示本次版本重新执行了全部下载或数据库测试。当时实际访问 Maven Central 完成以下检查：

- 7 个固定工件下载和全部 SHA-256 校验通过。
- 以仅含 Java 平台类的父加载器隔离服务器库，成功加载下载库并解析渐变 MiniMessage。
- 第二次使用完整缓存不重新下载。
- 故意损坏一个缓存后重新下载并校验通过。
- 故意提供错误摘要时拒绝工件，且不留下最终 Jar 或 `.part`。

探针缓存保存在 `target/loader-probe/`，不进入成品。这个结果验证公共库下载及隔离加载，不等同于真实服务器启动或客户端玩法验证；真实 Paper 启动记录由项目验证报告单独说明。

复跑探针时使用 JDK 25，将 `RuntimeLibrary.java`、`RuntimeLibraryCatalog.java`、`LibraryDownloader.java`、`RuntimeClassLoader.java` 与探针编译到 `lib/verification/classes/`，然后执行 `java -cp lib/verification/classes RuntimeLibrariesProbe target/loader-probe`。
