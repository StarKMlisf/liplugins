> 后续版本1.13.0已加入Folia区域调度，HUD与安全卸载也继续保留；最新同Jar验证见 [1.13.0验证记录](VERIFICATION-1.13.0.md)。下文保留1.10.2历史证据。

# LiSkills 1.10.2 验证记录

环境：2026-08-31，Java25.0.3，Windows，Paper26.1.2 build74。生产源码先以Spigot26.1.2编译，再以实际目标Paper API交叉编译；没有使用Paper独占API、NMS或Folia适配。

## 最终成品

- Jar：`LiSkills-1.10.2.jar`
- SHA-256：`C82563FAD2751CBBD361C1D9A99F6803BEE8EA7CE314FBC6410B2DFAD7E59DCC`
- 单元测试：**457项通过**，失败/错误/跳过均0。
- **14组Paper探针共2520项检查**（不计验证方式与未测边界说明行），10个协议客户端正常退出。
- **SQLite/MySQL各17项真实JDBC检查**，使用MySQL8.0.45隔离实例。失去写入回执是在实际提交后注入，不是模拟整个数据库。
- 离线迁移实跑：SQLite 33项、MySQL 33项，验证实际CLI、真实往返、冲突零覆盖与源文件不变。
- 上述全部检查使用同一个最终Jar；发行脚本核对每项SHA，不接受旧Jar证据。

## 五轮迭代

| 轮次 | 构建版本 | 单元测试 | 主题 |
| --- | --- | ---: | --- |
| 1 | 1.6.0 | 250 | 防刷和真实掉落归属 |
| 2 | 1.7.1 | 324 | 原版主动与生存平衡、药水取消修复 |
| 3 | 1.8.0 | 378 | 装备规则与自然来源、可选数据库 |
| 4 | 1.9.0 | 420 | 完整来源界面、职业奖励排行与离线迁移 |
| 5 | 1.10.2 | 457 | 完整生存技能、持久奖励账本、迁移预检与取消死亡防刷 |

每轮Jar和当轮通过的验证记录单独保存在`dist/iterations/`；其覆盖范围以对应JSON为准，并非每轮都跑最终全套。第三轮首次Sources检查因远端测试区块尚未进入方块模拟而失败；探针补上加载票据与60tick预热后，仍用原生倒塌及实际经验断言通过，没有手动替代上段竹子破坏。

## 最终Paper检查

| 探针 | 检查数 | 模式 | 重点 |
| --- | ---: | --- | --- |
| LiSkillsSmoke | 10 | 旧数值回归 | 独立启动、原子重载和命令 |
| LiSkillsMenuProbe | 93 | 旧数值回归 | 可配置菜单、来源分页和只读物品 |
| LiSkillsCompatibilityProbe | 76 | 旧数值回归 | 真实LiRealEnchant成功事件与去重 |
| LiSkillsGatheringProbe | 100 | 旧数值回归 | 采集队列、补种、取消及互斥 |
| LiSkillsPlayerProbe | 85 | 旧数值回归 | 协议登录及原生玩家采集 |
| LiSkillsAbilitiesProbe | 178 | 旧数值回归 | 保留的旧主动与魔力退款 |
| LiSkillsCustomContentProbe | 197 | 旧数值回归 | 真实CustomCrops/CustomFishing及成长兼容 |
| LiSkillsRpgProbe | 261 | 成长开启/控制数值 | 55被动、9属性、采集与宝藏 |
| LiSkillsCombatRpgProbe | 137 | 成长开启/控制数值 | 战斗、附魔、酿造及LRE共存 |
| LiSkillsAntiExploitProbe | 229 | 成长开启/控制数值 | 人工方块、取消、重放、区块持久标记 |
| LiSkillsAuraManaProbe | 109 | 成长开启/控制数值 | 8项Aura风格主动及真实取消退款 |
| LiSkillsItemProbe | 56 | 成长开启/控制数值 | 装备槽、属性/特性/经验、要求与LRE物品 |
| LiSkillsExtendedProbe | 91 | 默认生存平衡 | 默认生存平衡、奖励、职业、排行和导出 |
| LiSkillsSourcesProbe | 898 | 成长开启/控制数值 | 真实采集及移动、钓鱼、炼金与附魔交易契约 |

前七组保留既有回归数值，其中CustomContent还显式切入新成长阶段；后七组开启成长。Extended专门验证实际默认生存平衡，其他成长组使用受控数值便于确定触发结果，不把高概率测试参数当作默认服务器强度。

## 验证方式与边界

- Paper仅在本工程`target/runtime-paper`、127.0.0.1:25681运行；MySQL仅在新建测试目录和127.0.0.1:33317运行，未访问生产3306、未修改用户原附魔、宠物或AuraSkills项目。
- 协议玩家正常登录；部分采集调用Bukkit `Player.breakBlock`、实际掉落与区块保存，移动由正常位置协议推进。其他保护、物品交易、药水、第三方兼容检查采用真实实体/插件加公开事件注入和显式库存提交；不是所有操作都由真人客户端完成。
- 防刷包含人工矿物、精采回放、区块卸载后标记、最终取消、坐标替换、同事件重放及附魔连锁。安装前已有人工方块无法追溯。
- 生存强度验证包含11技能/55被动/9属性、常规主动最长20秒/冷却至少120秒/最高10阶，生命成长最多5颗心、暴击率点数上限15；外部插件附加能力不归LiSkills强制限制。
- 装备验收覆盖六槽、堆叠不倍增、严格要求、属性/特性/经验、外部PDC和LiRealEnchant附魔保留。Aura物品迁移仅显式支持的公开标签，未知数据拒绝猜测。
- 存储验收包括真实中文档案往返、单实例锁、版本冲突、写入回执丢失的幂等恢复、损坏档案拒绝以及不回退空YAML。不是多服同步。
- 职业/奖励验证包括自然经验归属、独立账本与PDC回滚、领取高水位、每日限额和无Vault失败路径；没有真实经济提供器的付款验收，不声称跨Vault/控制台命令具有原子事务。
- 尚未进行真人Java客户端视觉验收、长期多人压力测试、所有领地保护插件组合验收；不做基岩专项、不支持Folia。

## 第三方Jar

LiRealEnchant dev201、CustomCrops3.6.54、CustomFishing2.3.26的精确Jar哈希记录在对应结果JSON。商业插件Jar只供本机验证，不进入源码包或安装包；SQL驱动/API也不合并到插件Jar，运行时按固定版本和哈希加载。

## 可复现

1. `./build.ps1 -Offline`（首次没有API缓存时不加Offline）。
2. 先按[隔离验收环境](VERIFICATION-SETUP.md)准备Paper测试目录、协议库及本地工具路径，再使用 `./tools/run-verification.ps1` 顺序执行14组；自行合法提供文档所列第三方验证Jar。源码包不包含服务器、商业插件、SQL驱动或Node依赖，不能解压后直接运行探针。
3. 新建隔离MySQL8.0.45测试数据库后，运行 `python tools/run-storage-verification.py <java.exe路径> 33317 liskills_probe`；脚本不启动服务且拒绝3306。
4. 离线迁移回归方法见存储文档；保留源、目标和测试报告，不能针对生产目录运行探针。
5. `python tools/write-verification-report.py` 与 `python tools/package-release.py` 核对五轮记录和最终证据后生成报告/安装包。
