# 离线迁移技能档案

`ProfileMigrationTool`支持本插件的YAML、SQLite、MySQL任意两端组合，包括SQL迁回YAML。它是成品Jar中的独立Java入口，不启动Minecraft，不修改`storage.yml`，不会因为服务器配置切换而自动复制。**默认只预检，显式追加`--apply`才执行。**需使用已经包含默认预检的版本；较早的入口要求显式执行，不具备此默认预检模式。

只迁移UUID、名称、全部技能等级/本级经验、自定义技能、魔力和冷却。收入与奖励的权威高水位位于 `plugins/LiSkills/reward-ledger/<uuid>.ledger`，世界PDC中的相关值仅为镜像；技能迁移和 `/lsk export` 均不包含此账本，必须另行完整备份 `reward-ledger/`。选职、永久玩家属性加成、背包与物品仍保存在世界 `playerdata`，也要完整备份。请停服后分别保全技能存储、完整奖励账本目录、世界玩家数据三部分，不能用其中一份替代另外两份。旧技能私有SQL表不可直接当源，必须先通过已有旧档导入流程转换成本插件格式。

## 执行前

1. 停止源与目标LiSkills实例，停止会编辑这些档案的脚本、数据库管理工具。先保存两端和世界的完整副本。MySQL服务本身需要继续运行，插件与外部写入必须停止。
2. 准备两个**独立、互不包含**的数据目录。YAML源要有`players/`；SQLite源要有配置指定的现有数据库；MySQL源目录仍需存在，用于检查未解决恢复记录。
3. 准备两份完整的`storage.yml`，分别描述源与目标。可以复制现有配置后只修改副本。密码留在配置文件，不作为命令行参数传入；限制这两份文件的访问权限。
4. 单独指定驱动缓存目录，例如项目`lib/storage-api`。不能放进源数据目录，也不能用包含源目录的父目录充当缓存。下载仍校验固定SHA-256，不接受任意下载URL。SQLite本机库由驱动提取到Java临时目录，不写入源插件目录。
5. 若存在未解决`recovery/<uuid>.yml`/`.yml.tmp`、YAML玩家`.yml.tmp`或导出`INCOMPLETE.txt`，先保留副本并人工核对。工具拒绝跳过这些证据去迁移较旧档案。

目标可以已有其他UUID的档案。相同UUID必须所有字段完全一致（包括名称），才允许幂等跳过；不会合并等级、取较大值或覆盖不同档案。源/目标SQL配置不能指向同一数据库和表前缀；该组合的独占锁会拒绝第二次打开。

## Windows入口

使用JDK 25和已构建成品。公共API依赖集中放在`lib/api`，不需要也不能把它们塞入插件Jar。默认脚本会读取项目的`lib/api`；可用`-ApiDirectory`指定另一个已有依赖目录。以下路径是示例，应改成实际位置：

```powershell
& .\tools\migrate-storage.ps1 `
  -PluginJar 'C:\migration\LiSkills.jar' `
  -SourceDirectory 'C:\migration\old-data' `
  -SourceConfig 'C:\migration\from.yml' `
  -TargetDirectory 'C:\migration\new-data' `
  -TargetConfig 'C:\migration\to.yml' `
  -DriverDirectory 'C:\migration\drivers' `
  -ApiDirectory 'C:\migration\lib\api'
```

上面只预检，报告源档案数、待迁移、相同、冲突及目标现有数量。缺失目标不会初始化；现有目标只读。核对结果后使用相同命令追加`-Apply`才实际复制，执行阶段会重新读取和检查冲突，不沿用旧预检计划。`from.yml`和`to.yml`的`type`决定方向：

| 源type | 目标type | 典型用途 |
| --- | --- | --- |
| YAML | MYSQL | 从本地玩家文件转到独立数据库 |
| MYSQL | YAML | 从数据库导出可检查的独立玩家文件 |
| YAML | SQLITE | 从多个玩家文件转到本地数据库 |
| SQLITE | YAML | 从SQLite恢复独立玩家文件 |
| MYSQL/SQLITE | SQLITE/MYSQL | 不经中间YAML文件的数据库复制 |

MySQL数据库本身须提前建立，服务器需允许GET_LOCK。只预检需要读取相关表的SELECT权限；明确执行时目标另需CREATE、INSERT权限，常规插件运行还需要UPDATE权限。源账户只需SELECT及GET_LOCK权限，工具不会在源建表。目标表不存在时，预检报告待迁移数量而不创建，只有显式执行才能初始化自己的表。

也可以直接调用Java，Linux将classpath分隔符`;`改为`:`：

```text
java -cp "LiSkills.jar;lib/api/*" net.liplugins.liskills.internal.storage.migration.ProfileMigrationTool --source "old-data" --source-config "from.yml" --target "new-data" --target-config "to.yml" --drivers "drivers"
java -cp "LiSkills.jar;lib/api/*" net.liplugins.liskills.internal.storage.migration.ProfileMigrationTool --source "old-data" --source-config "from.yml" --target "new-data" --target-config "to.yml" --drivers "drivers" --apply
java -cp "LiSkills.jar;lib/api/*" net.liplugins.liskills.internal.storage.migration.ProfileMigrationTool --help
```

退出码0在预检模式表示读取完成且无冲突，**不表示已复制**；在`--apply`模式才表示复制后完整读回校验通过。预检存在冲突返回3，并仍输出全部计数；读取/配置/连接错误返回1，消息资源不能加载返回2。错误日志不打印密码和异常堆栈，但仍可能包含UUID、目录、账户/主机，请不要公开完整管理日志。

## 写入与只读边界

- 工具先锁定并完整读取源。源损坏时不会初始化目标目录/表。默认预检只读目标并统计全部冲突，不创建目标玩家档案。明确执行会重新锁定和读取目标，校验UUID唯一性、结构和全部冲突；发现任一不同档案时，**本次零玩家写入**。
- 预检的YAML玩家目录或SQLite文件不存在时返回空视图，连目标目录也不创建。MySQL在既有数据库取得会话锁，收到缺表错误1146/42S02后还会核对目标对象自身不存在，防止把损坏视图误当空表；已有SQLite数据库按引擎的大小写规则查询`sqlite_schema`。权限不足、断线、缺列和损坏结构都使预检失败，不伪装成空目标。SQLite主文件缺失却残留WAL/SHM/回滚日志也会拒绝，不忽略待恢复证据。[MySQL错误码说明](https://dev.mysql.com/doc/mysql-errors/8.0/en/server-error-reference.html#error_er_no_such_table)
- 创建目标时仅使用`insertIfAbsent`。YAML先完整写入同目录临时文件，再创建禁止替换的硬链接占用目标名称，随后清理临时名称；SQL只使用INSERT和主键约束，不把迁移转成UPDATE。即使其他进程绕过锁抢先创建同UUID，也不会覆盖它。YAML目标文件系统需支持硬链接（例如NTFS/ext4）；不支持时安全失败，请使用受支持的本地暂存目录，不降级为覆盖写入。
- 最后重新读取目标，核对“原目标+源”的完整并集。目标原有但不在源中的档案也必须原样保留。
- 这是逐档案提交，不是跨所有后端的全局事务。网络或磁盘在中途失败时，前面一部分可能已新增成功；源一直保留，修复后原参数重跑，相同已完成档案会跳过。不会为了回滚而删除已存在资料。
- 源YAML不改文件内容；源SQL接口拒绝save/insert，MySQL连接设为只读，不执行CREATE。SQLite用`mode=ro&immutable=1`读取，避免为只读WAL连接在源目录创建或改写共享内存文件；此模式以离线不变为前提，不能一边开数据库编辑器写源一边迁移。[SQLite只读WAL说明](https://www.sqlite.org/wal.html#read_only_databases)、[immutable约束](https://www.sqlite.org/uri.html#uriimmutable)
- 源和已经存在的目标持有与运行插件相同的独占权。YAML可能在已有玩家目录新建`players/.session.lock`，SQLite可能在已有数据库旁新建`<数据库名>.liskills.lock`；这是只读预检允许创建的管理文件，释放锁后保留空文件不代表仍被占用。完全缺失的文件型目标不创建锁或目录，其预检仅代表当时观测结果；真正执行时会重新获取目标锁和检查。MySQL使用会话GET_LOCK，不建锁表。此锁约束LiSkills实例，不约束绕过它的SQL客户端。预检若需下载驱动，仅写显式缓存与驱动自己的Java临时目录，这两类写入不属于玩家档案迁移。
- SQLite源若存在回滚`-journal`文件会拒绝读取，不会在只读迁移中猜测或修复未完成事务。请先备份，按数据库恢复流程处理；不要只删日志。WAL是数据库的一部分，不能丢弃后单独复制主文件。

## 部署迁移结果

成功后先核对数量和抽样字段。YAML/SQLite目标在独立目录，停服状态下保存原目录副本，再部署已核验的目标玩家目录或数据库及其必要伴随文件。MySQL目标无需搬动本地玩家文件，修改服务器`storage.yml`指向已核验的数据库/表前缀即可。**工具不会执行这些部署、移动、删除或配置修改。**

重启后再核对实际加载、经验增减、魔力及排行榜。保留原源资料直到确认所有流程正常。相同数据库/表前缀仍只支持一个LiSkills实例，迁移不等于跨服同步。

## 验证层次

单测覆盖全量冲突零写入、保留不同UUID、重复UUID拒绝、源读取失败、提交后回包丢失的幂等续跑、目标最终核验、YAML文件不覆盖、接口只读、源目录不初始化、恢复文件拒绝、命令行参数和真实YAML CLI往返。默认预检另覆盖缺失目标不创建、计数/退出码、MySQL缺表与权限/连接/结构错误区分、SQLite schema只读查询。SQL接口替身的这些单测不能描述为真实数据库验收。

`LiSkillsMigrationProbe`保留原17项真实JDBC/CLI迁移检查，并增加16项默认预检检查，每个数据库后端33项：缺失目录/文件/表无初始化、已有数据库缺表、损坏表不得当空目标、全部计数、冲突退出码、锁与行版本/文件SHA不变。`tools/run-storage-verification.py`会生成`Migration-SQLITE-result.json`及`Migration-MYSQL-result.json`。实际通过状态以最终发行验证报告为准，不凭源码存在宣称已完成。
