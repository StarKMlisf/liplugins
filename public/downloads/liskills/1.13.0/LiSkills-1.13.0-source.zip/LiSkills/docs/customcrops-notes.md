# CustomCrops 农耕兼容

本轮按实际 `CustomCrops-3.6.54.jar` 的公开 API 核对。LiSkills 不修改 CustomCrops、CraftEngine、作物配置或掉落，只把确认完成的成熟作物收获计入农耕技能。外部 API 反射封装位于 `lib/customcrops`，运行时从已启用的 CustomCrops 插件类加载器读取，不把 CustomCrops 代码和 Jar 打进 LiSkills 成品。

## 收获经验

- 用 CustomCrops 作物配置的 **作物 ID** 匹配经验，例如作物配置顶层 `tomato`；不是种子物品 ID、阶段模型 ID 或收获物品 ID。未单独配置的作物使用默认值，配置为 `0` 可以关闭对应奖励。
- 成熟要求为 `maxPoints > 0` 且 `CropBlock.point(state) >= maxPoints`，不按原版载体材质猜成熟度。
- 玩家直接破坏使用 `CropBreakEvent` 的 `BREAK` 原因；右键采摘使用主手 `CropInteractEvent`。爆炸、踩踏、物理破坏、自动生长和独立 `ACTION/CUSTOM` 事件不发经验。
- 上述事件只建立候选，**不会立即发经验**。之后必须收到同一玩家、世界和方块位置的 `QualityCropActionEvent` 或 `DropItemActionEvent`，最终产出中至少有一个非空气且数量大于零的物品。
- 至少等待下一 tick，复查主事件、右键动作附属的 `ACTION` 破坏和产出取消状态；产出被后置监听器清空或取消时不计入奖励。多个品质果实、种子和同一动作上下文中的多项掉落合并为一次经验。
- 同时要求 CustomCrops 的已加载作物状态移除、替换，或成长点数降低，证明发生了收获；只右键查看、水壶浇水或对永久成熟模型执行无状态变化的掉落动作不会发经验。
- 候选存活最多 8 tick，全服最多 2048 个，每份最多 16 个产出事件。不同动作上下文、同位置尚未结算时再次点击或破坏（包括另一名玩家）、延迟超过窗口、跨世界、退出重进或配置重载等歧义情况保守跳过；坐标占用独立于玩家，避免两人各自结算同一次状态变化。
- 不按掉落数量、品质数量或事件个数重复奖励；技能等级限制、权限、世界限制和经验倍率继续走 LiSkills 统一结算。

## 采集与补种避让

CustomCrops 管理的作物、花盆、喷灌器等方块由它自己维护。LiSkills 的原版方块经验、右键原版收获、丰收补种、树木连锁和平面挖掘会避让这些位置，不把载体方块当普通原版方块刷经验或补成小麦。

归属查询只读取已加载区块和 CustomCrops 的公开方块注册表；不调用加载区块的方法。成功收获后仍保留 4 tick 的有界位置记录，防止 CustomCrops 先移除模型、后执行的原版监听误发第二次经验。缓存最多 4096 个位置，极端超量时短暂保守避让。

关闭兼容经验开关只停止额外经验，**不会关闭安全避让**。没有安装 CustomCrops 时 LiSkills 正常工作；API 缺失或运行异常时只提示一次中文告警并关闭桥接，仍在对方插件启用时保守阻止技能处理无法确认的方块。修正依赖版本后重启服务器恢复。

## 明确边界

LiSkills 不代替 CustomCrops 补种，不修改品质、掉落数量、肥料、季节、生长速度、CraftEngine 模型或保护插件的决定。使用长延迟掉落、完全自定义命令发物品、非主手采摘、永久成熟且不改变状态等特殊动作链的作物，当前不会自动发技能经验，避免把不确定操作计为收获。

核对依据：[官方文档](https://momi.gtemc.cn/customcrops)、[公开 CropBlock 流程](https://github.com/Xiao-MoMi/Custom-Crops/blob/main/api/src/main/java/net/momirealms/customcrops/api/core/block/CropBlock.java)、[品质产出事件](https://github.com/Xiao-MoMi/Custom-Crops/blob/main/api/src/main/java/net/momirealms/customcrops/api/event/QualityCropActionEvent.java)、[单项产出事件](https://github.com/Xiao-MoMi/Custom-Crops/blob/main/api/src/main/java/net/momirealms/customcrops/api/event/DropItemActionEvent.java)。完整运行证据与未验收范围见本次版本的验证报告。
