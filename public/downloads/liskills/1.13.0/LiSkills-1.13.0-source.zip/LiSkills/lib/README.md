# 前置 API 与构建工具

运行 `build.ps1` 或 Maven `package` 时，编译使用的前置 API 及其传递依赖统一复制到 `lib/api/`。
这些文件仅供开发、检查和编译，不会进入 LiSkills 成品 Jar；无需把它们复制到服务器插件目录。

构建脚本优先使用指定的 Maven、环境中已安装的 Maven或用户工具缓存；没有可用 Maven 时，从 Maven Central 下载固定的 3.9.15，并校验官方 SHA-512，缓存在 `lib/build-tools/`。

服务器启动时优先使用已有的 MiniMessage / Adventure 库。缺失时，插件从固定的 Maven Central HTTPS 地址下载固定版本到 `plugins/LiSkills/lib/`，逐个校验内置 SHA-256；下载失败会给出中文原因并停用插件，不加载不完整文件。

编译 API：Spigot 26.1.2、PlaceholderAPI 2.11.6、Adventure 4.26.1。
自家附魔 API：LiSkills 1.4.1 沿用 `LiRealEnchantAPI-2.0.0-dev201.jar`，本轮未修改附魔，API存放在本目录供兼容回归及开发参考。API仍为v1，保留dev200引入的完成事件与上下文查询。开发目录的旧dev200 API仅为历史文件，不随本轮源码交付；编译联合探针明确选择dev201。生产桥接只调用公开接口/事件，不将API或附魔实现打入LiSkills Jar。

运行时安装的是 `LiRealEnchant2-2.0.0-dev201-paper26.jar`，不是上述 API Jar。dev201 修复附魔自身的补种取消、覆盖与种子消费问题。关闭 LiSkills 的附魔额外经验开关仍保留公开预检识别和同工具安全避让，详见 [兼容说明](../docs/COMPATIBILITY.md)。

运行基准：Paper 26.1.2 / Java 25。本版 LiSkills 不声明 Folia 支持。

本机验证额外将实际Paper26.1.2build74的API复制到`lib/verification-api/`；`tools/check-paper-api.ps1`让该API排在Spigot SNAPSHOT前交叉编译全部业务源码。只用于兼容验证，不进入源码包/安装包；本地存在隔离服API时`build.ps1`自动执行，以防同版本号不同实现缺少方法。

CustomCrops/CustomFishing公开API适配代码在`src/main/java/net/liplugins/liskills/lib/customcrops`和`lib/customfishing`，从已启用插件的类加载器绑定接口，编译自身插件不需要它们的Jar。开发验证专用的`lib/verification-dependencies/`由开发者自行放入合法取得的`CustomCrops-3.6.54.jar`与`CustomFishing-2.3.26.jar`，不纳入Git、源码包或安装包。技能不会自动下载这两款插件。
