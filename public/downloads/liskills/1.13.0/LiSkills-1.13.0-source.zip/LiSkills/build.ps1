[CmdletBinding()]
param(
    [string]$JavaHome,
    [string]$MavenHome,
    [switch]$SkipTests,
    [switch]$Offline
)

$ErrorActionPreference = 'Stop'
$projectDirectory = $PSScriptRoot
$mavenVersion = '3.9.15'

# 编译 API 对应 Java 25；优先显式参数，再尝试本机已有 JDK，避免误用 PATH 中的 Java 21。
$javaCandidates = @($JavaHome, $env:JAVA_HOME)
foreach ($jdkParent in @((Join-Path $env:ProgramFiles 'Eclipse Adoptium'), (Join-Path $env:ProgramFiles 'Java'))) {
    if (Test-Path -LiteralPath $jdkParent) {
        $javaCandidates += @(Get-ChildItem -LiteralPath $jdkParent -Directory -Filter 'jdk-25*' | Sort-Object Name -Descending | ForEach-Object FullName)
    }
}
$selectedJava = $null
foreach ($candidate in $javaCandidates) {
    if ([string]::IsNullOrWhiteSpace($candidate)) { continue }
    $releaseFile = Join-Path $candidate 'release'
    if ((Test-Path -LiteralPath (Join-Path $candidate 'bin/javac.exe')) -and (Test-Path -LiteralPath $releaseFile)) {
        if ((Get-Content -LiteralPath $releaseFile -Raw) -match 'JAVA_VERSION="25(?:\.|\+|\")') {
            $selectedJava = $candidate
            break
        }
    }
}
if (-not $selectedJava) {
    throw '没有找到 JDK 25。安装后使用 .\build.ps1 -JavaHome "JDK目录"。'
}

$mavenCandidates = @($MavenHome, (Join-Path $env:USERPROFILE ".cache/tooling/apache-maven-$mavenVersion"), (Join-Path $projectDirectory "lib/build-tools/apache-maven-$mavenVersion"))
$selectedMaven = $null
foreach ($candidate in $mavenCandidates) {
    if (-not [string]::IsNullOrWhiteSpace($candidate) -and (Test-Path -LiteralPath (Join-Path $candidate 'bin/mvn.cmd'))) {
        $selectedMaven = Join-Path $candidate 'bin/mvn.cmd'
        break
    }
}
if (-not $selectedMaven) {
    if ($Offline) { throw '离线构建未找到 Maven 3.9.15，请使用 -MavenHome 指定 Maven 目录。' }
    $toolsDirectory = Join-Path $projectDirectory 'lib/build-tools'
    New-Item -ItemType Directory -Path $toolsDirectory -Force | Out-Null
    $archive = Join-Path $toolsDirectory "apache-maven-$mavenVersion-bin.zip"
    $archiveUri = "https://repo.maven.apache.org/maven2/org/apache/maven/apache-maven/$mavenVersion/apache-maven-$mavenVersion-bin.zip"
    Write-Host "正在从 Maven Central 下载 Maven $mavenVersion..."
    $checksumResponse = Invoke-WebRequest -Uri "$archiveUri.sha512" -TimeoutSec 30
    $checksumText = if ($checksumResponse.Content -is [byte[]]) { [Text.Encoding]::UTF8.GetString($checksumResponse.Content) } else { [string]$checksumResponse.Content }
    $expected = $checksumText.Trim().Split(' ')[0].ToUpperInvariant()
    if ($expected -notmatch '^[0-9A-F]{128}$') { throw '官方 Maven SHA-512 校验文件格式错误。' }
    Invoke-WebRequest -Uri $archiveUri -OutFile "$archive.part" -TimeoutSec 60
    $actual = (Get-FileHash -LiteralPath "$archive.part" -Algorithm SHA512).Hash
    if ($actual -ne $expected) { throw 'Maven 下载校验失败，未解压未运行。请检查网络后重试。' }
    Move-Item -LiteralPath "$archive.part" -Destination $archive -Force
    Expand-Archive -LiteralPath $archive -DestinationPath $toolsDirectory -Force
    $selectedMaven = Join-Path $toolsDirectory "apache-maven-$mavenVersion/bin/mvn.cmd"
}

$previousJavaHome = $env:JAVA_HOME
$previousPath = $env:PATH
$previousMavenOptions = $env:MAVEN_OPTS
try {
    $env:JAVA_HOME = $selectedJava
    $env:PATH = (Join-Path $selectedJava 'bin') + [IO.Path]::PathSeparator + $previousPath
    $env:MAVEN_OPTS = "$previousMavenOptions -Dfile.encoding=UTF-8 -Dstdout.encoding=UTF-8 -Dstderr.encoding=UTF-8 -Duser.language=en"
    Write-Host "Java: $selectedJava"
    Write-Host "Maven: $selectedMaven"
    $mavenArguments = @('-B', '-ntp', '-f', (Join-Path $projectDirectory 'pom.xml'), 'package')
    if ($SkipTests) { $mavenArguments += '-DskipTests=true' }
    if ($Offline) { $mavenArguments += '-o' }
    & $selectedMaven @mavenArguments
    if ($LASTEXITCODE -ne 0) { throw "Maven 构建失败，退出码 $LASTEXITCODE。" }

    [xml]$pom = Get-Content -LiteralPath (Join-Path $projectDirectory 'pom.xml') -Raw
    $artifact = Join-Path $projectDirectory "target/LiSkills-$($pom.project.version).jar"
    if (-not (Test-Path -LiteralPath $artifact)) { throw "没有找到构建成品：$artifact" }
    # 普通 Jar 必须只含自身类。此处再检查一次，防止以后误加 shade 导致依赖打入成品。
    $jarEntries = & (Join-Path $selectedJava 'bin/jar.exe') tf $artifact
    if ($LASTEXITCODE -ne 0) { throw '无法检查构建成品。' }
    foreach ($requiredEntry in @('plugin.yml', 'config.yml', 'skills.yml', 'messages.yml', 'menu.yml', 'abilities.yml', 'stats.yml', 'loot.yml', 'balance.yml', 'items.yml', 'mana_abilities.yml', 'sources.yml', 'xp_requirements.yml', 'rewards.yml', 'jobs.yml', 'leaderboards.yml', 'storage.yml', 'migration-messages.properties', 'storage-tool-messages.yml', 'net/liplugins/liskills/LiSkillsPlugin.class', 'net/liplugins/liskills/internal/LiSkillsRuntime.class')) {
        if ($jarEntries -notcontains $requiredEntry) { throw "成品缺少必要入口或配置：$requiredEntry" }
    }
    $foreignClasses = @($jarEntries | Where-Object { $_ -match '\.class$' -and $_ -notmatch '^net/liplugins/liskills/' })
    if ($foreignClasses.Count -gt 0) { throw "成品包含外部依赖类：$($foreignClasses[0])" }
    # 同名Spigot SNAPSHOT可能比目标Paper实现更早加入接口；本地有实际API时验证二者交集。
    $runtimeApi=Join-Path $projectDirectory 'target/runtime-paper/libraries/io/papermc/paper/paper-api/26.1.2.build.74-stable/paper-api-26.1.2.build.74-stable.jar'
    if(Test-Path -LiteralPath $runtimeApi) {
        & (Join-Path $projectDirectory 'tools/check-paper-api.ps1') -JavaHome $selectedJava -PaperApiSource $runtimeApi
    }
    $hash = (Get-FileHash -LiteralPath $artifact -Algorithm SHA256).Hash
    Write-Host "成品：$artifact"
    Write-Host "SHA-256：$hash"
    Write-Host '依赖 API 已复制到 lib/api；成品不包含外部依赖。'
} finally {
    $env:JAVA_HOME = $previousJavaHome
    $env:PATH = $previousPath
    $env:MAVEN_OPTS = $previousMavenOptions
}
