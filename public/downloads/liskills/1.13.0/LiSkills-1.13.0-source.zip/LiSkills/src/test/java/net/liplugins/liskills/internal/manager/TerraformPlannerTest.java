package net.liplugins.liskills.internal.manager;

import net.liplugins.liskills.internal.config.TerraformSettings;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Proxy;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.*;

class TerraformPlannerTest {
    private static final Set<Material> DIRT_ONLY = Set.of(Material.DIRT);

    @Test
    void configurationCannotExpandSafeTerrainWhitelistOrEnableZeroExperienceSources() {
        Map<Material, Double> sources = new HashMap<>();
        sources.put(Material.DIRT, 0.3);
        sources.put(Material.GRAVEL, 1.5);
        sources.put(Material.SAND, 0.0);
        sources.put(Material.CLAY, -1.0);
        sources.put(Material.MUD, Double.NaN);
        sources.put(Material.RED_SAND, Double.POSITIVE_INFINITY);
        sources.put(Material.CHEST, 100.0);
        sources.put(Material.DIAMOND_ORE, 100.0);
        sources.put(Material.FARMLAND, 100.0);
        sources.put(Material.DIRT_PATH, 100.0);
        sources.put(Material.MUDDY_MANGROVE_ROOTS, 100.0);
        assertEquals(Set.of(Material.DIRT, Material.GRAVEL), TerraformPlanner.allowedMaterials(sources));
    }

    @Test
    void onlySameMaterialFourNeighborConnectionsOnOriginalHeightAreSelected() {
        TerraformPlanner.Position origin = position(0, 65, 0);
        Map<TerraformPlanner.Position, Material> world = Map.of(
                origin, Material.DIRT, position(1, 65, 0), Material.DIRT,
                position(2, 65, 0), Material.DIRT, position(-1, 65, 0), Material.SAND,
                position(-1, 65, -1), Material.DIRT, position(0, 64, 0), Material.DIRT,
                position(0, 66, 0), Material.DIRT);
        Set<TerraformPlanner.Position> queried = new HashSet<>();
        List<TerraformPlanner.Position> result = TerraformPlanner.scan(origin, limits(25, 256, 4),
                Set.of(Material.DIRT, Material.SAND), point -> {
                    queried.add(point);
                    return world.getOrDefault(point, Material.AIR);
                });
        assertEquals(Set.of(origin, position(1, 65, 0), position(2, 65, 0)), Set.copyOf(result));
        assertTrue(queried.stream().allMatch(point -> point.y() == 65), "扫描本身也不能访问上下层");
    }

    @Test
    void placedOrUnavailableBarrierCannotBeUsedToReachDirtBehindIt() {
        TerraformPlanner.Position origin = position(0, 64, 0);
        Set<TerraformPlanner.Position> queried = new HashSet<>();
        List<TerraformPlanner.Position> result = TerraformPlanner.scan(origin, limits(25, 256, 4), DIRT_ONLY, point -> {
            queried.add(point);
            if (point.equals(position(1, 64, 0))) return null;
            return point.z() == 0 && point.x() >= 0 ? Material.DIRT : Material.AIR;
        });
        assertEquals(List.of(origin), result);
        assertFalse(queried.contains(position(2, 64, 0)), "人工方块或未加载区块不能成为扩散路径");
    }

    @Test
    void denseTerrainObeysBothSelectionAndTotalLookupBudgets() {
        AtomicInteger scans = new AtomicInteger();
        List<TerraformPlanner.Position> limitedScans = TerraformPlanner.scan(position(0, 64, 0), limits(100, 8, 8),
                DIRT_ONLY, point -> { scans.incrementAndGet(); return Material.DIRT; });
        assertEquals(8, limitedScans.size());
        assertEquals(8, scans.get(), "起始格不能额外查询一次，扫描总量含起始格");
        scans.set(0);
        List<TerraformPlanner.Position> limitedBlocks = TerraformPlanner.scan(position(0, 64, 0), limits(3, 256, 8),
                DIRT_ONLY, point -> { scans.incrementAndGet(); return Material.DIRT; });
        assertEquals(3, limitedBlocks.size(), "总破坏上限含玩家手动破坏的起始格");
        assertEquals(3, scans.get());
        assertEquals(limitedBlocks.size(), new HashSet<>(limitedBlocks).size(), "交叉路径不能重复选择同一格");
    }

    @Test
    void negativeCoordinatesHaveSymmetricHorizontalRadius() {
        TerraformPlanner.Position origin = position(-17, -40, -1);
        List<TerraformPlanner.Position> result = TerraformPlanner.scan(origin, limits(100, 100, 2), DIRT_ONLY,
                point -> Material.DIRT);
        assertEquals(25, result.size());
        assertTrue(result.stream().allMatch(point -> point.y() == -40
                && Math.abs(point.x() - origin.x()) <= 2 && Math.abs(point.z() - origin.z()) <= 2));
    }

    @Test
    void integerCoordinateEdgesDoNotWrapAcrossTheWorld() {
        List<TerraformPlanner.Position> result = TerraformPlanner.scan(position(Integer.MAX_VALUE, 64, Integer.MIN_VALUE),
                limits(100, 100, 1), DIRT_ONLY, point -> Material.DIRT);
        assertEquals(4, result.size());
        assertTrue(result.stream().allMatch(point -> point.x() >= Integer.MAX_VALUE - 1
                && point.z() <= Integer.MIN_VALUE + 1));
    }

    @Test
    void unavailableOriginAndUnsafeMaterialNeverStartTraversal() {
        AtomicInteger scans = new AtomicInteger();
        assertTrue(TerraformPlanner.scan(position(0, 64, 0), limits(25, 256, 4), DIRT_ONLY,
                point -> { scans.incrementAndGet(); return null; }).isEmpty());
        assertEquals(1, scans.get());
        assertTrue(TerraformPlanner.scan(position(0, 64, 0), limits(25, 256, 4), Set.of(Material.CHEST),
                point -> Material.CHEST).isEmpty(), "即使调用方传入错误白名单，也不允许容器");
    }

    @Test
    void invalidLimitsAreRejectedInsteadOfCreatingUnlimitedJobs() {
        assertThrows(IllegalArgumentException.class, () -> TerraformPlanner.scan(position(0, 64, 0), limits(0, 256, 4),
                DIRT_ONLY, point -> Material.DIRT));
        assertThrows(IllegalArgumentException.class, () -> TerraformPlanner.scan(position(0, 64, 0), limits(25, 0, 4),
                DIRT_ONLY, point -> Material.DIRT));
        assertThrows(IllegalArgumentException.class, () -> TerraformPlanner.scan(position(0, 64, 0), limits(25, 256, 0),
                DIRT_ONLY, point -> Material.DIRT));
    }

    @Test
    void worldAccessChecksHeightAndLoadedNegativeChunkBeforeReadingBlocks() {
        AtomicInteger chunkQueries = new AtomicInteger();
        AtomicInteger blockQueries = new AtomicInteger();
        Block expected = (Block) Proxy.newProxyInstance(Block.class.getClassLoader(), new Class<?>[]{Block.class},
                (proxy, method, arguments) -> { throw new UnsupportedOperationException(method.getName()); });
        World world = (World) Proxy.newProxyInstance(World.class.getClassLoader(), new Class<?>[]{World.class},
                (proxy, method, arguments) -> switch (method.getName()) {
                    case "getMinHeight" -> -64;
                    case "getMaxHeight" -> 320;
                    case "isChunkLoaded" -> {
                        chunkQueries.incrementAndGet();
                        yield (int) arguments[0] == -2 && (int) arguments[1] == -1;
                    }
                    case "getBlockAt" -> { blockQueries.incrementAndGet(); yield expected; }
                    default -> throw new UnsupportedOperationException(method.getName());
                });
        assertNull(TerraformPlanner.loadedBlock(world, position(-17, -65, -1), location -> true));
        assertNull(TerraformPlanner.loadedBlock(world, position(-17, 320, -1), location -> true));
        assertEquals(0, chunkQueries.get());
        assertNull(TerraformPlanner.loadedBlock(world, position(0, 64, 0), location -> true));
        assertEquals(0, blockQueries.get(), "不得通过 getBlockAt 隐式加载区块");
        assertSame(expected, TerraformPlanner.loadedBlock(world, position(-17, -64, -1), location -> true));
        assertNull(TerraformPlanner.loadedBlock(world, position(-17, -64, -1), location -> false), "非所属区域即使区块已加载也不能访问方块");
        assertEquals(1, blockQueries.get());
    }

    private static TerraformPlanner.Position position(int x, int y, int z) {
        return new TerraformPlanner.Position(x, y, z);
    }

    private static TerraformSettings limits(int blocks, int scans, int radius) {
        return new TerraformSettings(blocks, scans, 4, radius);
    }
}
