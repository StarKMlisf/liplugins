package net.liplugins.liskills.internal.manager.passive.combat;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class XpConversionTest {
    @Test void partialAwardsAccumulateWithoutLosingFraction(){var result=XpConversion.convert(12.5,18,30);assertEquals(1,result.experience());assertEquals(.5,result.remainder());}
    @Test void exactThresholdHasNoResidual(){var result=XpConversion.convert(29.75,.25,30);assertEquals(1,result.experience());assertEquals(0,result.remainder());}
    @Test void manyExperiencePointsAreGrantedInOneBoundedOperation(){var result=XpConversion.convert(0,305,30);assertEquals(10,result.experience());assertEquals(5,result.remainder());}
    @Test void invalidInputNeverGrantsExperience(){for(double value:new double[]{Double.NaN,Double.POSITIVE_INFINITY,-1,0})assertEquals(0,XpConversion.convert(0,value,30).experience());}
    @Test void invalidThresholdCannotDivideByZero(){for(double value:new double[]{Double.NaN,Double.POSITIVE_INFINITY,-1,0,.001})assertEquals(0,XpConversion.convert(0,30,value).experience());}
    @Test void invalidSavedRemainderIsDiscarded(){assertEquals(1,XpConversion.convert(Double.NaN,30,30).experience());assertEquals(1,XpConversion.convert(-100,30,30).experience());}
    @Test void excessiveAwardsCannotOverflowNativeExperience(){var result=XpConversion.convert(0,Double.MAX_VALUE,.01);assertEquals(100_000,result.experience());assertTrue(result.remainder()>=0 && result.remainder()<.01);}
}
