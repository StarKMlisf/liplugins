package net.liplugins.liskills.internal.hook.customfishing;

import org.junit.jupiter.api.Test;
import java.util.stream.IntStream;
import static org.junit.jupiter.api.Assertions.assertEquals;

class CustomFishingClaimsConcurrencyTest {
    @Test void concurrentResultCallbacksCanOnlyClaimOneHookOnce() {
        var claims = new CustomFishingClaims<String>(128, 1000);
        assertEquals(1, IntStream.range(0, 128).parallel().filter(ignored -> claims.claim("hook", 10)).count());
        assertEquals(1, claims.size());
    }
}
