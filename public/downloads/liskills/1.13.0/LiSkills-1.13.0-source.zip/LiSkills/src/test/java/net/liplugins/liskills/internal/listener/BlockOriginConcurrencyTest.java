package net.liplugins.liskills.internal.listener;

import org.junit.jupiter.api.Test;
import java.util.stream.IntStream;
import static org.junit.jupiter.api.Assertions.assertEquals;

class BlockOriginConcurrencyTest {
    @Test void concurrentRegionsCannotClaimTheSameOriginChannelTwice() {
        var ledger = new BlockOriginLedger<String>(128);
        long stamp = ledger.capture("one-position");
        long successes = IntStream.range(0, 128).parallel().filter(ignored -> ledger.claim("one-position", stamp, 1)).count();
        assertEquals(1, successes);
        assertEquals(1, IntStream.range(0, 128).parallel().filter(ignored -> ledger.claim("one-position", stamp, 2)).count());
    }
}
