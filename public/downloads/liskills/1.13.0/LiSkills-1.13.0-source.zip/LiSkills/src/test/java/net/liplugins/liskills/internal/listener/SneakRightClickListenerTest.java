package net.liplugins.liskills.internal.listener;

import org.bukkit.Material;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SneakRightClickListenerTest {
    @Test
    void correspondingMainHandItemsMapToSkillsWithoutConfusingPickaxesAndAxes() {
        assertEquals("mining", SneakRightClickListener.skillFor(Material.DIAMOND_PICKAXE));
        assertEquals("foraging", SneakRightClickListener.skillFor(Material.NETHERITE_AXE));
        assertEquals("farming", SneakRightClickListener.skillFor(Material.IRON_HOE));
        assertEquals("fighting",SneakRightClickListener.skillFor(Material.DIAMOND_SWORD));
        assertNull(SneakRightClickListener.skillFor(Material.AIR));
        assertEquals("archery",SneakRightClickListener.skillFor(Material.BOW));
        assertEquals("fishing",SneakRightClickListener.skillFor(Material.FISHING_ROD));
        assertEquals("defense",SneakRightClickListener.skillFor(Material.SHIELD));
        assertNull(SneakRightClickListener.skillFor(Material.CROSSBOW));
    }
}
