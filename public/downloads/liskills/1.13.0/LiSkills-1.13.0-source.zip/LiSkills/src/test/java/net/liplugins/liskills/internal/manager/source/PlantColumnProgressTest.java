package net.liplugins.liskills.internal.manager.source;

import org.junit.jupiter.api.Test;
import java.util.List;
import static net.liplugins.liskills.internal.manager.source.PlantColumnProgress.State.*;
import static org.junit.jupiter.api.Assertions.*;

class PlantColumnProgressTest {
    @Test void nativeOneTickPerSegmentCollapsesAsOneBoundedTransaction() {
        var column=new PlantColumnProgress(3);
        assertEquals(new PlantColumnProgress.Decision(false,1),column.observe(List.of(REMOVED,ORIGINAL,ORIGINAL)));
        assertEquals(new PlantColumnProgress.Decision(false,2),column.observe(List.of(REMOVED,REMOVED,ORIGINAL)));
        assertEquals(new PlantColumnProgress.Decision(true,3),column.observe(List.of(REMOVED,REMOVED,REMOVED)));
    }
    @Test void NoOpRootDoesNotWaitForUnrelatedLaterBreak() {
        assertEquals(new PlantColumnProgress.Decision(true,0),new PlantColumnProgress(3).observe(List.of(ORIGINAL,ORIGINAL,ORIGINAL)));
    }
    @Test void UpperSegmentRemovedBeforeLiveLowerSegmentIsNotOriginalRootHarvest() {
        assertEquals(new PlantColumnProgress.Decision(true,0),new PlantColumnProgress(3).observe(List.of(REMOVED,ORIGINAL,REMOVED)));
    }
    @Test void ReplacementOrSourceGenerationInvalidatesPreviouslyObservedColumn() {
        var column=new PlantColumnProgress(3);column.observe(List.of(REMOVED,REMOVED,ORIGINAL));
        assertEquals(new PlantColumnProgress.Decision(true,0),column.observe(List.of(REMOVED,ORIGINAL,ORIGINAL)));
        assertEquals(new PlantColumnProgress.Decision(true,0),new PlantColumnProgress(3).observe(List.of(REMOVED,INVALID,ORIGINAL)));
    }
    @Test void StalledPhysicsHasHardDeadlineAndOnlyConfirmedPrefix() {
        var column=new PlantColumnProgress(3);
        for(int attempt=1;attempt<5;attempt++)assertFalse(column.observe(List.of(REMOVED,REMOVED,ORIGINAL)).finished());
        assertEquals(new PlantColumnProgress.Decision(true,2),column.observe(List.of(REMOVED,REMOVED,ORIGINAL)));
    }
    @Test void MaximumConfiguredColumnNeverCreatesUnboundedWait() {
        var column=new PlantColumnProgress(256);var states=new java.util.ArrayList<>(java.util.Collections.nCopies(256,ORIGINAL));states.set(0,REMOVED);
        for(int attempt=1;attempt<258;attempt++)assertFalse(column.observe(states).finished());
        assertTrue(column.observe(states).finished());assertThrows(IllegalArgumentException.class,()->new PlantColumnProgress(257));
    }
}
