package net.liplugins.liskills.internal.manager.passive.combat;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ForgingRepairMathTest {
    @Test void repairsOnlyObservedVanillaRepairAndNeverAddsDamage() {
        assertEquals(175, ForgingRepairMath.enhancedDamage(300, 200, 25));
        assertEquals(0, ForgingRepairMath.enhancedDamage(300, 20, 25));
        assertEquals(300, ForgingRepairMath.enhancedDamage(300, 300, 100));
        assertEquals(200, ForgingRepairMath.enhancedDamage(300, 200, Double.NaN));
        assertEquals(0, ForgingRepairMath.enhancedDamage(Integer.MAX_VALUE, 10, 1000));
    }
    @Test void skillRepairHasFinitePerEventCapAndDoesNotRepairTinyOrInvalidXp() {
        assertEquals(25, ForgingRepairMath.mendingAmount(50, 200));
        assertEquals(200, ForgingRepairMath.mendingAmount(1e9, 200));
        assertEquals(0, ForgingRepairMath.mendingAmount(.5, 200));
        assertEquals(0, ForgingRepairMath.mendingAmount(Double.POSITIVE_INFINITY, 200));
        assertEquals(0, ForgingRepairMath.mendingAmount(-2, 200));
    }
}
