package net.liplugins.liskills.internal.hook.customfishing;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CustomFishingEffectRulesTest {
    @Test void skillComposesWithExistingBaitRodAndLootMultipliers() {
        assertEquals(.4, CustomFishingEffectRules.adjusted(.8, .5), 1e-12);
        assertEquals(1.5, CustomFishingEffectRules.adjusted(3, .5), 1e-12);
    }
    @Test void zeroAndNeutralEffectsRemainUnchanged() {
        assertEquals(0, CustomFishingEffectRules.adjusted(0, .5));
        assertEquals(.8, CustomFishingEffectRules.adjusted(.8, 1));
    }
    @Test void invalidUpstreamNumbersAreNotReplacedWithInventedValidBonuses() {
        assertTrue(Double.isNaN(CustomFishingEffectRules.adjusted(Double.NaN, .5)));
        assertEquals(Double.POSITIVE_INFINITY, CustomFishingEffectRules.adjusted(Double.POSITIVE_INFINITY, .5));
        assertEquals(-2, CustomFishingEffectRules.adjusted(-2, .5));
    }
    @Test void invalidOrSlowingSkillMultipliersCannotChangeThirdPartyEffects() {
        for (double factor : new double[] {Double.NaN, Double.POSITIVE_INFINITY, -1, 0, 1.1})
            assertEquals(.8, CustomFishingEffectRules.adjusted(.8, factor));
        assertTrue(Double.isFinite(CustomFishingEffectRules.adjusted(Double.MAX_VALUE, .5)));
    }
}
