package net.liplugins.liskills.internal.manager;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class PotionApplicationRulesTest {
    @Test void nativeApiTrueButCancelledWithNoEffectIsFailure() {
        assertFalse(PotionApplicationRules.applied(true,2,100,false,-1,0,false));
    }
    @Test void cancelledUpgradeLeavingWeakerLongerEffectIsFailure() {
        assertFalse(PotionApplicationRules.applied(true,2,100,true,1,1000,false));
    }
    @Test void cancelledExtensionLeavingSameLevelShortEffectIsFailure() {
        assertFalse(PotionApplicationRules.applied(true,2,100,true,2,99,false));
    }
    @Test void fullyAppliedRequestedEffectCommits() {
        assertTrue(PotionApplicationRules.applied(true,2,100,true,2,100,false));
        assertTrue(PotionApplicationRules.applied(true,2,100,true,2,200,false));
    }
    @Test void unrelatedReplacedAmplifierDoesNotProveOurRequestedEffectSucceeded() {
        assertFalse(PotionApplicationRules.applied(true,2,100,true,8,1000,false));
        assertFalse(PotionApplicationRules.applied(false,2,100,true,2,100,false));
    }
    @Test void infiniteActualEffectIsRecognizedWithoutTreatingNegativeDurationAsOrdinaryTime() {
        assertTrue(PotionApplicationRules.applied(true,2,100,true,2,-1,true));
        assertFalse(PotionApplicationRules.applied(true,2,100,true,2,-1,false));
    }
}
