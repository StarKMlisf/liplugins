package net.liplugins.liskills.internal.config;

import org.bukkit.Material;
import org.bukkit.configuration.file.YamlConfiguration;
import org.junit.jupiter.api.Test;
import java.util.List;
import java.util.Set;
import static org.junit.jupiter.api.Assertions.*;

class ItemSettingsTest {
    private YamlConfiguration fixture() throws Exception {
        var yaml = new YamlConfiguration();
        yaml.loadFromString("""
                enabled: false
                message-cooldown-millis: 2000
                rules:
                  example:
                    enabled: true
                    name: '<gold>测试装备'
                    match:
                      materials: [DIAMOND_SWORD]
                      pdc-key: 'liskills:item_id'
                      pdc-value: 'Guardian_Blade'
                    slots: [main_hand, off_hand]
                    attributes: {strength: 5, speed: -2}
                    requirements: {fighting: 10, sorcery_2: 5}
                    uses: [attack, interact]
                """);
        return yaml;
    }
    private ItemSettings parse(YamlConfiguration yaml) {
        return ItemSettings.parse(yaml, material -> Set.of(Material.DIAMOND_SWORD, Material.DIAMOND_CHESTPLATE).contains(material));
    }

    @Test void parsesExplicitOptInAndCustomSkillRequirementsWithoutRewritingIdentity() throws Exception {
        var settings = parse(fixture());
        assertFalse(settings.enabled());
        assertEquals(2000, settings.messageCooldownMillis());
        var rule = settings.rules().getFirst();
        assertEquals("Guardian_Blade", rule.pdcValue());
        assertEquals(Set.of(ItemSlot.MAIN_HAND, ItemSlot.OFF_HAND), rule.slots());
        assertEquals(-2, rule.attributes().get("speed"));
        assertEquals(5, rule.requirements().get("sorcery_2"));
        assertEquals(Set.of(ItemUse.ATTACK, ItemUse.INTERACT), rule.uses());
    }
    @Test void permitsEmptyRuleSetAndInternalBackfillMarker() throws Exception {
        var yaml = new YamlConfiguration();
        yaml.loadFromString("enabled: false\nmessage-cooldown-millis: 0\nrules: {}\n__liskills_backfill: true\n");
        assertTrue(parse(yaml).rules().isEmpty());
        assertFalse(ItemSettings.disabled().enabled());
    }
    @Test void freezesRuleCollectionsAndOriginalParserSnapshot() throws Exception {
        var yaml = fixture(); var settings = parse(yaml); var rule = settings.rules().getFirst();
        yaml.set("rules.example.attributes.strength", 999);
        assertEquals(5, rule.attributes().get("strength"));
        assertThrows(UnsupportedOperationException.class, () -> settings.rules().clear());
        assertThrows(UnsupportedOperationException.class, () -> rule.attributes().clear());
        assertThrows(UnsupportedOperationException.class, () -> rule.requirements().clear());
        assertThrows(UnsupportedOperationException.class, () -> rule.slots().clear());
    }
    @Test void rejectsMissingOrPartialIdentityAndUnusableMaterial() throws Exception {
        var noIdentity = fixture(); noIdentity.set("rules.example.match.materials", List.of());
        noIdentity.set("rules.example.match.pdc-key", ""); noIdentity.set("rules.example.match.pdc-value", "");
        assertThrows(IllegalArgumentException.class, () -> parse(noIdentity));
        for (Object invalid : List.of("minecraft", "Other:Key", "bad key:value")) {
            var yaml = fixture(); yaml.set("rules.example.match.pdc-key", invalid);
            assertThrows(IllegalArgumentException.class, () -> parse(yaml));
        }
        var partial = fixture(); partial.set("rules.example.match.pdc-value", "");
        assertThrows(IllegalArgumentException.class, () -> parse(partial));
        for (String material : List.of("AIR", "WATER", "NOT_A_MATERIAL")) {
            var yaml = fixture(); yaml.set("rules.example.match.materials", List.of(material));
            assertThrows(IllegalArgumentException.class, () -> parse(yaml));
        }
    }
    @Test void rejectsWrongScalarsUnknownFieldsAndInvalidCustomSkillSyntax() throws Exception {
        for (Object number : new Object[]{Double.NaN, Double.POSITIVE_INFINITY, 100001, "5"}) {
            var yaml = fixture(); yaml.set("rules.example.attributes.strength", number);
            assertThrows(IllegalArgumentException.class, () -> parse(yaml));
        }
        for (Object number : new Object[]{0, 1.5, 1001, "10"}) {
            var yaml = fixture(); yaml.set("rules.example.requirements.fighting", number);
            assertThrows(IllegalArgumentException.class, () -> parse(yaml));
        }
        var badSkill = fixture(); badSkill.set("rules.example.requirements.Bad-Skill", 5);
        assertThrows(IllegalArgumentException.class, () -> parse(badSkill));
        var badStat = fixture(); badStat.set("rules.example.attributes.armour", 5);
        assertThrows(IllegalArgumentException.class, () -> parse(badStat));
        var unknown = fixture(); unknown.set("enabld", true);
        assertThrows(IllegalArgumentException.class, () -> parse(unknown));
        var emptySlots = fixture(); emptySlots.set("rules.example.slots", List.of());
        assertThrows(IllegalArgumentException.class, () -> parse(emptySlots));
        var badUse = fixture(); badUse.set("rules.example.uses", List.of("teleport"));
        assertThrows(IllegalArgumentException.class, () -> parse(badUse));
    }
    @Test void permitsPdcOnlyBonusOnlyAndRequirementOnlyRules() throws Exception {
        var pdcOnly = fixture(); pdcOnly.set("rules.example.match.materials", List.of());
        pdcOnly.set("rules.example.uses", List.of());
        assertTrue(parse(pdcOnly).rules().getFirst().uses().isEmpty());
        var bonusOnly = fixture(); bonusOnly.set("rules.example.requirements", new YamlConfiguration());
        assertTrue(parse(bonusOnly).rules().getFirst().requirements().isEmpty());
        var requirementOnly = fixture(); requirementOnly.set("rules.example.attributes", new YamlConfiguration());
        assertTrue(parse(requirementOnly).rules().getFirst().attributes().isEmpty());
    }
}
