package net.liplugins.liskills.internal.manager;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ManaShieldMathTest {
    @Test void fullBalanceStillLeavesDamageAndOnlyPaysForAbsorption(){
        var result=ManaShieldMath.calculate(8,100,2,.75);
        assertEquals(6,result.damage());assertEquals(12,result.mana());
    }
    @Test void lowBalanceGivesPartialProtectionWithoutNegativeMana(){
        var result=ManaShieldMath.calculate(8,3,2,.75);
        assertEquals(1.5,result.damage());assertEquals(3,result.mana());
    }
    @Test void zeroAndInvalidDamageCannotProduceMoneyOrProtection(){
        for(double damage:new double[]{0,-1,Double.NaN,Double.POSITIVE_INFINITY}){
            var result=ManaShieldMath.calculate(damage,100,2,.75);
            assertEquals(0,result.damage());assertEquals(0,result.mana());
        }
    }
    @Test void invalidCurrencyAndImmuneRatiosAreRejected(){
        for(double rate:new double[]{0,-1,Double.NaN,Double.POSITIVE_INFINITY})assertEquals(0,ManaShieldMath.calculate(8,100,rate,.75).damage());
        for(double ratio:new double[]{0,-1,1,1.1,Double.NaN})assertEquals(0,ManaShieldMath.calculate(8,100,2,ratio).damage());
        assertEquals(0,ManaShieldMath.calculate(8,0,2,.75).damage());
    }
    @Test void fractionalCostNeverExceedsAvailableMana(){
        var result=ManaShieldMath.calculate(999,1.1,3.3,.95);
        assertTrue(result.mana()<=1.1);assertTrue(result.damage()>0 && result.damage()<999);
    }
}
