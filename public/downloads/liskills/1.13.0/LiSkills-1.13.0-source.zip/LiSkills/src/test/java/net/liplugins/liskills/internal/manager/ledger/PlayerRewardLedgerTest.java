package net.liplugins.liskills.internal.manager.ledger;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import static org.junit.jupiter.api.Assertions.*;

class PlayerRewardLedgerTest {
    @TempDir Path root;
    private final UUID player=UUID.randomUUID();
    private LedgerState empty(){return new LedgerState(20_000,0,Map.of());}
    private PlayerRewardLedger.RewardRequest request(String key,int oldLevel,int newLevel){return new PlayerRewardLedger.RewardRequest(key,oldLevel,newLevel,2,1,1000);}

    @Test void firstIncomeImportsLegacyOnceAndSurvivesMirrorRollbackAndRestart()throws Exception {
        AtomicInteger imports=new AtomicInteger();
        try(var ledger=new PlayerRewardLedger(root)){
            var reservation=ledger.reserveIncome(player,20_000,40,100,()->{imports.incrementAndGet();return new LedgerState(20_000,70,Map.of("reward_old_mining",10));});
            assertEquals(30,reservation.amount());assertEquals(100,ledger.snapshot(player).income());assertEquals(10,ledger.snapshot(player).rewardHighWatermarks().get("reward_old_mining"));
        }
        try(var restarted=new PlayerRewardLedger(root)){
            assertEquals(0,restarted.reserveIncome(player,20_000,40,100,()->{imports.incrementAndGet();return empty();}).amount());
            assertEquals(1,imports.get());assertEquals(100,restarted.snapshot(player).income());
        }
    }
    @Test void incomeRolloverUsesUtcDayAndClockRollbackCannotResetBudget()throws Exception {
        try(var ledger=new PlayerRewardLedger(root)){
            assertEquals(100,ledger.reserveIncome(player,20_000,100,100,this::empty).amount());
            assertEquals(0,ledger.reserveIncome(player,19_999,100,100,this::empty).amount());
            assertEquals(25,ledger.reserveIncome(player,20_001,25,100,this::empty).amount());
            assertEquals(20_001,ledger.snapshot(player).incomeDay());assertEquals(25,ledger.snapshot(player).income());
            assertEquals(0,ledger.reserveIncome(player,20_000,100,100,this::empty).amount());
        }
    }
    @Test void loweredLimitDoesNotErasePreviouslyAttemptedIncome()throws Exception {
        try(var ledger=new PlayerRewardLedger(root)){
            ledger.reserveIncome(player,20_000,80,100,this::empty);
            assertEquals(0,ledger.reserveIncome(player,20_000,20,50,this::empty).amount());assertEquals(80,ledger.snapshot(player).income());
            assertEquals(20,ledger.reserveIncome(player,20_000,100,100,this::empty).amount());
        }
    }
    @Test void unrepresentableTinyIncomeCannotBePaidWithoutAdvancingTheLedger()throws Exception {
        try(var ledger=new PlayerRewardLedger(root)){
            ledger.reserveIncome(player,20_000,100,1000,this::empty);
            assertEquals(0,ledger.reserveIncome(player,20_000,1e-30,1000,this::empty).amount());assertEquals(100,ledger.snapshot(player).income());
        }
    }
    @Test void skippedLevelsAreCommittedBeforeTheBoundedAwardsAreReturned()throws Exception {
        String key="reward_quest_mining";
        try(var ledger=new PlayerRewardLedger(root)){
            var result=ledger.reserveRewards(player,List.of(request(key,1,7)),2,this::empty);
            assertEquals(List.of(2,3),result.awards().stream().map(PlayerRewardLedger.ClaimedReward::level).toList());
            assertEquals(7,ledger.snapshot(player).rewardHighWatermarks().get(key));
            assertTrue(ledger.reserveRewards(player,List.of(request(key,1,7)),2,this::empty).awards().isEmpty());
        }
        try(var restarted=new PlayerRewardLedger(root)){
            assertTrue(restarted.reserveRewards(player,List.of(request(key,1,7)),2,()->{throw new AssertionError("must not re-read rolled-back PDC");}).awards().isEmpty());
        }
    }
    @Test void globalRewardBudgetDoesNotLeaveOtherRulesReplayable()throws Exception {
        try(var ledger=new PlayerRewardLedger(root)){
            var result=ledger.reserveRewards(player,List.of(request("reward_first_mining",1,4),request("reward_second_mining",1,4)),2,this::empty);
            assertEquals(2,result.awards().size());assertEquals(Map.of("reward_first_mining",4,"reward_second_mining",4),result.state().rewardHighWatermarks());
        }
    }
    @Test void legacyRewardHighWatermarkIsImportedBeforeFirstIncomeOrReward()throws Exception {
        String key="reward_legacy_mining";
        try(var ledger=new PlayerRewardLedger(root)){
            var result=ledger.reserveRewards(player,List.of(request(key,1,10)),10,()->new LedgerState(20_000,50,Map.of(key,8)));
            assertEquals(List.of(9,10),result.awards().stream().map(PlayerRewardLedger.ClaimedReward::level).toList());
            assertEquals(50,ledger.snapshot(player).income());
        }
    }
    @Test void changingRulePeriodOnlyClaimsUnprocessedMatchingLevels()throws Exception {
        String key="reward_period_mining";
        try(var ledger=new PlayerRewardLedger(root)){
            var result=ledger.reserveRewards(player,List.of(new PlayerRewardLedger.RewardRequest(key,1,20,5,5,20)),10,this::empty);
            assertEquals(List.of(5,10,15,20),result.awards().stream().map(PlayerRewardLedger.ClaimedReward::level).toList());
            assertTrue(ledger.reserveRewards(player,List.of(request(key,1,20)),10,this::empty).awards().isEmpty());
        }
    }
    @Test void existingCorruptedFileNeverFallsBackToLegacyOrEmptyAndIsNotOverwritten()throws Exception {
        try(var ledger=new PlayerRewardLedger(root)){
            ledger.reserveIncome(player,20_000,20,100,this::empty);byte[] broken=Files.readAllBytes(ledger.path(player));broken[25]^=1;Files.write(ledger.path(player),broken);
            assertThrows(IOException.class,()->ledger.reserveIncome(player,20_000,5,100,()->{throw new AssertionError("corrupt file must not seed PDC");}));
            assertThrows(IOException.class,()->ledger.reserveRewards(player,List.of(request("reward_qa_mining",1,2)),2,this::empty));
            assertArrayEquals(broken,Files.readAllBytes(ledger.path(player)));
        }
    }
    @Test void interruptedTemporaryFileBlocksFirstSeedEvenWithoutPublishedLedger()throws Exception {
        Files.writeString(root.resolve(player+".ledger.tmp"),"interrupted");
        try(var ledger=new PlayerRewardLedger(root)){
            assertThrows(IOException.class,()->ledger.reserveIncome(player,20_000,5,100,()->{throw new AssertionError("unconfirmed temp must not seed");}));
            assertFalse(Files.exists(ledger.path(player)));assertEquals("interrupted",Files.readString(root.resolve(player+".ledger.tmp")));
        }
    }
    @Test void outputIoFailureCannotReturnAPaymentReservation()throws Exception {
        Path blocked=root.resolve("not-a-directory");Files.writeString(blocked,"keep");
        try(var ledger=new PlayerRewardLedger(blocked)){
            assertThrows(IOException.class,()->ledger.reserveIncome(player,20_000,5,100,this::empty));
            assertThrows(IOException.class,()->ledger.reserveRewards(player,List.of(request("reward_qa_mining",1,2)),2,this::empty));
        }
        assertEquals("keep",Files.readString(blocked));
    }
    @Test void failureDuringCommitNeverReturnsRewardsOrWritesAnEmptyFallback()throws Exception {
        try(var ledger=new PlayerRewardLedger(root)){
            assertThrows(IOException.class,()->ledger.reserveRewards(player,List.of(request("reward_qa_mining",1,2)),2,()->{
                Files.createDirectory(ledger.path(player));return empty();
            }));
            assertTrue(Files.isDirectory(ledger.path(player)));assertFalse(Files.exists(root.resolve(player+".ledger.tmp")));
        }
    }
    @Test void malformedLegacyCannotCreateAnAuthoritativeEmptyFile()throws Exception {
        try(var ledger=new PlayerRewardLedger(root)){
            assertThrows(IOException.class,()->ledger.reserveIncome(player,20_000,5,100,()->new LedgerState(20_000,Double.NaN,Map.of())));
            assertFalse(Files.exists(ledger.path(player)));
        }
    }
    @Test void directoryLockRefusesAnotherLiveWriterAndCloseDoesNotRewriteFiles()throws Exception {
        Path file;
        try(var first=new PlayerRewardLedger(root);var second=new PlayerRewardLedger(root)){
            first.reserveIncome(player,20_000,5,100,this::empty);file=first.path(player);
            assertThrows(IOException.class,()->second.reserveIncome(player,20_000,5,100,this::empty));
            Files.delete(file);
        }
        assertFalse(Files.exists(file));
    }
    @Test void allConfiguredRuleAndSkillPairsFitButFurtherKeysFailWithoutMutation()throws Exception {
        Map<String,Integer> full=new HashMap<>();for(int rule=0;rule<128;rule++)for(int skill=0;skill<64;skill++)full.put("reward_r"+rule+"_s"+skill,2);
        try(var ledger=new PlayerRewardLedger(root)){
            ledger.reserveIncome(player,20_000,5,100,()->new LedgerState(20_000,0,full));byte[] before=Files.readAllBytes(ledger.path(player));
            assertEquals(8192,ledger.snapshot(player).rewardHighWatermarks().size());assertTrue(before.length<LedgerCodec.MAX_BYTES);
            assertThrows(IOException.class,()->ledger.reserveRewards(player,List.of(request("reward_extra_mining",1,2)),1,this::empty));
            assertArrayEquals(before,Files.readAllBytes(ledger.path(player)));
        }
    }
    @Test void invalidIncomeAndRewardRequestsNeverReachPersistence()throws Exception {
        try(var ledger=new PlayerRewardLedger(root)){
            assertThrows(IllegalArgumentException.class,()->ledger.reserveIncome(player,20_000,Double.NaN,100,this::empty));
            assertThrows(IllegalArgumentException.class,()->ledger.reserveIncome(player,20_000,1,1_000_001,this::empty));
            var same=request("reward_qa_mining",1,2);assertThrows(IllegalArgumentException.class,()->ledger.reserveRewards(player,List.of(same,same),2,this::empty));
            assertNull(ledger.snapshot(player));
        }
    }
}
