package net.liplugins.liskills.internal.manager;

import org.bukkit.World;
import org.bukkit.block.Block;
import org.junit.jupiter.api.Test;
import java.lang.reflect.Proxy;
import static org.junit.jupiter.api.Assertions.*;

class GatheringRegionBoundaryTest {
    @Test void unownedTreePositionDoesNotEvenQueryChunkOrBlockState() {
        World world = (World) Proxy.newProxyInstance(World.class.getClassLoader(), new Class<?>[]{World.class},
                (proxy, method, args) -> switch (method.getName()) {
                    case "getMinHeight" -> -64;
                    case "getMaxHeight" -> 320;
                    default -> throw new AssertionError("foreign world access: " + method.getName());
                });
        assertNull(TreePlanner.loadedBlock(world, new TreeTraversal.Position(512, 80, 512), location -> false));
    }

    @Test void unownedTerraformPositionNeverLoadsOrReadsAChunk() {
        World world = (World) Proxy.newProxyInstance(World.class.getClassLoader(), new Class<?>[]{World.class},
                (proxy, method, args) -> switch (method.getName()) {
                    case "getMinHeight" -> -64;
                    case "getMaxHeight" -> 320;
                    default -> throw new AssertionError("foreign world access: " + method.getName());
                });
        assertNull(TerraformPlanner.loadedBlock(world, new TerraformPlanner.Position(-513, 80, -513), location -> false));
    }

    @Test void unownedReplantStopsBeforeWorldReadInventoryPaymentOrProtectionEvent() {
        Block foreign = (Block) Proxy.newProxyInstance(Block.class.getClassLoader(), new Class<?>[]{Block.class},
                (proxy, method, args) -> { throw new AssertionError("foreign block access: " + method.getName()); });
        var transaction = new CropReplantTransaction(null, event -> fail("must not send placement"), block -> false);
        assertEquals(CropReplantTransaction.Result.CHANGED,
                transaction.place(null, foreign, null, true, () -> { throw new AssertionError("must not query player"); }));
    }
}
