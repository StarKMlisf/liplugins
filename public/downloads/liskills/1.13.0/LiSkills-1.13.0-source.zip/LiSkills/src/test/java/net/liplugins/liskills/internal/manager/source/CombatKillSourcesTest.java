package net.liplugins.liskills.internal.manager.source;

import net.liplugins.liskills.internal.config.SkillDefinition;
import org.bukkit.Material;
import org.bukkit.entity.EntityType;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class CombatKillSourcesTest {
    private SkillDefinition skill(String id, boolean enabled, Map<EntityType, Double> mobs) {
        return new SkillDefinition(id, id, "来源测试", Material.PAPER, enabled, 100, 100, 100, Map.of(), mobs, 999, null);
    }

    @Test void nativeCombatTypesDoNotCrossAwardButExplicitOtherSkillsShareTheKill() {
        var definitions = List.of(skill("fighting", true, Map.of(EntityType.ZOMBIE, 2.0)),
                skill("archery", true, Map.of(EntityType.ZOMBIE, 3.0)),
                skill("hunting", true, Map.of(EntityType.ZOMBIE, 7.0)),
                skill("farming", true, Map.of(EntityType.ZOMBIE, 5.0)));
        assertEquals(Map.of("fighting", 2.0, "hunting", 7.0, "farming", 5.0), CombatKillSources.select(definitions, "fighting", EntityType.ZOMBIE));
        assertEquals(Map.of("archery", 3.0, "hunting", 7.0, "farming", 5.0), CombatKillSources.select(definitions, "archery", EntityType.ZOMBIE));
    }

    @Test void disabledOrMissingDefaultSkillDoesNotBlockOtherConfiguredSources() {
        var custom = skill("hunting", true, Map.of(EntityType.COW, 7.0));
        assertEquals(Map.of("hunting", 7.0), CombatKillSources.select(List.of(custom), "fighting", EntityType.COW));
        assertEquals(Map.of("hunting", 7.0), CombatKillSources.select(List.of(skill("fighting", false, Map.of(EntityType.COW, 2.0)), custom), "fighting", EntityType.COW));
        assertEquals(Map.of("hunting", 7.0), CombatKillSources.select(List.of(skill("archery", false, Map.of(EntityType.COW, 3.0)), custom), "archery", EntityType.COW));
    }

    @Test void disabledEmptyUnmappedAndNonPositiveSourcesDoNotConsumeADeath() {
        var definitions = List.of(skill("disabled", false, Map.of(EntityType.COW, 7.0)),
                skill("empty", true, Map.of()), skill("other", true, Map.of(EntityType.ZOMBIE, 7.0)),
                skill("zero", true, Map.of(EntityType.COW, 0.0)), skill("negative", true, Map.of(EntityType.COW, -1.0)),
                skill("invalid", true, Map.of(EntityType.COW, Double.NaN)));
        assertTrue(CombatKillSources.select(definitions, "fighting", EntityType.COW).isEmpty());
    }

    @Test void nonCombatDamageMustNotSelectAnyKillSource() {
        assertTrue(CombatKillSources.select(List.of(skill("hunting", true, Map.of(EntityType.COW, 7.0))), "fall", EntityType.COW).isEmpty());
    }

    @Test void resultIsAnImmutableSnapshotOfConfiguredPositiveRewards() {
        var result = CombatKillSources.select(List.of(skill("hunting", true, Map.of(EntityType.COW, 7.0))), "archery", EntityType.COW);
        assertThrows(UnsupportedOperationException.class, () -> result.put("fighting", 2.0));
    }
}
