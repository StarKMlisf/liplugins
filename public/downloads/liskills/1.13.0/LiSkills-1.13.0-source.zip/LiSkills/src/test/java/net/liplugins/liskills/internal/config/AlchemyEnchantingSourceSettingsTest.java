package net.liplugins.liskills.internal.config;

import org.bukkit.configuration.file.YamlConfiguration;
import org.junit.jupiter.api.Test;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import static org.junit.jupiter.api.Assertions.*;

class AlchemyEnchantingSourceSettingsTest {
    private YamlConfiguration defaults()throws Exception {
        var yaml=new YamlConfiguration();try(var in=getClass().getResourceAsStream("/sources.yml")){yaml.load(new InputStreamReader(in,StandardCharsets.UTF_8));}return yaml;
    }
    @Test void allAuraAlchemyAndEnchantingSourceCategoriesExistAtConservativeMultiplier()throws Exception {
        var yaml=defaults();var alchemy=AlchemySourceSettings.parse(yaml.getConfigurationSection("alchemy"));var enchanting=EnchantingSourceSettings.parse(yaml.getConfigurationSection("enchanting"));
        assertEquals(17,alchemy.experience().size());assertEquals(9,enchanting.experience().size());
        assertEquals(2.5,alchemy.xp("brew.awkward"));assertEquals(125,alchemy.xp("drink.enchanted-golden-apple"));
        assertEquals(7.5,enchanting.xp("table.weapon"));assertEquals(9,enchanting.xp("grindstone"));
        assertTrue(alchemy.requireSplashTarget());assertEquals(5,alchemy.maximumBrewingSteps());
    }
    @Test void administratorsCanRestoreAuraNumbersWithoutChangingSourceBehavior()throws Exception {
        var yaml=defaults();yaml.set("alchemy.experience-multiplier",1);yaml.set("enchanting.experience-multiplier",1);
        assertEquals(70,AlchemySourceSettings.parse(yaml.getConfigurationSection("alchemy")).xp("lingering.upgraded"));
        assertEquals(24,EnchantingSourceSettings.parse(yaml.getConfigurationSection("enchanting")).xp("anvil.armor"));
    }
    @Test void missingSectionsInvalidNumbersAndOversizedClaimStepsFailValidation()throws Exception {
        assertThrows(IllegalArgumentException.class,()->AlchemySourceSettings.parse(null));assertThrows(IllegalArgumentException.class,()->EnchantingSourceSettings.parse(null));
        var yaml=defaults();yaml.set("alchemy.maximum-brewing-steps",6);assertThrows(IllegalArgumentException.class,()->AlchemySourceSettings.parse(yaml.getConfigurationSection("alchemy")));
        var invalid=defaults();invalid.set("enchanting.experience.grindstone",Double.NaN);assertThrows(IllegalArgumentException.class,()->EnchantingSourceSettings.parse(invalid.getConfigurationSection("enchanting")));
    }
    @Test void invalidGrindstoneBlockListIsNotSilentlyIgnored()throws Exception {
        var yaml=defaults();yaml.set("enchanting.blocked-grindstone-enchants",java.util.List.of(123));
        assertThrows(IllegalArgumentException.class,()->EnchantingSourceSettings.parse(yaml.getConfigurationSection("enchanting")));
    }
}
