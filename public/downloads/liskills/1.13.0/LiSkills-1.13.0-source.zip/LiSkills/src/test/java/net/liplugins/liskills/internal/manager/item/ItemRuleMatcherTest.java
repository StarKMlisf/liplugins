package net.liplugins.liskills.internal.manager.item;

import net.liplugins.liskills.internal.config.ItemRule;
import net.liplugins.liskills.internal.config.ItemSlot;
import net.liplugins.liskills.internal.config.ItemUse;
import org.bukkit.Material;
import org.junit.jupiter.api.Test;
import java.util.Map;
import java.util.Set;
import static org.junit.jupiter.api.Assertions.*;

class ItemRuleMatcherTest {
    private ItemRule rule(boolean enabled, Set<Material> materials, String key, String value) {
        return new ItemRule("test", "测试", enabled, materials, key, value, Set.of(ItemSlot.MAIN_HAND), Map.of("strength", 1.0), Map.of(), Set.of(ItemUse.ATTACK));
    }
    @Test void materialOnlyNeverReadsOrModifiesPdc() {
        var rule = rule(true, Set.of(Material.DIAMOND_SWORD), "", "");
        assertTrue(ItemRuleMatcher.matches(rule, Material.DIAMOND_SWORD, key -> { fail("无PDC条件不能读取数据"); return null; }));
        assertFalse(ItemRuleMatcher.matches(rule, Material.IRON_SWORD, key -> { fail(); return null; }));
    }
    @Test void combinesMaterialAndTypedStringIdentityWithAnd() {
        var rule = rule(true, Set.of(Material.DIAMOND_SWORD), "liskills:item_id", "Blade");
        assertTrue(ItemRuleMatcher.matches(rule, Material.DIAMOND_SWORD, key -> "liskills:item_id".equals(key) ? "Blade" : null));
        assertFalse(ItemRuleMatcher.matches(rule, Material.IRON_SWORD, key -> "Blade"));
        assertFalse(ItemRuleMatcher.matches(rule, Material.DIAMOND_SWORD, key -> "blade"));
        assertFalse(ItemRuleMatcher.matches(rule, Material.DIAMOND_SWORD, key -> null));
    }
    @Test void pdcOnlyDoesNotMeanAnyItemMatches() {
        var rule = rule(true, Set.of(), "liskills:item_id", "staff");
        assertTrue(ItemRuleMatcher.matches(rule, Material.STICK, key -> "staff"));
        assertFalse(ItemRuleMatcher.matches(rule, Material.STICK, key -> "another_staff"));
        assertFalse(ItemRuleMatcher.matches(rule, Material.AIR, key -> "staff"));
        assertFalse(ItemRuleMatcher.matches(rule, Material.CAVE_AIR, key -> "staff"));
        assertFalse(ItemRuleMatcher.matches(rule, null, key -> "staff"));
    }
    @Test void disabledRuleDoesNotConsultItemIdentity() {
        assertFalse(ItemRuleMatcher.matches(rule(false, Set.of(), "liskills:item_id", "staff"), Material.STICK,
                key -> { fail("停用规则不读PDC"); return null; }));
    }
}
