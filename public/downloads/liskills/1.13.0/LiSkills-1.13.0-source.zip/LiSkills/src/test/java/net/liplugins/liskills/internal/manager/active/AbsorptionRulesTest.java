package net.liplugins.liskills.internal.manager.active;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class AbsorptionRulesTest {
    @Test void fullDamageConsumesExactMana(){assertEquals(8,AbsorptionRules.cost(4,50,2,20));}
    @Test void insufficientManaDoesNotPartiallyAbsorb(){assertEquals(0,AbsorptionRules.cost(4,7,2,20));}
    @Test void exactlyEmptyingManaIsRejectedLikeAura(){assertEquals(0,AbsorptionRules.cost(4,8,2,20));}
    @Test void survivalHitCeilingPreservesLargeDamage(){assertEquals(0,AbsorptionRules.cost(21,100,2,20));}
    @Test void ceilingIncludesItsBoundary(){assertEquals(40,AbsorptionRules.cost(20,100,2,20));}
    @Test void malformedInputsDoNotCreateFreeAbsorption(){
        for(double invalid:new double[]{-1,0,Double.NaN,Double.POSITIVE_INFINITY}){
            assertEquals(0,AbsorptionRules.cost(invalid,100,2,20));
            assertEquals(0,AbsorptionRules.cost(4,100,invalid,20));
            assertEquals(0,AbsorptionRules.cost(4,100,2,invalid));
        }
    }
    @Test void infiniteOrMissingManaIsRejected(){assertEquals(0,AbsorptionRules.cost(4,Double.NaN,2,20));assertEquals(0,AbsorptionRules.cost(4,Double.POSITIVE_INFINITY,2,20));}
}
