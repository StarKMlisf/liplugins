package net.liplugins.liskills.internal.manager;

import net.liplugins.liskills.internal.config.*;
import org.junit.jupiter.api.Test;
import java.util.Map;
import static org.junit.jupiter.api.Assertions.*;

class ActiveSkillProgressionTest {
    private static final BalanceSettings SURVIVAL=new BalanceSettings(true,Map.of(),Map.of());
    private static final BalanceSettings ORIGINAL=new BalanceSettings(false,Map.of(),Map.of());
    private static final ActiveGrowth GROWTH=new ActiveGrowth(true,6,20,5,-5,12);
    private ActiveSkill base(String type,int duration,int cooldown,double mana) {
        return new ActiveSkill(true,"测试","HASTE",0,duration,cooldown,5,mana,type);
    }
    @Test void rankIsCappedBeforeEveryGrowthCalculation() {
        var skill=base("SPEED_MINE",10,60,20);
        assertEquals(10,ActiveSkillProgression.rank(skill,GROWTH,true,1000,SURVIVAL));
        var actual=ActiveSkillProgression.resolve(skill,GROWTH,true,1000,SURVIVAL);
        assertEquals(20,actual.durationSeconds());assertEquals(120,actual.cooldownSeconds());
        assertEquals(128,actual.manaCost(),"应为20+9*12，不能先按原始20阶收取248魔力");
    }
    @Test void balanceDisabledRestoresOriginalRankDurationCooldownAndMana() {
        var skill=base("SPEED_MINE",10,60,20);
        assertEquals(20,ActiveSkillProgression.rank(skill,GROWTH,true,1000,ORIGINAL));
        var actual=ActiveSkillProgression.resolve(skill,GROWTH,true,1000,ORIGINAL);
        assertEquals(105,actual.durationSeconds());assertEquals(105,actual.cooldownSeconds());assertEquals(248,actual.manaCost());
    }
    @Test void exactUnlockBoundariesAndConfiguredGrowthLimitRemainEffective() {
        var skill=base("LIGHTNING_BLADE",5,120,20);
        assertEquals(0,ActiveSkillProgression.rank(skill,GROWTH,true,4,SURVIVAL));
        assertEquals(1,ActiveSkillProgression.rank(skill,GROWTH,true,5,SURVIVAL));
        assertEquals(1,ActiveSkillProgression.rank(skill,GROWTH,true,10,SURVIVAL));
        assertEquals(2,ActiveSkillProgression.rank(skill,GROWTH,true,11,SURVIVAL));
        assertEquals(10,ActiveSkillProgression.rank(skill,GROWTH,true,59,SURVIVAL));
        var onlyThree=new ActiveGrowth(true,6,3,5,-5,12);
        assertEquals(3,ActiveSkillProgression.rank(skill,onlyThree,true,1000,SURVIVAL));
    }
    @Test void disabledOrMissingGrowthStillHonorsTheIndependentSurvivalLimits() {
        var skill=base("POTION",90,95,7);
        for(ActiveGrowth growth:new ActiveGrowth[]{null,new ActiveGrowth(false,6,20,5,-5,12),GROWTH}) {
            var actual=ActiveSkillProgression.resolve(skill,growth,false,1000,SURVIVAL);
            assertEquals(20,actual.durationSeconds());assertEquals(120,actual.cooldownSeconds());assertEquals(7,actual.manaCost());
            assertEquals(1,ActiveSkillProgression.rank(skill,growth,false,1000,SURVIVAL));
        }
    }
    @Test void sharpHookIsInstantAndDoesNotInheritWindowDurationOrLongCooldown() {
        var hook=base("SHARP_HOOK",1,2,5);
        var actual=ActiveSkillProgression.resolve(hook,GROWTH,true,1000,SURVIVAL);
        assertEquals(1,actual.durationSeconds());assertEquals(1,actual.cooldownSeconds());assertEquals(113,actual.manaCost());
        assertEquals(10,ActiveSkillProgression.rank(hook,GROWTH,true,1000,SURVIVAL));
        var first=ActiveSkillProgression.resolve(hook,GROWTH,true,5,SURVIVAL);
        assertEquals(2,first.cooldownSeconds());assertEquals(5,first.manaCost());
    }
    @Test void chargedToggleIsAlwaysFreeAndHasNoActivationCooldownEvenWithCustomLegacyFields() {
        var toggle=base("AURA_CHARGED_SHOT",1,60,20);
        for(BalanceSettings balance:new BalanceSettings[]{SURVIVAL,ORIGINAL})for(boolean progression:new boolean[]{true,false}) {
            var actual=ActiveSkillProgression.resolve(toggle,GROWTH,progression,1000,balance);
            assertEquals(1,actual.durationSeconds());assertEquals(0,actual.cooldownSeconds());assertEquals(0,actual.manaCost());
        }
        assertEquals(10,ActiveSkillProgression.rank(toggle,GROWTH,true,1000,SURVIVAL));
    }
    @Test void oldChargedFishAndShieldTypesRetainWindowGrowthAndActivationCost() {
        for(String type:new String[]{"CHARGED_SHOT","QUICK_FISH","MANA_SHIELD"}) {
            var skill=base(type,10,60,20);var actual=ActiveSkillProgression.resolve(skill,GROWTH,true,1000,SURVIVAL);
            assertEquals(20,actual.durationSeconds());assertEquals(120,actual.cooldownSeconds());assertEquals(128,actual.manaCost());
            var original=ActiveSkillProgression.resolve(skill,GROWTH,true,1000,ORIGINAL);
            assertEquals(105,original.durationSeconds());assertEquals(105,original.cooldownSeconds());assertEquals(248,original.manaCost());
        }
    }
    @Test void customLimitsPreserveLongerCooldownAndLowerSkillRankLimits() {
        var settings=new BalanceSettings(true,Map.of(),Map.of(),new BalanceSettings.ActiveLimits(7,15,3));
        var skill=base("ABSORPTION",10,300,20);var actual=ActiveSkillProgression.resolve(skill,GROWTH,true,1000,settings);
        assertEquals(7,actual.durationSeconds());assertEquals(290,actual.cooldownSeconds());assertEquals(44,actual.manaCost());
        assertEquals(3,ActiveSkillProgression.rank(skill,GROWTH,true,1000,settings));
    }
}
