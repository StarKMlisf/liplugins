package net.liplugins.liskills.internal.config;

import net.liplugins.liskills.internal.manager.stat.*;
import net.liplugins.liskills.internal.storage.SkillProgress;
import org.bukkit.Material;
import org.bukkit.configuration.file.YamlConfiguration;
import org.junit.jupiter.api.Test;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;

class BalanceSettingsTest {
    private YamlConfiguration yaml(String file)throws Exception{var y=new YamlConfiguration();try(var in=getClass().getResourceAsStream("/"+file)){y.load(new InputStreamReader(in,StandardCharsets.UTF_8));}return y;}
    @Test void Level100SurvivalTotalsRemainCloseToVanilla()throws Exception{
        var balance=BalanceSettings.parse(yaml("balance.yml"));var stats=balance.apply(StatsSettings.parse(yaml("stats.yml")));
        Map<String,SkillDefinition> skills=new LinkedHashMap<>();Map<String,SkillProgress> progress=new HashMap<>();
        stats.growth().keySet().forEach(id->{skills.put(id,new SkillDefinition(id,id,id,Material.STONE,true,100,100,100,Map.of(),Map.of(),0,null));progress.put(id,new SkillProgress(100,0));});
        var values=StatGrowthCalculator.calculate(stats,skills,progress,id->true);
        assertTrue(StatTraits.value(stats,values,"hp")<=10);assertTrue(StatTraits.value(stats,values,"attack-damage")<=25);
        assertTrue(StatTraits.value(stats,values,"crit-chance")<=15);assertTrue(StatTraits.value(stats,values,"damage-reduction")<.2);
        assertTrue(StatTraits.value(stats,values,"gathering-luck")<=15);assertTrue(StatTraits.value(stats,values,"max-mana")<=120);
    }
    @Test void PassiveCapsPreventGuaranteedLootAndBleedEscalation()throws Exception{
        var balance=BalanceSettings.parse(yaml("balance.yml"));var stats=StatsSettings.parse(yaml("stats.yml"));
        var original=PassiveSettings.parse(yaml("abilities.yml"),stats.growth().keySet());var values=balance.apply(original);
        assertEquals(70,values.size());assertTrue(values.get("lucky_miner").value(1000)<=15);assertTrue(values.get("bleed").secondary(1000)<=1);
        assertEquals(original.keySet(),balance.passives().keySet());
        assertTrue(values.get("revival").value(1000)<=4);assertTrue(values.get("revival").secondary(1000)<=10);
        assertTrue(values.get("skill_mender").value(1000)<=5);assertTrue(values.get("thunder_fall").secondary(1000)<=25);
        assertTrue(values.get("xp_convert").value(2)>original.get("xp_convert").value(2));
        assertEquals(5,original.get("lucky_miner").value(2));assertEquals(0,values.get("lucky_miner").value(1));
    }
    @Test void DisabledLayerReturnsUnchangedDefinitions()throws Exception{var y=yaml("balance.yml");y.set("enabled",false);var balance=BalanceSettings.parse(y);var stats=StatsSettings.parse(yaml("stats.yml"));assertSame(stats,balance.apply(stats));}
    @Test void InvalidMultiplierRejectsWholeSnapshot()throws Exception{var y=yaml("balance.yml");y.set("stats.health.multiplier",Double.NaN);assertThrows(IllegalArgumentException.class,()->BalanceSettings.parse(y));}
    @Test void activeDefaultsAreExplicitAndOlderFilesWithoutTheSectionRemainReadable()throws Exception {
        var y=yaml("balance.yml");var settings=BalanceSettings.parse(y);
        assertEquals(new BalanceSettings.ActiveLimits(20,120,10),settings.active());
        y.set("active",null);assertEquals(settings.active(),BalanceSettings.parse(y).active());
    }
    @Test void invalidActiveLimitsRejectTheSnapshotInsteadOfSilentlyFallingBack()throws Exception {
        for(var edit:Map.<String,Object>of("maximum-duration-seconds",121,"minimum-cooldown-seconds",0,"maximum-rank",2.5).entrySet()) {
            var y=yaml("balance.yml");y.set("active."+edit.getKey(),edit.getValue());
            assertThrows(IllegalArgumentException.class,()->BalanceSettings.parse(y),edit.getKey());
        }
        var y=yaml("balance.yml");y.set("active",false);assertThrows(IllegalArgumentException.class,()->BalanceSettings.parse(y));
        assertThrows(IllegalArgumentException.class,()->new BalanceSettings.ActiveLimits(0,120,10));
    }
}
