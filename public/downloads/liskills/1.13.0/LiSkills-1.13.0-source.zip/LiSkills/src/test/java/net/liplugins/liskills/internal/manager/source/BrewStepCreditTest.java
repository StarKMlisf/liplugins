package net.liplugins.liskills.internal.manager.source;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class BrewStepCreditTest {
    @Test void consecutiveRecipesAccumulateUntilPlayerTakesTheBottle() {
        var credit=BrewStepCredit.first(10).append(15,5).append(25,5);
        assertEquals(3,credit.steps());assertEquals(50,credit.experience());
    }
    @Test void sixthAndLaterConversionsCannotInflateAnUntakenBottle() {
        var credit=BrewStepCredit.first(10);
        for(int i=0;i<20;i++)credit=credit.append(25,5);
        assertEquals(5,credit.steps());assertEquals(110,credit.experience());
    }
    @Test void configuredOneStepLimitKeepsOnlyTheFirstRealRecipe() {
        var credit=BrewStepCredit.first(2.5).append(100,1);
        assertEquals(1,credit.steps());assertEquals(2.5,credit.experience());
    }
}
