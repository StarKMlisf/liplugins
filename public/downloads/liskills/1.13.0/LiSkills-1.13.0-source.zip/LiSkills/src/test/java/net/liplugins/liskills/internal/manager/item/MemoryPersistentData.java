package net.liplugins.liskills.internal.manager.item;

import org.bukkit.NamespacedKey;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import java.lang.reflect.Proxy;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/** 仅验证Bukkit PDC类型/键读取契约，不模拟服务器物品或客户端。 */
final class MemoryPersistentData {
    private record Value(Class<?> primitive, Object value) { }
    static PersistentDataContainer create() {
        Map<NamespacedKey, Value> data = new LinkedHashMap<>();
        return (PersistentDataContainer) Proxy.newProxyInstance(PersistentDataContainer.class.getClassLoader(),
                new Class<?>[]{PersistentDataContainer.class}, (proxy, method, arguments) -> {
                    String name = method.getName();
                    if (name.equals("set")) {
                        data.put((NamespacedKey) arguments[0], new Value(((PersistentDataType<?,?>) arguments[1]).getPrimitiveType(), arguments[2])); return null;
                    }
                    if (name.equals("has")) {
                        Value value = data.get(arguments[0]);
                        return value != null && (arguments.length == 1 || value.primitive().equals(((PersistentDataType<?,?>) arguments[1]).getPrimitiveType()));
                    }
                    if (name.equals("get")) {
                        Value value = data.get(arguments[0]);
                        if (value == null) return null;
                        if (!value.primitive().equals(((PersistentDataType<?,?>) arguments[1]).getPrimitiveType())) throw new IllegalArgumentException("type mismatch");
                        return value.value();
                    }
                    if (name.equals("getKeys")) return Set.copyOf(data.keySet());
                    if (name.equals("isEmpty")) return data.isEmpty();
                    if (name.equals("remove")) { data.remove(arguments[0]); return null; }
                    if (name.equals("toString")) return data.toString();
                    throw new UnsupportedOperationException(name);
                });
    }
}
