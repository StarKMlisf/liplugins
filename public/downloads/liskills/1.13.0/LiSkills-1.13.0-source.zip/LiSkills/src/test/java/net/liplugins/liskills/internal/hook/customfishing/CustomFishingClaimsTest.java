package net.liplugins.liskills.internal.hook.customfishing;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CustomFishingClaimsTest {
    @Test void aHookCannotAwardTwiceBeforeItsHistoryExpires() {
        var claims = new CustomFishingClaims<String>(4, 100);
        assertTrue(claims.claim("hook-a", 10));
        assertFalse(claims.claim("hook-a", 11));
        assertFalse(claims.claim("hook-a", 109));
        assertTrue(claims.claim("hook-a", 110));
    }
    @Test void rejectedReplayDoesNotKeepAHistoryEntryAliveForever() {
        var claims = new CustomFishingClaims<String>(4, 100);
        claims.claim("hook-a", 10);
        for (long time = 11; time < 110; time++) assertFalse(claims.claim("hook-a", time));
        claims.clean(110);
        assertEquals(0, claims.size());
    }
    @Test void ownershipRefreshProtectsLongerLivedFishingHooks() {
        var claims = new CustomFishingClaims<String>(2, 100);
        claims.remember("a", 0);
        claims.remember("b", 10);
        claims.remember("a", 20);
        claims.remember("c", 30);
        assertEquals(2, claims.size());
        assertTrue(claims.contains("a", 110));
        assertFalse(claims.contains("b", 110));
        assertFalse(claims.contains("a", 120));
    }
    @Test void sustainedUniqueHooksCannotGrowTheMemoryLimit() {
        var claims = new CustomFishingClaims<Integer>(32, 1000);
        for (int id = 0; id < 100_000; id++) claims.remember(id, 0);
        assertEquals(32, claims.size());
        assertFalse(claims.contains(0, 1));
        assertTrue(claims.contains(99_999, 1));
        claims.clear();
        assertEquals(0, claims.size());
    }
}
