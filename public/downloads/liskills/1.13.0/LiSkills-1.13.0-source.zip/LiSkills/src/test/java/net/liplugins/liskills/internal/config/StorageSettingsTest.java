package net.liplugins.liskills.internal.config;

import org.bukkit.configuration.file.YamlConfiguration;
import org.junit.jupiter.api.Test;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import static org.junit.jupiter.api.Assertions.*;

class StorageSettingsTest {
    private YamlConfiguration yaml()throws Exception{
        var yaml=new YamlConfiguration();try(var resource=getClass().getResourceAsStream("/storage.yml")){assertNotNull(resource);yaml.load(new InputStreamReader(resource,StandardCharsets.UTF_8));}return yaml;
    }
    @Test void defaultRemainsYamlWithExplicitSecureMysqlAndLocalSqlite()throws Exception{
        var settings=StorageSettings.parse(yaml());assertEquals(StorageSettings.defaults(),settings);
        assertEquals(StorageSettings.Type.YAML,settings.type());assertEquals(StorageSettings.SslMode.VERIFY_IDENTITY,settings.mysql().sslMode());assertFalse(settings.mysql().allowPublicKeyRetrieval());
    }
    @Test void permitsEachBackendAndNeverEchoesPassword()throws Exception{
        for(String type:new String[]{"MYSQL","SQLITE","YAML"}){
            var yaml=yaml();yaml.set("type",type);yaml.set("mysql.password","do-not-log-this-secret");
            var settings=StorageSettings.parse(yaml);assertEquals(StorageSettings.Type.valueOf(type),settings.type());assertFalse(settings.toString().contains("do-not-log-this-secret"));
        }
    }
    @Test void rejectsUrlInjectionAndPathTraversal()throws Exception{
        for(String field:new String[]{"mysql.host","mysql.database","mysql.table-prefix"}){
            var yaml=yaml();yaml.set(field,"foo?password=secret");assertThrows(IllegalArgumentException.class,()->StorageSettings.parse(yaml));
        }
        for(String name:new String[]{"../data.sqlite","C:/data.sqlite","foo..sqlite","/tmp/sqlite","a\\b.sqlite"}){
            var yaml=yaml();yaml.set("sqlite.file",name);assertThrows(IllegalArgumentException.class,()->StorageSettings.parse(yaml));
        }
    }
    @Test void rejectsWrongTypesAndUnboundedTimeoutsButAllowsInternalBackfill()throws Exception{
        for(String field:new String[]{"mysql.port","mysql.connect-timeout-millis","mysql.socket-timeout-millis","mysql.query-timeout-seconds","shutdown-timeout-seconds","sqlite.busy-timeout-millis"}){
            var yaml=yaml();yaml.set(field,Double.NaN);assertThrows(IllegalArgumentException.class,()->StorageSettings.parse(yaml));
            yaml.set(field,0);assertThrows(IllegalArgumentException.class,()->StorageSettings.parse(yaml));
        }
        var yaml=yaml();yaml.set("__liskills_backfill",true);assertNotNull(StorageSettings.parse(yaml));yaml.set("mysql.typo",true);assertThrows(IllegalArgumentException.class,()->StorageSettings.parse(yaml));
    }
}
