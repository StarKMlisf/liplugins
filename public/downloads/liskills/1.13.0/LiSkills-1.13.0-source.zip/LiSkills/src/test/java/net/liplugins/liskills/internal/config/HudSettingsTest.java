package net.liplugins.liskills.internal.config;

import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.configuration.file.YamlConfiguration;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class HudSettingsTest {
    @Test void acceptsCompleteSnapshotAndExistingMessageKeys() {
        HudSettings settings = HudSettings.parse(configuration());
        settings.validateMessages(messages());
        assertTrue(settings.enabled());
        assertTrue(settings.defaultEnabled());
        assertEquals(10, settings.updateTicks());
        assertEquals(5, settings.experienceDurationSeconds());
        assertEquals(BarColor.BLUE, settings.mana().color());
        assertEquals(BarStyle.SOLID, settings.health().style());
    }

    @Test void invalidRefreshTimingCannotReplaceCurrentSnapshot() {
        for (Object value : new Object[]{0, 201, 1.5, "10", Double.NaN}) {
            var yaml = configuration();
            yaml.set("update-ticks", value);
            assertThrows(IllegalArgumentException.class, () -> HudSettings.parse(yaml));
        }
    }

    @Test void invalidExpiryAndBooleanFailBeforeRendering() {
        var yaml = configuration();
        yaml.set("experience-duration-seconds", 61);
        assertThrows(IllegalArgumentException.class, () -> HudSettings.parse(yaml));
        var invalid = configuration();
        invalid.set("default-enabled", "true");
        assertThrows(IllegalArgumentException.class, () -> HudSettings.parse(invalid));
    }

    @Test void unsupportedBarsAndInlineMessageTextAreRejected() {
        for (String path : new String[]{"health.color", "mana.style", "skill.message"}) {
            var yaml = configuration();
            yaml.set(path, "<red>生命 {health}");
            assertThrows(IllegalArgumentException.class, () -> HudSettings.parse(yaml));
        }
    }

    @Test void disabledBarStillValidatesItsConfigurationForSafeReenable() {
        var yaml = configuration();
        yaml.set("health.enabled", false);
        yaml.set("health.style", "UNKNOWN");
        assertThrows(IllegalArgumentException.class, () -> HudSettings.parse(yaml));
    }

    @Test void missingAndNonStringMessagesAreRejectedBeforeSnapshotPublication() {
        HudSettings settings = HudSettings.parse(configuration());
        for (Object invalid : new Object[]{"", 123, java.util.List.of("生命")}) {
            var messages = messages();
            messages.set("hud.health", invalid);
            assertThrows(IllegalArgumentException.class, () -> settings.validateMessages(messages));
        }
        var messages = messages();
        messages.set("hud.skill-maximum", null);
        assertThrows(IllegalArgumentException.class, () -> settings.validateMessages(messages));
    }

    @Test void caseInsensitiveEnumsKeepAdministratorChoice() {
        var yaml = configuration();
        yaml.set("health.color", "purple");
        yaml.set("health.style", "segmented_10");
        var settings = HudSettings.parse(yaml);
        assertEquals(BarColor.PURPLE, settings.health().color());
        assertEquals(BarStyle.SEGMENTED_10, settings.health().style());
    }

    private static YamlConfiguration configuration() {
        var result = new YamlConfiguration();
        result.set("enabled", true);
        result.set("default-enabled", true);
        result.set("update-ticks", 10);
        result.set("experience-duration-seconds", 5);
        for (String id : new String[]{"health", "mana", "skill"}) {
            result.set(id + ".enabled", true);
            result.set(id + ".color", id.equals("mana") ? "BLUE" : "RED");
            result.set(id + ".style", "SOLID");
            result.set(id + ".message", "hud." + id);
        }
        result.set("skill.maximum-message", "hud.skill-maximum");
        return result;
    }

    private static YamlConfiguration messages() {
        var result = new YamlConfiguration();
        for (String key : new String[]{"health", "mana", "skill", "skill-maximum"})
            result.set("hud." + key, "<red>{health} {mana} {skill}");
        return result;
    }
}
