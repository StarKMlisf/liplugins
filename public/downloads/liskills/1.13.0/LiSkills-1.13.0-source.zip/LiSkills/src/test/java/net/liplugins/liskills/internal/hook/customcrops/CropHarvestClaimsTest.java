package net.liplugins.liskills.internal.hook.customcrops;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CropHarvestClaimsTest {
    private static CropHarvestAttempt readyAttempt() {
        CropHarvestAttempt attempt = new CropHarvestAttempt(new Object(), 0);
        assertTrue(attempt.attach(new Object(), new Object(), 0));
        return attempt;
    }

    @Test void twoPlayersAtOneWorldPositionCannotBothConsumeOneStateChange() {
        CropHarvestClaims<String> claims = new CropHarvestClaims<>();
        CropHarvestAttempt firstPlayer = readyAttempt(), secondPlayer = readyAttempt();
        assertTrue(claims.reserve("world:1,64,1", firstPlayer));
        assertFalse(claims.reserve("world:1,64,1", secondPlayer));
        assertFalse(firstPlayer.commit(1, true, true, true));
        assertFalse(secondPlayer.commit(1, true, true, true));
    }

    @Test void unrelatedPlayersAndLocationsDoNotBlockEachOther() {
        CropHarvestClaims<String> claims = new CropHarvestClaims<>();
        CropHarvestAttempt first = readyAttempt(), second = readyAttempt();
        assertTrue(claims.reserve("world:1,64,1", first));
        assertTrue(claims.reserve("world:2,64,1", second));
        assertTrue(first.commit(1, true, true, true));
        assertTrue(second.commit(1, true, true, true));
    }

    @Test void anotherPlayersCancelledOrIneligibleClickInvalidatesAnUnsettledHarvest() {
        CropHarvestClaims<String> claims = new CropHarvestClaims<>();
        CropHarvestAttempt first = readyAttempt();
        assertTrue(claims.reserve("world:1,64,1", first));
        assertTrue(claims.conflict("world:1,64,1"));
        assertFalse(first.commit(1, true, true, true));
        assertFalse(claims.conflict("other-world:1,64,1"));
    }

    @Test void onlyOwningCandidateCanReleaseThePositionBeforeTheNextHarvest() {
        CropHarvestClaims<String> claims = new CropHarvestClaims<>();
        CropHarvestAttempt first = readyAttempt(), next = readyAttempt();
        assertTrue(claims.reserve("world:1,64,1", first));
        claims.release("world:1,64,1", next);
        assertFalse(claims.reserve("world:1,64,1", next));
        claims.release("world:1,64,1", first);
        CropHarvestAttempt fresh = readyAttempt();
        assertTrue(claims.reserve("world:1,64,1", fresh));
        assertTrue(fresh.commit(1, true, true, true));
    }
}
