package net.liplugins.liskills.internal.manager;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ManaMathTest {
    @Test void onlyMissingOldStateStartsFullAndZeroDoesNotRefill(){
        assertEquals(100,ManaMath.available(-1,100));
        assertEquals(0,ManaMath.available(0,100));
        assertEquals(0,ManaMath.spend(20,100,20));
    }
    @Test void lowerMaximumClampsButHigherMaximumDoesNotGrantFreeMana(){
        assertEquals(40,ManaMath.available(70,40));
        assertEquals(70,ManaMath.available(70,200));
    }
    @Test void badNumbersAndOverspendDoNotProduceABalance(){
        for(double bad:new double[]{-1,Double.NaN,Double.POSITIVE_INFINITY,101})assertThrows(IllegalArgumentException.class,()->ManaMath.spend(100,100,bad));
        assertThrows(IllegalArgumentException.class,()->ManaMath.available(-0.5,100));
    }
}
