package net.liplugins.liskills.internal.config;

import org.bukkit.configuration.file.YamlConfiguration;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class AuraManaSettingsTest {
    @Test void defaultsKeepOriginalAbilitySemanticsWithCaps(){
        AuraManaSettings settings=AuraManaSettings.defaults();
        assertEquals(5,settings.lightningBlade().percent(1));assertEquals(10,settings.lightningBlade().percent(2));
        assertEquals(50,settings.lightningBlade().percent(1000));assertEquals(0,settings.lightningBlade().percent(0));
        assertEquals(.5,settings.sharpHook().damage(1));assertEquals(5,settings.sharpHook().damage(1000));assertFalse(settings.sharpHook().allowPvp());
        assertEquals(3,settings.speedMine().hasteLevel());
    }
    @Test void completeConfigurationParses(){assertEquals(AuraManaSettings.defaults(),AuraManaSettings.parse(config()));}
    @Test void rejectsQuotedNumbers(){var config=config();config.set("sharp-hook.base-damage","0.5");assertThrows(IllegalArgumentException.class,()->AuraManaSettings.parse(config));}
    @Test void rejectsUnsafeDistance(){var config=config();config.set("sharp-hook.maximum-distance",65);assertThrows(IllegalArgumentException.class,()->AuraManaSettings.parse(config));}
    @Test void rejectsNonFiniteMultiplier(){var config=config();config.set("lightning-blade.maximum-attack-speed-percent",Double.NaN);assertThrows(IllegalArgumentException.class,()->AuraManaSettings.parse(config));}
    @Test void rejectsFractionalPotionLevel(){var config=config();config.set("speed-mine.haste-level",3.5);assertThrows(IllegalArgumentException.class,()->AuraManaSettings.parse(config));}
    @Test void missingBooleanFailsClosed(){var config=config();config.set("sharp-hook.allow-pvp",null);assertThrows(IllegalArgumentException.class,()->AuraManaSettings.parse(config));}
    private static YamlConfiguration config() {
        var result=new YamlConfiguration();
        result.set("lightning-blade.base-attack-speed-percent",5);result.set("lightning-blade.attack-speed-per-level",5);result.set("lightning-blade.maximum-attack-speed-percent",50);
        result.set("sharp-hook.base-damage",.5);result.set("sharp-hook.damage-per-level",.5);result.set("sharp-hook.maximum-damage",5);result.set("sharp-hook.maximum-distance",33);result.set("sharp-hook.allow-pvp",false);
        result.set("absorption.mana-per-damage",2);result.set("absorption.maximum-damage-per-hit",20);result.set("absorption.allow-environmental-damage",false);result.set("speed-mine.haste-level",3);
        return result;
    }
}
