package net.liplugins.liskills.internal.manager.hud;

import org.bukkit.NamespacedKey;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Proxy;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class HudPreferenceStoreTest {
    private static final NamespacedKey KEY = new NamespacedKey("liskills", "hud_enabled");

    @Test void missingPreferenceTracksDefaultWithoutSavingItAsAnOverride() {
        var data = container();
        var preferences = new HudPreferenceStore(KEY);
        assertTrue(preferences.enabled(data, true));
        assertFalse(preferences.enabled(data, false));
        assertFalse(data.has(KEY));
    }

    @Test void explicitChoiceSurvivesManagerRecreationAndChangedDefaults() {
        var data = container();
        new HudPreferenceStore(KEY).setEnabled(data, false);
        assertFalse(new HudPreferenceStore(KEY).enabled(data, true));
        assertEquals((byte) 0, data.get(KEY, PersistentDataType.BYTE));
        new HudPreferenceStore(KEY).setEnabled(data, true);
        assertTrue(new HudPreferenceStore(KEY).enabled(data, false));
    }

    @Test void malformedByteOnlyRemovesHudKeyAndFallsBackToConfiguredDefault() {
        var data = container();
        var other = new NamespacedKey("other", "setting");
        data.set(other, PersistentDataType.STRING, "unchanged");
        for (byte malformed : new byte[]{2, -1, 127}) {
            data.set(KEY, PersistentDataType.BYTE, malformed);
            assertFalse(new HudPreferenceStore(KEY).enabled(data, false));
            assertFalse(data.has(KEY));
        }
        assertEquals("unchanged", data.get(other, PersistentDataType.STRING));
    }

    @Test void wrongPersistentTypeCannotThrowDuringHudRefresh() {
        var data = container();
        data.set(KEY, PersistentDataType.STRING, "off");
        assertTrue(new HudPreferenceStore(KEY).enabled(data, true));
        assertFalse(data.has(KEY));
    }

    private record Stored(Class<?> type, Object value) { }
    private static PersistentDataContainer container() {
        Map<NamespacedKey, Stored> entries = new HashMap<>();
        return (PersistentDataContainer) Proxy.newProxyInstance(PersistentDataContainer.class.getClassLoader(),
                new Class<?>[]{PersistentDataContainer.class}, (proxy, method, arguments) -> {
                    NamespacedKey key = (NamespacedKey) arguments[0];
                    return switch (method.getName()) {
                        case "set" -> {
                            entries.put(key, new Stored(((PersistentDataType<?, ?>) arguments[1]).getPrimitiveType(), arguments[2]));
                            yield null;
                        }
                        case "has" -> entries.containsKey(key) && (arguments.length == 1
                                || entries.get(key).type().equals(((PersistentDataType<?, ?>) arguments[1]).getPrimitiveType()));
                        case "get" -> {
                            Stored value = entries.get(key);
                            if (value == null) yield null;
                            if (!value.type().equals(((PersistentDataType<?, ?>) arguments[1]).getPrimitiveType()))
                                throw new IllegalArgumentException("persistent data type mismatch");
                            yield value.value();
                        }
                        case "remove" -> { entries.remove(key); yield null; }
                        default -> throw new UnsupportedOperationException(method.getName());
                    };
                });
    }
}
