package net.liplugins.liskills.internal.manager.passive.gathering;

import net.liplugins.liskills.internal.config.LootEntrySettings;
import org.bukkit.Material;
import org.junit.jupiter.api.Test;
import java.util.List;
import java.util.Set;
import static org.junit.jupiter.api.Assertions.*;

class GatheringLootTest {
    @Test void weightedSelectionHasStableHalfOpenBoundaries() {
        var iron = new LootEntrySettings(Material.IRON_INGOT, 1, 1, 1, 0, Set.of(), null);
        var gold = new LootEntrySettings(Material.GOLD_INGOT, 3, 1, 1, 0, Set.of(), null);
        assertSame(iron, GatheringLoot.choose(List.of(iron, gold), 0));
        assertSame(iron, GatheringLoot.choose(List.of(iron, gold), .249999));
        assertSame(gold, GatheringLoot.choose(List.of(iron, gold), .25));
        assertSame(gold, GatheringLoot.choose(List.of(iron, gold), .999999));
    }
    @Test void emptyPoolAndInvalidRollNeverSelectItem() {
        var item = new LootEntrySettings(Material.IRON_INGOT, 1, 1, 1, 0, Set.of(), null);
        assertNull(GatheringLoot.choose(List.of(), .5));
        assertNull(GatheringLoot.choose(List.of(item), Double.NaN));
        assertNull(GatheringLoot.choose(List.of(item), 1));
    }
    @Test void eachPoolUsesItsDedicatedAuraAbility() {
        assertEquals("treasure_hunter", GatheringLoot.ability("fishing", "rare"));
        assertEquals("epic_catch", GatheringLoot.ability("fishing", "epic"));
        assertEquals("metal_detector", GatheringLoot.ability("excavation", "rare"));
        assertEquals("lucky_spades", GatheringLoot.ability("excavation", "epic"));
    }
}
