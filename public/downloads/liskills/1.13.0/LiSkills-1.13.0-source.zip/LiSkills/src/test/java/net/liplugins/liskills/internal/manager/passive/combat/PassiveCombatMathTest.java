package net.liplugins.liskills.internal.manager.passive.combat;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class PassiveCombatMathTest {
    @Test void attackBonusesCombineBeforeMultiplication(){assertEquals(12.2,PassiveCombatMath.attack(10,4,3,15),1e-9);}
    @Test void independentDefensesMultiply(){assertEquals(7.2,PassiveCombatMath.reduce(PassiveCombatMath.reduce(10,.2),.1),1e-9);}
    @Test void invalidDamageDoesNotBecomeHealingOrInfinity(){
        for(double damage:new double[]{-1,0,Double.NaN,Double.POSITIVE_INFINITY})assertEquals(0,PassiveCombatMath.attack(damage,100,100,100));
    }
    @Test void malformedBonusesAreIgnored(){assertEquals(10,PassiveCombatMath.attack(10,Double.NaN,Double.POSITIVE_INFINITY,-100));}
    @Test void reductionCannotProduceNegativeDamage(){assertEquals(.1,PassiveCombatMath.reduce(10,100),1e-9);assertEquals(10,PassiveCombatMath.reduce(10,Double.NaN));}
    @Test void extremeAdministratorValuesRemainBounded(){assertEquals(1_000_000,PassiveCombatMath.attack(Double.MAX_VALUE,Double.MAX_VALUE,100,100));}
}
