package net.liplugins.liskills.internal.manager.source;

import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryView;
import org.junit.jupiter.api.Test;
import java.lang.reflect.Proxy;
import java.util.concurrent.atomic.AtomicReference;
import static org.junit.jupiter.api.Assertions.*;

class SourceContainerChangesTest {
    private static final class Fixture {
        final AtomicReference<InventoryView> current=new AtomicReference<>();
        final Inventory inventory=(Inventory)Proxy.newProxyInstance(getClass().getClassLoader(),new Class<?>[]{Inventory.class},(p,m,a)->switch(m.getName()){
            case "getSize"->3;case "getType"->InventoryType.GRINDSTONE;case "hashCode"->System.identityHashCode(p);case "equals"->p==a[0];default->null;
        });
        final Player player=(Player)Proxy.newProxyInstance(getClass().getClassLoader(),new Class<?>[]{Player.class},(p,m,a)->switch(m.getName()){
            case "getOpenInventory"->current.get();case "hashCode"->System.identityHashCode(p);case "equals"->p==a[0];default->null;
        });
        final InventoryView view=view();
        Fixture(){current.set(view);}
        InventoryView view(){return (InventoryView)Proxy.newProxyInstance(getClass().getClassLoader(),new Class<?>[]{InventoryView.class},(p,m,a)->switch(m.getName()){
            case "getPlayer"->player;case "getTopInventory","getBottomInventory","getInventory"->inventory;case "getType"->InventoryType.GRINDSTONE;
            case "convertSlot"->a[0];case "hashCode"->System.identityHashCode(p);case "equals"->p==a[0];default->null;
        });}
        InventoryClickEvent click(int slot){return new InventoryClickEvent(view,slot==2?InventoryType.SlotType.RESULT:InventoryType.SlotType.CONTAINER,slot,ClickType.LEFT,InventoryAction.PICKUP_ALL);}
    }
    @Test void stableCompletedReceiptAndDuplicateSameEventRemainValid() {
        var fixture=new Fixture();var changes=new SourceContainerChanges();var event=fixture.click(2);var receipt=changes.begin(event);
        assertTrue(changes.valid(receipt));changes.onClick(event);assertNull(changes.begin(event));assertTrue(changes.valid(receipt));
    }
    @Test void closingOrReplacingViewCannotBorrowAnotherResultReceipt() {
        var fixture=new Fixture();var changes=new SourceContainerChanges();var receipt=changes.begin(fixture.click(2));
        fixture.current.set(fixture.view());assertFalse(changes.valid(receipt));
    }
    @Test void realInputChangeInvalidatesOldReceipt() {
        var fixture=new Fixture();var changes=new SourceContainerChanges();var receipt=changes.begin(fixture.click(2));
        changes.onClick(fixture.click(0));assertFalse(changes.valid(receipt));
    }
    @Test void lateCancelledInputChangeDoesNotInvalidateCompletedReceipt() {
        var fixture=new Fixture();var changes=new SourceContainerChanges();var receipt=changes.begin(fixture.click(2));var input=fixture.click(0);
        changes.onClick(input);input.setCancelled(true);assertTrue(changes.valid(receipt));
    }
    @Test void lateCancelledSecondResultDoesNotInvalidateFirstReceipt() {
        var fixture=new Fixture();var changes=new SourceContainerChanges();var receipt=changes.begin(fixture.click(2));var second=fixture.click(2);
        changes.onClick(second);assertNull(changes.begin(second));second.setCancelled(true);assertTrue(changes.valid(receipt));
    }
    @Test void collectToCursorFromPlayerInventoryCanChangeContainerInputs() {
        var fixture=new Fixture();var changes=new SourceContainerChanges();var receipt=changes.begin(fixture.click(2));
        var collect=new InventoryClickEvent(fixture.view,InventoryType.SlotType.CONTAINER,4,ClickType.DOUBLE_CLICK,InventoryAction.COLLECT_TO_CURSOR);
        changes.onClick(collect);assertFalse(changes.valid(receipt));
    }
    @Test void finishedReceiptAllowsNextIndependentTransaction() {
        var fixture=new Fixture();var changes=new SourceContainerChanges();var first=changes.begin(fixture.click(2));changes.finish(first);
        var second=changes.begin(fixture.click(2));assertNotNull(second);assertTrue(changes.valid(second));
    }
}
