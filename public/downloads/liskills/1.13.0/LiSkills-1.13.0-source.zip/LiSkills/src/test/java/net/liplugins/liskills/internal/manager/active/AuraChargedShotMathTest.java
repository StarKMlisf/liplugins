package net.liplugins.liskills.internal.manager.active;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class AuraChargedShotMathTest {
    @Test void fullDrawPaysTenManaAndGivesFivePercent(){var shot=AuraChargedShotMath.calculate(10,1,100,.5,25);assertEquals(10,shot.mana());assertEquals(1.05,shot.multiplier(),1e-9);}
    @Test void halfDrawPaysHalfAndScalesBonus(){var shot=AuraChargedShotMath.calculate(10,.5,100,.5,25);assertEquals(5,shot.mana());assertEquals(1.025,shot.multiplier(),1e-9);}
    @Test void lowManaUsesOnlyRemainingBalance(){var shot=AuraChargedShotMath.calculate(10,1,3,.5,25);assertEquals(3,shot.mana());assertEquals(1.015,shot.multiplier(),1e-9);}
    @Test void bonusIsCappedWithoutCreatingMana(){var shot=AuraChargedShotMath.calculate(100,1,100,10,25);assertEquals(100,shot.mana());assertEquals(1.25,shot.multiplier(),1e-9);}
    @Test void forceCannotExceedFullDraw(){assertEquals(10,AuraChargedShotMath.calculate(10,2,100,.5,25).mana());}
    @Test void emptyAndMalformedInputsDoNotBoost(){for(double value:new double[]{0,-1,Double.NaN,Double.POSITIVE_INFINITY}){assertEquals(0,AuraChargedShotMath.calculate(10,value,100,.5,25).mana());assertEquals(1,AuraChargedShotMath.calculate(10,1,value,.5,25).multiplier());}}
}
