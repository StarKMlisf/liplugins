package net.liplugins.liskills.internal.listener;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class BlockOriginLedgerTest {
    @Test void boundedColumnKeepaliveRetainsOriginalGenerationAndExistingClaims() {
        var ledger=new BlockOriginLedger<String>(8);long stamp=ledger.capture("column");assertTrue(ledger.claim("column",stamp,2));
        for(int tick=0;tick<258;tick++) { ledger.advance();assertTrue(ledger.unchanged("column",stamp));assertEquals(stamp,ledger.capture("column"));assertFalse(ledger.claim("column",stamp,2)); }
        ledger.change("column");assertFalse(ledger.unchanged("column",stamp));assertFalse(ledger.claim("column",stamp,1));
    }
    @Test void capturesShareGenerationButIndependentXpAndBonusAreEachClaimableOnce() {
        var ledger = new BlockOriginLedger<String>(8); long stamp = ledger.capture("ore");
        assertEquals(stamp, ledger.capture("ore"));
        assertTrue(ledger.claim("ore", stamp, 1)); assertFalse(ledger.claim("ore", stamp, 1));
        assertTrue(ledger.claim("ore", stamp, 2)); assertFalse(ledger.claim("ore", stamp, 2));
        assertEquals(stamp, ledger.capture("ore")); assertFalse(ledger.claim("ore", stamp, 1));
    }
    @Test void sameTickReplacementInvalidatesAllCallbacksButNotOtherLocations() {
        var ledger = new BlockOriginLedger<String>(8); long old = ledger.capture("ore"), neighbor = ledger.capture("tree");
        long replacement = ledger.change("ore");
        assertNotEquals(old, replacement); assertFalse(ledger.unchanged("ore", old));
        assertFalse(ledger.claim("ore", old, 2)); assertTrue(ledger.unchanged("tree", neighbor));
        assertTrue(ledger.claim("ore", replacement, 1));
    }
    @Test void chunkLifecycleInvalidatesEvenWhenPositionImmediatelyReloads() {
        var ledger = new BlockOriginLedger<String>(8); long before = ledger.capture("0:0/ore"), other = ledger.capture("1:0/ore");
        ledger.invalidate(key -> key.startsWith("0:0/")); long afterUnload = ledger.capture("0:0/ore");
        ledger.invalidate(key -> key.startsWith("0:0/"));
        assertFalse(ledger.unchanged("0:0/ore", before)); assertFalse(ledger.unchanged("0:0/ore", afterUnload));
        assertTrue(ledger.unchanged("1:0/ore", other));
    }
    @Test void expiredGenerationNeverBecomesValidAfterRecapture() {
        var ledger = new BlockOriginLedger<String>(8); long old = ledger.capture("ore");
        for (int tick = 0; tick < 5; tick++) ledger.advance();
        assertFalse(ledger.unchanged("ore", old)); assertNotEquals(old, ledger.capture("ore"));
    }
    @Test void fullLedgerFailsClosedIncludingEarlierPendingProofThenRecovers() {
        var ledger = new BlockOriginLedger<String>(1); long old = ledger.capture("ore");
        assertEquals(-1, ledger.change("another")); assertFalse(ledger.unchanged("ore", old));
        assertEquals(-1, ledger.capture("ore"));
        for (int tick = 0; tick < 5; tick++) ledger.advance();
        long next = ledger.capture("another"); assertTrue(next >= 0); assertTrue(ledger.unchanged("another", next));
        assertFalse(ledger.claim("ore", old, 1));
    }
}
