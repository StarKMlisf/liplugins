package net.liplugins.liskills.internal.manager.item;

import net.liplugins.liskills.internal.config.ItemRule;
import net.liplugins.liskills.internal.config.ItemSlot;
import org.junit.jupiter.api.Test;
import java.util.List;
import java.util.Map;
import java.util.Set;
import static org.junit.jupiter.api.Assertions.*;

class ItemAttributeCalculatorTest {
    private ItemRule rule(String id, Set<ItemSlot> slots, Map<String, Double> attributes) {
        return new ItemRule(id, id, true, Set.of(), "liskills:item_id", id, slots, attributes, Map.of(), Set.of());
    }
    @Test void BothHandsAndArmorContributeOncePerEquippedSlot() {
        var sword = rule("blade", Set.of(ItemSlot.MAIN_HAND, ItemSlot.OFF_HAND), Map.of("strength", 5.0));
        var armor = rule("armor", Set.of(ItemSlot.CHEST), Map.of("health", 8.0));
        var result = ItemAttributeCalculator.calculate(Map.of(ItemSlot.MAIN_HAND, List.of(sword), ItemSlot.OFF_HAND, List.of(sword), ItemSlot.CHEST, List.of(armor)));
        assertEquals(Map.of("strength", 10.0, "health", 8.0), result);
        assertThrows(UnsupportedOperationException.class, () -> result.put("strength", 99.0));
    }
    @Test void WrongSlotAndUnqualifiedEmptyRuleListProvideNoAttributes() {
        var armor = rule("armor", Set.of(ItemSlot.CHEST), Map.of("health", 8.0));
        assertTrue(ItemAttributeCalculator.calculate(Map.of(ItemSlot.MAIN_HAND, List.of(armor), ItemSlot.CHEST, List.of())).isEmpty());
    }
    @Test void MultipleMatchingRulesAddSignedValuesBeforeStatCaps() {
        var first = rule("first", Set.of(ItemSlot.MAIN_HAND), Map.of("strength", 5.0, "speed", -2.0));
        var second = rule("second", Set.of(ItemSlot.MAIN_HAND), Map.of("strength", -3.0, "speed", 1.0));
        assertEquals(Map.of("strength", 2.0, "speed", -1.0), ItemAttributeCalculator.calculate(Map.of(ItemSlot.MAIN_HAND, List.of(first, second))));
    }
}
