package net.liplugins.liskills.internal.config;

import org.bukkit.configuration.file.YamlConfiguration;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class AbsorptionActivationSettingsTest {
    @Test void missingNodesKeepOriginalReadyMode(){assertEquals(AbsorptionActivationSettings.defaults(),AbsorptionActivationSettings.parse(new YamlConfiguration()));}
    @Test void alternateGestureCanBeConfigured(){var yaml=new YamlConfiguration();yaml.set("absorption.activation-mode","SHIELD_RIGHT_CLICK");yaml.set("absorption.ready-seconds",6);assertEquals(new AbsorptionActivationSettings(AbsorptionActivationSettings.Mode.SHIELD_RIGHT_CLICK,6),AbsorptionActivationSettings.parse(yaml));}
    @Test void unknownModeIsRejected(){var yaml=new YamlConfiguration();yaml.set("absorption.activation-mode","UNKNOWN");assertThrows(IllegalArgumentException.class,()->AbsorptionActivationSettings.parse(yaml));}
    @Test void invalidReadyWindowIsRejected(){for(double invalid:new double[]{0,11,2.5,Double.NaN}){var yaml=new YamlConfiguration();yaml.set("absorption.ready-seconds",invalid);assertThrows(IllegalArgumentException.class,()->AbsorptionActivationSettings.parse(yaml));}}
}
