package net.liplugins.liskills.internal.manager.source;

import net.liplugins.liskills.internal.config.AgilitySourceSettings;
import org.junit.jupiter.api.Test;
import java.util.Map;
import static org.junit.jupiter.api.Assertions.*;

class AgilityProgressTest {
    private AgilitySourceSettings settings() { return new AgilitySourceSettings(true,20,30,10,10,4,3,4,30,120,100,Map.of("walk",.2,"sprint",.06,"swim",.6,"jump",7.0)); }
    private AgilityProgress.Snapshot at(double x,int walk,int sprint,int swim,int jumps,long time) { return new AgilityProgress.Snapshot(x,64,0,walk,sprint,swim,jumps,time); }
    private AgilityProgress tracker() { return new AgilityProgress(at(0,0,0,0,0,0)); }
    @Test void realWalkingNeedsRouteVarietyAndMinimumDistanceBeforeAuraRate() {
        var progress=tracker(); assertTrue(progress.sample(at(4,400,0,0,0,1000),settings()).isEmpty());
        assertTrue(progress.sample(at(8,800,0,0,0,2000),settings()).isEmpty());
        assertTrue(progress.sample(at(12,1200,0,0,0,3000),settings()).isEmpty());
        assertEquals(2.4,progress.sample(at(16,1600,0,0,0,4000),settings()).get("walk"),1e-8);
    }
    @Test void sprintAndSwimUseSeparateCountersAndRates() {
        for(String source:Map.of("sprint",.72,"swim",7.2).keySet()) {
            var progress=tracker(); Map<String,Double> earned=Map.of();
            for(int step=1;step<=4;step++)earned=progress.sample(at(step*4,0,source.equals("sprint")?step*400:0,source.equals("swim")?step*400:0,0,step*1000),settings());
            assertEquals(source.equals("sprint")?.72:7.2,earned.get(source),1e-8); assertEquals(1,earned.size());
        }
    }
    @Test void stationaryCounterChangesAndStationaryJumpingAreRejected() {
        var progress=tracker();
        for(int step=1;step<=20;step++)assertTrue(progress.sample(at(0,step*100,0,0,step,step*1000),settings()).isEmpty());
        progress=tracker();
        for(int step=1;step<=20;step++)assertTrue(progress.sample(at(0,0,0,0,step,step*1000),settings()).isEmpty());
    }
    @Test void teleportAndStatisticSpikeAreBaselinedWithoutLaterCatchup() {
        var progress=tracker(); assertTrue(progress.sample(at(4,400,0,0,0,1000),settings()).isEmpty());
        assertTrue(progress.sample(at(8,800,0,0,0,2000),settings()).isEmpty());
        assertTrue(progress.sample(at(100,10000,0,0,0,3000),settings()).isEmpty());
        assertTrue(progress.sample(at(104,10400,0,0,0,4000),settings()).isEmpty());
        assertTrue(progress.sample(at(108,10800,0,0,0,5000),settings()).isEmpty());
        assertEquals(2.4,progress.sample(at(112,11200,0,0,0,6000),settings()).get("walk"),1e-8);
    }
    @Test void negativeOrExcessiveCountersRejectEvenWithRealPositionChanges() {
        var progress=new AgilityProgress(at(0,1000,0,0,10,0));
        assertTrue(progress.sample(at(4,900,0,0,11,1000),settings()).isEmpty());
        assertTrue(progress.sample(at(8,1300,0,0,20,2000),settings()).isEmpty());
        assertTrue(progress.sample(at(12,100000,0,0,21,3000),settings()).isEmpty());
    }
    @Test void movingWithoutFreshInputExpiresAndDoesNotBankPendingDistance() {
        var progress=tracker(); double earned=0;
        for(int step=1;step<=40;step++) {
            var award=progress.sample(at(step*4,step*400,0,0,0,step*1000),settings());
            if(step>30)assertTrue(award.isEmpty()); earned+=award.getOrDefault("walk",0.0);
        }
        assertTrue(earned>0); progress.activity(40000);
        assertTrue(progress.sample(at(164,16400,0,0,0,41000),settings()).isEmpty());
        assertTrue(progress.sample(at(168,16800,0,0,0,42000),settings()).isEmpty());
        assertEquals(2.4,progress.sample(at(172,17200,0,0,0,43000),settings()).get("walk"),1e-8);
    }
    @Test void RepeatedShortRouteHasFiniteCellBudgetEvenWithContinuousActivity() {
        var progress=tracker(); int walked=0; double earned=0;
        for(int step=1;step<=100;step++) {
            int position=switch(step%4){case 1->4;case 2->8;case 3->12;default->8;};
            walked+=400; progress.activity(step*1000L);
            earned+=progress.sample(at(position,walked,0,0,0,step*1000L),settings()).getOrDefault("walk",0.0);
        }
        assertTrue(earned>0); assertTrue(earned<5,"finite 3 cells cannot reward 400 meters of looping");
    }
    @Test void trustedMovingJumpsKeepAuraThresholdAndMultiplier() {
        var settings=new AgilitySourceSettings(true,20,30,10,10,4,2,4,30,120,10,Map.of("walk",0.0,"sprint",0.0,"swim",0.0,"jump",7.0));
        var progress=tracker(); progress.sample(at(4,400,0,0,4,1000),settings); progress.sample(at(8,800,0,0,8,2000),settings);
        assertEquals(Map.of("jump",7.0),progress.sample(at(12,1200,0,0,12,3000),settings));
        assertTrue(progress.sample(at(16,1600,0,0,16,4000),settings).isEmpty());
        assertEquals(Map.of("jump",7.0),progress.sample(at(20,2000,0,0,20,5000),settings));
    }
    @Test void clockRollbackAndLongUnsampledGapClearPartialCounters() {
        var progress=tracker(); progress.sample(at(4,400,0,0,0,1000),settings()); progress.sample(at(8,800,0,0,0,2000),settings());
        assertTrue(progress.sample(at(12,1200,0,0,0,1900),settings()).isEmpty());
        assertTrue(progress.sample(at(16,1600,0,0,0,10000),settings()).isEmpty());
    }
    @Test void deniedMovementNeverBanksDistanceButAuthorizedJumpProgressContinues() {
        var settings=new AgilitySourceSettings(true,20,30,10,10,4,2,4,30,120,10,Map.of("walk",.2,"sprint",.06,"swim",.6,"jump",7.0));
        var progress=tracker();progress.sample(at(4,400,0,0,4,1000),settings,true,true);
        progress.sample(at(8,800,0,0,8,2000),settings,false,true);
        assertEquals(Map.of("jump",7.0),progress.sample(at(12,1200,0,0,12,3000),settings,true,true));
        assertTrue(progress.sample(at(16,1600,0,0,16,4000),settings,true,true).isEmpty());
        var earned=progress.sample(at(20,2000,0,0,20,5000),settings,true,true);
        assertEquals(2.4,earned.get("walk"),1e-8);assertEquals(7.0,earned.get("jump"),1e-8);assertEquals(2,earned.size());
    }
    @Test void deniedJumpingClearsOnlyJumpProgressAndDoesNotLoseAuthorizedMovement() {
        var settings=new AgilitySourceSettings(true,20,30,10,10,4,2,4,30,120,10,Map.of("walk",.2,"sprint",.06,"swim",.6,"jump",7.0));
        var progress=tracker();progress.sample(at(4,400,0,0,4,1000),settings,true,true);
        progress.sample(at(8,800,0,0,8,2000),settings,true,false);
        var earned=progress.sample(at(12,1200,0,0,12,3000),settings,true,true);
        assertEquals(2.4,earned.get("walk"),1e-8);assertEquals(1,earned.size());
        assertTrue(progress.sample(at(16,1600,0,0,16,4000),settings,true,true).isEmpty());
        assertEquals(Map.of("jump",7.0),progress.sample(at(20,2000,0,0,20,5000),settings,true,true));
    }
}
