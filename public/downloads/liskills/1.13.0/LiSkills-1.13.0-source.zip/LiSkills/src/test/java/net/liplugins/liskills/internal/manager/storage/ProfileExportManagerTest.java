package net.liplugins.liskills.internal.manager.storage;

import net.liplugins.liskills.internal.storage.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import static org.junit.jupiter.api.Assertions.*;

class ProfileExportManagerTest {
    @TempDir Path directory;
    @Test void independentExportsRoundTripWithoutOverwriting()throws Exception{
        UUID uuid=UUID.randomUUID();var profile=new ProfileSnapshot(uuid,"Tester",Map.of("mining",new SkillProgress(12,3.5)),Map.of("mining",123L),17.0);
        try(var exports=new ProfileExportManager(directory,()->CompletableFuture.completedFuture(List.of(profile)))){
            var first=exports.export().get(5,TimeUnit.SECONDS);var second=exports.export().get(5,TimeUnit.SECONDS);
            assertNotEquals(first.directory(),second.directory());assertTrue(Files.exists(first.directory().resolve("COMPLETE.txt")));
            assertFalse(Files.exists(first.directory().resolve("INCOMPLETE.txt")));assertEquals(profile,new ProfileStore(first.directory().resolve("players")).load(uuid,null));
        }
    }
    @Test void busyExportRefusesSecondRequestAndDoesNotCreatePartialEmptyBackup()throws Exception{
        var source=new CompletableFuture<List<ProfileSnapshot>>();try(var exports=new ProfileExportManager(directory,()->source)){
            var first=exports.export();assertThrows(CompletionException.class,()->exports.export().join());
            source.completeExceptionally(new IllegalStateException("bad source"));assertThrows(CompletionException.class,first::join);
            try(var files=Files.list(directory)){assertEquals(0,files.count());}
        }
    }
}
