package net.liplugins.liskills.internal.manager;

import org.bukkit.Material;
import org.bukkit.entity.EntityType;
import org.bukkit.inventory.EquipmentSlot;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ChargedShotRulesTest {
    @Test void configuredBoundaryUsesTheSamePrecisionAsBukkitForce() {
        assertTrue(qualifies(0.9F, 0.9), "精确90%蓄力不应因float舍入误差被拒绝");
        assertFalse(qualifies(Math.nextDown(0.9F), 0.9), "门槛下一档仍然不得触发");
        assertTrue(qualifies(1.0F, 1.0));
        assertFalse(qualifies(Math.nextDown(1.0F), 1.0));
        assertTrue(qualifies(0.1F, 0.1));
        assertFalse(qualifies(0.5F, 0.9));
    }

    @Test void bowMainHandAndOrdinaryArrowTypesAreRequiredTogether() {
        assertTrue(ChargedShotRules.qualifies(Material.BOW, EquipmentSlot.HAND, EntityType.ARROW, 1, 0.9));
        assertTrue(ChargedShotRules.qualifies(Material.BOW, EquipmentSlot.HAND, EntityType.SPECTRAL_ARROW, 1, 0.9));
        assertFalse(ChargedShotRules.qualifies(Material.CROSSBOW, EquipmentSlot.HAND, EntityType.ARROW, 1, 0.9));
        assertFalse(ChargedShotRules.qualifies(Material.BOW, EquipmentSlot.OFF_HAND, EntityType.ARROW, 1, 0.9));
        assertFalse(ChargedShotRules.qualifies(Material.BOW, EquipmentSlot.HAND, EntityType.FIREWORK_ROCKET, 1, 0.9));
        assertFalse(ChargedShotRules.qualifies(Material.BOW, EquipmentSlot.HAND, EntityType.TRIDENT, 1, 0.9));
        assertFalse(ChargedShotRules.qualifies(null, EquipmentSlot.HAND, EntityType.ARROW, 1, 0.9));
    }

    @Test void invalidForcesAndThresholdsCannotCreateChargedArrows() {
        for (float force : new float[]{Float.NaN, Float.POSITIVE_INFINITY, Float.NEGATIVE_INFINITY, -1, 1.01F})
            assertFalse(qualifies(force, 0.9));
        for (double threshold : new double[]{Double.NaN, Double.POSITIVE_INFINITY, 0, 1.01})
            assertFalse(qualifies(1, threshold));
    }

    @Test void multiplierAppliesToBaseDamageAndLeavesNativeMitigationForBukkit() {
        assertEquals(15, ChargedShotRules.boostedDamage(10, 8, 1.5).orElseThrow());
        assertEquals(10, ChargedShotRules.boostedDamage(10, 2, 1.0).orElseThrow());
        assertEquals(50, ChargedShotRules.boostedDamage(10, 8, 5.0).orElseThrow());
    }

    @Test void zeroAbsorbedOrInvalidDamageDoesNotSpendTheFirstEffectiveHit() {
        assertTrue(ChargedShotRules.boostedDamage(10, 0, 1.5).isEmpty());
        for (double damage : new double[]{0, -1, Double.NaN, Double.POSITIVE_INFINITY}) {
            assertTrue(ChargedShotRules.boostedDamage(damage, 1, 1.5).isEmpty());
            assertTrue(ChargedShotRules.boostedDamage(10, damage, 1.5).isEmpty());
        }
    }

    @Test void overflowAndInvalidMultipliersDoNotWriteNonfiniteDamage() {
        assertTrue(ChargedShotRules.boostedDamage(Double.MAX_VALUE, Double.MAX_VALUE, 5).isEmpty());
        for (double multiplier : new double[]{0.5, 5.1, Double.NaN, Double.POSITIVE_INFINITY})
            assertTrue(ChargedShotRules.boostedDamage(10, 8, multiplier).isEmpty());
    }

    private boolean qualifies(float force, double minimum) {
        return ChargedShotRules.qualifies(Material.BOW, EquipmentSlot.HAND, EntityType.ARROW, force, minimum);
    }
}
