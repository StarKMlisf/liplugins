package net.liplugins.liskills.internal.manager.source;

import org.junit.jupiter.api.Test;
import java.util.Map;
import java.util.Set;
import static org.junit.jupiter.api.Assertions.*;

class EnchantingSourceRulesTest {
    @Test void tableUsesActualEnchantmentLevelSumRatherThanThirtyLevelRequirement() {
        var additions=Map.of("minecraft:sharpness",4,"minecraft:unbreaking",3);
        assertEquals(7,EnchantingSourceRules.addedLevels(Map.of(),additions,additions,40));
    }
    @Test void requestedButMissingOrLowerActualEnchantmentsGiveNothing() {
        assertEquals(0,EnchantingSourceRules.addedLevels(Map.of(),Map.of("minecraft:sharpness",4),Map.of(),40));
        assertEquals(0,EnchantingSourceRules.addedLevels(Map.of(),Map.of("minecraft:sharpness",4),Map.of("minecraft:sharpness",3),40));
    }
    @Test void preExistingUnchangedLevelsCannotBeRepeatedlyClaimed() {
        var enchant=Map.of("minecraft:sharpness",4);
        assertEquals(0,EnchantingSourceRules.addedLevels(enchant,enchant,enchant,40));
        assertEquals(5,EnchantingSourceRules.addedLevels(enchant,Map.of("minecraft:sharpness",5),Map.of("minecraft:sharpness",5),40));
    }
    @Test void grindstoneCountsBothInputsButNotRemainingCurses() {
        assertEquals(7,EnchantingSourceRules.removedLevels(Map.of("minecraft:sharpness",4,"minecraft:vanishing_curse",1),
                Map.of("minecraft:unbreaking",3,"minecraft:binding_curse",1),Map.of("minecraft:vanishing_curse",1),Set.of(),40));
    }
    @Test void customBlockedEnchantmentsAndUnremovedLevelsAreExcluded() {
        var before=Map.of("minecraft:sharpness",5,"minecraft:unbreaking",3,"custom:kept",8);
        assertEquals(2,EnchantingSourceRules.removedLevels(before,Map.of(),Map.of("minecraft:sharpness",3),Set.of("unbreaking","custom:kept"),40));
    }
    @Test void abnormalLevelsAreBoundedAndPlainRepairHasNoEnchantExperience() {
        assertEquals(40,EnchantingSourceRules.removedLevels(Map.of("minecraft:sharpness",255),Map.of(),Map.of(),Set.of(),40));
        assertEquals(0,EnchantingSourceRules.removedLevels(Map.of(),Map.of(),Map.of(),Set.of(),40));
        assertEquals(40,EnchantingSourceRules.addedLevels(Map.of(),Map.of("minecraft:sharpness",255),Map.of("minecraft:sharpness",255),40));
    }
}
