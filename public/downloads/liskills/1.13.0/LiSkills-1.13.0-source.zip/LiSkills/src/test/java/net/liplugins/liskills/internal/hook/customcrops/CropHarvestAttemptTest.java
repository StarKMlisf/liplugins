package net.liplugins.liskills.internal.hook.customcrops;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CropHarvestAttemptTest {
    @Test void onlyActuallyMaturePositiveGrowthCropsQualify() {
        assertTrue(CropHarvestAttempt.mature(10, 10));
        assertTrue(CropHarvestAttempt.mature(12, 10));
        assertFalse(CropHarvestAttempt.mature(9, 10));
        assertFalse(CropHarvestAttempt.mature(0, 0));
        assertFalse(CropHarvestAttempt.mature(10, -1));
    }

    @Test void harvestNeedsOutputFinalAcceptanceStateChangeAndNextTick() {
        CropHarvestAttempt attempt = new CropHarvestAttempt(new Object(), 10);
        assertFalse(attempt.commit(11, true, true, true), "点击或破坏预事件不能单独发奖");
        assertTrue(attempt.attach(new Object(), new Object(), 11));
        assertFalse(attempt.commit(11, true, true, true), "等待事件所有监听器结束");
        assertFalse(attempt.commit(12, false, true, true));
        assertFalse(attempt.commit(12, true, false, true));
        assertFalse(attempt.commit(12, true, true, false), "永久成熟状态不能凭点击刷经验");
        assertTrue(attempt.commit(12, true, true, true));
        assertFalse(attempt.commit(13, true, true, true), "每次收获只结算一次");
    }

    @Test void repeatedEventIdentityDoesNotDuplicateTheSameDrop() {
        CropHarvestAttempt attempt = new CropHarvestAttempt(new Object(), 0);
        Object output = new Object(), context = new Object();
        assertTrue(attempt.attach(output, context, 0));
        assertFalse(attempt.attach(output, context, 1));
        assertTrue(attempt.commit(1, true, true, true), "重复派发同事件不延长等待，也不重复结算");
    }

    @Test void multipleQualityAndSeedDropsInOneContextAwardOnce() {
        CropHarvestAttempt attempt = new CropHarvestAttempt(new Object(), 0);
        Object context = new Object();
        assertTrue(attempt.attach(new Object(), context, 0));
        assertTrue(attempt.attach(new Object(), context, 1));
        assertFalse(attempt.commit(1, true, true, true));
        assertTrue(attempt.commit(2, true, true, true));
        assertFalse(attempt.commit(3, true, true, true));
    }

    @Test void competingPrimaryAtSamePositionIsAmbiguous() {
        Object primary = new Object();
        CropHarvestAttempt attempt = new CropHarvestAttempt(primary, 0);
        assertTrue(attempt.attach(new Object(), new Object(), 0));
        attempt.competingPrimary(primary);
        attempt.competingPrimary(new Object());
        assertFalse(attempt.commit(1, true, true, true));
    }

    @Test void distinctActionContextsCannotBeCombinedAtSamePlayerPosition() {
        CropHarvestAttempt attempt = new CropHarvestAttempt(new Object(), 0);
        assertTrue(attempt.attach(new Object(), new Object(), 0));
        assertFalse(attempt.attach(new Object(), new Object(), 0));
        assertFalse(attempt.commit(1, true, true, true));
    }

    @Test void delayedOutputsCannotReviveExpiredHarvests() {
        CropHarvestAttempt attempt = new CropHarvestAttempt(new Object(), 0);
        Object context = new Object();
        assertTrue(attempt.attach(new Object(), context, 7));
        assertFalse(attempt.expired(8));
        assertTrue(attempt.expired(9));
        assertFalse(attempt.attach(new Object(), context, 9));
        assertFalse(attempt.commit(9, true, true, true));
    }

    @Test void outputsAndMismatchedSourcesRemainBounded() {
        CropHarvestAttempt attempt = new CropHarvestAttempt(new Object(), 0);
        Object context = new Object();
        for (int index = 0; index < CropHarvestAttempt.MAX_OUTPUTS; index++) assertTrue(attempt.attach(new Object(), context, 0));
        assertFalse(attempt.attach(new Object(), context, 0));
        assertFalse(attempt.commit(1, true, true, true));
        CropHarvestAttempt missing = new CropHarvestAttempt(new Object(), 0);
        assertFalse(missing.attach(new Object(), null, 0));
        assertFalse(missing.commit(1, true, true, true));
    }

    @Test void secondarySourceInvalidationCannotBeReversedByLaterOutput() {
        CropHarvestAttempt attempt = new CropHarvestAttempt(new Object(), 0);
        attempt.invalidate();
        assertFalse(attempt.attach(new Object(), new Object(), 1));
        assertFalse(attempt.commit(2, true, true, true));
    }
}
