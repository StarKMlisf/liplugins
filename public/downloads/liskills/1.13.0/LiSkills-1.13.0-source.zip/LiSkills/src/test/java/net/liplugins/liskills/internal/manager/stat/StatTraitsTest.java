package net.liplugins.liskills.internal.manager.stat;

import net.liplugins.liskills.internal.config.StatsSettings;
import org.bukkit.configuration.file.YamlConfiguration;
import org.junit.jupiter.api.Test;

import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class StatTraitsTest {
    private StatsSettings settings() throws Exception {
        var yaml = new YamlConfiguration();
        try (var input = getClass().getResourceAsStream("/stats.yml")) {
            yaml.load(new InputStreamReader(input, StandardCharsets.UTF_8));
        }
        return StatsSettings.parse(yaml);
    }

    @Test void eachDefaultTraitMatchesUpstreamUnitsAndFormulas() throws Exception {
        var settings = settings();
        Map<String, Double> values = Map.of("strength", 100.0, "health", 10.0, "regeneration", 50.0,
                "luck", 100.0, "wisdom", 100.0, "toughness", 100.0, "crit_chance", 30.0,
                "crit_damage", 75.0, "speed", 20.0);
        assertEquals(40, StatTraits.value(settings, values, "attack-damage"));
        assertEquals(10, StatTraits.value(settings, values, "hp"));
        assertEquals(1, StatTraits.value(settings, values, "saturation-regen"));
        assertEquals(1, StatTraits.value(settings, values, "hunger-regen"));
        assertEquals(1, StatTraits.value(settings, values, "mana-regen"));
        assertEquals(50, StatTraits.value(settings, values, "gathering-luck"));
        assertEquals(40, StatTraits.value(settings, values, "experience-bonus"));
        assertEquals(1 - Math.pow(1.025, -10), StatTraits.value(settings, values, "anvil-discount"), 1e-12);
        assertEquals(200, StatTraits.value(settings, values, "max-mana"));
        assertEquals(1 - Math.pow(1.01, -30), StatTraits.value(settings, values, "damage-reduction"), 1e-12);
        assertEquals(30, StatTraits.value(settings, values, "crit-chance"));
        assertEquals(75, StatTraits.value(settings, values, "crit-damage"));
        assertEquals(20, StatTraits.value(settings, values, "movement-speed"));
    }

    @Test void damageAndMovementLimitsStayFiniteAtExtremeInput() throws Exception {
        var settings = settings();
        assertEquals(1, StatTraits.reduction(1e9, 1.01));
        assertEquals(0, StatTraits.reduction(100, 1));
        assertEquals(0, StatTraits.reduction(Double.NaN, 1.01));
        assertEquals(1000, StatTraits.value(settings, Map.of("health", 1e6), "hp"));
        assertEquals(200, StatTraits.value(settings, Map.of("speed", 1e6), "movement-speed"));
        assertEquals(100, StatTraits.value(settings, Map.of("crit_chance", 1e6), "crit-chance"));
        assertEquals(0, StatTraits.value(settings, Map.of("strength", Double.NaN), "attack-damage"));
    }

    @Test void experienceUsesOriginalFloorRoundingWithoutIntegerOverflow() {
        assertEquals(1, StatTraits.experience(1, 40));
        assertEquals(14, StatTraits.experience(10, 40));
        assertEquals(Integer.MAX_VALUE, StatTraits.experience(Integer.MAX_VALUE, 1e9));
        assertEquals(-1, StatTraits.experience(-1, 40));
        assertEquals(0, StatTraits.experience(0, 40));
    }

    @Test void anvilDiscountPreservesFreeOperationsAndNeverChargesZeroForPaidOnes() {
        assertEquals(0, StatTraits.anvilCost(0, 0.8));
        assertEquals(-1, StatTraits.anvilCost(-1, 0.8));
        assertEquals(1, StatTraits.anvilCost(1, 0.999));
        assertEquals(8, StatTraits.anvilCost(10, 0.2));
        assertEquals(1, StatTraits.anvilCost(10, 1));
    }
}
