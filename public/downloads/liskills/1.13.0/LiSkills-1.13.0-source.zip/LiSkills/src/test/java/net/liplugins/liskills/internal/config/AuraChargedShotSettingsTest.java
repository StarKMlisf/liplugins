package net.liplugins.liskills.internal.config;

import org.bukkit.configuration.file.YamlConfiguration;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class AuraChargedShotSettingsTest {
    @Test void oldConfigDoesNotBecomeInvalid(){assertEquals(AuraChargedShotSettings.defaults(),AuraChargedShotSettings.parse(new YamlConfiguration()));}
    @Test void originalRankCostAndCoefficientArePreserved(){var settings=AuraChargedShotSettings.defaults();assertEquals(10,settings.manaCost(1));assertEquals(15,settings.manaCost(2));assertEquals(.5,settings.damagePercentPerMana(1));assertEquals(.6,settings.damagePercentPerMana(2),1e-9);assertEquals(0,settings.manaCost(0));}
    @Test void partialNewSectionFailsRatherThanIgnoringMistakes(){var yaml=new YamlConfiguration();yaml.set("charged-shot.base-mana-cost",10);assertThrows(IllegalArgumentException.class,()->AuraChargedShotSettings.parse(yaml));}
}
