package net.liplugins.liskills.internal.manager;

import org.bukkit.Material;
import org.bukkit.block.data.Ageable;
import org.bukkit.block.data.BlockData;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Proxy;

import static org.junit.jupiter.api.Assertions.*;

class CropReplantRulesTest {
    @Test void eachSupportedCropUsesItsActualSeedAndCorrectSoil() {
        Material[][] pairs = {
                {Material.WHEAT, Material.WHEAT_SEEDS}, {Material.CARROTS, Material.CARROT},
                {Material.POTATOES, Material.POTATO}, {Material.BEETROOTS, Material.BEETROOT_SEEDS},
                {Material.NETHER_WART, Material.NETHER_WART}
        };
        for (Material[] pair : pairs) {
            assertEquals(pair[1], CropReplantRules.seed(pair[0]));
            Material soil = pair[0] == Material.NETHER_WART ? Material.SOUL_SAND : Material.FARMLAND;
            assertTrue(CropReplantRules.supports(pair[0], soil));
            assertFalse(CropReplantRules.supports(pair[0], Material.DIRT));
            assertFalse(CropReplantRules.supports(pair[0], soil == Material.SOUL_SAND ? Material.FARMLAND : Material.SOUL_SAND));
        }
    }

    @Test void growthCountersAndOtherMaturePlantsAreNeverReplanted() {
        for (Material unsupported : new Material[]{Material.SUGAR_CANE, Material.CACTUS, Material.COCOA,
                Material.SWEET_BERRY_BUSH, Material.TORCHFLOWER_CROP, Material.AIR}) {
            assertNull(CropReplantRules.seed(unsupported));
            assertFalse(CropReplantRules.mature(unsupported, age(unsupported, 7, 7)));
            assertFalse(CropReplantRules.supports(unsupported, Material.FARMLAND));
        }
    }

    @Test void immatureCropsStayProtectedUntilTheirOwnMaximumAge() {
        assertFalse(CropReplantRules.mature(Material.WHEAT, age(Material.WHEAT, 6, 7)));
        assertTrue(CropReplantRules.mature(Material.WHEAT, age(Material.WHEAT, 7, 7)));
        assertFalse(CropReplantRules.mature(Material.NETHER_WART, age(Material.NETHER_WART, 2, 3)));
        assertTrue(CropReplantRules.mature(Material.NETHER_WART, age(Material.NETHER_WART, 3, 3)));
    }

    @Test void seedlingResetsCloneWithoutMutatingHarvestSnapshot() {
        Ageable harvested = age(Material.WHEAT, 7, 7);
        BlockData seedling = CropReplantRules.seedling(harvested);
        assertNotSame(harvested, seedling);
        assertEquals(0, ((Ageable) seedling).getAge());
        assertEquals(7, harvested.getAge());
        assertEquals(Material.WHEAT, seedling.getMaterial());
    }

    @Test void onlyActualHoeMaterialsActivateTheAbility() {
        assertTrue(CropReplantRules.isHoe(Material.WOODEN_HOE));
        assertTrue(CropReplantRules.isHoe(Material.NETHERITE_HOE));
        assertFalse(CropReplantRules.isHoe(Material.DIAMOND_AXE));
        assertFalse(CropReplantRules.isHoe(Material.WHEAT_SEEDS));
        assertFalse(CropReplantRules.isHoe(Material.AIR));
    }

    private static Ageable age(Material material, int initial, int max) {
        int[] current = {initial};
        return (Ageable) Proxy.newProxyInstance(Ageable.class.getClassLoader(), new Class<?>[]{Ageable.class},
                (object, method, args) -> switch (method.getName()) {
                    case "getMaterial" -> material;
                    case "getAge" -> current[0];
                    case "getMaximumAge" -> max;
                    case "setAge" -> { current[0] = (int) args[0]; yield null; }
                    case "clone" -> age(material, current[0], max);
                    default -> throw new UnsupportedOperationException(method.getName());
                });
    }
}
