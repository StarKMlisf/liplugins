package net.liplugins.liskills.internal.manager;

import net.liplugins.liskills.internal.config.QuickFishSettings;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class QuickFishWaitTest {
    @Test void defaultSettingsHalveTheOriginalRange() {
        assertEquals(new QuickFishWait.Range(50, 300), shorten(100, 600, .5, 20));
    }

    @Test void minimumBoundsOurAccelerationButNeverSlowsAlreadyFastHooks() {
        assertEquals(new QuickFishWait.Range(20, 30), shorten(100, 600, .05, 20));
        assertEquals(new QuickFishWait.Range(0, 10), shorten(0, 10, .5, 20));
        assertEquals(new QuickFishWait.Range(10, 300), shorten(10, 600, .5, 20));
        assertEquals(new QuickFishWait.Range(100, 600), shorten(100, 600, .5, 1200));
    }

    @Test void roundUpPreservesNonZeroSmallRanges() {
        assertEquals(new QuickFishWait.Range(1, 2), shorten(1, 3, .5, 1));
        assertEquals(new QuickFishWait.Range(3, 5), shorten(5, 9, .5, 1));
    }

    @Test void maximumIntegerWaitDoesNotOverflowOrInvertTheRange() {
        assertEquals(new QuickFishWait.Range(1_073_741_824, 1_073_741_824),
                shorten(Integer.MAX_VALUE, Integer.MAX_VALUE, .5, 20));
    }

    @Test void neutralMultiplierDoesNotChangeOtherPluginsWaitTimes() {
        assertEquals(new QuickFishWait.Range(7, 47), shorten(7, 47, 1, 20));
    }

    @Test void invalidConfigurationCannotProduceNegativeOrInvertedWaits() {
        for (double value : new double[]{Double.NaN, Double.POSITIVE_INFINITY, -.1, 0, .049, 1.01})
            assertThrows(IllegalArgumentException.class, () -> shorten(100, 600, value, 20));
        assertThrows(IllegalArgumentException.class, () -> shorten(100, 600, .5, 0));
        assertThrows(IllegalArgumentException.class, () -> shorten(100, 600, .5, 1201));
        assertThrows(IllegalArgumentException.class, () -> new QuickFishWait.Range(-1, 5));
        assertThrows(IllegalArgumentException.class, () -> new QuickFishWait.Range(8, 5));
    }

    private QuickFishWait.Range shorten(int minimum, int maximum, double multiplier, int floor) {
        return QuickFishWait.shorten(new QuickFishWait.Range(minimum, maximum), new QuickFishSettings(multiplier, floor));
    }
}
