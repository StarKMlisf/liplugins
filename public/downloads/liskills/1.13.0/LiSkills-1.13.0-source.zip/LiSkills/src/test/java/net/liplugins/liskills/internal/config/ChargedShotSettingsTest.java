package net.liplugins.liskills.internal.config;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ChargedShotSettingsTest {
    @Test void documentedDefaultsAndInclusiveLimitsAreAccepted() {
        assertDoesNotThrow(() -> new ChargedShotSettings(0.9, 1.5, 1024, 10));
        assertDoesNotThrow(() -> new ChargedShotSettings(0.1, 1, 1, 1));
        assertDoesNotThrow(() -> new ChargedShotSettings(1, 5, 8192, 60));
    }

    @Test void invalidNumbersAndUnboundedTrackingLimitsAreRejected() {
        for (double force : new double[]{0, 1.1, Double.NaN, Double.POSITIVE_INFINITY})
            assertThrows(IllegalArgumentException.class, () -> new ChargedShotSettings(force, 1.5, 1024, 10));
        for (double multiplier : new double[]{0.9, 5.1, Double.NaN, Double.POSITIVE_INFINITY})
            assertThrows(IllegalArgumentException.class, () -> new ChargedShotSettings(0.9, multiplier, 1024, 10));
        for (int maximum : new int[]{0, 8193, Integer.MAX_VALUE})
            assertThrows(IllegalArgumentException.class, () -> new ChargedShotSettings(0.9, 1.5, maximum, 10));
        for (int lifetime : new int[]{0, 61, Integer.MAX_VALUE})
            assertThrows(IllegalArgumentException.class, () -> new ChargedShotSettings(0.9, 1.5, 1024, lifetime));
    }
}
