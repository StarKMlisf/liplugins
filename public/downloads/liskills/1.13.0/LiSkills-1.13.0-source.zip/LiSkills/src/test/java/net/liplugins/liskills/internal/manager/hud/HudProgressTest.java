package net.liplugins.liskills.internal.manager.hud;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class HudProgressTest {
    @Test void progressIsBoundedEvenWhenExternalModifiersChangeMaximum() {
        assertEquals(0.25, HudProgress.fraction(5, 20));
        assertEquals(1, HudProgress.fraction(40, 20));
        assertEquals(0, HudProgress.fraction(-2, 20));
        assertEquals(0, HudProgress.fraction(20, 0));
    }

    @Test void nonFiniteServerValuesNeverReachBossBarProgress() {
        for (double invalid : new double[]{Double.NaN, Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY}) {
            assertEquals(0, HudProgress.fraction(invalid, 20));
            assertEquals(0, HudProgress.fraction(20, invalid));
            assertEquals(0, HudProgress.value(invalid));
        }
    }
}
