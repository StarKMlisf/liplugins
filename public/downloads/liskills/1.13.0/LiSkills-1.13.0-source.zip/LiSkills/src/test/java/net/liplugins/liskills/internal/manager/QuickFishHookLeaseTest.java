package net.liplugins.liskills.internal.manager;

import net.liplugins.liskills.internal.config.QuickFishSettings;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.FishHook;
import org.bukkit.entity.Player;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Proxy;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

class QuickFishHookLeaseTest {
    @Test void snapshotsCurrentRangeAndRestoresBothEndsWithOnePairedWrite() {
        Hook fixture = new Hook();
        fixture.minimum = 80;
        fixture.maximum = 500;
        QuickFishHookLease lease = fixture.apply();
        assertEquals(new QuickFishWait.Range(80, 500), lease.original());
        assertEquals(40, fixture.minimum);
        assertEquals(250, fixture.maximum);
        assertEquals(1, fixture.writes);
        lease.restoreIfUnchanged();
        assertEquals(80, fixture.minimum);
        assertEquals(500, fixture.maximum);
        assertEquals(2, fixture.writes);
    }

    @Test void aLaterPluginChangingEitherEndRetainsItsWholeRange() {
        for (boolean minimumChanged : new boolean[]{true, false}) {
            Hook fixture = new Hook();
            QuickFishHookLease lease = fixture.apply();
            if (minimumChanged) fixture.minimum = 49;
            else fixture.maximum = 299;
            lease.restoreIfUnchanged();
            assertEquals(minimumChanged ? 49 : 50, fixture.minimum);
            assertEquals(minimumChanged ? 300 : 299, fixture.maximum);
            assertEquals(1, fixture.writes, "第三方只改一端，也不能用旧快照覆盖另一端");
        }
    }

    @Test void ownershipTransferPreventsRestoringAnotherPlayersHook() {
        Hook fixture = new Hook();
        QuickFishHookLease lease = fixture.apply();
        fixture.owner = UUID.randomUUID();
        lease.restoreIfUnchanged();
        assertEquals(1, fixture.writes);
        assertFalse(QuickFishHookLease.usable(fixture.hook, fixture.originalOwner));
    }

    @Test void invalidDeadOrUnloadedHooksAreNotMutatedOrLoaded() {
        for (int scenario = 0; scenario < 3; scenario++) {
            Hook fixture = new Hook();
            QuickFishHookLease lease = fixture.apply();
            if (scenario == 0) fixture.valid = false;
            if (scenario == 1) fixture.dead = true;
            if (scenario == 2) fixture.loaded = false;
            lease.restoreIfUnchanged();
            assertEquals(1, fixture.writes);
        }
    }

    @Test void leaseRetainsWindowGenerationAndHookIdentity() {
        Hook fixture = new Hook();
        QuickFishHookLease lease = fixture.apply();
        assertEquals(37L, lease.token());
        assertTrue(lease.matches(fixture.hook));
        assertFalse(lease.matches(new Hook().hook));
    }

    /** 使用轻量实体代理，仅替代 Bukkit 查询，不替代区间计算或回滚判定。 */
    private static final class Hook {
        private final UUID originalOwner = UUID.randomUUID();
        private final UUID id = UUID.randomUUID();
        private UUID owner = originalOwner;
        private boolean valid = true;
        private boolean dead;
        private boolean loaded = true;
        private int minimum = 100;
        private int maximum = 600;
        private int writes;
        private final World world = proxy(World.class, (method, args) -> {
            if (method.equals("isChunkLoaded")) return loaded;
            throw new UnsupportedOperationException(method);
        });
        private final Player shooter = proxy(Player.class, (method, args) -> {
            if (method.equals("getUniqueId")) return owner;
            throw new UnsupportedOperationException(method);
        });
        private final FishHook hook = proxy(FishHook.class, (method, args) -> switch (method) {
            case "getMinWaitTime" -> minimum;
            case "getMaxWaitTime" -> maximum;
            case "setWaitTime" -> {
                minimum = (int) args[0];
                maximum = (int) args[1];
                if (minimum < 0 || maximum < minimum) throw new IllegalArgumentException("invalid paired write");
                writes++;
                yield null;
            }
            case "isValid" -> valid;
            case "isDead" -> dead;
            case "getShooter" -> shooter;
            case "getUniqueId" -> id;
            case "getLocation" -> new Location(world, -17.5, 65, -.5);
            default -> throw new UnsupportedOperationException(method);
        });

        private QuickFishHookLease apply() {
            return QuickFishHookLease.apply(hook, originalOwner, 37L, new QuickFishSettings(.5, 20));
        }
    }

    private static <T> T proxy(Class<T> type, Invocation invocation) {
        return type.cast(Proxy.newProxyInstance(type.getClassLoader(), new Class<?>[]{type},
                (object, method, args) -> invocation.call(method.getName(), args)));
    }
    private interface Invocation { Object call(String method, Object[] args); }
}
