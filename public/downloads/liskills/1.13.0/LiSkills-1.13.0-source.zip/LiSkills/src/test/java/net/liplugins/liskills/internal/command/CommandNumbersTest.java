package net.liplugins.liskills.internal.command;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CommandNumbersTest {
    @Test
    void rejectsUnsafeExperienceBeforeItCanReachPlayerData() {
        for (String value : new String[]{"NaN", "Infinity", "+Infinity", "-Infinity", "1e309", "-1", "words"}) {
            assertNull(CommandNumbers.experience(value, 1_000), value);
        }
    }

    @Test
    void usesCurrentConfiguredMaximumAndAllowsFractionalExperience() {
        assertEquals(0.0, CommandNumbers.experience("0", 100));
        assertEquals(12.5, CommandNumbers.experience("12.5", 100));
        assertEquals(100.0, CommandNumbers.experience("100", 100));
        assertNull(CommandNumbers.experience("100.01", 100));
        assertNull(CommandNumbers.experience("12.5", 10));
    }

    @Test
    void levelsAreWholeNumbersWithinTheSelectedSkillsRange() {
        for (String value : new String[]{"NaN", "Infinity", "1.5", "-1", "0", "101", "2147483648"}) {
            assertNull(CommandNumbers.level(value, 100), value);
        }
        assertEquals(1, CommandNumbers.level("1", 100));
        assertEquals(100, CommandNumbers.level("100", 100));
        assertNull(CommandNumbers.level("100", 50));
    }
}
