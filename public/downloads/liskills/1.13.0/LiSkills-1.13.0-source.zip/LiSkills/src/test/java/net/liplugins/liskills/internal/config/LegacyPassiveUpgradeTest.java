package net.liplugins.liskills.internal.config;

import org.bukkit.configuration.file.YamlConfiguration;
import org.junit.jupiter.api.Test;

import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import static org.junit.jupiter.api.Assertions.*;

class LegacyPassiveUpgradeTest {
    private YamlConfiguration yaml(String resource) throws Exception {
        var yaml = new YamlConfiguration();
        yaml.options().parseComments(true);
        try (var reader = new InputStreamReader(Objects.requireNonNull(getClass().getResourceAsStream(resource)), StandardCharsets.UTF_8)) { yaml.load(reader); }
        return yaml;
    }

    @Test void exactReleasedJarTemplatesMigrateOnceAndPreserveValues() throws Exception {
        // fixture为dist/LiSkills-1.10.2.jar内abilities.yml的五段原文，包含原始中文注释。
        var old = yaml("/legacy-passives-1.10.2.yml");
        var defaults = yaml("/abilities.yml");
        assertEquals(5, old.getConfigurationSection("abilities").getKeys(false).size());
        assertTrue(LegacyPassiveUpgrade.apply(old, defaults));
        Map.of("golden_heal","endurance","meal_steal","endurance","life_steal","healing",
                "golden_heart","healing","anvil_master","forging").forEach((id, skill) -> assertEquals(skill, old.getString("abilities."+id+".skill")));
        assertEquals(5, old.getInt("abilities.anvil_master.unlock-level"));
        assertEquals(43, old.getDouble("abilities.anvil_master.base-value"));
        assertFalse(LegacyPassiveUpgrade.apply(old, defaults));
    }

    @Test void customizedValueOptionInlineCommentAndBlockCommentAreNeverMigrated() throws Exception {
        var old = yaml("/legacy-passives-1.10.2.yml");
        old.set("abilities.golden_heal.base-value", 9.0);
        old.set("abilities.meal_steal.options.custom_limit", 12);
        old.setComments("abilities.life_steal.description", List.of("服主自定义备注"));
        old.setInlineComments("abilities.golden_heart.skill", List.of("保留炼药归属"));
        old.setComments("abilities.anvil_master", List.of("自定义铁砧模板"));
        String before = old.saveToString();
        assertFalse(LegacyPassiveUpgrade.apply(old, yaml("/abilities.yml")));
        assertEquals(before, old.saveToString());
    }

    @Test void oneCustomizedTemplateDoesNotBlockOtherOriginalTemplates() throws Exception {
        var old = yaml("/legacy-passives-1.10.2.yml");
        old.set("abilities.golden_heal.enabled", false);
        assertTrue(LegacyPassiveUpgrade.apply(old, yaml("/abilities.yml")));
        assertEquals("agility", old.getString("abilities.golden_heal.skill"));
        assertFalse(old.getBoolean("abilities.golden_heal.enabled"));
        assertEquals("endurance", old.getString("abilities.meal_steal.skill"));
        assertEquals("forging", old.getString("abilities.anvil_master.skill"));
    }
}
