package net.liplugins.liskills.internal.config;

import org.bukkit.configuration.file.YamlConfiguration;
import org.junit.jupiter.api.Test;
import java.util.List;
import java.util.HashSet;
import static org.junit.jupiter.api.Assertions.*;

class LegacyMenuUpgradeTest {
    private YamlConfiguration yaml(String body) throws Exception {
        var yaml = new YamlConfiguration(); yaml.options().parseComments(true); yaml.loadFromString(body); return yaml;
    }
    private YamlConfiguration defaults() throws Exception {
        return yaml("skill-slots: [10,11,12,13,14,15,16,28,29,30,31,32,33,34,40]\n");
    }
    @Test void upgradesCustomSmallLayoutWithoutMovingExistingSlotsOrButtons() throws Exception {
        var current = yaml("size: 27\ninfo-slot: 10\nclose-slot: 26\n# 服主顺序\nskill-slots: [20,19,18,17,16,15,14,13,12,11,9]\n");
        var existing = List.copyOf(current.getIntegerList("skill-slots"));
        assertTrue(LegacyMenuUpgrade.apply(current, defaults()));
        var slots = current.getIntegerList("skill-slots");
        assertEquals(existing, slots.subList(0, existing.size()));
        assertEquals(15, new HashSet<>(slots).size());
        assertTrue(slots.stream().allMatch(n -> n >= 0 && n < 27 && n != 10 && n != 26));
        assertEquals(List.of("服主顺序"), current.getComments("skill-slots"));
        assertFalse(LegacyMenuUpgrade.apply(current, defaults()));
    }
    @Test void neverRepairsMalformedSlotsOrRewritesVersionedCustomization() throws Exception {
        for (String values : List.of("[10,10]", "[10,1.5]", "[10,49]", "[10,54]")) {
            var current = yaml("size: 54\ninfo-slot: 49\nclose-slot: 53\nskill-slots: " + values + "\n");
            String before = current.saveToString();
            assertFalse(LegacyMenuUpgrade.apply(current, defaults())); assertEquals(before, current.saveToString());
        }
        var current = yaml("config-version: 1\nsize: 54\ninfo-slot: 49\nclose-slot: 53\nskill-slots: [10]\n");
        assertFalse(LegacyMenuUpgrade.apply(current, defaults()));
        assertEquals(List.of(10), current.getIntegerList("skill-slots"));
    }
    @Test void missingButtonsCanStillBeBackfilledAfterExtendingTheOldSkillList() throws Exception {
        var current=yaml("skill-slots: [10,11,12,13,14,15,16,28,29,30,31]\n");
        var defaults=defaults();defaults.set("size",54);defaults.set("info-slot",49);defaults.set("close-slot",53);
        assertTrue(LegacyMenuUpgrade.apply(current,defaults));
        assertEquals(15,current.getIntegerList("skill-slots").size());
        assertFalse(current.contains("info-slot"));
        assertFalse(current.getIntegerList("skill-slots").contains(49));
    }
}
