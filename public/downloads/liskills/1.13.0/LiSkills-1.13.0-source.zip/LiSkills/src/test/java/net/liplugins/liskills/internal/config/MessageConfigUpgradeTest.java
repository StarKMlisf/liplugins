package net.liplugins.liskills.internal.config;

import org.bukkit.configuration.file.YamlConfiguration;
import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class MessageConfigUpgradeTest {
    @Test void changesExactHistoricValueButKeepsCustomComment(){
        var old=new YamlConfiguration();old.set("storage.shutdown-timeout","技能数据保存超过 20 秒，请检查磁盘和权限，不要立即强制终止 Java 进程。");old.setComments("storage.shutdown-timeout",List.of("服主注释"));
        var defaults=new YamlConfiguration();defaults.set("storage.shutdown-timeout","等待 {seconds} 秒");assertTrue(MessageConfigUpgrade.apply(old,defaults));assertEquals("等待 {seconds} 秒",old.getString("storage.shutdown-timeout"));assertEquals(List.of("服主注释"),old.getComments("storage.shutdown-timeout"));
    }
    @Test void preservesCustomTextAndMissingKey(){
        var old=new YamlConfiguration();old.set("storage.shutdown-timeout","联系本服管理");var defaults=new YamlConfiguration();defaults.set("storage.shutdown-timeout","等待 {seconds} 秒");assertFalse(MessageConfigUpgrade.apply(old,defaults));assertEquals("联系本服管理",old.getString("storage.shutdown-timeout"));assertFalse(old.contains("storage.load-failed"));
    }
    @Test void rebrandsOnlyExactOldDefaultsAndPreservesAdministratorWording() throws Exception {
        var defaults=new YamlConfiguration();
        try(var reader=new java.io.InputStreamReader(getClass().getResourceAsStream("/messages.yml"),java.nio.charset.StandardCharsets.UTF_8)){defaults.load(reader);}
        var current=new YamlConfiguration();
        current.set("boot.conflict","检测到 AuraSkills。请先备份并移除旧插件，再启动 LiSkills，避免双重经验与属性叠加。");
        current.setComments("boot.conflict",List.of("管理员自定义注释"));
        current.set("extended.item-invalid","本服 Aura 数据问题请联系管理员");
        assertTrue(MessageConfigUpgrade.apply(current,defaults));
        assertEquals(defaults.getString("boot.conflict"),current.getString("boot.conflict"));
        assertFalse(current.getString("boot.conflict").contains("AuraSkills"));
        assertEquals(List.of("管理员自定义注释"),current.getComments("boot.conflict"));
        assertEquals("本服 Aura 数据问题请联系管理员",current.getString("extended.item-invalid"));
        assertTrue(defaults.getString("extended.usage-item").contains("legacy-preview|legacy-migrate"));
        assertFalse(MessageConfigUpgrade.apply(current,defaults));
    }
}
