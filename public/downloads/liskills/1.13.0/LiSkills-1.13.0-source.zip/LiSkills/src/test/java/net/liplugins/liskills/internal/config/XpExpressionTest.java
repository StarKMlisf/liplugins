package net.liplugins.liskills.internal.config;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class XpExpressionTest {
    @Test void originalTargetLevelExpressionKeepsExistingCurve(){var e=XpExpression.compile("multiplier * (level - 2) ^ 2 + base");assertEquals(100,e.evaluate(2,100,100));assertEquals(6400+100,e.evaluate(10,100,100));}
    @Test void precedenceParenthesesAndUnaryAreDeterministic(){assertEquals(14,XpExpression.compile("2+3*4").evaluate(1,0,0));assertEquals(512,XpExpression.compile("2^3^2").evaluate(1,0,0));assertEquals(12,XpExpression.compile("-2^2 + 16").evaluate(1,0,0));}
    @Test void invalidOrExecutableInputIsRejected(){for(String input:new String[]{"Runtime.exec(x)","level.foo","unknown+1","(level+2","","0/0"})assertThrows(IllegalArgumentException.class,()->XpExpression.compile(input).evaluate(1,0,0));}
    @Test void NonPositiveOrOverflowCannotBecomeAFreeLevel(){for(String input:new String[]{"0","-1","2^10000","1/0"})assertThrows(IllegalArgumentException.class,()->XpExpression.compile(input).evaluate(1,0,0));}
}
