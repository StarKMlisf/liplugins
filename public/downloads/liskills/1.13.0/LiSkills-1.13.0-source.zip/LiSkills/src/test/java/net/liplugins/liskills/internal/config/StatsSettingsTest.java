package net.liplugins.liskills.internal.config;

import org.bukkit.configuration.file.YamlConfiguration;
import org.junit.jupiter.api.Test;

import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

import static org.junit.jupiter.api.Assertions.*;

class StatsSettingsTest {
    private YamlConfiguration defaults() throws Exception {
        YamlConfiguration yaml = new YamlConfiguration();
        try (var input = getClass().getResourceAsStream("/stats.yml")) {
            assertNotNull(input);
            yaml.load(new InputStreamReader(input, StandardCharsets.UTF_8));
        }
        return yaml;
    }

    @Test void completeBundledNineStatsAndFifteenSkillGrowthRulesAreValid() throws Exception {
        StatsSettings settings = StatsSettings.parse(defaults());
        assertEquals(9, settings.definitions().size());
        assertEquals(15, settings.growth().size());
        assertEquals(20, settings.traits().size());
        assertEquals(2, settings.rewardStartLevel());
        assertEquals(new StatGrowth("crit_chance", 1, 1), settings.growthFor("archery").getFirst());
        assertEquals(new StatGrowth("crit_damage", 1, 1), settings.growthFor("fighting").getFirst());
        assertEquals(java.util.List.of(new StatGrowth("regeneration",1,1),new StatGrowth("toughness",1,2)),settings.growthFor("endurance"));
        assertEquals(java.util.List.of(new StatGrowth("regeneration",1,1),new StatGrowth("health",0.4,2)),settings.growthFor("healing"));
        assertEquals(java.util.List.of(new StatGrowth("toughness",1,1),new StatGrowth("wisdom",1,2)),settings.growthFor("forging"));
        assertEquals(java.util.List.of(new StatGrowth("strength",1,1),new StatGrowth("wisdom",1,2)),settings.growthFor("sorcery"));
        assertFalse(settings.growth().values().stream().flatMap(java.util.Collection::stream).anyMatch(g -> g.stat().equals("speed")));
    }

    @Test void rejectsMalformedOrUnknownRulesBeforePublishing() throws Exception {
        for (Object bad : new Object[]{0, 1.5, 1001, "2", Double.NaN}) {
            var yaml = defaults(); yaml.set("reward-start-level", bad);
            assertThrows(IllegalArgumentException.class, () -> StatsSettings.parse(yaml));
        }
        var wrongStat = defaults(); wrongStat.set("growth.farming.unknown.value", 1);
        assertThrows(IllegalArgumentException.class, () -> StatsSettings.parse(wrongStat));
        var wrongTrait = defaults(); wrongTrait.set("traits.gathering-luck.enabled", "true");
        assertThrows(IllegalArgumentException.class, () -> StatsSettings.parse(wrongTrait));
        var nonfinite = defaults(); nonfinite.set("traits.hp.modifier", Double.POSITIVE_INFINITY);
        assertThrows(IllegalArgumentException.class, () -> StatsSettings.parse(nonfinite));
        var excessiveBase = defaults(); excessiveBase.set("stats.health.maximum", 5); excessiveBase.set("stats.health.base", 6);
        assertThrows(IllegalArgumentException.class, () -> StatsSettings.parse(excessiveBase));
    }

    @Test void acceptsExplicitNoEffectRulesAndFreezesAllCollections() throws Exception {
        var yaml = defaults(); yaml.set("traits.hp.modifier", 0); yaml.set("stats.speed.enabled", false);
        yaml.set("growth.farming.health.value", 0);
        var settings = StatsSettings.parse(yaml);
        assertEquals(0, settings.trait("hp").modifier());
        assertFalse(settings.definitions().get("speed").enabled());
        assertThrows(UnsupportedOperationException.class, () -> settings.definitions().clear());
        assertThrows(UnsupportedOperationException.class, () -> settings.growthFor("farming").clear());
        assertThrows(UnsupportedOperationException.class, () -> settings.traits().clear());
    }
}
