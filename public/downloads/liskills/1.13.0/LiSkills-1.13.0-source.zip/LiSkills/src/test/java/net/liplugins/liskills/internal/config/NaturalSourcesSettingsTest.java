package net.liplugins.liskills.internal.config;

import org.bukkit.configuration.file.YamlConfiguration;
import org.junit.jupiter.api.Test;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import static org.junit.jupiter.api.Assertions.*;

class NaturalSourcesSettingsTest {
    private YamlConfiguration defaults() {
        return YamlConfiguration.loadConfiguration(new InputStreamReader(getClass().getResourceAsStream("/sources.yml"),StandardCharsets.UTF_8));
    }
    @Test void defaultsKeepAuraValuesWithBoundedNaturalSources() {
        var value=NaturalSourcesSettings.parse(defaults());
        assertTrue(value.verticalPlantsEnabled()); assertEquals(64,value.maximumPlantBlocks()); assertFalse(value.silkTouchMineralLuck());
        assertEquals(1000,value.fishingXp("treasure")); assertEquals(30,value.fishingXp("junk"));
        assertEquals(2000,value.fishingXp("rare")); assertEquals(5000,value.fishingXp("epic"));
        assertEquals(.2,value.agility().experience().get("walk")); assertEquals(100,value.agility().jumpsPerAward());
    }
    @Test void invalidFiniteIntegerAndBooleanValuesAreRejected() {
        for(Object[] invalid:new Object[][]{{"blocks.maximum-plant-blocks",257},{"blocks.maximum-plant-blocks",1.5},{"fishing.categories.rare",Double.NaN},
                {"agility.sample-ticks",0},{"agility.minimum-unique-cells",1},{"agility.sources.walk",-1},{"blocks.vertical-plants","yes"}}) {
            var yaml=defaults(); yaml.set((String)invalid[0],invalid[1]); assertThrows(IllegalArgumentException.class,()->NaturalSourcesSettings.parse(yaml),(String)invalid[0]);
        }
    }
    @Test void exportedSourceMapsCannotBeMutated() {
        var value=NaturalSourcesSettings.parse(defaults());
        assertThrows(UnsupportedOperationException.class,()->value.fishingExperience().put("rare",1.0));
        assertThrows(UnsupportedOperationException.class,()->value.agility().experience().put("walk",1.0));
    }
}
