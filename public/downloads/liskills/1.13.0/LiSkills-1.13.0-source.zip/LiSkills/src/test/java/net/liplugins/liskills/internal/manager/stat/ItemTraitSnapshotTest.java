package net.liplugins.liskills.internal.manager.stat;

import net.liplugins.liskills.internal.config.ItemModifier;
import net.liplugins.liskills.internal.config.StatsSettings;
import net.liplugins.liskills.internal.storage.PlayerProfile;
import net.liplugins.liskills.internal.storage.ProfileSnapshot;
import net.liplugins.liskills.internal.storage.SkillProgress;
import org.bukkit.configuration.file.YamlConfiguration;
import org.junit.jupiter.api.Test;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import static org.junit.jupiter.api.Assertions.*;

class ItemTraitSnapshotTest {
    private StatsSettings settings() throws Exception {
        var yaml = new YamlConfiguration();
        try (var input = getClass().getResourceAsStream("/stats.yml")) { yaml.load(new InputStreamReader(input, StandardCharsets.UTF_8)); }
        return StatsSettings.parse(yaml);
    }
    @Test void rawTraitsReceiveModifiersBeforeNonlinearFormulaAndSafetyCaps() throws Exception {
        var values = new StatValueSnapshot(Map.of("toughness", 100.0, "health", 10.0, "wisdom", 20.0),
                Map.of("damage-reduction", new ItemModifier(20, 2, 0), "hp", new ItemModifier(2000, 1, 0),
                        "max-mana", new ItemModifier(10, 2, 50)));
        assertEquals(StatTraits.reduction(100, 1.01), StatTraits.value(settings(), values, "damage-reduction"), 1e-12);
        assertEquals(1000, StatTraits.value(settings(), values, "hp"));
        assertEquals(150, StatTraits.value(settings(), values, "max-mana"), 1e-9);
        assertEquals(40, StatTraits.value(settings(), Map.of("wisdom", 20.0), "max-mana"));
    }
    @Test void fullGatheringTraitUsesLegacyBaseExactlyOnceThenNamedModifiers() throws Exception {
        var values = new StatValueSnapshot(Map.of("luck", 100.0), Map.of("farming-luck", new ItemModifier(25, 2, 0)));
        assertEquals(50, StatTraits.value(settings(), values, "gathering-luck"));
        assertEquals(150, StatTraits.value(settings(), values, "farming-luck"), 1e-9);
        assertEquals(50, StatTraits.value(settings(), values, "mining-luck"));
        assertEquals(0, StatTraits.value(settings(), values, "luck"));
        assertEquals(0, StatTraits.value(settings(), values, "double-drop"));
    }
    @Test void vanillaLuckAndDoubleDropAreIndependentDirectTraits() throws Exception {
        var values = new StatValueSnapshot(Map.of("luck", 100.0), Map.of("luck", new ItemModifier(3, 1, 0), "double-drop", new ItemModifier(150, 1, 0)));
        assertEquals(3, StatTraits.value(settings(), values, "luck"));
        assertEquals(100, StatTraits.value(settings(), values, "double-drop"));
        assertEquals(20, StatsSettings.TRAITS.size());
    }
    @Test void snapshotsHaveOnlyStatEntriesAndNoMutableTraitExposure() {
        var traits = new HashMap<>(Map.of("max-mana", new ItemModifier(10, 1, 0)));
        var values = new StatValueSnapshot(StatManager.zeroValues(), traits); traits.clear();
        assertEquals(9, values.size()); assertFalse(values.containsKey("max-mana")); assertEquals(1, values.itemTraits().size());
        assertThrows(UnsupportedOperationException.class, () -> values.put("strength", 1.0));
        assertThrows(UnsupportedOperationException.class, () -> values.itemTraits().clear());
    }
    @Test void profileAtomicallyRetainsBothMapsOnLevelChangeAndClearsThemOnSuppression() {
        var profile = new PlayerProfile(new ProfileSnapshot(UUID.randomUUID(), "player", Map.of(), Map.of(), 100));
        var values = Map.of("wisdom", 20.0); var traits = Map.of("max-mana", new ItemModifier(10, 1, 0));
        profile.statValues(5, values, traits, false);
        assertEquals(traits, profile.attributeSnapshot(5).itemTraits());
        profile.progress("enchanting", new SkillProgress(2, 0));
        assertNull(profile.attributeSnapshot(5)); assertEquals(traits, profile.previousAttributeSnapshot(5).itemTraits());
        profile.statValues(5, StatManager.zeroValues(), true);
        profile.progress("enchanting", new SkillProgress(3, 0));
        assertTrue(profile.attributeSnapshot(5).itemTraits().isEmpty()); assertTrue(profile.statsSuppressed());
        assertNull(profile.attributeSnapshot(6));
        assertEquals(5, ProfileSnapshot.class.getRecordComponents().length);
    }
}
