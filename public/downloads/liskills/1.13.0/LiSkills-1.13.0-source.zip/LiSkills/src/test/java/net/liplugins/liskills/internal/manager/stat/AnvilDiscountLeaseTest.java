package net.liplugins.liskills.internal.manager.stat;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class AnvilDiscountLeaseTest {
    @Test void repeatedPreparationUsesTheOriginalPrice() {
        var lease = new AnvilDiscountLease("same-input-result", 20, 15);
        assertEquals(20, lease.originalFor("same-input-result", 15));
        assertEquals(15, StatTraits.anvilCost(lease.originalFor("same-input-result", 15), .25));
        assertTrue(lease.owns("same-input-result", 15));
    }

    @Test void changedInputsOrThirdPartyPriceBecomeANewBaseline() {
        var lease = new AnvilDiscountLease("old-result", 20, 15);
        assertEquals(30, lease.originalFor("old-result", 30));
        assertEquals(15, lease.originalFor("new-result", 15));
        assertFalse(lease.owns("old-result", 30));
        assertFalse(lease.owns("new-result", 15));
    }
}
