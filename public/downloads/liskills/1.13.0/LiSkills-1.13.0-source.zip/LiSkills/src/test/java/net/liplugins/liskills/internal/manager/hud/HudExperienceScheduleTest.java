package net.liplugins.liskills.internal.manager.hud;

import org.junit.jupiter.api.Test;

import java.util.Set;
import java.util.UUID;
import java.util.HashSet;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.*;

class HudExperienceScheduleTest {
    private static final UUID FIRST = new UUID(0, 1);
    private static final UUID SECOND = new UUID(0, 2);

    @Test void oneSecondExperienceAppearsAndExpiresBeforeTenSecondDataRefresh() {
        var schedule = new HudExperienceSchedule();
        var experience = new HudExperience();
        experience.add("mining", 4, 0, 1);
        schedule.changed(FIRST, experience.expires());
        boolean skillBarVisible = false;
        int skillRefreshes = 0;
        // 每 tick 只消费需要刷新的技能条；常驻生命/魔力的下一轮仍在第 200 tick。
        for (int tick = 1; tick < 200; tick++) {
            long now = tick * 50L;
            if (drain(schedule, now).contains(FIRST)) {
                skillBarVisible = experience.visible(now);
                skillRefreshes++;
            }
            if (tick < 20) assertTrue(skillBarVisible, "经验应于下一 tick 出现");
            else assertFalse(skillBarVisible, "经验在 1 秒到期，不能留到 10 秒的数据刷新");
        }
        assertEquals(2, skillRefreshes, "只刷新首次显示和到期，不创建无限提前刷新");
    }

    @Test void manyGainsInOneTickProduceOnlyOnePlayerRefresh() {
        var schedule = new HudExperienceSchedule();
        for (int index = 0; index < 1000; index++) schedule.changed(FIRST, 5000);
        assertEquals(Set.of(FIRST), drain(schedule, 50));
        assertTrue(drain(schedule, 100).isEmpty());
    }

    @Test void extendingEarliestDeadlineDoesNotExpireEarlyOrKeepRescanningAsDue() {
        var schedule = new HudExperienceSchedule();
        schedule.changed(FIRST, 1000);
        drain(schedule, 50);
        schedule.changed(FIRST, 2000);
        assertEquals(Set.of(FIRST), drain(schedule, 500));
        assertTrue(drain(schedule, 1000).isEmpty());
        assertTrue(drain(schedule, 1500).isEmpty());
        assertEquals(Set.of(FIRST), drain(schedule, 2000));
        assertTrue(drain(schedule, 2050).isEmpty());
    }

    @Test void newGainAndAnotherPlayersExpiryOnlyRefreshTheirOwnIds() {
        var schedule = new HudExperienceSchedule();
        schedule.changed(FIRST, 1000);
        drain(schedule, 50);
        schedule.changed(SECOND, 2000);
        assertEquals(Set.of(FIRST, SECOND), drain(schedule, 1000));
        assertTrue(drain(schedule, 1500).isEmpty());
        assertEquals(Set.of(SECOND), drain(schedule, 2000));
    }

    @Test void quitOrPersonalOffRemovesBothPendingRefreshAndExpiry() {
        var schedule = new HudExperienceSchedule();
        schedule.changed(FIRST, 1000);
        schedule.changed(SECOND, 2000);
        schedule.remove(FIRST);
        assertEquals(Set.of(SECOND), drain(schedule, 50));
        assertTrue(drain(schedule, 1000).isEmpty());
        schedule.remove(SECOND);
        assertTrue(drain(schedule, 2000).isEmpty());
    }

    @Test void reloadAndCloseDiscardPendingExperienceAndOldSessionDeadlines() {
        var schedule = new HudExperienceSchedule();
        schedule.changed(FIRST, 1000);
        schedule.clear();
        assertTrue(drain(schedule, 50).isEmpty());
        schedule.changed(FIRST, 3000);
        assertEquals(Set.of(FIRST), drain(schedule, 100));
        assertTrue(drain(schedule, 1000).isEmpty());
        assertEquals(Set.of(FIRST), drain(schedule, 3000));
    }

    @Test void fastRegionNeverConsumesSlowRegionsDirtyExperienceOrExpiry() {
        var schedule = new HudExperienceSchedule();
        schedule.changed(FIRST, 1000);
        schedule.changed(SECOND, 5000);
        assertTrue(schedule.drain(FIRST, 50));
        assertFalse(schedule.drain(FIRST, 100));
        assertTrue(schedule.drain(FIRST, 1000));
        assertFalse(schedule.drain(FIRST, 1500));
        assertTrue(schedule.drain(SECOND, 2000), "另一区域尚未领取的经验必须保留");
        assertFalse(schedule.drain(SECOND, 4000));
        assertTrue(schedule.drain(SECOND, 5000));
        assertFalse(schedule.drain(SECOND, 5050));
    }

    @Test void extendingOnePlayersDeadlineDoesNotDependOnOtherRegionTicks() {
        var schedule = new HudExperienceSchedule();
        schedule.changed(FIRST, 1000);
        assertTrue(schedule.drain(FIRST, 50));
        schedule.changed(FIRST, 3000);
        for (long now = 100; now <= 4000; now += 50) assertFalse(schedule.drain(SECOND, now));
        assertTrue(schedule.drain(FIRST, 2000));
        assertFalse(schedule.drain(FIRST, 2500));
        assertTrue(schedule.drain(FIRST, 3000));
    }

    @Test void concurrentRegionsKeepIndependentPendingChanges() throws Exception {
        var schedule = new HudExperienceSchedule();
        var start = new CountDownLatch(1);
        var finished = new CountDownLatch(2);
        for (UUID uuid : Set.of(FIRST, SECOND)) Thread.ofPlatform().start(() -> {
            try {
                if (!start.await(2, TimeUnit.SECONDS)) return;
                for (int index = 0; index < 5000; index++) schedule.changed(uuid, 10_000L + index);
            } catch (InterruptedException error) { Thread.currentThread().interrupt(); }
            finally { finished.countDown(); }
        });
        start.countDown();
        assertTrue(finished.await(5, TimeUnit.SECONDS));
        assertTrue(schedule.drain(FIRST, 50));
        assertFalse(schedule.drain(FIRST, 100));
        assertTrue(schedule.drain(SECOND, 50));
        assertFalse(schedule.drain(SECOND, 100));
        assertTrue(schedule.drain(FIRST, 14999));
        assertTrue(schedule.drain(SECOND, 14999));
    }

    /** 单线程服的两个玩家依次领取；生产代码从不替其他区域消费变更。 */
    private static Set<UUID> drain(HudExperienceSchedule schedule, long now) {
        Set<UUID> changed = new HashSet<>();
        for (UUID uuid : Set.of(FIRST, SECOND)) if (schedule.drain(uuid, now)) changed.add(uuid);
        return changed;
    }
}
