package net.liplugins.liskills.internal.config;

import org.bukkit.configuration.file.YamlConfiguration;
import org.junit.jupiter.api.Test;
import java.util.Set;
import static org.junit.jupiter.api.Assertions.*;

class JobsSettingsTest {
    private YamlConfiguration yaml()throws Exception{var yaml=new YamlConfiguration();yaml.loadFromString("enabled: false\nselection-required: true\ndisable-unselected-xp: false\nmaximum-jobs: 2\nchange-cooldown-seconds: 300\ndaily-limit: 1000\nmoney-per-xp:\n  mining: 0.02\n");return yaml;}
    @Test void defaultDoesNotBlockFreeSkillGrowth()throws Exception{var rules=JobsSettings.parse(yaml(),Set.of("mining"));assertFalse(rules.enabled());assertFalse(rules.disableUnselectedXp());assertEquals(.02,rules.moneyPerXp().get("mining"));}
    @Test void rejectsUnknownSkillAndNegativeIncome()throws Exception{var yaml=yaml();assertThrows(IllegalArgumentException.class,()->JobsSettings.parse(yaml,Set.of()));yaml.set("money-per-xp.mining",-.01);assertThrows(IllegalArgumentException.class,()->JobsSettings.parse(yaml,Set.of("mining")));}
    @Test void rejectsUnboundedLimitsAndFractionalCapacity()throws Exception{var yaml=yaml();yaml.set("maximum-jobs",2.5);assertThrows(IllegalArgumentException.class,()->JobsSettings.parse(yaml,Set.of("mining")));yaml.set("maximum-jobs",2);yaml.set("daily-limit",Double.NaN);assertThrows(IllegalArgumentException.class,()->JobsSettings.parse(yaml,Set.of("mining")));}
}
