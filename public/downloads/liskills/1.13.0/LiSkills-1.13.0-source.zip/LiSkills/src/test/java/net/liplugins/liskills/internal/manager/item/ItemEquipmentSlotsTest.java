package net.liplugins.liskills.internal.manager.item;

import net.liplugins.liskills.internal.config.ItemSlot;
import org.bukkit.Material;
import org.bukkit.inventory.EquipmentSlot;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ItemEquipmentSlotsTest {
    @Test void mapsOnlyFourPlayerArmorInventorySlots() {
        assertEquals(ItemSlot.FEET, ItemEquipmentSlots.inventorySlot(36));
        assertEquals(ItemSlot.LEGS, ItemEquipmentSlots.inventorySlot(37));
        assertEquals(ItemSlot.CHEST, ItemEquipmentSlots.inventorySlot(38));
        assertEquals(ItemSlot.HEAD, ItemEquipmentSlots.inventorySlot(39));
        assertNull(ItemEquipmentSlots.inventorySlot(35)); assertNull(ItemEquipmentSlots.inventorySlot(40));
        assertEquals(ItemSlot.OFF_HAND, ItemSlot.from(EquipmentSlot.OFF_HAND)); assertNull(ItemSlot.from(null));
    }
    @Test void includesElytraAndPumpkinButNotWeaponsOrAnimalArmor() {
        assertEquals(ItemSlot.CHEST, ItemEquipmentSlots.armorSlot(Material.ELYTRA));
        assertEquals(ItemSlot.HEAD, ItemEquipmentSlots.armorSlot(Material.CARVED_PUMPKIN));
        assertEquals(ItemSlot.HEAD, ItemEquipmentSlots.armorSlot(Material.PLAYER_HEAD));
        assertEquals(ItemSlot.HEAD, ItemEquipmentSlots.armorSlot(Material.DIAMOND_HELMET));
        assertEquals(ItemSlot.LEGS, ItemEquipmentSlots.armorSlot(Material.DIAMOND_LEGGINGS));
        assertEquals(ItemSlot.FEET, ItemEquipmentSlots.armorSlot(Material.DIAMOND_BOOTS));
        assertNull(ItemEquipmentSlots.armorSlot(Material.DIAMOND_SWORD));
        assertNull(ItemEquipmentSlots.armorSlot(Material.DIAMOND_HORSE_ARMOR));
    }
}
