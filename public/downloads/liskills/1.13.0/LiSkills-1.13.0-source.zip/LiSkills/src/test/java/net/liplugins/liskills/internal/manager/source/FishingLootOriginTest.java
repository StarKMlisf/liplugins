package net.liplugins.liskills.internal.manager.source;

import org.bukkit.NamespacedKey;
import org.bukkit.entity.Item;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.junit.jupiter.api.Test;
import java.lang.reflect.Proxy;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import static org.junit.jupiter.api.Assertions.*;

class FishingLootOriginTest {
    @Test void poolOriginBelongsToOneHookAndIsConsumedOnlyOnce() {
        Item item=item();UUID hook=UUID.randomUUID();FishingLootOrigin.mark(item,hook,"rare");
        assertEquals("rare",FishingLootOrigin.consume(item,hook));assertNull(FishingLootOrigin.consume(item,hook));
        FishingLootOrigin.mark(item,hook,"epic");assertEquals("epic",FishingLootOrigin.consume(item,hook));
    }
    @Test void differentHookCannotReuseAnOldCatchPool() {
        Item item=item();UUID hook=UUID.randomUUID();FishingLootOrigin.mark(item,hook,"rare");
        assertNull(FishingLootOrigin.consume(item,UUID.randomUUID()));assertNull(FishingLootOrigin.consume(item,hook));
    }
    @Test void wrongTypeAndUnsupportedPoolDoNotCauseBonusOrThrow() {
        Item item=item();UUID hook=UUID.randomUUID();
        item.getPersistentDataContainer().set(new NamespacedKey("liskills","fishing_pool_origin"),PersistentDataType.INTEGER,1);
        assertNull(FishingLootOrigin.consume(item,hook));assertTrue(item.getPersistentDataContainer().isEmpty());
        FishingLootOrigin.mark(item,hook,"unknown");assertNull(FishingLootOrigin.consume(item,hook));
    }
    private Item item() {
        Map<NamespacedKey,Object> values=new HashMap<>();
        PersistentDataContainer container=(PersistentDataContainer)Proxy.newProxyInstance(getClass().getClassLoader(),new Class<?>[]{PersistentDataContainer.class},(proxy,method,args)->switch(method.getName()) {
            case "set"->{values.put((NamespacedKey)args[0],args[2]);yield null;}
            case "get"->{Object value=values.get(args[0]);if(value!=null && !((PersistentDataType<?,?>)args[1]).getPrimitiveType().isInstance(value))throw new IllegalArgumentException("wrong PDC type");yield value;}
            case "has"->values.containsKey(args[0]) && (args.length==1 || ((PersistentDataType<?,?>)args[1]).getPrimitiveType().isInstance(values.get(args[0])));
            case "remove"->{values.remove(args[0]);yield null;}
            case "isEmpty"->values.isEmpty();
            default->throw new UnsupportedOperationException(method.getName());
        });
        return (Item)Proxy.newProxyInstance(getClass().getClassLoader(),new Class<?>[]{Item.class},(proxy,method,args)-> {
            if(method.getName().equals("getPersistentDataContainer"))return container;
            throw new UnsupportedOperationException(method.getName());
        });
    }
}
