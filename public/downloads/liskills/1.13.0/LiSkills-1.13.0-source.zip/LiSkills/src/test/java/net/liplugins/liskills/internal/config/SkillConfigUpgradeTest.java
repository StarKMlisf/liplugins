package net.liplugins.liskills.internal.config;

import org.bukkit.configuration.file.YamlConfiguration;
import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class SkillConfigUpgradeTest {
    private YamlConfiguration oldDefaults() throws Exception {
        YamlConfiguration yaml=new YamlConfiguration();
        yaml.loadFromString("""
                skills:
                  farming:
                    enabled: true
                    active:
                      enabled: true
                      type: POTION
                      name: '丰收补给'
                      effect: SATURATION
                      amplifier: 0
                      duration-seconds: 10
                      cooldown-seconds: 60
                      unlock-level: 5
                      mana-cost: 20.0
                  excavation:
                    enabled: true
                    active:
                      enabled: true
                      type: POTION
                      name: '大地挖掘'
                      effect: HASTE
                      amplifier: 0
                      duration-seconds: 10
                      cooldown-seconds: 60
                      unlock-level: 5
                      mana-cost: 20.0
                """);
        return yaml;
    }
    @Test void exactHistoricTemplatesUpgradeOnceWithoutReplacingComments() throws Exception {
        var yaml=oldDefaults();
        yaml.setComments("skills.farming.active.type",List.of("保留管理员注释"));
        assertTrue(SkillConfigUpgrade.apply(yaml));
        assertEquals("REPLENISH",yaml.getString("skills.farming.active.type"));
        assertEquals("TERRAFORM",yaml.getString("skills.excavation.active.type"));
        assertEquals(List.of("保留管理员注释"),yaml.getComments("skills.farming.active.type"));
        yaml.set("skills.farming.active.type","POTION");
        assertFalse(SkillConfigUpgrade.apply(yaml));
        assertEquals("POTION",yaml.getString("skills.farming.active.type"));
    }
    @Test void customCostsNamesAndUnknownOptionsAreNotMigrated() throws Exception {
        for(String key:List.of("mana-cost","name","custom-option")) {
            var yaml=oldDefaults();
            yaml.set("skills.farming.active."+key,key.equals("mana-cost")?31.0:"自定义");
            assertTrue(SkillConfigUpgrade.apply(yaml));
            assertEquals("POTION",yaml.getString("skills.farming.active.type"),key);
            assertEquals(key.equals("mana-cost")?31.0:"自定义",yaml.get("skills.farming.active."+key));
        }
    }
    @Test void disabledSkillsAndAbilitiesKeepTheirBehavior() throws Exception {
        var yaml=oldDefaults();
        yaml.set("skills.farming.enabled",false);
        yaml.set("skills.excavation.active.enabled",false);
        SkillConfigUpgrade.apply(yaml);
        assertEquals("POTION",yaml.getString("skills.farming.active.type"));
        assertEquals("POTION",yaml.getString("skills.excavation.active.type"));
    }
    @Test void invalidAndFutureRevisionsAreNotSilentlyOverwritten() throws Exception {
        for(Object version:List.of(4,1.5,"invalid")) {
            var yaml=oldDefaults();yaml.set("config-version",version);
            assertFalse(SkillConfigUpgrade.apply(yaml));
            assertEquals(version,yaml.get("config-version"));
        }
        assertFalse(SkillConfigUpgrade.apply(new YamlConfiguration()));
    }
    @Test void versionTwoDoesNotRepeatFarmingMigrationButUpgradesNewDefaults() throws Exception {
        var yaml=oldDefaults();yaml.set("config-version",2);
        for(String id:List.of("archery","fishing","defense")) {
            yaml.set("skills."+id+".enabled",true);
            yaml.createSection("skills."+id+".active",yaml.getConfigurationSection("skills.farming.active").getValues(false));
            yaml.set("skills."+id+".active.name",switch(id){case "archery"->"游击步伐";case "fishing"->"幸运垂钓";default->"坚韧护体";});
            yaml.set("skills."+id+".active.effect",switch(id){case "archery"->"SPEED";case "fishing"->"LUCK";default->"RESISTANCE";});
        }
        yaml.setComments("skills.archery.active.type",List.of("我的设置注释"));
        yaml.set("skills.fishing.active.mana-cost",25);
        yaml.set("skills.defense.enabled",false);
        assertTrue(SkillConfigUpgrade.apply(yaml));
        assertEquals(3,yaml.getInt("config-version"));
        assertEquals("POTION",yaml.getString("skills.farming.active.type"));
        assertEquals("CHARGED_SHOT",yaml.getString("skills.archery.active.type"));
        assertEquals(List.of("我的设置注释"),yaml.getComments("skills.archery.active.type"));
        assertEquals("POTION",yaml.getString("skills.fishing.active.type"));
        assertEquals("POTION",yaml.getString("skills.defense.active.type"));
        assertFalse(SkillConfigUpgrade.apply(yaml));
    }
}
