package net.liplugins.liskills.internal.manager.passive.gathering;

import org.bukkit.Material;
import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class DoubleDropRulesTest {
    @Test void originalNineBasicTerrainSourcesAreSupported() {
        for (Material material : List.of(Material.STONE, Material.COBBLESTONE, Material.SAND, Material.GRAVEL,
                Material.DIRT, Material.GRASS_BLOCK, Material.ANDESITE, Material.DIORITE, Material.GRANITE))
            assertTrue(DoubleDropRules.roll(material, 100, .99), material.name());
    }
    @Test void OreLogsCropsAndNonOriginalTerrainAreNotEligible() {
        for (Material material : List.of(Material.DIAMOND_ORE, Material.IRON_ORE, Material.OAK_LOG, Material.WHEAT,
                Material.NETHERITE_BLOCK, Material.RED_SAND, Material.DEEPSLATE, Material.CLAY, Material.AIR))
            assertFalse(DoubleDropRules.roll(material, 100, 0), material.name());
    }
    @Test void percentageRollUsesExclusiveBoundaryAndCapsAtHundred() {
        assertTrue(DoubleDropRules.roll(Material.STONE, 25, .249));
        assertFalse(DoubleDropRules.roll(Material.STONE, 25, .25));
        assertTrue(DoubleDropRules.roll(Material.STONE, 1e12, .99999));
        assertFalse(DoubleDropRules.roll(Material.STONE, 0, 0));
    }
    @Test void InvalidNumbersNeverProduceRewards() {
        for (double value : new double[]{-1, Double.NaN, Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY})
            assertFalse(DoubleDropRules.roll(Material.STONE, value, 0));
        for (double value : new double[]{-1, 1, Double.NaN, Double.POSITIVE_INFINITY})
            assertFalse(DoubleDropRules.roll(Material.STONE, 100, value));
    }
}
