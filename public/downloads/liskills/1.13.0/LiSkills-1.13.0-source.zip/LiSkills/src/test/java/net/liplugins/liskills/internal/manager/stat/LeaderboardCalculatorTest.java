package net.liplugins.liskills.internal.manager.stat;
import net.liplugins.liskills.internal.manager.leaderboard.LeaderboardCalculator;
import net.liplugins.liskills.internal.config.SkillDefinition;
import net.liplugins.liskills.internal.storage.*;
import org.bukkit.Material;
import org.junit.jupiter.api.Test;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;

class LeaderboardCalculatorTest {
    private final SkillDefinition skill=new SkillDefinition("mining","采矿","采矿",Material.STONE,true,100,100,100,Map.of(),Map.of(),0,null);
    private ProfileSnapshot player(String name,int level,double xp){return new ProfileSnapshot(UUID.nameUUIDFromBytes(name.getBytes()),name,Map.of("mining",new SkillProgress(level,xp)),Map.of());}
    @Test void TiesUseXpAndDeterministicNameOrder(){var rows=LeaderboardCalculator.calculate(List.of(player("Z",10,20),player("B",10,30),player("A",10,30)),Map.of("mining",skill),100);assertEquals(List.of("A","B","Z"),rows.get("mining").stream().map(LeaderboardCalculator.Entry::name).toList());}
    @Test void CapsAndDuplicateUuidsDoNotCreateMultipleRanks(){var p=player("A",150,0);var rows=LeaderboardCalculator.calculate(List.of(p,p,player("B",99,0)),Map.of("mining",skill),1);assertEquals(1,rows.get("total").size());assertEquals(100,rows.get("mining").getFirst().level());}
    @Test void MissingSkillsCountAsExistingOneLevelBaseline(){var p=new ProfileSnapshot(UUID.randomUUID(),"A",Map.of(),Map.of());assertEquals(1,LeaderboardCalculator.calculate(List.of(p),Map.of("mining",skill),10).get("total").getFirst().level());}
}
