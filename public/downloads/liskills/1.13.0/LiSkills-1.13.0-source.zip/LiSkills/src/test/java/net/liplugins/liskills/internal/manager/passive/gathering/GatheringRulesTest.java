package net.liplugins.liskills.internal.manager.passive.gathering;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class GatheringRulesTest {
    @Test void luckUsesGuaranteedPiecesPlusOneFractionalRoll() {
        assertEquals(2, GatheringRules.extraDrops(250, .9));
        assertEquals(3, GatheringRules.extraDrops(250, .1));
    }
    @Test void exactHundredsDoNotRollAnAdditionalPiece() {
        assertEquals(2, GatheringRules.extraDrops(200, 0));
        assertEquals(0, GatheringRules.extraDrops(0, 0));
    }
    @Test void fractionalBoundaryIsExclusiveAndDoesNotMultiplyExistingStack() {
        assertEquals(1, GatheringRules.extraDrops(50, .49));
        assertEquals(0, GatheringRules.extraDrops(50, .50));
        assertEquals(2, GatheringRules.extraDrops(250, .50));
    }
    @Test void hostileChanceValuesCannotCreateUnboundedDrops() {
        assertEquals(0, GatheringRules.extraDrops(Double.NaN, .1));
        assertEquals(0, GatheringRules.extraDrops(Double.POSITIVE_INFINITY, .1));
        assertEquals(64, GatheringRules.extraDrops(1e12, .1));
        assertEquals(0, GatheringRules.extraDrops(100, 1));
    }
    @Test void treasureCombinesBaseLuckAndAbilityInPercentagePoints() {
        assertEquals(.035, GatheringRules.poolChance(2, .1, 10, .5), 1e-12);
        assertEquals(1, GatheringRules.poolChance(90, 10, 10, 50));
        assertEquals(0, GatheringRules.poolChance(1, 0, 0, Double.NaN));
    }
    @Test void treasureScaleOptionMultipliesCommonChanceInsteadOfAddingPoints() {
        assertEquals(.03, GatheringRules.poolChance(2, 0, 0, 50, true), 1e-12);
        assertEquals(.52, GatheringRules.poolChance(2, 0, 0, 50, false), 1e-12);
        assertEquals(.045, GatheringRules.poolChance(2, .1, 10, 50, true), 1e-12);
        assertEquals(0, GatheringRules.poolChance(0, 0, 0, 100, true));
    }
    @Test void plantFoodAddsSaturationAfterVanillaAndRespectsFoodLevel() {
        assertEquals(4.1f, GatheringRules.saturation(4, 20, 1), .0001);
        assertEquals(5f, GatheringRules.saturation(4, 5, 100), .0001);
        assertEquals(8f, GatheringRules.saturation(8, 5, 100), .0001);
    }
    @Test void invalidPlantBonusDoesNotDamageExistingSaturation() {
        assertEquals(4, GatheringRules.saturation(4, 20, Double.NaN));
        assertEquals(4, GatheringRules.saturation(4, 20, -1));
    }
    @Test void grapplerRetainsAuraFormulaAndRejectsUnsafeComponents() {
        assertEquals(.006, GatheringRules.pullFactor(50), 1e-12);
        assertEquals(.010, GatheringRules.pullFactor(150), 1e-12);
        assertTrue(GatheringRules.safeVelocity(-4, 4, 0));
        assertFalse(GatheringRules.safeVelocity(4.01, 0, 0));
        assertFalse(GatheringRules.safeVelocity(0, Double.NaN, 0));
    }
}
