package net.liplugins.liskills.internal.manager;

import net.liplugins.liskills.internal.config.*;
import net.liplugins.liskills.internal.storage.SkillProgress;
import org.bukkit.Material;
import org.junit.jupiter.api.Test;
import java.util.Map;
import static org.junit.jupiter.api.Assertions.*;

class ProgressionTest {
    private SkillDefinition definition(int max){return new SkillDefinition("mining","挖矿","test",Material.STONE,true,max,100,100,Map.of(),Map.of(),0,new ActiveSkill(false,"none","HASTE",0,10,60,5));}
    @Test void carriesExperienceAcrossSeveralLevelsWithoutRoundingLoss(){
        // 1->2:100, 2->3:200, 3->4:500。
        assertEquals(new SkillProgress(4,0.5),Progression.add(definition(100),new SkillProgress(1,99.5),701));
    }
    @Test void rejectsPoisonNumbersAndNegativeAmounts(){
        for(double bad:new double[]{Double.NaN,Double.POSITIVE_INFINITY,Double.NEGATIVE_INFINITY,-1})
            assertThrows(IllegalArgumentException.class,()->Progression.add(definition(100),new SkillProgress(1,0),bad));
    }
    @Test void detectsOverflowBeforeMutatingState(){
        assertThrows(IllegalArgumentException.class,()->Progression.add(definition(100),new SkillProgress(1,Double.MAX_VALUE),Double.MAX_VALUE));
    }
    @Test void cappedSkillsDoNotRetainOverflowAndReducedCapsDoNotDeleteProgress(){
        assertEquals(new SkillProgress(3,0),Progression.add(definition(3),new SkillProgress(1,0),1e9));
        assertEquals(new SkillProgress(80,31),Progression.add(definition(50),new SkillProgress(80,31),15));
    }
    @Test void feedbackCountsOnlyCreditedExperienceAcrossLevelCaps(){
        SkillDefinition skill=definition(3);
        SkillProgress before=new SkillProgress(1,90),after=Progression.add(skill,before,1e9);
        assertEquals(210,Progression.gained(skill,before,after,1e9));
        assertEquals(0,Progression.gained(skill,after,after,100));
    }
    @Test void feedbackKeepsFractionalGainsAcrossLevelTransitions(){
        SkillDefinition skill=definition(100);
        SkillProgress before=new SkillProgress(1,99.5),after=Progression.add(skill,before,1.25);
        assertEquals(1.25,Progression.gained(skill,before,after,1.25));
        assertEquals(0,Progression.gained(skill,before,before,0));
    }
}
