package net.liplugins.liskills.internal.config;

import org.bukkit.configuration.file.YamlConfiguration;
import org.junit.jupiter.api.Test;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;

class PassiveProgressionTest {
    private static final Set<String> SKILLS=Set.of("farming","foraging","mining","fishing","excavation","archery","defense","fighting","agility","alchemy","enchanting","endurance","healing","forging","sorcery");
    private YamlConfiguration defaults() throws Exception {
        var yaml=new YamlConfiguration();
        try(var reader=new InputStreamReader(Objects.requireNonNull(getClass().getResourceAsStream("/abilities.yml")),StandardCharsets.UTF_8)){yaml.load(reader);}
        return yaml;
    }
    @Test void legacyMapContainsFiveAbilitiesForEachImplementedSkillAndNoneForSorcery() throws Exception {
        var abilities=PassiveSettings.parse(defaults(),SKILLS);
        assertEquals(70,abilities.size());
        SKILLS.forEach(skill->assertEquals(skill.equals("sorcery")?0:5,abilities.values().stream().filter(p->p.skill().equals(skill)).count(),skill));
        assertEquals("endurance",abilities.get("golden_heal").skill());
        assertEquals("endurance",abilities.get("meal_steal").skill());
        assertEquals("healing",abilities.get("life_steal").skill());
        assertEquals("healing",abilities.get("golden_heart").skill());
        assertEquals("forging",abilities.get("anvil_master").skill());
        assertEquals(5,abilities.get("anvil_master").unlockLevel());
        assertEquals(0,abilities.get("bountiful_harvest").level(1));
        assertEquals(1,abilities.get("bountiful_harvest").level(2));
        assertEquals(2,abilities.get("bountiful_harvest").level(7));
    }
    @Test void rankAndNextUnlockAgreeAcrossEverySkillLevel() throws Exception {
        for(var ability:PassiveSettings.parse(defaults(),SKILLS).values())for(int level=1;level<=100;level++) {
            int next=ability.nextUnlock(level);
            if(next>0) {
                assertTrue(next>level);
                assertEquals(ability.level(level)+1,ability.level(next));
            }
        }
    }
    @Test void disabledAbilitiesDoNotRetainValues() throws Exception {
        var yaml=defaults();yaml.set("abilities.farmer.enabled",false);
        var ability=PassiveSettings.parse(yaml,SKILLS).get("farmer");
        assertEquals(0,ability.level(100));assertEquals(0,ability.value(100));assertEquals(-1,ability.nextUnlock(100));
    }
    @Test void negativeIncrementsClampAtZeroAndCapsStopUnlocks() throws Exception {
        var yaml=defaults();yaml.set("abilities.xp_convert.base-value",2);yaml.set("abilities.xp_convert.per-level",-10);yaml.set("abilities.xp_convert.max-level",2);
        var ability=PassiveSettings.parse(yaml,SKILLS).get("xp_convert");
        assertEquals(0,ability.value(100));assertEquals(2,ability.level(100));assertEquals(-1,ability.nextUnlock(100));
    }
    @Test void invalidNonFiniteAndFractionalGrowthAreRejected() throws Exception {
        var yaml=defaults();yaml.set("abilities.farmer.base-value",Double.NaN);
        assertThrows(IllegalArgumentException.class,()->PassiveSettings.parse(yaml,SKILLS));
        var invalid=defaults();invalid.set("active-growth.farming.level-interval",1.5);
        assertThrows(IllegalArgumentException.class,()->ActiveGrowth.parse(invalid,SKILLS));
    }
    @Test void activeGrowthPreservesCustomBaseAndNeverExceedsRuntimeBounds() throws Exception {
        var growth=ActiveGrowth.parse(defaults(),SKILLS).get("farming");
        var base=new ActiveSkill(true,"custom","SPEED",0,10,60,6,17,"REPLENISH");
        assertEquals(base,growth.resolve(base,6));
        var next=growth.resolve(base,12);
        assertEquals(15,next.durationSeconds());assertEquals(55,next.cooldownSeconds());assertEquals(29,next.manaCost());
        var maximum=growth.resolve(base,1000);
        assertTrue(maximum.durationSeconds()<=120);assertTrue(maximum.cooldownSeconds()>=maximum.durationSeconds());
        assertEquals(0,growth.rank(5,6));assertEquals(20,growth.rank(1000,6));
    }
}
