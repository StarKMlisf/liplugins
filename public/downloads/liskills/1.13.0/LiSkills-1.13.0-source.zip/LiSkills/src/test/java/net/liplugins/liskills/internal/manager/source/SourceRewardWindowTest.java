package net.liplugins.liskills.internal.manager.source;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class SourceRewardWindowTest {
    @Test void failedTransactionsDoNotConsumeBudgetOrStartCooldown() {
        var window=new SourceRewardWindow();assertEquals(20,window.available("drink",20,100,1000));
        assertEquals(20,window.available("drink",20,100,1000));
    }
    @Test void committedActionStartsOnlyItsOwnSourceCooldown() {
        var window=new SourceRewardWindow();window.available("drink",20,100,1000);window.commit("drink",20,40,1000);
        assertEquals(0,window.available("drink",20,100,2999));assertEquals(20,window.available("drink",20,100,3000));
        assertEquals(20,window.available("brew",20,100,2000));
    }
    @Test void sourcesShareFinitePerSkillMinuteBudget() {
        var window=new SourceRewardWindow();window.available("drink",80,100,1000);window.commit("drink",80,0,1000);
        assertEquals(20,window.available("brew",50,100,1001));window.commit("brew",20,0,1001);
        assertEquals(0,window.available("splash",30,100,1002));assertEquals(30,window.available("splash",30,100,61000));
    }
    @Test void invalidOrZeroAmountsNeverEnterTheBudget() {
        var window=new SourceRewardWindow();assertEquals(0,window.available("drink",Double.NaN,100,1000));
        assertEquals(0,window.available("drink",Double.POSITIVE_INFINITY,100,1000));assertEquals(0,window.available("drink",-1,100,1000));
    }
}
