package net.liplugins.liskills.internal.listener;

import org.bukkit.*;
import org.bukkit.block.*;
import org.bukkit.event.block.*;
import org.bukkit.event.entity.EntityChangeBlockEvent;
import org.bukkit.event.world.*;
import org.bukkit.persistence.*;
import org.junit.jupiter.api.Test;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;
import static net.liplugins.liskills.internal.listener.BlockOriginTestWorld.*;

class PlacedBlockTrackerTest {
    private static final NamespacedKey KEY = new NamespacedKey("liskills", "placed_blocks_v2");
    private final BlockOriginTestWorld world = new BlockOriginTestWorld();
    private final PlacedBlockTracker tracker = new PlacedBlockTracker(KEY, block -> true);
    private Block block(int x) { return world.block(x, 70, 1); }
    @Test void foreignRegionIsUnknownAndCannotReadOrOverwritePersistedOrigins() {
        Block ore = block(0);
        var foreign = new PlacedBlockTracker(KEY, ignored -> false);
        assertTrue(foreign.contains(ore), "未拥有区域按未知人工来源处理，不能放行经验");
        foreign.mark(ore);
        assertFalse(tracker.contains(ore));
        tracker.mark(ore);
        foreign.remove(ore);
        assertTrue(tracker.contains(ore));
        assertEquals(-1, foreign.stamp(ore));
        assertFalse(foreign.claimExperience(ore, 0));
    }
    private BlockPlaceEvent place(Block block, Material material) {
        BlockState before = block.getState(); world.set(block, material);
        BlockPlaceEvent event = new BlockPlaceEvent(block, before, block, null, null, true);
        tracker.onPlace(event); return event;
    }
    @Test void chunkPersistedMarkersSurviveNewTrackerAndNegativeCoordinates() {
        Block underground = world.block(-1, -64, -17), surface = world.block(-1, 64, -17);
        tracker.mark(underground); tracker.mark(surface); tracker.mark(underground);
        var reloaded = new PlacedBlockTracker(KEY, block -> true);
        assertTrue(reloaded.contains(underground)); assertTrue(reloaded.contains(surface));
        assertFalse(reloaded.contains(world.block(15, -64, 15)));
        reloaded.remove(underground); assertFalse(reloaded.contains(underground)); assertTrue(reloaded.contains(surface));
        reloaded.remove(surface); assertTrue(surface.getChunk().getPersistentDataContainer().isEmpty());
    }
    @Test void denseSectionUses64WordsAndRemovingOneBitPreservesNeighbors() {
        for (int x = 0; x < 16; x++) for (int y = -16; y < 0; y++) for (int z = 0; z < 16; z++) tracker.mark(world.block(x, y, z));
        Block first = world.block(0, -16, 0); var pdc = first.getChunk().getPersistentDataContainer();
        long[] words = pdc.get(new NamespacedKey("liskills", "placed_blocks_v2_-1"), PersistentDataType.LONG_ARRAY);
        assertNotNull(words); assertEquals(64, words.length); for (long word : words) assertEquals(-1L, word);
        tracker.remove(first); assertFalse(tracker.contains(first)); assertTrue(tracker.contains(world.block(15, -1, 15)));
        tracker.mark(world.block(0, 0, 0)); assertEquals(2, pdc.getKeys().size());
    }
    @Test void malformedBitmapNeverBecomesNaturalOrGetsOverwritten() {
        Block ore = block(0); var pdc = ore.getChunk().getPersistentDataContainer();
        NamespacedKey section = new NamespacedKey("liskills", "placed_blocks_v2_4");
        pdc.set(section, PersistentDataType.LONG_ARRAY, new long[1]);
        assertTrue(tracker.contains(ore)); tracker.remove(ore); tracker.mark(ore);
        assertEquals(1, pdc.get(section, PersistentDataType.LONG_ARRAY).length);
        pdc.set(section, PersistentDataType.STRING, "damaged"); assertTrue(tracker.contains(ore)); tracker.remove(ore);
        assertEquals("damaged", pdc.get(section, PersistentDataType.STRING));
    }
    @Test void cancelledPlacementRestoresOnlyItsOwnFinalReplacedState() {
        Block ore = block(0); BlockPlaceEvent event = place(ore, Material.DIAMOND_ORE);
        assertTrue(tracker.contains(ore)); event.setCancelled(true); world.set(ore, Material.AIR); tracker.settle();
        assertFalse(tracker.contains(ore));
        world.set(ore, Material.STONE); tracker.mark(ore); event = place(ore, Material.DIAMOND_ORE);
        event.setCancelled(true); world.set(ore, Material.STONE); tracker.settle(); assertTrue(tracker.contains(ore));
    }
    @Test void sameTickCancelledPlacementCannotClearNewReplacement() {
        Block ore = block(0); var first = place(ore, Material.DIAMOND_ORE); first.setCancelled(true); world.set(ore, Material.AIR);
        place(ore, Material.DIAMOND_ORE); tracker.settle(); assertTrue(tracker.contains(ore));
    }
    @Test void multiPlacementMarksEveryReplacedPosition() {
        Block lower = block(0), upper = world.block(0, 71, 1); List<BlockState> states = List.of(lower.getState(), upper.getState());
        world.set(lower, Material.OAK_DOOR); world.set(upper, Material.OAK_DOOR);
        var event = new BlockMultiPlaceEvent(states, block(1), null, null, true); tracker.onPlace(event);
        assertTrue(tracker.contains(lower)); assertTrue(tracker.contains(upper));
        event.setCancelled(true); world.set(lower, Material.AIR); world.set(upper, Material.AIR); tracker.settle();
        assertFalse(tracker.contains(lower)); assertFalse(tracker.contains(upper));
    }
    @Test void adjacentPistonMovementPreservesBothDestinationsAcrossChunkBoundary() {
        Block first = block(15), second = block(16), target = block(17);
        world.set(first, Material.DIAMOND_ORE); world.set(second, Material.STONE); tracker.mark(first);
        tracker.onExtend(new BlockPistonExtendEvent(block(14), List.of(first, second), BlockFace.EAST));
        assertTrue(tracker.contains(first)); assertTrue(tracker.contains(target));
        world.set(first, Material.AIR); world.set(second, Material.DIAMOND_ORE); world.set(target, Material.STONE); tracker.settle();
        assertFalse(tracker.contains(first)); assertTrue(tracker.contains(second)); assertTrue(tracker.contains(target));
        assertTrue(new PlacedBlockTracker(KEY, block -> true).contains(target));
    }
    @Test void lateCancelledPistonRestoresPreviousMarksButNotLaterReplacements() {
        Block source = block(0), target = block(1); world.set(source, Material.DIAMOND_ORE); tracker.mark(source);
        var event = new BlockPistonExtendEvent(block(-1), List.of(source), BlockFace.EAST); tracker.onExtend(event); event.setCancelled(true); tracker.settle();
        assertTrue(tracker.contains(source)); assertFalse(tracker.contains(target));
        event = new BlockPistonExtendEvent(block(-1), List.of(source), BlockFace.EAST); tracker.onExtend(event); event.setCancelled(true);
        place(target, Material.DIAMOND_ORE); tracker.settle(); assertTrue(tracker.contains(target));
    }
    @Test void retractUsesPhysicalFacingTowardPiston() {
        Block source = block(2), target = block(1), piston = block(0); world.set(source, Material.DIAMOND_ORE);
        world.set(piston, data(Material.STICKY_PISTON, BlockFace.EAST)); tracker.mark(source);
        tracker.onRetract(new BlockPistonRetractEvent(piston, List.of(source), BlockFace.EAST));
        world.set(source, Material.AIR); world.set(target, Material.DIAMOND_ORE); tracker.settle();
        assertFalse(tracker.contains(source)); assertTrue(tracker.contains(target)); assertFalse(tracker.contains(block(3)));
    }
    @Test void fallingSourceClearsOnlyAfterRealVacatingAndLandingAlwaysBecomesArtificial() {
        Block source = block(0), target = block(1); world.set(source, Material.SAND); tracker.mark(source);
        tracker.onEntityChange(new EntityChangeBlockEvent(null, source, data(Material.AIR)));
        world.set(source, Material.AIR); tracker.settle(); assertFalse(tracker.contains(source));
        tracker.onEntityChange(new EntityChangeBlockEvent(null, target, data(Material.SAND)));
        world.set(target, Material.SAND); tracker.settle(); assertTrue(tracker.contains(target));
        var cancelled = new EntityChangeBlockEvent(null, target, data(Material.AIR)); tracker.onEntityChange(cancelled); cancelled.setCancelled(true);
        tracker.settle(); assertTrue(tracker.contains(target));
    }
    @Test void fallingSourceSameTickReplacementNeverGetsCleared() {
        Block source = block(0); world.set(source, Material.SAND); tracker.mark(source);
        tracker.onEntityChange(new EntityChangeBlockEvent(null, source, data(Material.AIR))); world.set(source, Material.AIR);
        place(source, Material.SAND); tracker.settle(); assertTrue(tracker.contains(source));
    }
    @Test void explosionCancellationAndEditedFinalListRetainMarkers() {
        Block ore = block(0); world.set(ore, Material.DIAMOND_ORE); tracker.mark(ore);
        var event = new BlockExplodeEvent(block(2), block(2).getState(), new ArrayList<>(List.of(ore)), 1, ExplosionResult.DESTROY);
        tracker.onBlockExplosion(event); event.setCancelled(true); tracker.settle(); assertTrue(tracker.contains(ore));
        event = new BlockExplodeEvent(block(2), block(2).getState(), new ArrayList<>(List.of(ore)), 1, ExplosionResult.DESTROY);
        tracker.onBlockExplosion(event); event.blockList().clear(); tracker.settle(); assertTrue(tracker.contains(ore));
        event = new BlockExplodeEvent(block(2), block(2).getState(), new ArrayList<>(List.of(ore)), 1, ExplosionResult.DESTROY);
        tracker.onBlockExplosion(event); world.set(ore, Material.AIR); tracker.settle(); assertFalse(tracker.contains(ore));
    }
    @Test void burnAndFadeCannotClearSameTickReplacementsOrCancelledBlocks() {
        Block log = block(0); world.set(log, Material.OAK_LOG); tracker.mark(log);
        var burn = new BlockBurnEvent(log, block(1)); tracker.onBurn(burn); burn.setCancelled(true); tracker.settle(); assertTrue(tracker.contains(log));
        var fade = new BlockFadeEvent(log, state(log, data(Material.AIR))); tracker.onFade(fade); world.set(log, Material.AIR);
        place(log, Material.OAK_LOG); tracker.settle(); assertTrue(tracker.contains(log));
    }
    @Test void cancelledTreeAndUnchangedExistingLogsNeverWashPlacedResources() {
        Block sapling = block(0), existingLog = block(1); world.set(sapling, Material.OAK_SAPLING); world.set(existingLog, Material.OAK_LOG);
        tracker.mark(sapling); tracker.mark(existingLog);
        var event = new StructureGrowEvent(sapling.getLocation(), TreeType.TREE, false, null,
                new ArrayList<>(List.of(state(sapling, data(Material.OAK_LOG)), existingLog.getState())));
        tracker.onTreeGrowth(event); event.setCancelled(true); tracker.settle(); assertTrue(tracker.contains(sapling)); assertTrue(tracker.contains(existingLog));
        event = new StructureGrowEvent(sapling.getLocation(), TreeType.TREE, false, null,
                new ArrayList<>(List.of(state(sapling, data(Material.OAK_LOG)), existingLog.getState())));
        tracker.onTreeGrowth(event); world.set(sapling, Material.OAK_LOG); tracker.settle();
        assertFalse(tracker.contains(sapling)); assertTrue(tracker.contains(existingLog));
        event = new StructureGrowEvent(existingLog.getLocation(), TreeType.BIRCH, false, null,
                new ArrayList<>(List.of(state(existingLog, data(Material.BIRCH_LOG)))));
        tracker.onTreeGrowth(event); world.set(existingLog, Material.BIRCH_LOG); tracker.settle();
        assertTrue(tracker.contains(existingLog), "生长替换玩家原木种类也不能洗白建材");
    }
    @Test void matureCropKeepsArtificialOriginForCustomSkillsWhileFarmingCanRecognizeMaturity() {
        Block crop = block(0); world.set(crop, crop(6)); tracker.mark(crop);
        var event = new BlockGrowEvent(crop, state(crop, crop(7))); tracker.onGrowth(event); event.setCancelled(true); tracker.settle();
        assertTrue(tracker.contains(crop));
        event = new BlockGrowEvent(crop, state(crop, crop(7))); tracker.onGrowth(event); world.set(crop, crop(7)); tracker.settle();
        assertTrue(tracker.contains(crop), "成熟作物不能通过删除标记让自定义技能绕过人工来源");
        assertTrue(HarvestMaturity.matureCrop(crop.getType(),crop.getBlockData()), "农业仍可使用成熟作物例外");
    }
    @Test void chunkUnloadLoadCannotReviveQueuedCleanupEvenIfSamePositionIsLoadedAgain() {
        Block ore = block(0); place(ore, Material.DIAMOND_ORE); long old = tracker.stamp(ore);
        tracker.defer(() -> tracker.clearIfUnchanged(ore, old)); tracker.onChunkUnload(new ChunkUnloadEvent(ore.getChunk())); world.loaded(ore.getChunk(), false);
        assertTrue(tracker.contains(ore)); assertFalse(tracker.unchanged(ore, old));
        world.loaded(ore.getChunk(), true); tracker.onChunkLoad(new ChunkLoadEvent(ore.getChunk(), false));
        place(ore, Material.DIAMOND_ORE); tracker.settle(); assertTrue(tracker.contains(ore)); assertFalse(tracker.claimExperience(ore, old));
    }
    @Test void cleanupDoesNotReopenAlreadyClaimedRewardChannels() {
        Block ore = block(0); tracker.mark(ore); long old = tracker.stamp(ore);
        assertTrue(tracker.claimExperience(ore, old)); tracker.clearIfUnchanged(ore, old);
        assertFalse(tracker.contains(ore)); assertFalse(tracker.claimExperience(ore, tracker.stamp(ore)));
        assertTrue(tracker.claimBonus(ore, old)); assertFalse(tracker.claimBonus(ore, old));
        tracker.mark(ore); assertFalse(tracker.claimBonus(ore, old)); assertTrue(tracker.contains(ore));
    }
    @Test void boundedQueueRejectsOverflowWithoutWeakeningMarker() {
        Block ore = block(0); tracker.mark(ore);
        for (int i = 0; i < 8192; i++) assertTrue(tracker.defer(() -> { }));
        assertFalse(tracker.defer(() -> tracker.remove(ore))); tracker.settle(); assertTrue(tracker.contains(ore));
    }
}
