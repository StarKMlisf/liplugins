package net.liplugins.liskills.internal.manager;

import org.bukkit.Material;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class TerraformManagerTest {
    @Test
    void onlyUncancelledAndActuallyClearedOriginsPermitAdditionalBreaks() {
        assertTrue(TerraformManager.originalSucceeded(false, Material.AIR));
        assertTrue(TerraformManager.originalSucceeded(false, Material.CAVE_AIR));
        assertTrue(TerraformManager.originalSucceeded(false, Material.VOID_AIR));
        assertFalse(TerraformManager.originalSucceeded(true, Material.AIR), "后续优先级取消也必须停止");
        assertFalse(TerraformManager.originalSucceeded(false, Material.DIRT), "保护检查或未发生的破坏不算成功");
        assertFalse(TerraformManager.originalSucceeded(false, Material.STONE), "被其他插件替换成不同方块也不是破坏成功");
        assertFalse(TerraformManager.originalSucceeded(false, Material.WATER), "非空气状态采用保守停止策略");
    }
}
