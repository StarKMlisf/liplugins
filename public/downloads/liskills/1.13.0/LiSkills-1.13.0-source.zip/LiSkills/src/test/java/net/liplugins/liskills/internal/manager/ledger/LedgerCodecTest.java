package net.liplugins.liskills.internal.manager.ledger;

import org.junit.jupiter.api.Test;
import java.io.IOException;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;

class LedgerCodecTest {
    @Test void deterministicRoundTripIncludesUuidAndAllBoundedFields()throws Exception {
        UUID uuid=UUID.randomUUID();var state=new LedgerState(20_000,2.5,Map.of("reward_first_mining",50,"reward_second_fishing",100));
        byte[] bytes=LedgerCodec.encode(uuid,state);assertEquals(state,LedgerCodec.decode(uuid,bytes));assertArrayEquals(bytes,LedgerCodec.encode(uuid,state));
        assertThrows(IOException.class,()->LedgerCodec.decode(UUID.randomUUID(),bytes));
    }
    @Test void everyTruncatedOrExtendedPayloadIsRejected()throws Exception {
        UUID uuid=UUID.randomUUID();byte[] bytes=LedgerCodec.encode(uuid,new LedgerState(20_000,0,Map.of()));
        for(int length=0;length<bytes.length;length++){int shorter=length;assertThrows(IOException.class,()->LedgerCodec.decode(uuid,Arrays.copyOf(bytes,shorter)));}
        assertThrows(IOException.class,()->LedgerCodec.decode(uuid,Arrays.copyOf(bytes,bytes.length+1)));
        assertThrows(IOException.class,()->LedgerCodec.decode(uuid,new byte[LedgerCodec.MAX_BYTES+1]));
    }
    @Test void invalidStateValuesAndRewardIdsCannotBeEncoded() {
        assertThrows(IllegalArgumentException.class,()->new LedgerState(-1,0,Map.of()));
        assertThrows(IllegalArgumentException.class,()->new LedgerState(1,Double.POSITIVE_INFINITY,Map.of()));
        assertThrows(IllegalArgumentException.class,()->new LedgerState(1,0,Map.of("reward_qa_mining",1001)));
        assertThrows(IllegalArgumentException.class,()->LedgerState.rewardKey("../other","mining"));
        assertEquals("reward_qa_reward_mining",LedgerState.rewardKey("qa_reward","mining"));
    }
    @Test void maximumLengthRuleAndSkillIdsRemainWithinTheOneMiBFileBound()throws Exception {
        Map<String,Integer> entries=new HashMap<>();
        for(int rule=0;rule<128;rule++)for(int skill=0;skill<64;skill++)entries.put(LedgerState.rewardKey("r"+String.format("%047d",rule),"s"+String.format("%047d",skill)),1000);
        var state=new LedgerState(20_000,1_000_000,entries);UUID uuid=UUID.randomUUID();byte[] bytes=LedgerCodec.encode(uuid,state);
        assertTrue(bytes.length<LedgerCodec.MAX_BYTES);assertEquals(state,LedgerCodec.decode(uuid,bytes));
    }
}
