package net.liplugins.liskills.internal.manager.item;

import net.liplugins.liskills.internal.config.ItemModifierOperation;
import net.liplugins.liskills.internal.config.ItemSlot;
import org.bukkit.NamespacedKey;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class AuraItemReaderTest {
    private final AuraItemReader reader = new AuraItemReader();
    private NamespacedKey key(String value) { return new NamespacedKey("auraskills", value); }
    private PersistentDataContainer modifier(String field, String id, double value, String operation) {
        var result = MemoryPersistentData.create();
        result.set(key(field), PersistentDataType.STRING, id); result.set(key("value"), PersistentDataType.DOUBLE, value);
        result.set(key("operation"), PersistentDataType.STRING, operation); return result;
    }
    @Test void readsOriginalListStatTraitAndThreeOperationsWithoutChangingSource() {
        var root = MemoryPersistentData.create();
        root.set(key("item_modifiers"), PersistentDataType.LIST.dataContainers(), List.of(
                modifier("stat", "auraskills/strength", 5, "add"), modifier("stat", "auraskills/strength", 1.5, "multiply"),
                modifier("stat", "auraskills/strength", 10, "add_percent")));
        root.set(key("armor_trait_modifiers"), PersistentDataType.LIST.dataContainers(), List.of(modifier("trait", "auraskills/farming_luck", 30, "add")));
        var foreign = new NamespacedKey("lirealenchant", "identity"); root.set(foreign, PersistentDataType.STRING, "keep-me");
        var before = root.getKeys(); var result = reader.preview(root, ItemSlot.CHEST);
        assertTrue(result.recognized()); assertTrue(result.complete(), result.problems().toString()); assertEquals(4, result.rules().size());
        assertEquals(30, result.rules().getLast().traits().get("farming-luck").add());
        assertEquals(before, root.getKeys()); assertEquals("keep-me", root.get(foreign, PersistentDataType.STRING));
        assertEquals(3, root.get(key("item_modifiers"), PersistentDataType.LIST.dataContainers()).size());
    }
    @Test void readsOriginalSlashSkillKeysGlobalXpAndRequirements() {
        var root = MemoryPersistentData.create(); var xp = MemoryPersistentData.create(); var requirements = MemoryPersistentData.create();
        xp.set(key("global"), PersistentDataType.DOUBLE, 10.0); xp.set(key("auraskills/mining"), PersistentDataType.DOUBLE, 25.0);
        requirements.set(key("auraskills/fighting"), PersistentDataType.INTEGER, 20);
        root.set(key("item_multipliers"), PersistentDataType.TAG_CONTAINER, xp);
        root.set(key("item_requirements"), PersistentDataType.TAG_CONTAINER, requirements);
        var result = reader.preview(root, null);
        assertTrue(result.complete(), result.problems().toString());
        assertEquals(10, result.rules().getFirst().skillXpMultipliers().get("all"));
        assertEquals(25, result.rules().getFirst().skillXpMultipliers().get("mining"));
        assertEquals(20, result.rules().getLast().requirements().get("fighting"));
    }
    @SuppressWarnings("deprecation")
    @Test void readsPre1204ArraysAndOlderContainerAddFormat() {
        var root = MemoryPersistentData.create(); var legacy = MemoryPersistentData.create();
        legacy.set(key("auraskills/strength"), PersistentDataType.DOUBLE, 4.0);
        root.set(key("item_modifiers"), PersistentDataType.TAG_CONTAINER, legacy);
        root.set(key("armor_trait_modifiers"), PersistentDataType.TAG_CONTAINER_ARRAY,
                new PersistentDataContainer[]{modifier("trait", "auraskills/double_drop", 20, "add")});
        var result = reader.preview(root, ItemSlot.FEET);
        assertTrue(result.complete(), result.problems().toString());
        assertEquals(4, result.rules().getFirst().attributes().get("strength"));
        assertEquals(20, result.rules().getLast().traits().get("double-drop").add());
    }
    @Test void wrongTypedOrUnknownDataRefusesWholePreviewRatherThanSilentlySkipping() {
        var root = MemoryPersistentData.create(); root.set(key("item_modifiers"), PersistentDataType.STRING, "bad");
        assertFalse(reader.preview(root, null).complete());
        root.set(key("item_modifiers"), PersistentDataType.LIST.dataContainers(), List.of(modifier("stat", "auraskills/strength", 5, "multiply_total")));
        assertFalse(reader.preview(root, null).complete());
        var record = modifier("stat", "auraskills/strength", 5, "add"); record.set(key("value"), PersistentDataType.INTEGER, 5);
        root.set(key("item_modifiers"), PersistentDataType.LIST.dataContainers(), List.of(record));
        assertFalse(reader.preview(root, null).complete());
    }
    @Test void unknownNamespacesArmorSlotAndOutOfRangeValuesBlockMigration() {
        var root = MemoryPersistentData.create();
        root.set(key("item_modifiers"), PersistentDataType.LIST.dataContainers(), List.of(modifier("stat", "custom/strength", 5, "add")));
        assertFalse(reader.preview(root, null).complete());
        root.remove(key("item_modifiers"));
        root.set(key("armor_trait_modifiers"), PersistentDataType.LIST.dataContainers(), List.of(modifier("trait", "auraskills/luck", 5, "add")));
        assertFalse(reader.preview(root, null).complete());
        assertTrue(reader.preview(root, ItemSlot.HEAD).complete());
        root.set(key("armor_trait_modifiers"), PersistentDataType.LIST.dataContainers(), List.of(modifier("trait", "auraskills/luck", Double.NaN, "add")));
        assertFalse(reader.preview(root, ItemSlot.HEAD).complete());
    }
    @Test void foreignPdcIsNotRecognizedAsAuraAndNoApiOrRawNbtIsRead() {
        var root = MemoryPersistentData.create(); root.set(new NamespacedKey("aureliumskills", "modifiers"), PersistentDataType.STRING, "legacy-private-nbt");
        var result = reader.preview(root, null);
        assertFalse(result.recognized()); assertTrue(result.complete()); assertTrue(result.rules().isEmpty());
    }
    @Test void allOriginalNineteenTraitNamesConvertToSupportedIds() {
        var root = MemoryPersistentData.create();
        for (String id : List.of("attack_damage", "hp", "saturation_regen", "hunger_regen", "mana_regen", "luck", "farming_luck",
                "foraging_luck", "mining_luck", "fishing_luck", "excavation_luck", "double_drop", "experience_bonus", "anvil_discount",
                "max_mana", "damage_reduction", "crit_chance", "crit_damage", "movement_speed")) {
            root.set(key("item_trait_modifiers"), PersistentDataType.LIST.dataContainers(), List.of(modifier("trait", "auraskills/" + id, 1, "add")));
            assertTrue(reader.preview(root, null).complete(), id);
        }
    }
}
