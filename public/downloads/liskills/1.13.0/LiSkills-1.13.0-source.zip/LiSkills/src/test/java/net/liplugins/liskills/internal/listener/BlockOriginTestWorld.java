package net.liplugins.liskills.internal.listener;

import org.bukkit.*;
import org.bukkit.block.*;
import org.bukkit.block.data.*;
import org.bukkit.persistence.*;
import java.lang.reflect.Proxy;
import java.util.*;

/** 仅替代世界/PDC存取；状态变化由测试显式执行，不模拟被测的来源或事务算法。 */
final class BlockOriginTestWorld {
    private final UUID uuid = UUID.randomUUID();
    private final Map<String, Block> blocks = new HashMap<>();
    private final Map<String, BlockData> states = new HashMap<>();
    private final Map<String, Chunk> chunks = new HashMap<>();
    private final Set<String> unloaded = new HashSet<>();
    final World world = proxy(World.class, (name, args) -> switch (name) {
        case "getUID" -> uuid;
        case "getMaxHeight" -> 320;
        case "isChunkLoaded" -> !unloaded.contains(args[0] + ":" + args[1]);
        case "getBlockAt" -> block((int) args[0], (int) args[1], (int) args[2]);
        default -> throw new UnsupportedOperationException(name);
    });
    Block block(int x, int y, int z) {
        String key = x + ":" + y + ":" + z;
        return blocks.computeIfAbsent(key, ignored -> proxy(Block.class, (name, args) -> switch (name) {
            case "getX" -> x;
            case "getY" -> y;
            case "getZ" -> z;
            case "getWorld" -> world;
            case "getLocation" -> new Location(world, x, y, z);
            case "getChunk" -> chunk(x >> 4, z >> 4);
            case "getBlockData" -> states.getOrDefault(key, data(Material.AIR));
            case "getType" -> states.getOrDefault(key, data(Material.AIR)).getMaterial();
            case "getState" -> state(block(x, y, z), states.getOrDefault(key, data(Material.AIR)));
            case "getRelative" -> {
                BlockFace face = (BlockFace) args[0];
                yield block(x + face.getModX(), y + face.getModY(), z + face.getModZ());
            }
            default -> throw new UnsupportedOperationException(name);
        }));
    }
    void set(Block block, Material material) { set(block, data(material)); }
    void set(Block block, BlockData data) { states.put(block.getX() + ":" + block.getY() + ":" + block.getZ(), data); }
    void loaded(Chunk chunk, boolean value) {
        String key = chunk.getX() + ":" + chunk.getZ();
        if (value) unloaded.remove(key); else unloaded.add(key);
    }
    private Chunk chunk(int x, int z) {
        return chunks.computeIfAbsent(x + ":" + z, ignored -> {
            PersistentDataContainer container = container();
            return proxy(Chunk.class, (name, args) -> switch (name) {
                case "getX" -> x;
                case "getZ" -> z;
                case "getWorld" -> world;
                case "getPersistentDataContainer" -> container;
                default -> throw new UnsupportedOperationException(name);
            });
        });
    }
    static BlockData data(Material material) { return data(material, null); }
    static BlockData data(Material material, BlockFace facing) {
        Class<? extends BlockData> type = facing == null ? BlockData.class : Directional.class;
        return proxy(type, (name, args) -> switch (name) {
            case "getMaterial" -> material;
            case "getAsString" -> material.name() + (facing == null ? "" : ":" + facing);
            case "clone" -> data(material, facing);
            case "matches" -> args[0] instanceof BlockData other && other.getAsString().equals(material.name() + (facing == null ? "" : ":" + facing));
            case "getFacing" -> facing;
            default -> throw new UnsupportedOperationException(name);
        });
    }
    static BlockData crop(int age) {
        return proxy(Ageable.class, (name, args) -> switch (name) {
            case "getMaterial" -> Material.WHEAT;
            case "getAsString" -> "WHEAT:" + age;
            case "clone" -> crop(age);
            case "matches" -> args[0] instanceof BlockData other && other.getAsString().equals("WHEAT:" + age);
            case "getAge" -> age;
            case "getMaximumAge" -> 7;
            default -> throw new UnsupportedOperationException(name);
        });
    }
    static BlockState state(Block block, BlockData data) {
        return proxy(BlockState.class, (name, args) -> switch (name) {
            case "getBlock" -> block;
            case "getBlockData" -> data;
            case "getType" -> data.getMaterial();
            case "getLocation" -> block.getLocation();
            case "getWorld" -> block.getWorld();
            default -> throw new UnsupportedOperationException(name);
        });
    }
    private static PersistentDataContainer container() {
        Map<NamespacedKey, Object> values = new HashMap<>();
        return proxy(PersistentDataContainer.class, (name, args) -> switch (name) {
            case "set" -> { values.put((NamespacedKey) args[0], copy(args[2])); yield null; }
            case "get" -> copy(values.get(args[0]));
            case "remove" -> { values.remove(args[0]); yield null; }
            case "has" -> values.containsKey(args[0]) && (args.length == 1 || args[1] == PersistentDataType.LONG_ARRAY && values.get(args[0]) instanceof long[]);
            case "isEmpty" -> values.isEmpty();
            case "getKeys" -> Set.copyOf(values.keySet());
            default -> throw new UnsupportedOperationException(name);
        });
    }
    private static Object copy(Object value) { return value instanceof long[] words ? words.clone() : value; }
    private static <T> T proxy(Class<T> type, Invocation invocation) {
        return type.cast(Proxy.newProxyInstance(type.getClassLoader(), new Class<?>[]{type}, (object, method, args) -> {
            if (method.getName().equals("toString")) return type.getSimpleName();
            if (method.getName().equals("hashCode")) return System.identityHashCode(object);
            if (method.getName().equals("equals")) return object == args[0];
            return invocation.call(method.getName(), args);
        }));
    }
    @FunctionalInterface private interface Invocation { Object call(String method, Object[] args); }
}
