package net.liplugins.liskills.internal.config;

import org.bukkit.configuration.file.YamlConfiguration;
import org.junit.jupiter.api.Test;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import static org.junit.jupiter.api.Assertions.*;

class LegacySourceSettingsTest {
    private YamlConfiguration defaults()throws Exception {
        var yaml=new YamlConfiguration();
        try(var stream=getClass().getResourceAsStream("/sources.yml")){yaml.load(new InputStreamReader(stream,StandardCharsets.UTF_8));}
        return yaml;
    }
    @Test void legacyDefaultsSeparateMovementPotionUseAndCraftingWithoutMovingJumping()throws Exception {
        var routing=SourceSkillRoutingSettings.parse(defaults().getConfigurationSection("legacy"));
        assertEquals("endurance",routing.movementSourceSkill("walk"));assertEquals("endurance",routing.movementSourceSkill("sprint"));
        assertEquals("endurance",routing.movementSourceSkill("swim"));assertEquals("agility",routing.movementSourceSkill("jump"));
        assertEquals("healing",routing.consumptionSkill());assertEquals("healing",routing.potionThrowSkill());
        assertEquals("forging",routing.anvilSkill());assertEquals("forging",routing.grindstoneSkill());
    }
    @Test void administratorCanRestorePreviousRoutingAndInvalidTargetsFailRatherThanSilentlyAwardingAnotherSkill()throws Exception {
        var yaml=defaults();yaml.set("legacy.movement-skill","agility");yaml.set("legacy.consumption-skill","alchemy");
        yaml.set("legacy.potion-throw-skill","alchemy");yaml.set("legacy.anvil-skill","enchanting");yaml.set("legacy.grindstone-skill","enchanting");
        var routing=SourceSkillRoutingSettings.parse(yaml.getConfigurationSection("legacy"));
        assertEquals("agility",routing.movementSourceSkill("walk"));assertEquals("alchemy",routing.consumptionSkill());
        assertEquals("alchemy",routing.potionThrowSkill());assertEquals("enchanting",routing.anvilSkill());assertEquals("enchanting",routing.grindstoneSkill());
        yaml.set("legacy.movement-skill","mining");assertThrows(IllegalArgumentException.class,()->SourceSkillRoutingSettings.parse(yaml.getConfigurationSection("legacy")));
    }
    @Test void sorceryCountsOnlyFinitePositiveManaAndHonorsDisabledSourceAndItsSafetyCap()throws Exception {
        var policy=SorcerySourceSettings.parse(defaults().getConfigurationSection("legacy.sorcery"));
        assertEquals(5,policy.manaExperience(10));assertEquals(2.5,policy.manaExperience(5));
        for(double invalid:new double[]{0,-1,Double.NaN,Double.POSITIVE_INFINITY})assertEquals(0,policy.manaExperience(invalid));
        assertEquals(250,policy.manaExperience(Double.MAX_VALUE));
        assertEquals(0,new SorcerySourceSettings(false,.5,250).manaExperience(10));
        assertEquals(0,new SorcerySourceSettings(true,0,250).manaExperience(10));
        var yaml=defaults();yaml.set("legacy.sorcery.mana-xp-per-point",Double.NaN);
        assertThrows(IllegalArgumentException.class,()->SorcerySourceSettings.parse(yaml.getConfigurationSection("legacy.sorcery")));
    }
}
