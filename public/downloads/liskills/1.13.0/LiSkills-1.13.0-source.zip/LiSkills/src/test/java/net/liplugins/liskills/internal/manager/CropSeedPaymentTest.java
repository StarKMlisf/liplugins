package net.liplugins.liskills.internal.manager;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Proxy;

import static org.junit.jupiter.api.Assertions.*;

class CropSeedPaymentTest {
    @Test void customNamedOrPersistentDataSeedsAndOtherCropsAreNeverConsumed() {
        ItemStack custom = stack(Material.WHEAT_SEEDS, 64, true);
        ItemStack carrots = stack(Material.CARROT, 64, false);
        ItemStack[] storage = {custom, carrots, null};
        assertFalse(CropSeedPayment.available(inventory(storage), Material.WHEAT_SEEDS));
        assertFalse(CropSeedPayment.consume(inventory(storage), Material.WHEAT_SEEDS));
        assertSame(custom, storage[0]);
        assertEquals(64, custom.getAmount());
        assertSame(carrots, storage[1]);
    }

    @Test void exactlyOneOrdinarySeedIsPaidWithoutReplacingUnrelatedInventory() {
        ItemStack custom = stack(Material.WHEAT_SEEDS, 12, true);
        ItemStack ordinary = stack(Material.WHEAT_SEEDS, 4, false);
        ItemStack[] storage = {custom, ordinary, stack(Material.DIAMOND, 20, false)};
        ItemStack other = storage[2];
        PlayerInventory inventory = inventory(storage);
        assertTrue(CropSeedPayment.available(inventory, Material.WHEAT_SEEDS));
        assertTrue(CropSeedPayment.consume(inventory, Material.WHEAT_SEEDS));
        assertSame(custom, storage[0]);
        assertSame(other, storage[2]);
        assertEquals(3, storage[1].getAmount());
        assertEquals(4, ordinary.getAmount(), "不直接修改事件前的 ItemStack 引用");
    }

    @Test void inventoryChangesBetweenAvailabilityAndCommitAreRespected() {
        ItemStack[] storage = {stack(Material.BEETROOT_SEEDS, 1, false), null};
        PlayerInventory inventory = inventory(storage);
        assertTrue(CropSeedPayment.available(inventory, Material.BEETROOT_SEEDS));
        storage[0] = stack(Material.DIAMOND, 3, false);
        assertFalse(CropSeedPayment.consume(inventory, Material.BEETROOT_SEEDS));
        assertEquals(Material.DIAMOND, storage[0].getType());
        assertEquals(3, storage[0].getAmount());

        storage[1] = stack(Material.BEETROOT_SEEDS, 1, false);
        assertTrue(CropSeedPayment.consume(inventory, Material.BEETROOT_SEEDS));
        assertNull(storage[1]);
        assertEquals(Material.DIAMOND, storage[0].getType());
    }

    private static ItemStack stack(Material type, int amount, boolean custom) { return new TestItem(type, amount, custom); }

    private static PlayerInventory inventory(ItemStack[] contents) {
        return (PlayerInventory) Proxy.newProxyInstance(PlayerInventory.class.getClassLoader(), new Class<?>[]{PlayerInventory.class},
                (object, method, args) -> switch (method.getName()) {
                    case "getStorageContents" -> contents.clone();
                    case "setItem" -> { contents[(int) args[0]] = (ItemStack) args[1]; yield null; }
                    default -> throw new UnsupportedOperationException(method.getName());
                });
    }

    /** 仅替代 ItemMeta 是否存在的查询，库存选槽和扣款代码使用真实实现。 */
    private static final class TestItem extends ItemStack {
        private final boolean custom;
        private TestItem(Material material, int amount, boolean custom) { super(material, amount); this.custom = custom; }
        @Override public boolean hasItemMeta() { return custom; }
    }
}
