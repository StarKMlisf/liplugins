package net.liplugins.liskills.internal.manager.item;

import org.junit.jupiter.api.Test;
import java.util.LinkedHashMap;
import java.util.Map;
import static org.junit.jupiter.api.Assertions.*;

class ItemRequirementTest {
    @Test void exactLevelMeetsRequirementAndOneLevelLessDoesNot() {
        assertTrue(ItemRequirement.firstFailure(Map.of("fighting", 10), true, id -> 10, id -> true, id -> true).isEmpty());
        var failure = ItemRequirement.firstFailure(Map.of("fighting", 10), true, id -> 9, id -> true, id -> true).orElseThrow();
        assertEquals(10, failure.required()); assertEquals(9, failure.current()); assertEquals(ItemRequirement.Reason.LEVEL, failure.reason());
    }
    @Test void allCustomAndBuiltInRequirementsMustPass() {
        var required = new LinkedHashMap<String, Integer>(); required.put("fighting", 10); required.put("sorcery_2", 5);
        var failure = ItemRequirement.firstFailure(required, true, id -> id.equals("fighting") ? 100 : 4, id -> true, id -> true).orElseThrow();
        assertEquals("sorcery_2", failure.skill());
        assertTrue(ItemRequirement.firstFailure(required, true, id -> 100, id -> true, id -> true).isEmpty());
    }
    @Test void unloadedProfileNeverGrantsRequirementsOrReadsUnavailableProgress() {
        var failure = ItemRequirement.firstFailure(Map.of("mining", 1), false,
                id -> { fail("档案未加载不能读取等级"); return 100; }, id -> true, id -> true).orElseThrow();
        assertEquals(ItemRequirement.Reason.PROFILE_LOADING, failure.reason());
    }
    @Test void MissingOrDisabledSkillAndPermissionDoNotPassHighLevel() {
        assertEquals(ItemRequirement.Reason.SKILL_UNAVAILABLE,
                ItemRequirement.firstFailure(Map.of("removed_skill", 1), true, id -> 100, id -> false, id -> true).orElseThrow().reason());
        assertEquals(ItemRequirement.Reason.PERMISSION,
                ItemRequirement.firstFailure(Map.of("mining", 1), true, id -> 100, id -> true, id -> false).orElseThrow().reason());
    }
    @Test void EmptyRequirementDoesNotInventARestriction() {
        assertTrue(ItemRequirement.firstFailure(Map.of(), false, id -> 0, id -> false, id -> false).isEmpty());
    }
}
