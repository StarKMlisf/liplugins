package net.liplugins.liskills.internal.manager.hud;

import net.liplugins.liskills.internal.config.HudSettings;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.Player;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class HudDisplayTest {
    @Test void unchangedFramesReuseBarsAndDoNotSendRedundantUpdates() {
        var created = new ArrayList<MemoryBar>();
        var display = display(created);
        display.render(HudDisplay.Slot.HEALTH, null, settings(true), "生命 10/20", .5);
        MemoryBar health = created.getFirst();
        int writes = health.writes;
        display.render(HudDisplay.Slot.HEALTH, null, settings(true), "生命 10/20", .5);
        assertEquals(1, created.size());
        assertEquals(writes, health.writes);
        assertEquals(1, health.viewers);
    }

    @Test void hidingOneLineAndClosingOwnerDoNotClearUnrelatedBars() {
        var created = new ArrayList<MemoryBar>();
        var display = display(created);
        for (var slot : HudDisplay.Slot.values()) display.render(slot, null, settings(true), slot.name(), .25);
        MemoryBar external = new MemoryBar("其他插件", settings(true));
        external.bar.addPlayer(null);
        display.hide(HudDisplay.Slot.SKILL);
        assertEquals(0, created.get(2).viewers);
        assertEquals(1, created.getFirst().viewers);
        display.close();
        display.close();
        assertTrue(created.stream().allMatch(bar -> bar.viewers == 0));
        assertEquals(1, external.viewers);
    }

    @Test void disablingConfiguredLineRemovesItImmediatelyAndReenableCreatesFreshBar() {
        var created = new ArrayList<MemoryBar>();
        var display = display(created);
        display.render(HudDisplay.Slot.MANA, null, settings(true), "魔力", .5);
        display.render(HudDisplay.Slot.MANA, null, settings(false), "魔力", .5);
        assertEquals(0, created.getFirst().viewers);
        display.render(HudDisplay.Slot.MANA, null, settings(true), "魔力", .5);
        assertEquals(2, created.size());
        assertEquals(1, created.getLast().viewers);
    }

    @Test void rendererAppliesFreshStyleAndSanitizesProgress() {
        var created = new ArrayList<MemoryBar>();
        var display = display(created);
        display.render(HudDisplay.Slot.HEALTH, null, settings(true), "旧", .5);
        var updated = new HudSettings.Bar(true, BarColor.PURPLE, BarStyle.SEGMENTED_10, "hud.health");
        display.render(HudDisplay.Slot.HEALTH, null, updated, "新", Double.NaN);
        MemoryBar health = created.getFirst();
        assertEquals("新", health.title);
        assertEquals(BarColor.PURPLE, health.color);
        assertEquals(BarStyle.SEGMENTED_10, health.style);
        assertEquals(0, health.progress);
    }

    private static HudSettings.Bar settings(boolean enabled) {
        return new HudSettings.Bar(enabled, BarColor.RED, BarStyle.SOLID, "hud.health");
    }

    private static HudDisplay display(List<MemoryBar> created) {
        return new HudDisplay((title, settings) -> {
            MemoryBar bar = new MemoryBar(title, settings);
            created.add(bar);
            return bar.bar;
        });
    }

    /** 只模拟 BossBar 所有权和状态契约；客户端图形仍由实服验证负责。 */
    private static final class MemoryBar {
        String title;
        BarColor color;
        BarStyle style;
        double progress = 1;
        int viewers;
        int writes;
        final BossBar bar;

        MemoryBar(String title, HudSettings.Bar settings) {
            this.title = title;
            color = settings.color();
            style = settings.style();
            bar = (BossBar) Proxy.newProxyInstance(BossBar.class.getClassLoader(), new Class<?>[]{BossBar.class},
                    (proxy, method, arguments) -> switch (method.getName()) {
                        case "getTitle" -> this.title;
                        case "getColor" -> color;
                        case "getStyle" -> style;
                        case "getProgress" -> progress;
                        case "setTitle" -> { this.title = (String) arguments[0]; writes++; yield null; }
                        case "setColor" -> { color = (BarColor) arguments[0]; writes++; yield null; }
                        case "setStyle" -> { style = (BarStyle) arguments[0]; writes++; yield null; }
                        case "setProgress" -> { progress = (double) arguments[0]; writes++; yield null; }
                        case "addPlayer" -> { viewers++; writes++; yield null; }
                        case "removeAll" -> { viewers = 0; writes++; yield null; }
                        default -> throw new UnsupportedOperationException(method.getName());
                    });
        }
    }
}
