package net.liplugins.liskills.internal.manager.item;

import net.liplugins.liskills.internal.config.ItemModifier;
import net.liplugins.liskills.internal.config.ItemModifierOperation;
import net.liplugins.liskills.internal.config.ItemSlot;
import org.junit.jupiter.api.Test;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import static org.junit.jupiter.api.Assertions.*;

class ItemEffectsTest {
    @Test void combinesAddsThenMultipliesThenPercentAcrossSlots() {
        var hand = ItemRuleEditor.stat(ItemRuleEditor.named("hand", Set.of(ItemSlot.MAIN_HAND)), "strength", ItemModifierOperation.ADD, 3);
        hand = ItemRuleEditor.stat(hand, "strength", ItemModifierOperation.MULTIPLY, 2);
        var chest = ItemRuleEditor.stat(ItemRuleEditor.named("chest", Set.of(ItemSlot.CHEST)), "strength", ItemModifierOperation.ADD_PERCENT, 25);
        chest = ItemRuleEditor.stat(chest, "strength", ItemModifierOperation.MULTIPLY, 0.5);
        var effects = ItemAttributeCalculator.effects(Map.of(ItemSlot.MAIN_HAND, List.of(hand), ItemSlot.CHEST, List.of(chest)));
        var values = new LinkedHashMap<>(Map.of("strength", 5.0, "wisdom", 10.0)); effects.applyStats(values);
        assertEquals(10, values.get("strength"), 1e-9); assertEquals(10, values.get("wisdom"));
    }
    @Test void zeroFactorAndMinusHundredPercentCancelAllAdds() {
        assertEquals(0, ItemModifier.aggregate(List.of(new ItemModifier(5, 10, 0), new ItemModifier(0, 0, 100))).apply(20));
        assertEquals(0, new ItemModifier(50, 2, -100).apply(20));
    }
    @Test void productIsBoundedAfterPercentageReductionWithoutOverflow() {
        var modifiers = java.util.Collections.nCopies(300, new ItemModifier(0, 10, 0));
        assertTrue(Double.isFinite(ItemModifier.aggregate(modifiers).apply(1e308)));
        assertEquals(100, ItemModifier.aggregate(modifiers).factor());
        assertEquals(0.5, ItemModifier.aggregate(List.of(new ItemModifier(0, 10, -99.9), new ItemModifier(0, 10, 0),
                new ItemModifier(0, 5, 0))).factor(), 1e-10);
        assertEquals(ItemModifier.MAXIMUM_VALUE, ItemModifier.aggregate(modifiers).apply(1e308));
    }
    @Test void experienceAddsGlobalAndSkillPercentOnlyOnceWithBounds() {
        var effects = new ItemEffectSnapshot(Map.of(), Map.of(), Map.of("all", 10.0, "mining", 25.0, "fishing", -100.0, "foraging", 10000.0));
        assertEquals(1.35, effects.skillExperienceMultiplier("mining"));
        assertEquals(1.1, effects.skillExperienceMultiplier("all"));
        assertEquals(1.1, effects.skillExperienceMultiplier("sorcery"));
        assertEquals(0.1, effects.skillExperienceMultiplier("fishing"), 1e-9);
        assertEquals(10, effects.skillExperienceMultiplier("foraging"));
        assertEquals(0, new ItemEffectSnapshot(Map.of(), Map.of(), Map.of("all", -100.0, "mining", -100.0)).skillExperienceMultiplier("mining"));
    }
    @Test void wrongSlotAndDisqualifiedEmptyListsGiveNoEffects() {
        var rule = ItemRuleEditor.experience(ItemRuleEditor.named("mining", Set.of(ItemSlot.MAIN_HAND)), "all", 25);
        var effects = ItemAttributeCalculator.effects(Map.of(ItemSlot.CHEST, List.of(rule), ItemSlot.MAIN_HAND, List.of()));
        assertTrue(effects.stats().isEmpty()); assertTrue(effects.traits().isEmpty()); assertEquals(1, effects.skillExperienceMultiplier("mining"));
    }
    @Test void traitOperationsDoNotDiscardRequirementsOrOtherNamedValues() {
        var rule = ItemRuleEditor.requirement(ItemRuleEditor.named("rune", Set.of(ItemSlot.OFF_HAND)), "sorcery_2", 30);
        rule = ItemRuleEditor.trait(rule, "max-mana", ItemModifierOperation.ADD, 10);
        rule = ItemRuleEditor.trait(rule, "max-mana", ItemModifierOperation.MULTIPLY, 2);
        rule = ItemRuleEditor.trait(rule, "max-mana", ItemModifierOperation.ADD_PERCENT, 50);
        assertEquals(30, rule.requirements().get("sorcery_2"));
        assertEquals(60, rule.traits().get("max-mana").apply(10), 1e-9);
        assertThrows(UnsupportedOperationException.class, () -> ruleMap().traits().clear());
    }
    private net.liplugins.liskills.internal.config.ItemRule ruleMap() {
        return ItemRuleEditor.trait(ItemRuleEditor.named("rune", Set.of(ItemSlot.OFF_HAND)), "hp", ItemModifierOperation.ADD, 2);
    }
}
