package net.liplugins.liskills.internal.manager.stat;

import net.liplugins.liskills.internal.config.SkillDefinition;
import net.liplugins.liskills.internal.config.StatsSettings;
import net.liplugins.liskills.internal.storage.SkillProgress;
import org.bukkit.Material;
import org.bukkit.configuration.file.YamlConfiguration;
import org.junit.jupiter.api.Test;

import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class StatGrowthCalculatorTest {
    private YamlConfiguration yaml() throws Exception {
        var yaml = new YamlConfiguration();
        try (var input = getClass().getResourceAsStream("/stats.yml")) {
            yaml.load(new InputStreamReader(input, StandardCharsets.UTF_8));
        }
        return yaml;
    }
    private Map<String, SkillDefinition> skills(StatsSettings settings) {
        Map<String, SkillDefinition> skills = new LinkedHashMap<>();
        settings.growth().keySet().forEach(id -> skills.put(id,
                new SkillDefinition(id, id, id, Material.STONE, true, 100, 100, 100, Map.of(), Map.of(), 0, null)));
        return skills;
    }
    private Map<String, SkillProgress> progress(StatsSettings settings, int level) {
        Map<String, SkillProgress> progress = new LinkedHashMap<>();
        settings.growth().keySet().forEach(id -> progress.put(id, new SkillProgress(level, 0)));
        return progress;
    }

    @Test void newLevelOneProfilesStartWithoutUnEarnedStats() throws Exception {
        var settings = StatsSettings.parse(yaml());
        var result = StatGrowthCalculator.calculate(settings, skills(settings), Map.of(), ignored -> true);
        assertEquals(9, result.size());
        assertTrue(result.values().stream().allMatch(value -> value == 0));
    }

    @Test void firstRewardIncludesSecondaryAndSubsequentIntervalsRemainAligned() throws Exception {
        var settings = StatsSettings.parse(yaml());
        var first = StatGrowthCalculator.calculate(settings, skills(settings), progress(settings, 2), ignored -> true);
        assertEquals(Map.of("strength", 5.0, "health", 2.0, "regeneration", 5.0, "luck", 3.0, "wisdom", 5.0,
                "toughness", 5.0, "crit_chance", 1.0, "crit_damage", 1.0, "speed", 0.0), first);
        var second = StatGrowthCalculator.calculate(settings, skills(settings), progress(settings, 3), ignored -> true);
        assertEquals(7, second.get("strength"));
        assertEquals(2.4, second.get("health"),1e-9);
        assertEquals(7, second.get("wisdom"));
        assertEquals(4, second.get("luck"));
        assertEquals(2, second.get("crit_chance"));
    }

    @Test void originalStartOneCanReproduceUpstreamSkillLevelRewards() throws Exception {
        var yaml = yaml(); yaml.set("reward-start-level", 1);
        var settings = StatsSettings.parse(yaml);
        var result = StatGrowthCalculator.calculate(settings, skills(settings), progress(settings, 100), ignored -> true);
        assertEquals(350, result.get("strength"));
        assertEquals(120, result.get("health"));
        assertEquals(450, result.get("regeneration"));
        assertEquals(200, result.get("luck"));
        assertEquals(350, result.get("wisdom"));
        assertEquals(400, result.get("toughness"));
        assertEquals(100, result.get("crit_chance"));
        assertEquals(100, result.get("crit_damage"));
    }

    @Test void missingPermissionsAndDisabledStatsDoNotAwardBonuses() throws Exception {
        var yaml = yaml(); yaml.set("stats.strength.enabled", false); yaml.set("stats.health.maximum", 0.5);
        var settings = StatsSettings.parse(yaml);
        var result = StatGrowthCalculator.calculate(settings, skills(settings), progress(settings, 100), id -> id.equals("farming"));
        assertEquals(0, result.get("strength"));
        assertEquals(0.5, result.get("health"));
        assertEquals(0, result.get("wisdom"));
        assertEquals(0, result.get("toughness"));
    }

    @Test void storedLevelsAboveNewCapsDoNotGrantOutOfRangeRewards() throws Exception {
        var settings = StatsSettings.parse(yaml());
        var capped = StatGrowthCalculator.calculate(settings, skills(settings), progress(settings, 100), ignored -> true);
        var old = StatGrowthCalculator.calculate(settings, skills(settings), progress(settings, 500), ignored -> true);
        assertEquals(capped, old);
        assertThrows(UnsupportedOperationException.class, () -> capped.put("health", 0.0));
    }
}
