package net.liplugins.liskills.internal.config;

import org.bukkit.Material;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.potion.PotionType;
import org.junit.jupiter.api.Test;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;

class LootSettingsTest {
    // 此层只测配置语法/表内容；上线入口仍使用 Bukkit 注册表，RPG运行探针另验真实材料。
    private LootSettings parsed(YamlConfiguration yaml) {
        Set<Material> sources = Set.of(Material.DIRT, Material.GRASS_BLOCK, Material.MYCELIUM, Material.COARSE_DIRT,
                Material.PODZOL, Material.ROOTED_DIRT, Material.SAND, Material.RED_SAND, Material.GRAVEL, Material.CLAY,
                Material.MUD, Material.SOUL_SAND, Material.SOUL_SOIL);
        return LootSettings.parse(yaml, (material, block) -> block ? sources.contains(material)
                : material != Material.AIR && material != Material.CAVE_AIR && material != Material.VOID_AIR);
    }
    private YamlConfiguration defaults() {
        return YamlConfiguration.loadConfiguration(new InputStreamReader(Objects.requireNonNull(
                getClass().getResourceAsStream("/loot.yml")), StandardCharsets.UTF_8));
    }
    @Test void fullAuraTablesHaveAllFiftyThreeEntriesAndEpicFirst() {
        LootSettings settings = parsed(defaults());
        assertEquals(53, settings.tables().values().stream().flatMap(List::stream).mapToInt(pool -> pool.entries().size()).sum());
        assertEquals("epic", settings.pools("fishing").getFirst().id());
        assertEquals("epic", settings.pools("excavation").getFirst().id());
        assertEquals(2, settings.pools("fishing").getLast().baseChance());
    }
    @Test void exactSourceRestrictionsPreventSandLootFromDirt() {
        var settings = parsed(defaults());
        var rare = settings.pools("excavation").getLast();
        var potato = rare.entries().stream().filter(entry -> entry.material() == Material.POTATO).findFirst().orElseThrow();
        assertTrue(potato.accepts(Material.ROOTED_DIRT));
        assertTrue(potato.accepts(Material.MYCELIUM));
        assertFalse(potato.accepts(Material.SAND));
        assertEquals(70, potato.experience());
    }
    @Test void tippedArrowsPreserveModernEquivalentPotionTypes() {
        var epic = parsed(defaults()).pools("fishing").getFirst();
        assertEquals(7, epic.entries().stream().filter(entry -> entry.material() == Material.TIPPED_ARROW).count());
        assertTrue(epic.entries().stream().anyMatch(entry -> entry.potion() == PotionType.HARMING));
        assertTrue(epic.entries().stream().anyMatch(entry -> entry.potion() == PotionType.REGENERATION));
    }
    @Test void reversedOrUnboundedAmountFailsWithoutPartialSettings() {
        for (Object invalid : List.of("8-2", "1-65", 0, 1.5, "999999999999999999999-2")) {
            var yaml = defaults(); editFirst(yaml, "amount", invalid);
            assertThrows(IllegalArgumentException.class, () -> parsed(yaml));
        }
    }
    @Test void illegalWeightOrSourceIsRejected() {
        for (Object weight : List.of(0, -1, Double.NaN, Double.POSITIVE_INFINITY)) {
            var yaml = defaults(); editFirst(yaml, "weight", weight);
            assertThrows(IllegalArgumentException.class, () -> parsed(yaml));
        }
        var yaml = defaults(); editFirst(yaml, "sources", List.of("DIAMOND_SWORD"));
        assertThrows(IllegalArgumentException.class, () -> parsed(yaml));
    }
    @Test void nonArrowPotionAndUnknownPoolAreRejected() {
        var yaml = defaults(); editFirst(yaml, "potion", "POISON");
        assertThrows(IllegalArgumentException.class, () -> parsed(yaml));
        var invalid = defaults(); invalid.set("tables.fishing.legendary", Map.of());
        assertThrows(IllegalArgumentException.class, () -> parsed(invalid));
    }
    @Test void emptyPoolAndCustomizedWeightRemainValid() {
        var yaml = defaults(); yaml.set("tables.excavation.epic.entries", List.of());
        editFirst(yaml, "weight", 123.5);
        LootSettings settings = parsed(yaml);
        assertTrue(settings.pools("excavation").getFirst().entries().isEmpty());
        assertEquals(123.5, settings.pools("fishing").getLast().entries().getFirst().weight());
    }
    @Test void parsedCollectionsCannotBeModified() {
        var settings = parsed(defaults());
        assertThrows(UnsupportedOperationException.class, () -> settings.tables().clear());
        assertThrows(UnsupportedOperationException.class, () -> settings.pools("fishing").clear());
        assertThrows(UnsupportedOperationException.class, () -> settings.pools("fishing").getFirst().entries().clear());
    }
    private void editFirst(YamlConfiguration yaml, String key, Object value) {
        String path = "tables.fishing.rare.entries";
        List<Map<?, ?>> entries = new ArrayList<>(yaml.getMapList(path));
        Map<Object, Object> first = new LinkedHashMap<>(entries.getFirst());
        first.put(key, value); entries.set(0, first); yaml.set(path, entries);
    }
}
