package net.liplugins.liskills.internal.listener;

import net.liplugins.liskills.internal.config.NaturalSourcesSettings;
import net.liplugins.liskills.internal.manager.source.BlockHarvestSources;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.Ageable;
import org.bukkit.block.data.type.SeaPickle;
import org.bukkit.configuration.file.YamlConfiguration;
import org.junit.jupiter.api.Test;
import java.io.InputStreamReader;
import java.lang.reflect.Proxy;
import java.nio.charset.StandardCharsets;
import static org.junit.jupiter.api.Assertions.*;

class BlockHarvestSourcesTest {
    private final BlockOriginTestWorld world=new BlockOriginTestWorld();
    private final PlacedBlockTracker placed=new PlacedBlockTracker(new NamespacedKey("liskills","placed_blocks_v2"), block -> true);
    private NaturalSourcesSettings settings(String path,Object value) {
        var yaml=YamlConfiguration.loadConfiguration(new InputStreamReader(getClass().getResourceAsStream("/sources.yml"),StandardCharsets.UTF_8));
        if(path!=null)yaml.set(path,value); return NaturalSourcesSettings.parse(yaml);
    }
    @Test void sugarCaneCountsAtMostThreePositionsAndKeepsEveryOrigin() {
        Block root=world.block(0,70,0); for(int y=70;y<74;y++)world.set(world.block(0,y,0),Material.SUGAR_CANE); placed.mark(root);
        var parts=BlockHarvestSources.capture(root,placed,settings(null,null),block->false);
        assertEquals(3,parts.size()); assertTrue(parts.getFirst().placed()); assertFalse(parts.get(1).placed());
        assertNotEquals(parts.getFirst().stamp(),parts.get(1).stamp());
    }
    @Test void plantColumnRespectsConfiguredBoundariesAndCustomOwners() {
        Block root=world.block(0,70,0); for(int y=70;y<80;y++)world.set(world.block(0,y,0),Material.BAMBOO);
        assertEquals(2,BlockHarvestSources.capture(root,placed,settings("blocks.maximum-plant-blocks",2),block->false).size());
        assertEquals(1,BlockHarvestSources.capture(root,placed,settings("blocks.vertical-plants",false),block->false).size());
        assertEquals(3,BlockHarvestSources.capture(root,placed,settings(null,null),block->block.getY()==73).size());
    }
    @Test void kelpPlantIncludesItsDifferentMaterialTipButNotUnrelatedPlants() {
        Block root=world.block(0,70,0);world.set(root,Material.KELP_PLANT);world.set(root.getRelative(BlockFace.UP),Material.KELP);world.set(world.block(0,72,0),Material.BAMBOO);
        var parts=BlockHarvestSources.capture(root,placed,settings(null,null),block->false); assertEquals(2,parts.size()); assertEquals(Material.KELP,parts.getLast().material());
    }
    @Test void originalBerryAndPickleStateMultipliersAndOffSwitchesAreExact() {
        Ageable berry=(Ageable)Proxy.newProxyInstance(Ageable.class.getClassLoader(),new Class[]{Ageable.class},(object,method,args)->method.getName().equals("getAge")?3:null);
        SeaPickle pickles=(SeaPickle)Proxy.newProxyInstance(SeaPickle.class.getClassLoader(),new Class[]{SeaPickle.class},(object,method,args)->method.getName().equals("getPickles")?4:null);
        assertEquals(2,BlockHarvestSources.multiplier(Material.SWEET_BERRY_BUSH,berry,settings(null,null)));
        assertEquals(4,BlockHarvestSources.multiplier(Material.SEA_PICKLE,pickles,settings(null,null)));
        assertEquals(1,BlockHarvestSources.multiplier(Material.SWEET_BERRY_BUSH,berry,settings("blocks.berry-state-multiplier",false)));
        assertEquals(1,BlockHarvestSources.multiplier(Material.SEA_PICKLE,pickles,settings("blocks.pickle-state-multiplier",false)));
    }
    @Test void silkPolicyMatchesMineralDroppingOresWithoutBlockingAncientDebrisOrOrdinaryTerrain() {
        assertTrue(BlockHarvestSources.mineralOre(Material.DEEPSLATE_IRON_ORE)); assertTrue(BlockHarvestSources.mineralOre(Material.DIAMOND_ORE));
        assertFalse(BlockHarvestSources.mineralOre(Material.ANCIENT_DEBRIS)); assertFalse(BlockHarvestSources.mineralOre(Material.STONE));
    }
}
