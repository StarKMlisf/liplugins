package net.liplugins.liskills.internal.manager;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class AbilityManaReservationTest {
    @Test
    void failedEffectRefundsOnlyItsReservationAndPreservesCallbackSpending() {
        Wallet wallet = new Wallet(100, 100);
        try (var reservation = wallet.reserve(20)) {
            assertEquals(80, wallet.balance);
            wallet.balance -= 30; // 外部药水回调的独立消费。
        }
        assertEquals(70, wallet.balance);
    }

    @Test
    void successfulEffectCannotBecomeFreeWhenCallbackSpendsRemainingMana() {
        Wallet wallet = new Wallet(20, 100);
        try (var reservation = wallet.reserve(20)) {
            assertEquals(0, wallet.balance, "效果发生前费用已被预留");
            wallet.balance = 0;
            reservation.commit();
        }
        assertEquals(0, wallet.balance);
    }

    @Test
    void reloadDuringFailureUsesNewMaximumAndKeepsExternalManaGain() {
        Wallet wallet = new Wallet(50, 100);
        try (var reservation = wallet.reserve(20)) {
            wallet.balance += 5;
            wallet.maximum = 45; // 回调中成功重载，将上限调低。
        }
        assertEquals(45, wallet.balance);
    }

    @Test
    void exceptionRefundIsIdempotentAndDisabledManaDoesNotUndoCallbackChanges() {
        Wallet wallet = new Wallet(50, 100);
        var reservation = wallet.reserve(20);
        assertThrows(IllegalStateException.class, () -> {
            try (reservation) { throw new IllegalStateException("external callback"); }
        });
        reservation.close();
        assertEquals(50, wallet.balance, "重复 close 不能重复退款");
        try (var disabled = wallet.reserve(0)) { wallet.balance = 12; }
        assertEquals(12, wallet.balance);
    }

    private static final class Wallet {
        double balance;
        double maximum;
        Wallet(double balance, double maximum) { this.balance = balance; this.maximum = maximum; }
        AbilityManager.ManaReservation reserve(double amount) {
            return new AbilityManager.ManaReservation(amount, () -> Math.min(balance, maximum), () -> maximum,
                    value -> balance = value, () -> balance -= amount);
        }
    }
}
