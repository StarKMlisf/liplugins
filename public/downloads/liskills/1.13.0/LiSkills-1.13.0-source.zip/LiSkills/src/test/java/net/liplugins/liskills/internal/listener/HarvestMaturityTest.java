package net.liplugins.liskills.internal.listener;

import org.bukkit.Material;
import org.bukkit.block.data.Ageable;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Proxy;

import static org.junit.jupiter.api.Assertions.*;

class HarvestMaturityTest {
    @Test
    void changedBerryAgeMustActuallyBeTheHarvestedState() {
        assertTrue(HarvestMaturity.harvestedState(Material.SWEET_BERRY_BUSH,age(1,3)));
        assertFalse(HarvestMaturity.harvestedState(Material.SWEET_BERRY_BUSH,age(2,3)), "3变2仍可采摘，经验与额外掉落均不得视为已采收");
        assertFalse(HarvestMaturity.harvestedState(Material.SWEET_BERRY_BUSH,age(3,3)));
        assertFalse(HarvestMaturity.harvestedState(Material.SWEET_BERRY_BUSH,age(0,3)), "幼苗替换不等于完成采收");
    }

    @Test
    void cropsMustReachTheirOwnMaximumAge() {
        assertFalse(HarvestMaturity.matureCrop(Material.SWEET_BERRY_BUSH,age(1,3)));
        assertTrue(HarvestMaturity.matureCrop(Material.SWEET_BERRY_BUSH,age(2,3)));
        assertTrue(HarvestMaturity.matureCrop(Material.SWEET_BERRY_BUSH,age(3,3)));
        assertFalse(HarvestMaturity.mayHarvest(Material.WHEAT, age(6, 7)));
        assertTrue(HarvestMaturity.mayHarvest(Material.WHEAT, age(7, 7)));
        assertFalse(HarvestMaturity.mayHarvest(Material.NETHER_WART, age(2, 3)));
        assertTrue(HarvestMaturity.matureCrop(Material.NETHER_WART, age(3, 3)));
    }

    @Test
    void growthCountersAreNotMistakenForCropMaturity() {
        assertTrue(HarvestMaturity.mayHarvest(Material.SUGAR_CANE, age(0, 15)));
        assertTrue(HarvestMaturity.mayHarvest(Material.CACTUS, age(2, 15)));
        assertTrue(HarvestMaturity.mayHarvest(Material.KELP, age(4, 25)));
        assertFalse(HarvestMaturity.matureCrop(Material.SUGAR_CANE, age(15, 15)), "计数满值不得绕过人工放置检查");
        assertFalse(HarvestMaturity.matureCrop(Material.CACTUS, age(15, 15)));
    }

    private Ageable age(int age, int maximum) {
        return (Ageable) Proxy.newProxyInstance(Ageable.class.getClassLoader(), new Class<?>[]{Ageable.class}, (object, method, args) -> switch (method.getName()) {
            case "getAge" -> age;
            case "getMaximumAge" -> maximum;
            default -> throw new UnsupportedOperationException(method.getName());
        });
    }
}
