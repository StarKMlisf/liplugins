package net.liplugins.liskills.internal.manager.active;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class SharpHookRulesTest {
    @Test void originalThirtyThreeBlockBoundaryIsInclusive(){assertTrue(SharpHookRules.withinRange(1089,33));assertFalse(SharpHookRules.withinRange(1089.01,33));}
    @Test void impossibleDistanceIsRejected(){assertFalse(SharpHookRules.withinRange(-1,33));assertFalse(SharpHookRules.withinRange(Double.NaN,33));assertFalse(SharpHookRules.withinRange(1,Double.POSITIVE_INFINITY));}
    @Test void healthLossCommitsCost(){assertTrue(SharpHookRules.damaged(10,0,9.5,0));}
    @Test void absorptionLossAlsoCountsAsRealHit(){assertTrue(SharpHookRules.damaged(10,4,10,3.5));}
    @Test void cancelledOrInvulnerableHitDoesNotCommit(){assertFalse(SharpHookRules.damaged(10,4,10,4));assertFalse(SharpHookRules.damaged(10,4,11,4));}
    @Test void invalidObservationDoesNotCommit(){assertFalse(SharpHookRules.damaged(10,0,Double.NaN,0));assertFalse(SharpHookRules.damaged(10,-1,9,0));}
}
