package net.liplugins.liskills.internal.manager;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ChargedShotAttemptTest {
    @Test void laterCancellationRestoresTheSameArrowOnlyAfterResolution() {
        ChargedShotAttempt attempt = new ChargedShotAttempt();
        assertTrue(attempt.begin());
        assertFalse(attempt.begin(), "本次事件未结束时嵌套伤害不能再增强");
        assertFalse(attempt.resolve(true, 15), "后置取消不能消费箭矢首次有效命中的资格");
        assertTrue(attempt.begin(), "下一tick结算取消后，后续真实命中可以重新尝试");
        assertTrue(attempt.resolve(false, 15));
        assertFalse(attempt.begin());
    }

    @Test void firstSuccessfulAttemptCannotBeReusedByPiercingOrLaterCalls() {
        ChargedShotAttempt attempt = new ChargedShotAttempt();
        assertTrue(attempt.begin());
        assertFalse(attempt.begin(), "同tick下一穿透目标也不能重复增强");
        assertTrue(attempt.resolve(false, 8));
        assertFalse(attempt.begin());
        assertTrue(attempt.resolve(true, 0), "重复结算不能把已消费资格恢复");
        assertFalse(attempt.begin());
    }

    @Test void laterZeroOrInvalidFinalDamageRetainsTheQualification() {
        for (double finalDamage : new double[]{0, -1, Double.NaN, Double.POSITIVE_INFINITY}) {
            ChargedShotAttempt attempt = new ChargedShotAttempt();
            assertTrue(attempt.begin());
            assertFalse(attempt.resolve(false, finalDamage));
            assertTrue(attempt.begin(), "后置监听器把最终伤害减为零或无效时，不应吃掉资格");
        }
    }

    @Test void resolutionBeforeAnyAttemptDoesNotInventAConsumedHit() {
        ChargedShotAttempt attempt = new ChargedShotAttempt();
        assertFalse(attempt.resolve(false, 15));
        assertTrue(attempt.begin());
    }
}
