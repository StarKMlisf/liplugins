package net.liplugins.liskills.internal.manager.source;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class BrewIngredientConsumptionTest {
    @Test void singleIngredientAndPartialStacksMustActuallyDecrease() {
        assertTrue(BrewIngredientConsumption.consumed(1,0,false));
        assertTrue(BrewIngredientConsumption.consumed(64,63,true));
    }
    @Test void UnchangedOrSameTickRefilledIngredientCannotProveCompletion() {
        assertFalse(BrewIngredientConsumption.consumed(1,1,true));
        assertFalse(BrewIngredientConsumption.consumed(64,64,true));
        assertFalse(BrewIngredientConsumption.consumed(32,33,true));
    }
    @Test void DragonBreathReplacedByGlassBottleCountsAsIngredientConsumed() {
        assertTrue(BrewIngredientConsumption.consumed(1,1,false));
    }
    @Test void NoOriginalIngredientNeverCreatesCredit() {
        assertFalse(BrewIngredientConsumption.consumed(0,0,false));
    }
}
