package net.liplugins.liskills.internal.config;

import org.bukkit.configuration.file.YamlConfiguration;
import org.junit.jupiter.api.Test;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import static org.junit.jupiter.api.Assertions.*;

class AuraTemplateUpgradeTest {
    private static final Map<String,List<String>> OLD=Map.of(
            "mining",List.of("POTION","极速采掘","HASTE"),
            "fishing",List.of("QUICK_FISH","快速咬钩","LUCK"),
            "archery",List.of("CHARGED_SHOT","蓄力射击","SPEED"),
            "defense",List.of("MANA_SHIELD","魔力护盾","RESISTANCE"),
            "fighting",List.of("POTION","战斗专注","STRENGTH"));
    private YamlConfiguration oldDefaults() {
        var yaml=new YamlConfiguration();yaml.set("config-version",3);
        OLD.forEach((id,values)->{
            yaml.set("skills."+id+".enabled",true);
            yaml.createSection("skills."+id+".active",Map.of("enabled",true,"type",values.get(0),"name",values.get(1),"effect",values.get(2),
                    "amplifier",0,"duration-seconds",10,"cooldown-seconds",60,"unlock-level",5,"mana-cost",20.0));
        });
        return yaml;
    }
    @Test void exactOldBlocksProduceTheShippedFourthTemplateAndKeepComments()throws Exception {
        var yaml=oldDefaults();var defaults=new YamlConfiguration();
        try(var in=getClass().getResourceAsStream("/skills.yml")){defaults.load(new InputStreamReader(in,StandardCharsets.UTF_8));}
        yaml.setComments("skills.mining.active.type",List.of("管理员自己的注释"));
        yaml.setInlineComments("skills.mining.active.mana-cost",List.of("保留行尾说明"));
        yaml.set("skills.mining.block-xp.STONE",123.5);
        assertTrue(AuraTemplateUpgrade.apply(yaml));assertEquals(4,yaml.getInt("config-version"));
        for(String id:OLD.keySet()) {
            String path="skills."+id+".active";
            var expected=defaults.getConfigurationSection(path);
            assertEquals(expected.getKeys(false),yaml.getConfigurationSection(path).getKeys(false));
            for(String key:expected.getKeys(false)) {
                Object value=expected.get(key),actual=yaml.get(path+"."+key);
                if(value instanceof Number number)assertEquals(number.doubleValue(),((Number)actual).doubleValue(),path+"."+key);
                else assertEquals(value,actual,path+"."+key);
            }
        }
        assertEquals(List.of("管理员自己的注释"),yaml.getComments("skills.mining.active.type"));
        assertEquals(List.of("保留行尾说明"),yaml.getInlineComments("skills.mining.active.mana-cost"));
        assertEquals(123.5,yaml.getDouble("skills.mining.block-xp.STONE"));
        assertFalse(AuraTemplateUpgrade.apply(yaml));
    }
    @Test void changingAnyOneFieldOrAddingAnUnknownKeyPreservesTheWholeBlock() {
        Map<String,Object> edits=Map.of("enabled",false,"type","QUICK_FISH","name","服主技能","effect","SPEED",
                "amplifier",1,"duration-seconds",11,"cooldown-seconds",61,"unlock-level",6,"mana-cost",21,"custom-option",true);
        for(var edit:edits.entrySet()) {
            var yaml=oldDefaults();yaml.set("skills.mining.active."+edit.getKey(),edit.getValue());
            var before=yaml.getConfigurationSection("skills.mining.active").getValues(false);
            assertTrue(AuraTemplateUpgrade.apply(yaml));
            assertEquals(before,yaml.getConfigurationSection("skills.mining.active").getValues(false),edit.getKey());
            assertEquals("ABSORPTION",yaml.getString("skills.defense.active.type"));
        }
    }
    @Test void missingFieldsAndDisabledSkillsAreNotMigrated() {
        var yaml=oldDefaults();yaml.set("skills.fishing.enabled",false);yaml.set("skills.archery.active.mana-cost",null);
        assertTrue(AuraTemplateUpgrade.apply(yaml));
        assertEquals("QUICK_FISH",yaml.getString("skills.fishing.active.type"));
        assertEquals("CHARGED_SHOT",yaml.getString("skills.archery.active.type"));
        assertFalse(yaml.contains("skills.archery.active.mana-cost"));
    }
    @Test void versionMarkerPreventsLaterCustomEditsBeingMistakenForOldDefaults() {
        var yaml=oldDefaults();yaml.set("skills.fishing.active.mana-cost",21);AuraTemplateUpgrade.apply(yaml);
        yaml.set("skills.fishing.active.mana-cost",20);assertFalse(AuraTemplateUpgrade.apply(yaml));
        assertEquals("QUICK_FISH",yaml.getString("skills.fishing.active.type"));
    }
    @Test void onlyExactNumericRevisionThreeIsAccepted() {
        for(Object revision:List.of(1,2,4,5,3.01,"3",true)) {
            var yaml=oldDefaults();yaml.set("config-version",revision);assertFalse(AuraTemplateUpgrade.apply(yaml));
            assertEquals(revision,yaml.get("config-version"));
        }
        var yaml=oldDefaults();yaml.set("config-version",3.0);yaml.set("skills.mining.active.mana-cost",20);
        assertTrue(AuraTemplateUpgrade.apply(yaml));assertEquals("SPEED_MINE",yaml.getString("skills.mining.active.type"));
        assertFalse(AuraTemplateUpgrade.apply(new YamlConfiguration()));
    }
    @Test void oldMigrationRunsFirstAndNewMigrationDoesNotRepeatItsResponsibilities() {
        var yaml=oldDefaults();yaml.set("config-version",2);
        for(String id:List.of("archery","fishing","defense")) {
            yaml.set("skills."+id+".active.type","POTION");
            yaml.set("skills."+id+".active.name",switch(id){case "archery"->"游击步伐";case "fishing"->"幸运垂钓";default->"坚韧护体";});
        }
        assertFalse(AuraTemplateUpgrade.apply(yaml));assertTrue(SkillConfigUpgrade.apply(yaml));
        assertTrue(AuraTemplateUpgrade.apply(yaml));
        assertEquals("AURA_CHARGED_SHOT",yaml.getString("skills.archery.active.type"));
        assertEquals("SHARP_HOOK",yaml.getString("skills.fishing.active.type"));
        assertEquals("ABSORPTION",yaml.getString("skills.defense.active.type"));
    }
}
