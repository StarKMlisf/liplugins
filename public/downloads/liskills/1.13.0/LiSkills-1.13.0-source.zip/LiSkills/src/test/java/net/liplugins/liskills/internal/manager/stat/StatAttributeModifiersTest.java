package net.liplugins.liskills.internal.manager.stat;

import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.inventory.EquipmentSlotGroup;
import org.junit.jupiter.api.Test;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class StatAttributeModifiersTest {
    private static final NamespacedKey OWNED = new NamespacedKey("liskills", "stat_health");
    private static final NamespacedKey FOREIGN = new NamespacedKey("another_plugin", "stat_health");

    @Test void removalPreservesCustomBaseAndSameNamedForeignModifier() {
        TestAttribute attribute = new TestAttribute(30);
        AttributeModifier foreign = modifier(FOREIGN, 4, AttributeModifier.Operation.ADD_NUMBER, EquipmentSlotGroup.ANY);
        attribute.addModifier(foreign);
        StatAttributeModifiers.update(attribute, OWNED, 12);
        assertEquals(46, attribute.getValue());

        StatAttributeModifiers.update(attribute, OWNED, 0);
        assertEquals(30, attribute.getBaseValue());
        assertEquals(34, attribute.getValue());
        assertEquals(List.of(foreign), List.copyOf(attribute.getModifiers()));
        assertEquals(0, attribute.baseWrites);
    }

    @Test void repeatedRefreshAndRepeatedCleanupDoNotStackOrTouchForeignBonuses() {
        TestAttribute attribute = new TestAttribute(20);
        attribute.addModifier(modifier(FOREIGN, .5, AttributeModifier.Operation.ADD_SCALAR, EquipmentSlotGroup.ANY));
        StatAttributeModifiers.update(attribute, OWNED, 10);
        int writes = attribute.modifierWrites;
        for (int index = 0; index < 20; index++) StatAttributeModifiers.update(attribute, OWNED, 10);
        assertEquals(writes, attribute.modifierWrites);
        assertEquals(45, attribute.getValue());
        for (int index = 0; index < 20; index++) StatAttributeModifiers.update(attribute, OWNED, 0);
        assertEquals(30, attribute.getValue());
        assertEquals(1, attribute.getModifiers().size());
        assertEquals(0, attribute.baseWrites);
    }

    @Test void upgradingAnOwnedModifierRepairsItsOperationAndSlotWithoutChangingItsKey() {
        TestAttribute attribute = new TestAttribute(20);
        attribute.addModifier(modifier(OWNED, 10, AttributeModifier.Operation.MULTIPLY_SCALAR_1, EquipmentSlotGroup.ANY));
        StatAttributeModifiers.update(attribute, OWNED, 10);
        assertEquals(30, attribute.getValue());
        attribute.removeModifier(attribute.modifiers.get(OWNED));
        attribute.addModifier(modifier(OWNED, 10, AttributeModifier.Operation.ADD_NUMBER, EquipmentSlotGroup.HAND));
        StatAttributeModifiers.update(attribute, OWNED, 10);
        assertEquals(EquipmentSlotGroup.ANY, attribute.modifiers.get(OWNED).getSlotGroup());
        assertEquals(AttributeModifier.Operation.ADD_NUMBER, attribute.modifiers.get(OWNED).getOperation());
    }

    @Test void invalidOrDisabledBonusesRemoveOnlyThePreviousOwnedValue() {
        for (double amount : new double[] { 0, -1, Double.NaN, Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY }) {
            TestAttribute attribute = new TestAttribute(30);
            attribute.addModifier(modifier(FOREIGN, 4, AttributeModifier.Operation.ADD_NUMBER, EquipmentSlotGroup.ANY));
            StatAttributeModifiers.update(attribute, OWNED, 10);
            StatAttributeModifiers.update(attribute, OWNED, amount);
            assertEquals(34, attribute.getValue());
            assertFalse(attribute.modifiers.containsKey(OWNED));
            assertEquals(0, attribute.baseWrites);
        }
        assertDoesNotThrow(() -> StatAttributeModifiers.update(null, OWNED, 10));
    }

    private static AttributeModifier modifier(NamespacedKey key, double amount,
                                              AttributeModifier.Operation operation, EquipmentSlotGroup group) {
        return new AttributeModifier(key, amount, operation, group);
    }

    /** Bukkit 属性替身会记录基值写入，确保卸载清理无法悄悄将玩家还原成固定二十点生命。 */
    private static final class TestAttribute implements AttributeInstance {
        private final Map<NamespacedKey, AttributeModifier> modifiers = new LinkedHashMap<>();
        private double base;
        private int baseWrites;
        private int modifierWrites;

        private TestAttribute(double base) { this.base = base; }
        @Override public Attribute getAttribute() { return null; }
        @Override public double getBaseValue() { return base; }
        @Override public void setBaseValue(double value) { base = value; baseWrites++; }
        @Override public Collection<AttributeModifier> getModifiers() { return List.copyOf(modifiers.values()); }
        @Override public void addModifier(AttributeModifier modifier) {
            if (modifiers.putIfAbsent(modifier.getKey(), modifier) != null) throw new IllegalArgumentException("duplicate modifier");
            modifierWrites++;
        }
        @Override public void removeModifier(AttributeModifier modifier) { modifiers.remove(modifier.getKey()); modifierWrites++; }
        @Override public double getValue() {
            double number = base + modifiers.values().stream()
                    .filter(modifier -> modifier.getOperation() == AttributeModifier.Operation.ADD_NUMBER)
                    .mapToDouble(AttributeModifier::getAmount).sum();
            double value = number * (1 + modifiers.values().stream()
                    .filter(modifier -> modifier.getOperation() == AttributeModifier.Operation.ADD_SCALAR)
                    .mapToDouble(AttributeModifier::getAmount).sum());
            for (AttributeModifier modifier : modifiers.values()) {
                if (modifier.getOperation() == AttributeModifier.Operation.MULTIPLY_SCALAR_1) value *= 1 + modifier.getAmount();
            }
            return value;
        }
        @Override public double getDefaultValue() { return 20; }
    }
}
