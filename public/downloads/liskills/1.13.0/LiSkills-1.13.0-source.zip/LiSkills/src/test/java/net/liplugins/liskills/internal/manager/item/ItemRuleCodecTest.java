package net.liplugins.liskills.internal.manager.item;

import net.liplugins.liskills.internal.config.ItemModifierOperation;
import net.liplugins.liskills.internal.config.ItemSlot;
import org.junit.jupiter.api.Test;
import java.util.List;
import java.util.Set;
import static org.junit.jupiter.api.Assertions.*;

class ItemRuleCodecTest {
    private final ItemRuleCodec codec = new ItemRuleCodec();
    @Test void roundTripsNamedRuleRequirementsAndAllEffectFamilies() {
        var rule = ItemRuleEditor.named("legendary", Set.of(ItemSlot.MAIN_HAND, ItemSlot.OFF_HAND));
        rule = ItemRuleEditor.stat(rule, "strength", ItemModifierOperation.ADD, 5);
        rule = ItemRuleEditor.stat(rule, "strength", ItemModifierOperation.MULTIPLY, 1.25);
        rule = ItemRuleEditor.stat(rule, "strength", ItemModifierOperation.ADD_PERCENT, 10);
        rule = ItemRuleEditor.trait(rule, "farming-luck", ItemModifierOperation.ADD, 40);
        rule = ItemRuleEditor.experience(rule, "all", 25);
        rule = ItemRuleEditor.requirement(rule, "sorcery_2", 12);
        var result = codec.decode(codec.encode(List.of(rule))).getFirst();
        assertEquals(rule.id(), result.id()); assertEquals(rule.slots(), result.slots());
        assertEquals(rule.attributes(), result.attributes()); assertEquals(rule.statMultipliers(), result.statMultipliers());
        assertEquals(rule.statPercentAdditions(), result.statPercentAdditions()); assertEquals(rule.traits(), result.traits());
        assertEquals(rule.skillXpMultipliers(), result.skillXpMultipliers()); assertEquals(rule.requirements(), result.requirements());
    }
    @Test void rejectsMalformedSchemaOversizeAndDuplicateNames() {
        assertThrows(IllegalArgumentException.class, () -> codec.decode("schema: 2\nrules: {}\n"));
        assertThrows(IllegalArgumentException.class, () -> codec.decode("schema: '1'\nrules: {}\n"));
        assertThrows(IllegalArgumentException.class, () -> codec.decode("schema: 1\nrules: {}\nforeign: true\n"));
        assertThrows(IllegalArgumentException.class, () -> codec.decode("x".repeat(65537)));
        var rule = ItemRuleEditor.experience(ItemRuleEditor.named("one", Set.of(ItemSlot.MAIN_HAND)), "all", 5);
        assertThrows(IllegalArgumentException.class, () -> codec.encode(List.of(rule, rule)));
        assertThrows(IllegalArgumentException.class, () -> codec.encode(java.util.Collections.nCopies(33, rule)));
    }
    @Test void managementApiCannotBypassNumericAndIdentifierValidation() {
        var rule = ItemRuleEditor.named("one", Set.of(ItemSlot.MAIN_HAND));
        assertThrows(IllegalArgumentException.class, () -> codec.encode(List.of(ItemRuleEditor.stat(rule, "strength", ItemModifierOperation.MULTIPLY, 11))));
        assertThrows(IllegalArgumentException.class, () -> codec.encode(List.of(ItemRuleEditor.experience(rule, "all", Double.NaN))));
        assertThrows(IllegalArgumentException.class, () -> codec.encode(List.of(ItemRuleEditor.trait(rule, "unknown", ItemModifierOperation.ADD, 1))));
        assertThrows(IllegalArgumentException.class, () -> codec.encode(List.of(ItemRuleEditor.requirement(rule, "BadSkill", 1))));
        assertThrows(IllegalArgumentException.class, () -> codec.encode(List.of(ItemRuleEditor.requirement(rule, "fighting", 0))));
    }
    @Test void ownedRulesCannotInjectConfigurationMatchers() {
        var rule = ItemRuleEditor.experience(ItemRuleEditor.named("one", Set.of(ItemSlot.MAIN_HAND)), "all", 5);
        String encoded = codec.encode(List.of(rule)).replace("    enabled:", "    match: {}\n    enabled:");
        assertThrows(IllegalArgumentException.class, () -> codec.decode(encoded));
    }
}
