package net.liplugins.liskills.internal.config;

import org.bukkit.configuration.file.YamlConfiguration;
import org.junit.jupiter.api.Test;
import java.util.Map;
import static org.junit.jupiter.api.Assertions.*;

class CustomExperienceRatesTest {
    @Test void exactIdsZerosAndDottedIdsSurviveYamlAndOverrideFallback() throws Exception {
        var yaml = new YamlConfiguration();
        yaml.loadFromString("rates:\n  'pack:Apple': 8.5\n  'pack:fish.rare': 12\n  disabled: 0\n");
        var rates = CustomExperienceRates.parse(yaml,"rates");
        var crops = new CustomCropsSettings(true,5,rates);
        var fish = new CustomFishingSettings(true,30,rates,true);
        assertEquals(8.5,crops.xp("pack:Apple"));
        assertEquals(5,crops.xp("pack:apple"));
        assertEquals(12,fish.xp("pack:fish.rare"));
        assertEquals(0,fish.xp("disabled"));
        assertEquals(30,fish.xp("unmapped"));
        assertEquals(0,crops.xp(null));
        assertThrows(UnsupportedOperationException.class,() -> rates.put("new",1.0));
    }

    @Test void rejectsInvalidNumericRewardsBeforeReplacingConfigSnapshot() throws Exception {
        for (String value : new String[]{"-1",".nan",".inf","1000000001","'30'","[1, 2]"}) {
            var yaml = new YamlConfiguration();
            yaml.loadFromString("rates:\n  tuna: "+value+"\n");
            assertThrows(IllegalArgumentException.class,() -> CustomExperienceRates.parse(yaml,"rates"),value);
        }
    }

    @Test void emptyMappingIsValidButScalarAndWhitespaceIdsAreRejected() throws Exception {
        var yaml = new YamlConfiguration();
        yaml.loadFromString("rates: {}\n");
        assertEquals(Map.of(),CustomExperienceRates.parse(yaml,"rates"));
        yaml.set("rates",false);
        assertThrows(IllegalArgumentException.class,() -> CustomExperienceRates.parse(yaml,"rates"));
        yaml.loadFromString("rates:\n  ' tuna ': 1\n");
        assertThrows(IllegalArgumentException.class,() -> CustomExperienceRates.parse(yaml,"rates"));
    }
}
