package net.liplugins.liskills.internal.manager.passive.combat;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class GrindstoneExperienceMathTest {
    @Test void upstreamKnownCostsAreUsedAndUnknownsAndCursesGiveNothing() {
        assertEquals(45, GrindstoneExperienceMath.minimum("sharpness", 5));
        assertEquals(25, GrindstoneExperienceMath.minimum("mending", 1));
        assertEquals(23, GrindstoneExperienceMath.minimum("sweeping_edge", 3));
        assertEquals(0, GrindstoneExperienceMath.minimum("binding_curse", 1));
        assertEquals(0, GrindstoneExperienceMath.minimum("custom_enchantment", 5));
        assertEquals(0, GrindstoneExperienceMath.minimum("sharpness", 256));
    }
    @Test void bonusUsesAverageVanillaXpWithFiniteLimits() {
        assertEquals(15, GrindstoneExperienceMath.bonus(100, 20));
        assertEquals(0, GrindstoneExperienceMath.bonus(0, 100));
        assertEquals(0, GrindstoneExperienceMath.bonus(100, Double.NaN));
        assertEquals(100_000, GrindstoneExperienceMath.bonus(Integer.MAX_VALUE, 1000));
    }
}
