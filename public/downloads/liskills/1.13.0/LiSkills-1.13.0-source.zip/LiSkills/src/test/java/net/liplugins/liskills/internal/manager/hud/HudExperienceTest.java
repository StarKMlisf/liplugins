package net.liplugins.liskills.internal.manager.hud;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class HudExperienceTest {
    @Test void sameSkillCombinesAndExtendsItsDisplayWindow() {
        var experience = new HudExperience();
        experience.add("mining", 4, 1000, 5);
        experience.add("mining", 6, 2000, 5);
        assertEquals(10, experience.gain());
        assertTrue(experience.visible(6999));
        assertFalse(experience.visible(7000));
    }

    @Test void switchingSkillStartsANewGainWithoutMixingExperienceUnits() {
        var experience = new HudExperience();
        experience.add("mining", 4, 1000, 5);
        experience.add("farming", 2, 2000, 5);
        assertEquals("farming", experience.skill());
        assertEquals(2, experience.gain());
    }

    @Test void aGainAtTheOldDeadlineDoesNotIncludeExpiredExperience() {
        var experience = new HudExperience();
        experience.add("mining", 4, 1000, 5);
        experience.add("mining", 2, 6000, 5);
        assertEquals(2, experience.gain());
        assertTrue(experience.visible(10999));
    }

    @Test void malformedAndExcessiveExternalGainsCannotPoisonDisplayedNumbers() {
        var experience = new HudExperience();
        assertFalse(experience.visible(0));
        experience.add("mining", Double.MAX_VALUE, 1000, 5);
        experience.add("mining", Double.MAX_VALUE, 1000, 5);
        assertEquals(1e15, experience.gain());
        for (double invalid : new double[]{Double.NaN, Double.POSITIVE_INFINITY, 0, -1})
            experience.add("farming", invalid, 2000, 5);
        assertEquals("mining", experience.skill());
        assertEquals(1e15, experience.gain());
    }
}
