package net.liplugins.liskills.internal.manager.source;

import org.bukkit.Material;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class FishingSourceRulesTest {
    @Test void vanillaTreasureAndJunkMatchAuraClassification() {
        for(Material material:new Material[]{Material.BOW,Material.ENCHANTED_BOOK,Material.NAME_TAG,Material.NAUTILUS_SHELL,Material.SADDLE})
            assertEquals("treasure",FishingSourceRules.category(material,false),material.name());
        for(Material material:new Material[]{Material.LILY_PAD,Material.BOWL,Material.LEATHER,Material.LEATHER_BOOTS,Material.ROTTEN_FLESH,Material.STICK,Material.STRING,Material.BONE,Material.INK_SAC,Material.TRIPWIRE_HOOK,Material.POTION})
            assertEquals("junk",FishingSourceRules.category(material,false),material.name());
    }
    @Test void rodEnchantmentDistinguishesTreasureFromJunk() {
        assertEquals("junk",FishingSourceRules.category(Material.FISHING_ROD,false));
        assertEquals("treasure",FishingSourceRules.category(Material.FISHING_ROD,true));
    }
    @Test void FishAndUnknownMaterialsPreserveSkillMaterialOrEventExperience() {
        for(Material material:new Material[]{Material.COD,Material.SALMON,Material.TROPICAL_FISH,Material.PUFFERFISH,Material.BAMBOO,Material.DIAMOND})assertNull(FishingSourceRules.category(material,false));
    }
}
