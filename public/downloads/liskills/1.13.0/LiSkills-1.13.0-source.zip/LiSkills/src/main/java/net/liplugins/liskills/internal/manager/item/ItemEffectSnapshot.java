package net.liplugins.liskills.internal.manager.item;

import net.liplugins.liskills.internal.config.ItemModifier;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/** 单次装备读取后的不可变效果；所有类别共享相同的等级/权限判定结果。 */
public record ItemEffectSnapshot(Map<String, ItemModifier> stats, Map<String, ItemModifier> traits,
                                 Map<String, Double> skillXpPercent) {
    public static final ItemEffectSnapshot EMPTY = new ItemEffectSnapshot(Map.of(), Map.of(), Map.of());
    public ItemEffectSnapshot {
        stats = Map.copyOf(stats); traits = Map.copyOf(traits); skillXpPercent = Map.copyOf(skillXpPercent);
    }
    public Map<String, Double> statAdditions() {
        Map<String, Double> result = new LinkedHashMap<>();
        stats.forEach((id, value) -> result.put(id, value.add()));
        return Collections.unmodifiableMap(result);
    }
    public void applyStats(Map<String, Double> values) {
        stats.forEach((id, modifier) -> values.computeIfPresent(id, (key, value) -> modifier.apply(value)));
    }
    public double trait(String id, double raw) { return traits.getOrDefault(id, ItemModifier.NONE).apply(raw); }
    /** 原版物品经验为百分比加法：全技能与指定技能相加；最终0至10倍，不按装备连乘。 */
    public double skillExperienceMultiplier(String skill) {
        double percent = skillXpPercent.getOrDefault("all", 0.0);
        if (!"all".equals(skill)) percent += skillXpPercent.getOrDefault(skill, 0.0);
        return Math.clamp(1 + percent / 100, 0, 10);
    }
}
