package net.liplugins.liskills.internal.listener;

import org.bukkit.Material;
import org.bukkit.block.data.Ageable;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.type.CaveVinesPlant;

import java.util.Set;

/** 区分真正的作物成熟年龄与甘蔗、仙人掌等植物的内部生长计数。 */
public final class HarvestMaturity {
    private static final Set<Material> AGE_CROPS = Set.of(
            Material.WHEAT, Material.POTATOES, Material.CARROTS, Material.BEETROOTS,
            Material.NETHER_WART, Material.COCOA, Material.SWEET_BERRY_BUSH,
            Material.PITCHER_CROP, Material.TORCHFLOWER_CROP
    );

    private HarvestMaturity() { }

    static boolean mayHarvest(Material material, BlockData data) {
        if (AGE_CROPS.contains(material)) return matureCrop(material, data);
        if (data instanceof CaveVinesPlant vines) return vines.isBerries();
        return true;
    }

    static boolean matureCrop(Material material, BlockData data) {
        // 甜浆果在第二阶段已可右键采收，不必等到最终第三阶段。
        if(material==Material.SWEET_BERRY_BUSH)return data instanceof Ageable age && age.getAge()>=2;
        if (AGE_CROPS.contains(material)) {
            return data instanceof Ageable age && age.getAge() == age.getMaximumAge();
        }
        return data instanceof CaveVinesPlant vines && vines.isBerries();
    }
    public static boolean harvestedState(Material material,BlockData data) {
        if(material==Material.SWEET_BERRY_BUSH)return data instanceof Ageable age && age.getAge()==1;
        return data instanceof CaveVinesPlant vines && !vines.isBerries();
    }
}
