package net.liplugins.liskills.internal.config;

/** 主动能力的时间语义；旧窗口类型和新增瞬发/开关类型严格区分。 */
public final class ActiveTimingRules {
    private ActiveTimingRules() { }
    public static boolean hasWindow(String type) {
        return !"SHARP_HOOK".equals(type) && !isToggle(type);
    }
    public static boolean isToggle(String type) { return "AURA_CHARGED_SHOT".equals(type); }
}
