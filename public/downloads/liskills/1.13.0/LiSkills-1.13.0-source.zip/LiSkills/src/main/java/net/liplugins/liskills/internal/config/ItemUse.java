package net.liplugins.liskills.internal.config;

/** 配置可逐项选择需要检查等级的使用入口；移动、丢弃和脱下物品不属于危险使用。 */
public enum ItemUse { ATTACK, BREAK, PLACE, INTERACT, SHOOT, CONSUME, FISH, EQUIP }
