package net.liplugins.liskills.internal.manager.stat;

import org.bukkit.NamespacedKey;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.inventory.EquipmentSlotGroup;

/** 只增减给定完整命名键的成长修饰符；绝不覆盖属性基值或清空其他来源的加成。 */
final class StatAttributeModifiers {
    private StatAttributeModifiers() { }

    static void update(AttributeInstance attribute, NamespacedKey key, double amount) {
        if (attribute == null) return;
        AttributeModifier previous = null;
        for (AttributeModifier modifier : attribute.getModifiers()) {
            if (modifier.getKey().equals(key)) previous = modifier;
        }
        // Folia 必须重建为 transient；不能把旧版本写入 NBT 的同值修饰符误当成已迁移。
        if (!net.liplugins.liskills.lib.scheduler.ServerThreads.folia()
                && previous != null && previous.getOperation() == AttributeModifier.Operation.ADD_NUMBER
                && previous.getSlotGroup().equals(EquipmentSlotGroup.ANY)
                && Double.isFinite(amount) && amount > 0 && Math.abs(previous.getAmount() - amount) < 1e-9) return;
        if (previous != null) attribute.removeModifier(previous);
        if (Double.isFinite(amount) && amount > 0) {
            net.liplugins.liskills.lib.scheduler.AttributeModifiers.add(attribute,
                    new AttributeModifier(key, amount, AttributeModifier.Operation.ADD_NUMBER, EquipmentSlotGroup.ANY));
        }
    }
}
