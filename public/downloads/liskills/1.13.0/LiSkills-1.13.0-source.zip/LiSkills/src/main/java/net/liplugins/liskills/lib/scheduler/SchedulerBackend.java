package net.liplugins.liskills.lib.scheduler;

import org.bukkit.Location;
import org.bukkit.entity.Entity;

/** 原生调度适配；返回仅负责取消的操作，null表示实体已退休而未接收任务。 */
interface SchedulerBackend {
    boolean enabled();
    Runnable global(Runnable run, long delay, long period);
    Runnable entity(Entity entity, Runnable run, Runnable retired, long delay, long period);
    Runnable region(Location location, Runnable run, long delay);
}
