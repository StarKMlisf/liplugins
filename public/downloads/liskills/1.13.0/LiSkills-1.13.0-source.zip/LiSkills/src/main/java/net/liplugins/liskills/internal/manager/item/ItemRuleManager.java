package net.liplugins.liskills.internal.manager.item;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.config.ItemRule;
import net.liplugins.liskills.internal.config.ItemSlot;
import net.liplugins.liskills.internal.config.ItemUse;
import net.liplugins.liskills.internal.manager.ProfileManager;
import net.liplugins.liskills.internal.manager.SkillManager;
import org.bukkit.GameMode;
import net.liplugins.liskills.lib.scheduler.ServerThreads;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import java.util.List;
import java.util.Optional;

/** 统一物品规则与等级资格，供物品属性、使用拦截和后续物品管理接口复用。 */
public final class ItemRuleManager {
    public static final String BYPASS_PERMISSION = "liskills.items.bypass";
    private final ConfigManager config;
    private final ProfileManager profiles;
    private final SkillManager skills;
    private final ItemMetadataService metadata;

    public ItemRuleManager(ConfigManager config, ProfileManager profiles, SkillManager skills) {
        this(config, profiles, skills, new ItemMetadataService());
    }
    public ItemRuleManager(ConfigManager config, ProfileManager profiles, SkillManager skills, ItemMetadataService metadata) {
        this.config = config; this.profiles = profiles; this.skills = skills;
        this.metadata = metadata;
    }

    public boolean active(Player player) {
        if (!config.items().enabled() || !config.progressionEnabled() || player == null
                || !ServerThreads.owns(player) || !player.isOnline() || player.isDead() || player.hasMetadata("NPC")) return false;
        var settings = config.settings();
        return !settings.disabledWorlds().contains(player.getWorld().getName())
                && (!settings.survivalOnly() || player.getGameMode() == GameMode.SURVIVAL || player.getGameMode() == GameMode.ADVENTURE);
    }

    /** 只读查询配置匹配，便于管理界面查看规则；调用者不必伪造装备或修改物品。 */
    public List<ItemRule> matching(ItemStack item, ItemSlot slot) {
        if (slot == null || !config.items().enabled()) return List.of();
        var result = new java.util.ArrayList<>(config.items().rules().stream().filter(rule -> rule.slots().contains(slot)
                && ItemRuleMatcher.matches(rule, item)).toList());
        var owned = metadata.read(item);
        if (owned.valid()) owned.rules().stream().filter(rule -> rule.enabled() && rule.slots().contains(slot)).forEach(result::add);
        return List.copyOf(result);
    }

    public Optional<ItemDenial> denial(Player player, ItemStack item, ItemSlot slot, ItemUse use) {
        if (!active(player) || player.hasPermission(BYPASS_PERMISSION)) return Optional.empty();
        if (!metadata.read(item).valid()) {
            ItemRule invalid = ItemRuleEditor.named("invalid_item_data", java.util.Set.of(slot == null ? ItemSlot.MAIN_HAND : slot));
            return Optional.of(new ItemDenial(invalid, new ItemRequirement("", 0, 0, ItemRequirement.Reason.ITEM_DATA_INVALID)));
        }
        for (ItemRule rule : matching(item, slot)) {
            if (!rule.uses().contains(use)) continue;
            var failure = failure(player, rule);
            if (failure.isPresent()) return Optional.of(new ItemDenial(rule, failure.get()));
        }
        return Optional.empty();
    }

    public boolean canUse(Player player, ItemStack item, ItemSlot slot, ItemUse use) {
        return ServerThreads.owns(player) && denial(player, item, slot, use).isEmpty();
    }

    /** 同一装备位命中的全部规则共同约束；不能绕过较严格规则只领取另一条规则的属性。 */
    public List<ItemRule> qualifying(Player player, ItemStack item, ItemSlot slot) {
        if (!active(player) || !skills.eligible(player) || profiles.get(player.getUniqueId()) == null) return List.of();
        if (!metadata.read(item).valid()) return List.of();
        List<ItemRule> matched = matching(item, slot);
        if (!player.hasPermission(BYPASS_PERMISSION) && matched.stream().anyMatch(rule -> failure(player, rule).isPresent()))
            return List.of();
        return matched;
    }

    private Optional<ItemRequirement> failure(Player player, ItemRule rule) {
        var profile = profiles.get(player.getUniqueId());
        return ItemRequirement.firstFailure(rule.requirements(), profile != null,
                id -> profile == null ? 0 : profile.progress(id).level(),
                id -> config.skill(id) != null && config.skill(id).enabled(),
                id -> player.hasPermission("liskills.use") && player.hasPermission("liskills.skill." + id));
    }
}
