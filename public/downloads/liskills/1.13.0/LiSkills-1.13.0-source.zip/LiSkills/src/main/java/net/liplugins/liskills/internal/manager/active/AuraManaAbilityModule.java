package net.liplugins.liskills.internal.manager.active;

import net.liplugins.liskills.internal.config.AuraManaSettings;
import net.liplugins.liskills.internal.config.AuraChargedShotSettings;
import net.liplugins.liskills.internal.config.AbsorptionActivationSettings;
import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.hook.LiRealEnchantHook;
import net.liplugins.liskills.internal.manager.AbilityManager;
import net.liplugins.liskills.internal.manager.ActiveAbilityHandler;
import net.liplugins.liskills.internal.manager.ProfileManager;
import net.liplugins.liskills.internal.manager.SkillAbilityWindows;
import net.liplugins.liskills.internal.manager.SkillManager;
import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.Bukkit;
import org.bukkit.entity.FishHook;
import org.bukkit.event.HandlerList;
import org.bukkit.plugin.java.JavaPlugin;
import java.util.Map;
import java.util.UUID;
import java.util.function.Predicate;
import java.util.function.Supplier;

/** 只负责补齐能力的依赖与生命周期；旧主动类型由原运行时继续持有。 */
public final class AuraManaAbilityModule implements AutoCloseable {
    private final JavaPlugin plugin;
    private final LightningBladeManager lightningBlade;
    private final SharpHookManager sharpHook;
    private final AbsorptionManager absorption;
    private final SpeedMineHandler speedMine;
    private final AuraChargedShotManager chargedShot;
    private boolean registered;
    public AuraManaAbilityModule(JavaPlugin plugin,ConfigManager config,ProfileManager profiles,SkillManager skills,
                                 SkillAbilityWindows windows,LiRealEnchantHook enchantments,TextService text,
                                 Supplier<AuraManaSettings> settings,Predicate<FishHook> customHook) {
        this(plugin,config,profiles,skills,windows,enchantments,text,settings,AuraChargedShotSettings::defaults,AbsorptionActivationSettings::defaults,customHook);
    }
    public AuraManaAbilityModule(JavaPlugin plugin,ConfigManager config,ProfileManager profiles,SkillManager skills,
                                 SkillAbilityWindows windows,LiRealEnchantHook enchantments,TextService text,
                                 Supplier<AuraManaSettings> settings,Supplier<AuraChargedShotSettings> chargedSettings,
                                 Supplier<AbsorptionActivationSettings> absorptionSettings,Predicate<FishHook> customHook) {
        this.plugin=plugin;
        lightningBlade=new LightningBladeManager(plugin,config,profiles,windows,text,settings);
        sharpHook=new SharpHookManager(plugin,config,profiles,skills,enchantments,text,settings,customHook);
        absorption=new AbsorptionManager(plugin,config,profiles,windows,text,enchantments,settings,absorptionSettings);
        speedMine=new SpeedMineHandler(text,settings);
        chargedShot=new AuraChargedShotManager(plugin,config,profiles,skills,enchantments,text,chargedSettings);
    }
    public Map<String,ActiveAbilityHandler> handlers(){return Map.of("LIGHTNING_BLADE",lightningBlade,"SHARP_HOOK",sharpHook,"ABSORPTION",absorption,"SPEED_MINE",speedMine,"AURA_CHARGED_SHOT",chargedShot);}
    public void register(AbilityManager abilities) {
        if(registered)return;registered=true;sharpHook.bind(abilities);absorption.bind(abilities);chargedShot.bind(abilities);
        Bukkit.getPluginManager().registerEvents(lightningBlade,plugin);
        Bukkit.getPluginManager().registerEvents(sharpHook,plugin);
        Bukkit.getPluginManager().registerEvents(absorption,plugin);
        Bukkit.getPluginManager().registerEvents(chargedShot,plugin);
    }
    public void settleFor(UUID player){absorption.settleFor(player);chargedShot.settleFor(player);}
    @Override public void close() {
        HandlerList.unregisterAll(lightningBlade);HandlerList.unregisterAll(sharpHook);HandlerList.unregisterAll(absorption);
        HandlerList.unregisterAll(chargedShot);
        lightningBlade.close();sharpHook.close();absorption.close();speedMine.close();chargedShot.close();registered=false;
    }
}
