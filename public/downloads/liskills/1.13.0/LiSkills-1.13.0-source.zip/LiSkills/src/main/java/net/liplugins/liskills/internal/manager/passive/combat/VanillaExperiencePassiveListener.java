package net.liplugins.liskills.internal.manager.passive.combat;

import net.liplugins.liskills.internal.manager.PassiveAbilityManager;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;

/** 经验战士只对击杀事件已有的原版经验翻倍，不产生技能经验或额外击杀。 */
final class VanillaExperiencePassiveListener implements Listener {
    private final PassiveAbilityManager passives;
    VanillaExperiencePassiveListener(PassiveAbilityManager passives) { this.passives = passives; }
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDeath(EntityDeathEvent event) {
        Player killer = event.getEntity().getKiller();
        if (killer != null && !(event.getEntity() instanceof Player) && event.getDroppedExp() > 0 && passives.roll(killer, "xp_warrior"))
            event.setDroppedExp((int) Math.min(1_000_000L, event.getDroppedExp() * 2L));
    }
}
