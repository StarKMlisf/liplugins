package net.liplugins.liskills.internal.manager;

import net.liplugins.liskills.internal.config.ActiveSkill;
import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.hook.LiRealEnchantHook;
import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.SpectralArrow;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityShootBowEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerItemBreakEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;
import net.liplugins.liskills.lib.scheduler.TaskHandle;
import net.liplugins.liskills.lib.scheduler.TaskScheduler;
import net.liplugins.liskills.lib.scheduler.ServerThreads;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.OptionalDouble;
import java.util.Set;
import java.util.UUID;

/** 追踪有限数量的本次窗口箭矢，只在原生第一次有效命中事件上调整伤害。 */
public final class ChargedShotManager implements ActiveAbilityHandler, Listener, AutoCloseable {
    private static final String SKILL = "archery";
    private static final String TYPE = "CHARGED_SHOT";
    private final ConfigManager config;
    private final SkillAbilityWindows windows;
    private final TextService text;
    private final LiRealEnchantHook enchantments;
    private final Map<UUID, Shot> shots = new java.util.concurrent.ConcurrentHashMap<>();
    private final Set<UUID> pendingDamage = java.util.concurrent.ConcurrentHashMap.newKeySet();
    private final TaskScheduler scheduler;
    private final EntityWorkQueue work = new EntityWorkQueue();
    private final TaskHandle cleanup;
    private int cleanupTicks;

    public ChargedShotManager(JavaPlugin plugin, ConfigManager config, SkillAbilityWindows windows,
                              TextService text, LiRealEnchantHook enchantments) {
        this.config = config;
        this.windows = windows;
        this.text = text;
        this.enchantments = enchantments;
        // 全服只有一个任务：每 tick 结算待定命中，每10tick清理记录，不为每支箭安排任务。
        cleanup = (scheduler = new TaskScheduler(plugin)).globalTimer( this::tick, 1L, 1L);
    }

    @Override public boolean activate(Player player, ActiveSkill active) {
        if (!ServerThreads.owns(player)) return false;
        if (player.getInventory().getItemInMainHand().getType() != Material.BOW) {
            text.send(player, "ability.charged-shot-tool");
            return false;
        }
        if (windows.active(player, SKILL)) {
            text.send(player, "ability.charged-shot-already-active");
            return false;
        }
        clean();
        if (shots.size() >= config.chargedShot().maxProjectiles()) {
            text.send(player, "ability.charged-shot-capacity");
            return false;
        }
        return windows.open(player, SKILL, TYPE, active, Set.of(Material.BOW));
    }

    @Override public long remainingMillis(Player player) { return windows.remainingMillis(player, SKILL); }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onShoot(EntityShootBowEvent event) {
        if (event.isCancelled() || !(event.getEntity() instanceof Player player) || !ServerThreads.owns(player) || !ServerThreads.owns(event.getProjectile())) return;
        ItemStack bow = event.getBow();
        if (bow == null || !ChargedShotRules.qualifies(bow.getType(), event.getHand(), event.getProjectile().getType(),
                event.getForce(), config.chargedShot().minimumForce())) return;
        if (!(event.getProjectile() instanceof Arrow || event.getProjectile() instanceof SpectralArrow)) return;
        Projectile projectile = (Projectile) event.getProjectile();
        if (!(projectile.getShooter() instanceof Player shooter) || !shooter.getUniqueId().equals(player.getUniqueId())) return;
        long token = windows.token(player, SKILL);
        long remaining = windows.remainingMillis(player, SKILL);
        if (token == 0 || remaining <= 0 || !projectile.getWorld().getUID().equals(player.getWorld().getUID())) return;
        UUID uuid = projectile.getUniqueId();
        if (shots.containsKey(uuid)) return;
        if (shots.size() >= config.chargedShot().maxProjectiles()) clean();
        // 达到硬上限时保留已经发出的箭，新箭正常原版飞行；不创建额外实体，也不逐箭再扣魔力。
        if (shots.size() >= config.chargedShot().maxProjectiles()) return;
        long now = System.currentTimeMillis();
        long lifetime = Math.min(remaining, config.chargedShot().projectileLifetimeSeconds() * 1000L);
        shots.put(uuid, new Shot(player.getUniqueId(), player.getWorld().getUID(), token,
                config.revision(), now + lifetime, event));
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent event) {
        if (!ServerThreads.owns(event.getEntity()) || event.isCancelled() || event.getCause() != EntityDamageEvent.DamageCause.PROJECTILE
                || !(event.getDamager() instanceof Projectile projectile) || !ServerThreads.owns(projectile)) return;
        if (enchantments != null && enchantments.isSecondaryDamage()) return;
        UUID uuid = projectile.getUniqueId();
        Shot shot = shots.get(uuid);
        if (shot == null) return;
        if (!(projectile.getShooter() instanceof Player shooter)
                || !valid(uuid, shot, shooter, System.currentTimeMillis())
                || !projectile.getWorld().getUID().equals(shot.world)
                || !event.getEntity().getWorld().getUID().equals(shot.world)) {
            forget(uuid, shot);
            return;
        }
        // Bukkit 的碰撞事件被保护插件取消时，不在后续伤害事件补上倍率；下一次正常碰撞会更新引用。
        if (shot.collision != null && shot.collision.isCancelled()) return;
        OptionalDouble boosted = ChargedShotRules.boostedDamage(event.getDamage(), event.getFinalDamage(),
                config.chargedShot().damageMultiplier());
        if (boosted.isEmpty()) return;
        // 暂时锁定资格，防止本次事件派发期间的穿透/嵌套回调重复强化。
        // 不能在 HIGHEST 就认定成功：更晚监听器仍可能取消，下一 tick 再读最终结果。
        if (!shot.attempt.begin()) return;
        shot.damage = event;
        pendingDamage.add(uuid);
        event.setDamage(boosted.getAsDouble());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onHit(ProjectileHitEvent event) {
        if (!ServerThreads.owns(event.getEntity())) return;
        UUID uuid = event.getEntity().getUniqueId();
        Shot shot = shots.get(uuid);
        if (shot == null) return;
        shot.collision = event;
        // 实体碰撞后还需等待原生伤害事件；落地的箭不能保留能力供随后重新利用。
        if (event.getHitBlock() != null && !event.isCancelled()) forget(uuid, shot);
    }

    private boolean valid(UUID projectile, Shot shot, Player shooter, long now) {
        return now < shot.expires && config.revision() == shot.revision && !shot.launch.isCancelled()
                && shot.launch.getProjectile().getUniqueId().equals(projectile)
                && shot.owner.equals(shooter.getUniqueId())
                // 远端射手不读装备或世界；换手、退服、换世界已有玩家事件立即撤销该玩家的箭记录。
                && (!ServerThreads.owns(shooter) || (shot.world.equals(shooter.getWorld().getUID()) && windows.token(shooter, SKILL) == shot.token));
    }

    private void tick() {
        // 同步事件不跨 Bukkit tick 派发；此时包括后置 MONITOR 的取消/减伤均已结束。
        Set<UUID> batch = Set.copyOf(pendingDamage);
        pendingDamage.clear();
        for (UUID uuid : batch) {
            Shot shot = shots.get(uuid);
            if (shot == null || shot.damage == null) continue;
            EntityDamageByEntityEvent damage = shot.damage;
            work.dispatch(scheduler,damage,damage.getEntity(),()->{
                if(shot.damage!=damage)return;
                shot.damage = null;
                if (shot.attempt.resolve(damage.isCancelled(), damage.getFinalDamage())) forget(uuid, shot);
            },()->forget(uuid,shot));
        }
        if (++cleanupTicks >= 10) { cleanupTicks = 0; clean(); }
    }

    private void clean() {
        long now = System.currentTimeMillis();
        shots.forEach((uuid, shot) -> {
            Player player = Bukkit.getPlayer(shot.owner);
            if(player==null){forget(uuid,shot);return;}
            work.dispatch(scheduler,shot,shot.launch.getProjectile(),()->{
                if(!valid(uuid,shot,player,now) || !shot.launch.getProjectile().isValid() || shot.launch.getProjectile().isDead())forget(uuid,shot);
            },()->forget(uuid,shot));
        });
    }

    private void forget(UUID uuid, Shot shot) {
        if (shots.remove(uuid, shot)) pendingDamage.remove(uuid);
    }

    @EventHandler public void onQuit(PlayerQuitEvent event) { remove(event.getPlayer()); }
    @EventHandler public void onDeath(PlayerDeathEvent event) { remove(event.getEntity()); }
    @EventHandler public void onWorld(PlayerChangedWorldEvent event) { remove(event.getPlayer()); }
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onHeld(PlayerItemHeldEvent event) {
        if (event.getPreviousSlot() != event.getNewSlot()) remove(event.getPlayer());
    }
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onSwap(PlayerSwapHandItemsEvent event) { remove(event.getPlayer()); }
    @EventHandler public void onToolBreak(PlayerItemBreakEvent event) {
        if (event.getBrokenItem().getType() == Material.BOW) remove(event.getPlayer());
    }

    private void remove(Player player) {
        windows.remove(player, SKILL);
        shots.entrySet().removeIf(entry -> {
            if (!entry.getValue().owner.equals(player.getUniqueId())) return false;
            pendingDamage.remove(entry.getKey());
            return true;
        });
    }

    @Override public void close() { cleanup.cancel(); scheduler.cancelAll(); shots.clear(); pendingDamage.clear(); }

    private static final class Shot {
        private final UUID owner, world;
        private final long token, revision, expires;
        private final EntityShootBowEvent launch;
        private final ChargedShotAttempt attempt = new ChargedShotAttempt();
        private volatile ProjectileHitEvent collision;
        private volatile EntityDamageByEntityEvent damage;

        private Shot(UUID owner, UUID world, long token, long revision, long expires, EntityShootBowEvent launch) {
            this.owner = owner;
            this.world = world;
            this.token = token;
            this.revision = revision;
            this.expires = expires;
            this.launch = launch;
        }
    }
}
