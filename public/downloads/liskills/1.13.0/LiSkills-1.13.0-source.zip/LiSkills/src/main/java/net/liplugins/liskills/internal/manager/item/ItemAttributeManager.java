package net.liplugins.liskills.internal.manager.item;

import net.liplugins.liskills.internal.config.ItemRule;
import net.liplugins.liskills.internal.config.ItemSlot;
import org.bukkit.entity.Player;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/** 只汇总当前六个装备位的九属性，不修改物品Meta或Bukkit原生修饰符。 */
public final class ItemAttributeManager {
    private final ItemRuleManager rules;
    public ItemAttributeManager(ItemRuleManager rules) { this.rules = rules; }

    public Map<String, Double> bonuses(Player player) {
        return effects(player).statAdditions();
    }
    public ItemEffectSnapshot effects(Player player) {
        if (!rules.active(player)) return ItemEffectSnapshot.EMPTY;
        Map<ItemSlot, List<ItemRule>> equipment = new EnumMap<>(ItemSlot.class);
        for (ItemSlot slot : ItemSlot.values()) {
            equipment.put(slot, rules.qualifying(player, player.getInventory().getItem(slot.equipmentSlot()), slot));
        }
        return ItemAttributeCalculator.effects(equipment);
    }
    public void apply(Player player, Map<String, Double> values) {
        effects(player).applyStats(values);
    }
    public double skillExperienceMultiplier(Player player, String skill) { return effects(player).skillExperienceMultiplier(skill); }
    public double trait(Player player, String id, double raw) { return effects(player).trait(id, raw); }
}
