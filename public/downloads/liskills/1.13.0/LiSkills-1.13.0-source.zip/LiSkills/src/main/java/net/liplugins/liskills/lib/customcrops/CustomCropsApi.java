package net.liplugins.liskills.lib.customcrops;

import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

import java.lang.reflect.Method;
import java.util.List;
import java.util.Optional;

/** 仅绑定 CustomCrops 3.6 的公开 API；不引用、打包或修改对方实现。 */
public final class CustomCropsApi {
    private static final String ROOT = "net.momirealms.customcrops.api.";
    private final Object worldManager;
    private final Object itemManager;
    private final Object blockRegistry;
    private final Class<?> cropBlock;
    private final Method getWorld, loadedState, positionFrom, blockId, registryContains;
    private final Method stateType, cropPoint, cropConfig, configId, maximumPoints;
    private final Method contextHolder;
    private final PrimaryBinding breaking, interacting;
    private final OutputBinding quality, item;

    public CustomCropsApi(Plugin plugin) throws ReflectiveOperationException {
        ClassLoader loader = plugin.getClass().getClassLoader();
        Class<?> entry = type(loader, "BukkitCustomCropsPlugin");
        Object instance = entry.getMethod("getInstance").invoke(null);
        if (instance == null) throw new IllegalStateException("CustomCrops API unavailable");
        worldManager = entry.getMethod("getWorldManager").invoke(instance);
        itemManager = entry.getMethod("getItemManager").invoke(instance);
        Class<?> world = type(loader, "core.world.CustomCropsWorld");
        Class<?> position = type(loader, "core.world.Pos3");
        Class<?> state = type(loader, "core.world.CustomCropsBlockState");
        Class<?> config = type(loader, "core.mechanic.crop.CropConfig");
        cropBlock = type(loader, "core.block.CropBlock");
        getWorld = type(loader, "core.world.WorldManager").getMethod("getWorld", World.class);
        loadedState = world.getMethod("getLoadedBlockState", position);
        positionFrom = position.getMethod("from", Location.class);
        blockId = type(loader, "core.ItemManager").getMethod("blockID", Block.class);
        blockRegistry = type(loader, "core.Registries").getField("BLOCKS").get(null);
        registryContains = type(loader, "core.Registry").getMethod("containsKey", Object.class);
        stateType = state.getMethod("type");
        cropPoint = cropBlock.getMethod("point", state);
        cropConfig = cropBlock.getMethod("config", state);
        configId = config.getMethod("id");
        maximumPoints = config.getMethod("maxPoints");
        contextHolder = type(loader, "context.Context").getMethod("holder");
        breaking = primary(loader, "CropBreakEvent", "entityBreaker", "reason");
        interacting = primary(loader, "CropInteractEvent", "getPlayer", "hand");
        quality = output(loader, "QualityCropActionEvent", "items");
        item = output(loader, "DropItemActionEvent", "item");
    }

    public List<Class<? extends Event>> primaryEvents() { return List.of(breaking.type, interacting.type); }
    public List<Class<? extends Event>> outputEvents() { return List.of(quality.type, item.type); }

    public Primary primary(Event event) throws ReflectiveOperationException {
        PrimaryBinding binding = breaking.type.isInstance(event) ? breaking : interacting;
        Object actor = binding.actor.invoke(event);
        if (!(actor instanceof Player player)) return null;
        boolean interaction = binding == interacting;
        Object mode = binding.mode.invoke(event);
        if (interaction && mode != EquipmentSlot.HAND) return null;
        String reason = interaction ? "INTERACT" : String.valueOf(mode);
        Object state = binding.state.invoke(event);
        Object kind = stateType.invoke(state);
        if (!cropBlock.isInstance(kind)) return null;
        Object config = binding.config.invoke(event);
        String id = (String) configId.invoke(config);
        int point = ((Number) cropPoint.invoke(kind, state)).intValue();
        int maximum = ((Number) maximumPoints.invoke(config)).intValue();
        return new Primary(player, ((Location) binding.location.invoke(event)).clone(), id,
                point, maximum, state, interaction, reason);
    }

    public Output output(Event event) throws ReflectiveOperationException {
        OutputBinding binding = quality.type.isInstance(event) ? quality : item;
        Object context = binding.context.invoke(event);
        Object holder = contextHolder.invoke(context);
        if (!(holder instanceof Player player)) return null;
        return new Output(player, ((Location) binding.location.invoke(event)).clone(), context);
    }

    /** 在下一 tick 读取最终物品列表，尊重后置监听器取消、清空或替换产出。 */
    public boolean hasOutput(Event event) throws ReflectiveOperationException {
        OutputBinding binding = quality.type.isInstance(event) ? quality : item;
        Object value = binding.items.invoke(event);
        if (value instanceof ItemStack stack) return present(stack);
        if (value instanceof Iterable<?> values) {
            for (Object element : values) if (element instanceof ItemStack stack && present(stack)) return true;
        }
        return false;
    }

    /** 只查询已加载状态，避免扫描或技能队列意外加载远处区块。 */
    public Object stateAt(Location location) throws ReflectiveOperationException {
        if (location.getWorld() == null || !location.getWorld().isChunkLoaded(location.getBlockX() >> 4, location.getBlockZ() >> 4)) return null;
        Optional<?> world = (Optional<?>) getWorld.invoke(worldManager, location.getWorld());
        if (world.isEmpty()) return null;
        Object position = positionFrom.invoke(null, location);
        return ((Optional<?>) loadedState.invoke(world.get(), position)).orElse(null);
    }

    public boolean owns(Block block) throws ReflectiveOperationException {
        if (!block.getWorld().isChunkLoaded(block.getX() >> 4, block.getZ() >> 4)) return false;
        if (stateAt(block.getLocation()) != null) return true;
        Object id = blockId.invoke(itemManager, block);
        return id != null && Boolean.TRUE.equals(registryContains.invoke(blockRegistry, id));
    }

    public boolean harvested(Primary primary) throws ReflectiveOperationException {
        // 世界被 CustomCrops 卸载不等于作物被收获，不能把查询不到状态直接当成功。
        Optional<?> loadedWorld = (Optional<?>) getWorld.invoke(worldManager, primary.location.getWorld());
        if (loadedWorld.isEmpty()) return false;
        Object current = stateAt(primary.location);
        if (current == null || current != primary.state) return true;
        Object kind = stateType.invoke(current);
        if (!cropBlock.isInstance(kind)) return true;
        Object currentConfig = cropConfig.invoke(kind, current);
        if (currentConfig == null || !primary.cropId.equals(configId.invoke(currentConfig))) return true;
        return ((Number) cropPoint.invoke(kind, current)).intValue() < primary.point;
    }

    private static boolean present(ItemStack stack) { return stack.getAmount() > 0 && !stack.getType().isAir(); }
    private static Class<?> type(ClassLoader loader, String name) throws ClassNotFoundException {
        return Class.forName(ROOT + name, true, loader);
    }
    private static PrimaryBinding primary(ClassLoader loader, String name, String actor, String mode) throws ReflectiveOperationException {
        Class<? extends Event> type = type(loader, "event." + name).asSubclass(Event.class);
        return new PrimaryBinding(type, type.getMethod(actor), type.getMethod(mode), type.getMethod("location"),
                type.getMethod("blockState"), type.getMethod("cropConfig"));
    }
    private static OutputBinding output(ClassLoader loader, String name, String items) throws ReflectiveOperationException {
        Class<? extends Event> type = type(loader, "event." + name).asSubclass(Event.class);
        return new OutputBinding(type, type.getMethod("context"), type.getMethod("location"), type.getMethod(items));
    }
    private record PrimaryBinding(Class<? extends Event> type, Method actor, Method mode, Method location, Method state, Method config) { }
    private record OutputBinding(Class<? extends Event> type, Method context, Method location, Method items) { }
    public record Primary(Player player, Location location, String cropId, int point, int maximum,
                          Object state, boolean interaction, String reason) { }
    public record Output(Player player, Location location, Object context) { }
}
