package net.liplugins.liskills.internal.listener;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.manager.AbilityManager;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;

/** 潜行右键主手对应工具快速施放，不拦截原版交互，不响应副手重复事件。 */
public final class SneakRightClickListener implements Listener {
    private final ConfigManager config;
    private final AbilityManager abilities;

    public SneakRightClickListener(ConfigManager config, AbilityManager abilities) {
        this.config = config;
        this.abilities = abilities;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onInteract(PlayerInteractEvent event) {
        if (!config.quickCast() || event.getHand() != EquipmentSlot.HAND) return;
        Player player = event.getPlayer();
        if (!player.isSneaking()) return;
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        // RIGHT_CLICK_AIR 的原版无操作可能使 isCancelled 为 true，使用具体的物品使用结果判断。
        if (event.useItemInHand() == Event.Result.DENY) return;
        if (event.getClickedBlock() != null) {
            if (event.getClickedBlock().getType().isInteractable() || event.useInteractedBlock() == Event.Result.DENY) return;
            Material offhand = player.getInventory().getItemInOffHand().getType();
            if (!offhand.isAir() && offhand.isBlock()) return;
        }
        String skill = skillFor(player.getInventory().getItemInMainHand().getType());
        if (skill != null) abilities.activate(player, skill);
    }

    static String skillFor(Material material) {
        String name = material.name();
        if (name.endsWith("_PICKAXE")) return "mining";
        if (name.endsWith("_AXE")) return "foraging";
        if (name.endsWith("_SHOVEL")) return "excavation";
        if (name.endsWith("_HOE")) return "farming";
        if (name.endsWith("_SWORD")) return "fighting";
        if(material==Material.BOW)return "archery";
        if(material==Material.FISHING_ROD)return "fishing";
        if(material==Material.SHIELD)return "defense";
        return null;
    }
}
