package net.liplugins.liskills.internal.manager.passive.combat;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.manager.PassiveAbilityManager;
import net.liplugins.liskills.internal.manager.ProfileManager;
import org.bukkit.Material;
import net.liplugins.liskills.lib.scheduler.ServerThreads;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.LingeringPotionSplashEvent;
import org.bukkit.event.entity.EntityPotionEffectEvent;
import org.bukkit.event.entity.PotionSplashEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

/** 糖分冲刺、喷溅延时和滞留衰减；只延长已实际落地的同级药水效果，不重放瞬间治疗或伤害。 */
final class PotionDurationPassiveListener implements Listener, AutoCloseable {
    private final ConfigManager config;
    private final ProfileManager profiles;
    private final PassiveAbilityManager passives;
    private final DeferredPassiveEffects effects;
    private final Map<EffectKey, Application> applications = new java.util.concurrent.ConcurrentHashMap<>();

    PotionDurationPassiveListener(ConfigManager config, ProfileManager profiles, PassiveAbilityManager passives, DeferredPassiveEffects effects) {
        this.config = config; this.profiles = profiles; this.passives = passives; this.effects = effects;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDrink(PlayerItemConsumeEvent event) {
        if (event.getItem().getType() != Material.POTION || !(event.getItem().getItemMeta() instanceof PotionMeta meta)) return;
        Player player = event.getPlayer();
        if (!passives.enabled(player, "sugar_rush")) return;
        Map<PotionEffectType, PotionEffect> expected = new LinkedHashMap<>();
        if (meta.getBasePotionType() != null) add(expected, meta.getBasePotionType().getPotionEffects());
        add(expected, meta.getCustomEffects());
        Map<PotionEffectType, Long> before = revisions(player, expected.keySet());
        PassiveSession session = PassiveSession.capture(player, profiles, config);
        effects.submit(player.getUniqueId(), () -> {
            if (event.isCancelled() || !session.valid(profiles, config)) return;
            for (PotionEffect effect : expected.values()) if (mobility(effect.getType()))
                extend(player, effect, 1, multiplier(passives.value(player, "sugar_rush")),
                        before.get(effect.getType()), EntityPotionEffectEvent.Cause.POTION_DRINK);
        });
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onSplash(PotionSplashEvent event) {
        Player shooter = event.getPotion().getShooter() instanceof Player player && ServerThreads.owns(player) ? player : null;
        PassiveSession shooterSession = shooter == null ? null : PassiveSession.capture(shooter, profiles, config);
        Map<PotionEffectType, PotionEffect> expected = new LinkedHashMap<>();
        add(expected, event.getPotion().getEffects());
        for (var entity : event.getAffectedEntities()) {
            if (!(entity instanceof Player player) || !ServerThreads.owns(player) || profiles.get(player.getUniqueId()) == null) continue;
            Map<PotionEffectType, Long> before = revisions(player, expected.keySet());
            PassiveSession session = PassiveSession.capture(player, profiles, config);
            effects.submit(player.getUniqueId(), () -> {
                if (event.isCancelled() || !session.valid(profiles, config)) return;
                double intensity = event.getIntensity(player);
                if (intensity <= 0) return;
                long targets = event.getAffectedEntities().stream().filter(target -> target instanceof Player
                        && profiles.get(target.getUniqueId()) != null && event.getIntensity(target) > 0).count();
                double splasher = shooterSession != null && shooterSession.valid(profiles, config)
                        ? passives.value(shooter, "splasher") * Math.min(100, targets) : 0;
                for (PotionEffect effect : expected.values()) {
                    double sugar = mobility(effect.getType()) ? passives.value(player, "sugar_rush") : 0;
                    extend(player, effect, intensity, multiplier(splasher) * multiplier(sugar),
                            before.get(effect.getType()), EntityPotionEffectEvent.Cause.POTION_SPLASH);
                }
            });
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onEffect(EntityPotionEffectEvent event) {
        if (!(event.getEntity() instanceof Player player) || event.getNewEffect() == null
                || (event.getCause() != EntityPotionEffectEvent.Cause.POTION_DRINK
                && event.getCause() != EntityPotionEffectEvent.Cause.POTION_SPLASH)) return;
        EffectKey key = new EffectKey(player.getUniqueId(), event.getNewEffect().getType());
        if (!applications.containsKey(key) && applications.size() >= 4096) return;
        Application previous = applications.get(key);
        applications.put(key, new Application(previous == null ? 1 : previous.revision + 1, event));
    }

    private Map<PotionEffectType, Long> revisions(Player player, Collection<PotionEffectType> types) {
        Map<PotionEffectType, Long> result = new HashMap<>();
        for (PotionEffectType type : types) {
            Application previous = applications.get(new EffectKey(player.getUniqueId(), type));
            result.put(type, previous == null ? 0 : previous.revision);
        }
        return result;
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onLingering(LingeringPotionSplashEvent event) {
        if (!(event.getEntity().getShooter() instanceof Player player) || !ServerThreads.owns(player) || !ServerThreads.owns(event.getAreaEffectCloud()) || !passives.enabled(player, "lingering")) return;
        var cloud = event.getAreaEffectCloud();
        cloud.setRadiusPerTick(cloud.getRadiusPerTick() * (float) Math.max(.01, 1 - passives.value(player, "lingering") / 100));
        cloud.setRadiusOnUse(cloud.getRadiusOnUse() * (float) Math.max(.01, 1 - passives.secondary(player, "lingering") / 100));
    }

    private static void add(Map<PotionEffectType, PotionEffect> target, Collection<PotionEffect> values) {
        for (PotionEffect effect : values) if (!effect.getType().isInstant()) target.merge(effect.getType(), effect,
                (first, second) -> second.getAmplifier() > first.getAmplifier() || second.getAmplifier() == first.getAmplifier()
                        && second.getDuration() > first.getDuration() ? second : first);
    }
    private static boolean mobility(PotionEffectType type) { return type.equals(PotionEffectType.SPEED) || type.equals(PotionEffectType.JUMP_BOOST); }
    private static double multiplier(double percent) { return 1 + Math.clamp(percent, 0, 1000) / 100; }

    private void extend(Player player, PotionEffect expected, double intensity, double multiplier, long previousRevision,
                        EntityPotionEffectEvent.Cause cause) {
        if (multiplier <= 1 || expected.getDuration() < 1) return;
        Application application = applications.get(new EffectKey(player.getUniqueId(), expected.getType()));
        // 必须恰好对应本次来源之后的一次成功原版施药，旧同级效果不作为成功凭据。
        if (application == null || application.revision != previousRevision + 1 || application.event.isCancelled()
                || application.event.getCause() != cause || application.event.getNewEffect() == null
                || application.event.getNewEffect().getAmplifier() != expected.getAmplifier()
                || application.event.getAction() != EntityPotionEffectEvent.Action.ADDED
                && (application.event.getAction() != EntityPotionEffectEvent.Action.CHANGED || !application.event.isOverride())) return;
        PotionEffect current = player.getPotionEffect(expected.getType());
        int vanilla = (int) Math.round(expected.getDuration() * Math.clamp(intensity, 0, 1));
        // 其他插件取消效果、改级别、延长/缩短持续时间时一律不认领；不覆盖较强或已存在的长效果。
        if (current == null || current.getAmplifier() != expected.getAmplifier() || current.getDuration() > vanilla
                || current.getDuration() < vanilla - 3) return;
        int duration = (int) Math.clamp(Math.round(vanilla * multiplier) - (vanilla - current.getDuration()), 1, 1_000_000);
        if (duration > current.getDuration()) player.addPotionEffect(new PotionEffect(current.getType(), duration,
                current.getAmplifier(), current.isAmbient(), current.hasParticles(), current.hasIcon()));
    }
    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent event) { applications.keySet().removeIf(key -> key.player.equals(event.getPlayer().getUniqueId())); }
    @Override public void close() { applications.clear(); }
    private record EffectKey(UUID player, PotionEffectType type) { }
    private record Application(long revision, EntityPotionEffectEvent event) { }
}
