package net.liplugins.liskills.internal.manager;

import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.Set;

/** 纯坐标六邻广度优先队列；所有入队点去重且受扫描总量与三个坐标轴范围限制。 */
final class TreeTraversal {
    record Position(int x, int y, int z) { }
    private static final int[][] OFFSETS = {{1,0,0},{-1,0,0},{0,1,0},{0,-1,0},{0,0,1},{0,0,-1}};
    private final Position origin;
    private final int radius;
    private final int maxScans;
    private final ArrayDeque<Position> queue = new ArrayDeque<>();
    private final Set<Position> visited = new HashSet<>();
    private int scans;

    TreeTraversal(Position origin, int radius, int maxScans) {
        if (radius < 1 || maxScans < 1) throw new IllegalArgumentException("tree traversal limits");
        this.origin = origin;
        this.radius = radius;
        this.maxScans = maxScans;
        queue.add(origin);
        visited.add(origin);
    }

    Position poll() {
        if (scans >= maxScans) return null;
        Position next = queue.pollFirst();
        if (next != null) scans++;
        return next;
    }

    void expand(Position position) {
        for (int[] offset : OFFSETS) {
            if (visited.size() >= maxScans) return;
            long x = (long) position.x + offset[0], y = (long) position.y + offset[1], z = (long) position.z + offset[2];
            if (Math.abs(x - origin.x) > radius || Math.abs(y - origin.y) > radius || Math.abs(z - origin.z) > radius) continue;
            if (x < Integer.MIN_VALUE || x > Integer.MAX_VALUE || y < Integer.MIN_VALUE || y > Integer.MAX_VALUE || z < Integer.MIN_VALUE || z > Integer.MAX_VALUE) continue;
            Position next = new Position((int) x, (int) y, (int) z);
            if (visited.add(next)) queue.addLast(next);
        }
    }

    int scans() { return scans; }
    int visitedCount() { return visited.size(); }
}
