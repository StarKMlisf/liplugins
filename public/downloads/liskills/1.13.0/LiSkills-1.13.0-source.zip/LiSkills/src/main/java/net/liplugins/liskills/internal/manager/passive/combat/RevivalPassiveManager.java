package net.liplugins.liskills.internal.manager.passive.combat;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.manager.PassiveAbilityManager;
import net.liplugins.liskills.internal.manager.ProfileManager;
import net.liplugins.liskills.internal.manager.stat.StatManager;
import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.plugin.java.JavaPlugin;
import net.liplugins.liskills.lib.scheduler.TaskHandle;
import net.liplugins.liskills.lib.scheduler.TaskScheduler;
import net.liplugins.liskills.lib.scheduler.ServerThreads;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** 复苏仅授予死亡重生后的30秒临时九属性；不保存到档案，也不恢复被其他插件管理的属性基值。 */
final class RevivalPassiveManager implements Listener, AutoCloseable {
    private final ConfigManager config;
    private final ProfileManager profiles;
    private final PassiveAbilityManager passives;
    private final StatManager stats;
    private final TextService text;
    private final DeferredPassiveEffects effects;
    private final Map<UUID, Lease> leases = new java.util.concurrent.ConcurrentHashMap<>();
    private final TaskScheduler scheduler;
    private final net.liplugins.liskills.internal.manager.EntityWorkQueue work = new net.liplugins.liskills.internal.manager.EntityWorkQueue();
    private final TaskHandle task;

    RevivalPassiveManager(JavaPlugin plugin, ConfigManager config, ProfileManager profiles, PassiveAbilityManager passives,
                          StatManager stats, TextService text, DeferredPassiveEffects effects) {
        this.config = config; this.profiles = profiles; this.passives = passives; this.stats = stats; this.text = text; this.effects = effects;
        stats.passiveBonusProvider(this::bonuses);
        task = (scheduler = new TaskScheduler(plugin)).globalTimer( this::cleanup, 1, 20);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onRespawn(PlayerRespawnEvent event) {
        Player player = event.getPlayer();
        remove(player);
        // 回末地传送门不算死亡；延后到玩家活着且档案仍为同一份时再计算资格。
        if (event.getRespawnReason() != PlayerRespawnEvent.RespawnReason.DEATH) return;
        var profile = profiles.get(player.getUniqueId());
        long revision = config.revision();
        effects.submit(player.getUniqueId(), () -> {
            if (profile == null || profiles.get(player.getUniqueId()) != profile || revision != config.revision()
                    || !player.getWorld().equals(event.getRespawnLocation().getWorld()) || !passives.enabled(player, "revival")) return;
            leases.put(player.getUniqueId(), new Lease(PassiveSession.capture(player, profiles, config), System.nanoTime() + 30_000_000_000L));
            stats.refresh(player);
            if (passives.flag("revival", "enable_message", true)) text.send(player, "passive.revival", Map.of(
                    "value", text.format(passives.value(player, "revival")), "secondary", text.format(passives.secondary(player, "revival")), "seconds", 30));
        });
    }

    private Map<String, Double> bonuses(Player player) {
        Lease lease = leases.get(player.getUniqueId());
        if (lease == null || !valid(lease) || !passives.enabled(player, "revival")) return Map.of();
        return Map.of("health", passives.value(player, "revival"), "regeneration", passives.secondary(player, "revival"));
    }

    private boolean valid(Lease lease) { return System.nanoTime() < lease.expires && lease.session.valid(profiles, config); }
    private void cleanup() {
        for (Lease lease : List.copyOf(leases.values())) work.dispatch(scheduler, lease, lease.session.player(), () -> {
            if (!valid(lease) || !passives.enabled(lease.session.player(), "revival")) remove(lease.session.player());
        }, () -> leases.remove(lease.session.player().getUniqueId(), lease));
    }
    @EventHandler(priority = EventPriority.LOWEST) public void onQuit(PlayerQuitEvent event) { remove(event.getPlayer()); }
    @EventHandler(priority = EventPriority.MONITOR) public void onDeath(PlayerDeathEvent event) { remove(event.getEntity()); }
    @EventHandler(priority = EventPriority.MONITOR) public void onWorld(PlayerChangedWorldEvent event) { remove(event.getPlayer()); }
    private void remove(Player player) { if (leases.remove(player.getUniqueId()) != null) stats.refresh(player); }
    @Override public void close() {
        task.cancel();
        scheduler.cancelAll();
        List<Player> players = leases.values().stream().map(lease -> lease.session.player()).toList();
        leases.clear(); stats.passiveBonusProvider(player -> Map.of()); players.forEach(stats::refresh);
    }
    private record Lease(PassiveSession session, long expires) { }
}
