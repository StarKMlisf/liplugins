package net.liplugins.liskills.internal.config;

import org.bukkit.configuration.ConfigurationSection;
import java.util.*;

/** 职业选择和自然经验收入配置；默认关闭经济，不改变普通技能升级。 */
public record JobsSettings(boolean enabled,boolean selectionRequired,boolean disableUnselectedXp,
                           int maximumJobs,int changeCooldownSeconds,double dailyLimit,Map<String,Double> moneyPerXp) {
    public JobsSettings { moneyPerXp=Map.copyOf(moneyPerXp); }
    public static JobsSettings parse(ConfigurationSection root,Set<String> skills){
        Map<String,Double> rates=new LinkedHashMap<>();
        var section=ConfigValues.section(root,"money-per-xp");
        for(String skill:section.getKeys(false)){
            if(!skills.contains(skill))throw ConfigValues.invalid("jobs.money-per-xp."+skill,"已注册技能");
            rates.put(skill,ConfigValues.number(section,skill,0,100));
        }
        return new JobsSettings(ConfigValues.bool(root,"enabled"),ConfigValues.bool(root,"selection-required"),
                ConfigValues.bool(root,"disable-unselected-xp"),ConfigValues.integer(root,"maximum-jobs",1,64),
                ConfigValues.integer(root,"change-cooldown-seconds",0,604800),ConfigValues.number(root,"daily-limit",0,1e6),rates);
    }
}
