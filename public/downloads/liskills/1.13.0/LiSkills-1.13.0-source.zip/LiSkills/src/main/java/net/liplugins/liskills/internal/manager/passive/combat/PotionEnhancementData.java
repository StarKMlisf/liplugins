package net.liplugins.liskills.internal.manager.passive.combat;

import org.bukkit.NamespacedKey;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionType;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/** 保存并校验本插件生成的药水元数据归属，不认领或清理第三方效果。 */
final class PotionEnhancementData {
    private final NamespacedKey marker,base,bonus,effects,lore;
    private final Set<NamespacedKey> requiredKeys;

    PotionEnhancementData(NamespacedKey marker) {
        this.marker=marker;
        base=key(marker,"_base");bonus=key(marker,"_bonus");effects=key(marker,"_effects");lore=key(marker,"_lore");
        requiredKeys=Set.of(marker,base,bonus,effects);
    }

    Upgrade read(PotionMeta meta) {
        PersistentDataContainer data=meta.getPersistentDataContainer();
        if(!data.has(marker,PersistentDataType.BYTE) || !data.has(base,PersistentDataType.STRING)
                || !data.has(bonus,PersistentDataType.DOUBLE) || !data.has(effects,PersistentDataType.STRING)
                || (data.getKeys().contains(lore) && !data.has(lore,PersistentDataType.STRING))) return null;
        if(!Byte.valueOf((byte)1).equals(data.get(marker,PersistentDataType.BYTE))) return null;
        String source=data.get(base,PersistentDataType.STRING),signature=data.get(effects,PersistentDataType.STRING);
        Double percent=data.get(bonus,PersistentDataType.DOUBLE);
        String generatedLore=data.get(lore,PersistentDataType.STRING);
        Set<NamespacedKey> expectedKeys=new HashSet<>(requiredKeys);
        if(generatedLore!=null) expectedKeys.add(lore);
        // 任意额外PDC、错类型记录、外部追加Lore或效果改动都表示不再由本模块独占。
        if(!data.getKeys().equals(expectedKeys) || source==null || signature==null || percent==null
                || !Double.isFinite(percent) || percent<=0 || percent>1000
                || !signature.equals(signature(meta.getCustomEffects()))
                || (generatedLore==null?meta.hasLore():!List.of(generatedLore).equals(meta.getLore()))) return null;
        try{return new Upgrade(PotionType.valueOf(source),percent,signature,generatedLore);}
        catch(IllegalArgumentException ignored){return null;}
    }

    void write(PotionMeta meta,PotionType type,double percent,String generatedLore) {
        PersistentDataContainer data=meta.getPersistentDataContainer();
        data.set(marker,PersistentDataType.BYTE,(byte)1);
        data.set(base,PersistentDataType.STRING,type.name());
        data.set(bonus,PersistentDataType.DOUBLE,percent);
        data.set(effects,PersistentDataType.STRING,signature(meta.getCustomEffects()));
        if(generatedLore==null) data.remove(lore);
        else data.set(lore,PersistentDataType.STRING,generatedLore);
    }

    void remove(PotionMeta meta) {
        // 调用者已核对全部归属信息；仅删除命名明确的自身字段，不清空容器。
        requiredKeys.forEach(meta.getPersistentDataContainer()::remove);
        meta.getPersistentDataContainer().remove(lore);
    }

    private static NamespacedKey key(NamespacedKey marker,String suffix) {
        return new NamespacedKey(marker.getNamespace(),marker.getKey()+suffix);
    }
    private static String signature(List<PotionEffect> values) {
        return values.stream().map(effect->effect.getType().getKey()+":"+effect.getDuration()+":"+effect.getAmplifier()
                +":"+effect.isAmbient()+":"+effect.hasParticles()+":"+effect.hasIcon()).collect(Collectors.joining(";"));
    }
    record Upgrade(PotionType base,double bonus,String signature,String lore) { }
}
