package net.liplugins.liskills.internal.manager;

import net.liplugins.liskills.lib.scheduler.ServerThreads;
import org.bukkit.Location;

import net.liplugins.liskills.internal.config.TreeFellingSettings;
import net.liplugins.liskills.internal.listener.PlacedBlockTracker;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.type.Leaves;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

/** 只读扫描树干与树冠环境，不加载新区块，不改变方块。 */
final class TreePlanner {
    private final Predicate<Block> placed;
    private final Predicate<Location> ownership;

    TreePlanner(PlacedBlockTracker placed) { this(placed::contains); }
    TreePlanner(Predicate<Block> placed) { this(placed, ServerThreads::owns); }
    TreePlanner(Predicate<Block> placed, Predicate<Location> ownership) { this.placed = placed; this.ownership = ownership; }

    List<TreeTraversal.Position> plan(Block origin, TreeFellingSettings settings) {
        if (!ownership.test(new Location(origin.getWorld(), origin.getX(), origin.getY(), origin.getZ()))) return List.of();
        String family = family(origin.getType());
        if (family == null || placed.test(origin)) return List.of();
        World world = origin.getWorld();
        TreeTraversal traversal = new TreeTraversal(position(origin), settings.radius(), settings.maxScans());
        List<TreeTraversal.Position> logs = new ArrayList<>();
        boolean naturalCanopy = false;
        TreeTraversal.Position next;
        while ((next = traversal.poll()) != null) {
            Block block = loadedBlock(world, next, ownership);
            if (block == null || placed.test(block)) continue;
            if (family.equals(family(block.getType()))) {
                if (logs.size() < settings.maxBlocks()) {
                    logs.add(next);
                }
                // 破坏上限不等于识别上限：仍可在扫描预算内继续找树冠，避免大树被完全拒绝。
                traversal.expand(next);
            } else if (canopy(block, family)) {
                naturalCanopy = true;
            }
        }
        return naturalCanopy ? List.copyOf(logs) : List.of();
    }

    static Block loadedBlock(World world, TreeTraversal.Position position) {
        return loadedBlock(world, position, ServerThreads::owns);
    }
    static Block loadedBlock(World world, TreeTraversal.Position position, Predicate<Location> ownership) {
        if (position.y() < world.getMinHeight() || position.y() >= world.getMaxHeight()
                || !ownership.test(new Location(world, position.x(), position.y(), position.z()))
                || !world.isChunkLoaded(position.x() >> 4, position.z() >> 4)) return null;
        return world.getBlockAt(position.x(), position.y(), position.z());
    }

    static TreeTraversal.Position position(Block block) {
        return new TreeTraversal.Position(block.getX(), block.getY(), block.getZ());
    }

    static String family(Material material) {
        String name = material.name();
        if (name.startsWith("STRIPPED_")) name = name.substring(9);
        if (name.endsWith("_LOG")) return name.substring(0, name.length() - 4);
        if (name.equals("CRIMSON_STEM")) return "CRIMSON";
        if (name.equals("WARPED_STEM")) return "WARPED";
        if (name.equals("MUSHROOM_STEM")) return "MUSHROOM";
        return null;
    }

    private boolean canopy(Block block, String family) {
        if (family.equals("CRIMSON")) return block.getType() == Material.NETHER_WART_BLOCK;
        if (family.equals("WARPED")) return block.getType() == Material.WARPED_WART_BLOCK;
        if (family.equals("MUSHROOM")) return block.getType() == Material.BROWN_MUSHROOM_BLOCK || block.getType() == Material.RED_MUSHROOM_BLOCK;
        return block.getType().name().equals(family + "_LEAVES")
                && block.getBlockData() instanceof Leaves leaves && !leaves.isPersistent();
    }
}
