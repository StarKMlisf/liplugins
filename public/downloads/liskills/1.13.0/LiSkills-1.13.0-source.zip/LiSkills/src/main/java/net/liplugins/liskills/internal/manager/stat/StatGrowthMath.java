package net.liplugins.liskills.internal.manager.stat;

/** 属性奖励次数的纯计算；副属性在首次奖励、首次+间隔等等级生效。 */
public final class StatGrowthMath {
    private StatGrowthMath() { }

    public static int awards(int level, int start, int interval) {
        if (start < 1 || interval < 1) throw new IllegalArgumentException("奖励起始等级和间隔必须为正整数");
        return level < start ? 0 : 1 + (level - start) / interval;
    }
}
