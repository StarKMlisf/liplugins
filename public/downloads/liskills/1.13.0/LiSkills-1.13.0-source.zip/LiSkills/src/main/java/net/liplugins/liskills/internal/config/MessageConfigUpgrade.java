package net.liplugins.liskills.internal.config;

import org.bukkit.configuration.file.YamlConfiguration;
import java.util.Map;

/** 历史固定存储提示的精确升级；此表仅匹配旧默认，不用于发送文本，新提示仍读取消息资源。 */
final class MessageConfigUpgrade {
    private static final Map<String,String> LEGACY=Map.of(
            "storage.load-failed","玩家 {player} 的档案加载失败：{error}；已拒绝创建空白档案覆盖，请检查 players 下的备份。",
            "storage.shutdown-timeout","技能数据保存超过 20 秒，请检查磁盘和权限，不要立即强制终止 Java 进程。",
            "boot.conflict","检测到 AuraSkills。请先备份并移除旧插件，再启动 LiSkills，避免双重经验与属性叠加。",
            "extended.item-aura-preview","<aqua>Aura识别：{recognized}；可完整迁移：{complete}；规则：{count}；问题：{problems}",
            "extended.item-invalid","<red>编辑未执行：参数越界、规则损坏、装备位冲突或Aura数据不完整。原物品未改动。",
            "extended.usage-item","/lsk item inspect|identify <ID>|stat/trait <规则> <属性/效果> ADD/MULTIPLY/ADD_PERCENT <值> [装备位]|xp <规则> <技能/all> <百分比> [装备位]|require <规则> <技能> <等级> [装备位]|remove <规则>|clear|aura-preview|aura-migrate");
    private MessageConfigUpgrade(){ }
    static boolean apply(YamlConfiguration current,YamlConfiguration defaults){
        boolean changed=false;
        for(var entry:LEGACY.entrySet())if(entry.getValue().equals(current.get(entry.getKey()))&&defaults.isString(entry.getKey())){
            current.set(entry.getKey(),defaults.getString(entry.getKey()));changed=true;
        }
        changed |= replaceLine(current,defaults,"rpg.stats-summary-lore","<gray>十一项技能分别提供主属性和副属性。","十五项职业");
        changed |= replaceLine(current,defaults,"rpg.summary-lore","<gray>下方列出此技能的五项被动能力。","当前页的被动能力");
        return changed;
    }
    private static boolean replaceLine(YamlConfiguration current,YamlConfiguration defaults,String path,String old,String marker) {
        if(!current.isList(path) || !defaults.isList(path))return false;
        var lines=new java.util.ArrayList<>(current.getStringList(path));
        String replacement=defaults.getStringList(path).stream().filter(line->line.contains(marker)).findFirst().orElse(null);
        if(replacement==null || !lines.contains(old))return false;
        lines.replaceAll(line->line.equals(old)?replacement:line);current.set(path,lines);return true;
    }
}
