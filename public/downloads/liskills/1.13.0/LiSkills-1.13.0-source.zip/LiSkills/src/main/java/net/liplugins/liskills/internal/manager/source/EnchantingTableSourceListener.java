package net.liplugins.liskills.internal.manager.source;

import net.liplugins.liskills.internal.config.EnchantingSourceSettings;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.enchantment.EnchantItemEvent;
import org.bukkit.inventory.ItemStack;
import java.util.function.Supplier;

/** 附魔台：最终事件未取消、原版等级已支付且结果确实有新增附魔才结算等级总和。 */
final class EnchantingTableSourceListener implements Listener {
    private final SourceExperienceService rewards;private final Supplier<EnchantingSourceSettings> settings;
    EnchantingTableSourceListener(SourceExperienceService rewards,Supplier<EnchantingSourceSettings> settings){this.rewards=rewards;this.settings=settings;}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void onEnchant(EnchantItemEvent event) {
        var policy=settings.get();var player=event.getEnchanter();var session=rewards.capture(player,"enchanting");
        ItemStack before=SourceItemRules.copy(event.getItem());
        if(!policy.enabled() || session==null || SourceItemRules.empty(before) || event.getExpLevelCost()<=0
                || (policy.ignoreCustomItems() && SourceItemRules.custom(before)))return;
        String category=SourceItemRules.category(before.getType());if(category==null)return;
        int previousLevel=player.getLevel();var oldEnchants=SourceEnchantments.read(before);
        rewards.deferOnce(event,()->{
            if(event.isCancelled() || !rewards.valid(session) || !settings.get().enabled() || player.getLevel()>=previousLevel)return;
            ItemStack actual=event.getInventory().getItem(0);
            if(SourceItemRules.empty(actual) || (actual.getType()!=before.getType() && !(before.getType()==Material.BOOK && actual.getType()==Material.ENCHANTED_BOOK))
                    || (policy.ignoreCustomItems() && SourceItemRules.custom(actual)))return;
            int levels=EnchantingSourceRules.addedLevels(oldEnchants,SourceEnchantments.keys(event.getEnchantsToAdd()),SourceEnchantments.read(actual),policy.maximumLevelsPerAction());
            rewards.award(session,"table",policy.xp("table."+category)*levels,policy.actionCooldownTicks(),policy.maximumXpPerMinute());
        });
    }
}
