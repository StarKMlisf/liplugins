package net.liplugins.liskills.internal.manager.source;

import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.EnchantmentStorageMeta;
import java.util.HashMap;
import java.util.Map;

/** 统一读取普通装备与附魔书的原生附魔等级，避免把存储附魔漏算或重复计算。 */
final class SourceEnchantments {
    private SourceEnchantments() { }
    static Map<String,Integer> read(ItemStack item) {
        if(SourceItemRules.empty(item))return Map.of();
        Map<String,Integer> values=new HashMap<>(keys(item.getEnchantments()));
        if(item.getItemMeta() instanceof EnchantmentStorageMeta storage)
            keys(storage.getStoredEnchants()).forEach((key,value)->values.merge(key,value,Math::max));
        return Map.copyOf(values);
    }
    static Map<String,Integer> keys(Map<Enchantment,Integer> entries) {
        Map<String,Integer> values=new HashMap<>();
        entries.forEach((key,value)->{if(key!=null && value!=null && value>0)values.put(key.getKey().toString(),value);});
        return values;
    }
}
