package net.liplugins.liskills.internal.manager;

import net.liplugins.liskills.internal.config.QuickFishSettings;

/** 计算合法且不会比原区间更慢的钓鱼等待上下限。 */
final class QuickFishWait {
    private QuickFishWait() { }

    record Range(int minimum, int maximum) {
        Range {
            if (minimum < 0 || maximum < minimum) throw new IllegalArgumentException("wait range");
        }
    }

    static Range shorten(Range original, QuickFishSettings settings) {
        double multiplier = settings.waitMultiplier();
        int minimum = settings.minimumWaitTicks();
        if (!Double.isFinite(multiplier) || multiplier < .05 || multiplier > 1 || minimum < 1 || minimum > 1200)
            throw new IllegalArgumentException("quick fish settings");
        // 下限只能限制本次缩短，不能反向拖慢已经被原版或其他插件缩短的鱼钩。
        int low = shorten(original.minimum, multiplier, minimum);
        int high = shorten(original.maximum, multiplier, minimum);
        return new Range(low, high);
    }

    private static int shorten(int original, double multiplier, int minimum) {
        // 向上取整避免小整数被意外变为零；double 乘法也避免 int 乘法溢出。
        return Math.min(original, Math.max(minimum, (int) Math.ceil(original * multiplier)));
    }
}
