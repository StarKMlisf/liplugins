package net.liplugins.liskills.internal.manager.ledger;

import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.entity.Player;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Logger;

/** 对账本不可用进行有界、限频的中文反馈；不改变原始故障记录，也不自动重试外部奖励。 */
public final class LedgerFailureReporter {
    private final Logger logger;private final TextService text;private final Map<UUID,Long> warned=new LinkedHashMap<>();
    public LedgerFailureReporter(Logger logger,TextService text){this.logger=logger;this.text=text;}
    public synchronized void failed(Player player,IOException error){
        long now=System.currentTimeMillis();if(now-warned.getOrDefault(player.getUniqueId(),0L)<60_000)return;
        if(warned.size()>=1024)warned.remove(warned.keySet().iterator().next());warned.put(player.getUniqueId(),now);
        text.send(player,"extended.ledger-unavailable");
        logger.warning(text.plain(text.text("extended.ledger-failed-log",Map.of("player",player.getUniqueId(),"error",String.valueOf(error.getMessage())))));
    }
}
