package net.liplugins.liskills.internal.manager.source;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.potion.PotionType;
import java.util.Set;

/** 来源用的材料分类和收货数量证明，不修改任何物品或第三方元数据。 */
public final class SourceItemRules {
    private static final Set<InventoryAction> TAKE=Set.of(InventoryAction.PICKUP_ALL,InventoryAction.PICKUP_HALF,InventoryAction.PICKUP_SOME,
            InventoryAction.PICKUP_ONE,InventoryAction.MOVE_TO_OTHER_INVENTORY,InventoryAction.HOTBAR_SWAP,InventoryAction.HOTBAR_MOVE_AND_READD);
    private SourceItemRules() { }
    public static boolean take(InventoryAction action){return TAKE.contains(action);}
    public static ItemStack copy(ItemStack item){return empty(item)?null:item.clone();}
    public static boolean empty(ItemStack item){return item==null || item.getType().isAir() || item.getAmount()<=0;}
    public static boolean same(ItemStack first,ItemStack second){return empty(first)?empty(second):!empty(second) && first.equals(second);}
    public static int count(Player player,ItemStack sample) {
        int count=count(player.getInventory().getContents(),sample);ItemStack cursor=player.getItemOnCursor();
        return count+(!empty(cursor) && cursor.isSimilar(sample)?cursor.getAmount():0);
    }
    static int count(ItemStack[] items,ItemStack sample) {
        if(empty(sample))return 0;int count=0;
        for(ItemStack item:items)if(!empty(item) && item.isSimilar(sample))count+=item.getAmount();
        return count;
    }
    static String category(Material type) {
        String name=type.name();
        if(type==Material.BOOK || type==Material.ENCHANTED_BOOK)return "book";
        if(name.endsWith("_HELMET") || name.endsWith("_CHESTPLATE") || name.endsWith("_LEGGINGS") || name.endsWith("_BOOTS") || type==Material.ELYTRA)return "armor";
        if(name.endsWith("_SWORD") || name.endsWith("_SPEAR") || type==Material.BOW || type==Material.CROSSBOW || type==Material.TRIDENT || type==Material.MACE)return "weapon";
        if(name.endsWith("_PICKAXE") || name.endsWith("_AXE") || name.endsWith("_SHOVEL") || name.endsWith("_HOE") || type==Material.FISHING_ROD || type==Material.SHEARS || type==Material.FLINT_AND_STEEL)return "tool";
        return null;
    }
    static String potionKind(ItemStack item) {
        if(empty(item) || !(item.getItemMeta() instanceof PotionMeta meta))return null;
        PotionType type=meta.getBasePotionType();
        if(type==null || type.getPotionEffects().isEmpty())return null;
        return type.name().startsWith("LONG_")?"extended":type.name().startsWith("STRONG_")?"upgraded":"regular";
    }
    public static boolean custom(ItemStack item) {
        if(empty(item))return false;ItemMeta meta=item.getItemMeta();if(meta==null)return false;
        // 自家炼金增强有固定前缀标记；允许其使用基础药水来源，其他PDC/模型物品默认避让。
        boolean owned=!meta.getPersistentDataContainer().getKeys().isEmpty();
        boolean foreign=meta.getPersistentDataContainer().getKeys().stream().anyMatch(key->!key.getNamespace().equals("liskills") || !key.getKey().matches("alchemist_duration(?:_base|_bonus|_effects|_lore)?"));
        return foreign || meta.hasItemModel() || meta.hasCustomModelDataComponent() || meta.hasItemName()
                || (meta instanceof PotionMeta potion && (potion.hasColor() || potion.hasCustomEffects() && !owned));
    }
}
