package net.liplugins.liskills.internal.manager.source;

import net.liplugins.liskills.internal.config.EnchantingSourceSettings;
import net.liplugins.liskills.internal.config.SourceSkillRoutingSettings;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.view.AnvilView;
import java.util.function.Supplier;

/** 铁砧：消耗附魔书并实际领取有新增附魔的成品后，按真实支付修复等级发经验。 */
final class AnvilSourceListener implements Listener {
    private final SourceExperienceService rewards;private final Supplier<EnchantingSourceSettings> settings;
    private final Supplier<SourceSkillRoutingSettings> routing;
    AnvilSourceListener(SourceExperienceService rewards,Supplier<EnchantingSourceSettings> settings,Supplier<SourceSkillRoutingSettings> routing){this.rewards=rewards;this.settings=settings;this.routing=routing;}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void onTake(InventoryClickEvent event) {
        if(!(event.getWhoClicked() instanceof Player player) || !(event.getView() instanceof AnvilView view)
                || event.getRawSlot()!=2 || !SourceItemRules.take(event.getAction()))return;
        var policy=settings.get();var session=rewards.capture(player,routing.get().anvilSkill());var inventory=view.getTopInventory();
        ItemStack left=SourceItemRules.copy(inventory.getItem(0)),right=SourceItemRules.copy(inventory.getItem(1)),result=SourceItemRules.copy(event.getCurrentItem());
        if(!policy.enabled() || session==null || SourceItemRules.empty(left) || SourceItemRules.empty(right) || SourceItemRules.empty(result)
                || right.getType()!=Material.ENCHANTED_BOOK || (policy.ignoreCustomItems() && (SourceItemRules.custom(left) || SourceItemRules.custom(right) || SourceItemRules.custom(result))))return;
        String category=SourceItemRules.category(left.getType());int repairCost=view.getRepairCost();
        if(category==null || repairCost<=0 || EnchantingSourceRules.addedLevels(SourceEnchantments.read(left),SourceEnchantments.read(result),SourceEnchantments.read(result),1)==0)return;
        int beforeReceipt=SourceItemRules.count(player,result),beforeLevel=player.getLevel();
        rewards.deferOnce(event,()->{
            if(event.isCancelled() || !rewards.valid(session) || !settings.get().enabled()
                    || SourceItemRules.same(left,inventory.getItem(0)) || SourceItemRules.same(right,inventory.getItem(1))
                    || SourceItemRules.count(player,result)<=beforeReceipt)return;
            int paid=Math.min(repairCost,Math.max(0,beforeLevel-player.getLevel()));
            int levels=Math.min(paid,policy.maximumLevelsPerAction());
            rewards.award(session,"anvil",policy.xp("anvil."+category)*levels,policy.actionCooldownTicks(),policy.maximumXpPerMinute());
        });
    }
}
