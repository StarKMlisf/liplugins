package net.liplugins.liskills.internal.listener;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.config.SkillDefinition;
import net.liplugins.liskills.internal.manager.SkillManager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.enchantment.EnchantItemEvent;

/** 附魔台实际附魔一次结算一次，不监听预览或菜单点击。 */
public final class EnchantExperienceListener implements Listener {
    private final ConfigManager config;
    private final SkillManager skills;

    public EnchantExperienceListener(ConfigManager config, SkillManager skills) {
        this.config = config;
        this.skills = skills;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onEnchant(EnchantItemEvent event) {
        if (event.getEnchantsToAdd().isEmpty() || event.getExpLevelCost() <= 0) return;
        SkillDefinition definition = config.skill("enchanting");
        if (definition == null || !definition.enabled()) return;
        skills.award(event.getEnchanter(), "enchanting", definition.eventXp());
    }
}
