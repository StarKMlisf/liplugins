package net.liplugins.liskills.lib.scheduler;

/** 本插件拥有的任务句柄；取消可跨线程调用，不会中断已经开始的回调。 */
public interface TaskHandle extends AutoCloseable {
    void cancel();
    boolean isCancelled();
    boolean isDone();
    @Override default void close() { cancel(); }
}
