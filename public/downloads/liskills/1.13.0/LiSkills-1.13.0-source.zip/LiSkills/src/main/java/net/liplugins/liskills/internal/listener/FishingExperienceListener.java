package net.liplugins.liskills.internal.listener;

import net.liplugins.liskills.lib.scheduler.ServerThreads;
import net.liplugins.liskills.lib.scheduler.TaskScheduler;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.manager.ProfileManager;
import net.liplugins.liskills.internal.manager.SkillManager;
import net.liplugins.liskills.internal.storage.PlayerProfile;
import net.liplugins.liskills.internal.manager.source.FishingSourceRules;
import net.liplugins.liskills.internal.manager.source.FishingLootOrigin;
import net.liplugins.liskills.internal.manager.source.FishingCatchQueue;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.plugin.java.JavaPlugin;
import java.util.UUID;
import java.util.function.Predicate;

/** 原版成功钓获延至下一tick确认最终取消状态；专属钓鱼插件拥有的事件完全交给桥接。 */
public final class FishingExperienceListener implements Listener {
    private final ConfigManager config;
    private final ProfileManager profiles;
    private final SkillManager skills;
    private final Predicate<PlayerFishEvent> customFishing;
    private final FishingCatchQueue catches;

    public FishingExperienceListener(JavaPlugin plugin, ConfigManager config, ProfileManager profiles,
                                     SkillManager skills, Predicate<PlayerFishEvent> customFishing) {
        this.config = config; this.profiles = profiles; this.skills = skills; this.customFishing = customFishing;
        catches=new FishingCatchQueue(new TaskScheduler(plugin));
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onFish(PlayerFishEvent event) {
        if (!ServerThreads.owns(event.getPlayer()) || !ServerThreads.owns(event.getHook()) || event.getState() != PlayerFishEvent.State.CAUGHT_FISH
                || !(event.getCaught() instanceof Item item) || !ServerThreads.owns(item) || item.getItemStack().getType().isAir()
                || item.getItemStack().getAmount() <= 0 || customFishing.test(event)) return;
        var definition = config.skill("fishing");
        Player player = event.getPlayer();
        PlayerProfile profile = profiles.get(player.getUniqueId());
        UUID hook = event.getHook().getUniqueId();
        if (definition == null || !definition.enabled() || profile == null) return;
        String category=FishingSourceRules.category(item.getItemStack().getType(),!item.getItemStack().getEnchantments().isEmpty());
        double fallback=config.sources().fishingCategoriesEnabled() && category!=null?config.sources().fishingXp(category):definition.eventXp();
        double xp = definition.blocks().getOrDefault(item.getItemStack().getType(),fallback);
        Pending entry=new Pending(event, player, profile, player.getWorld().getUID(), hook, config.revision(), xp);
        catches.submit(hook, player, () -> settle(entry));
    }
    private void settle(Pending entry) {
            Player player = entry.player;
            if (entry.event.isCancelled() || customFishing.test(entry.event) || !player.isOnline() || player.isDead()
                    || profiles.get(player.getUniqueId()) != entry.profile || entry.revision != config.revision()
                    || !player.getWorld().getUID().equals(entry.world)) return;
            double xp=entry.xp;
            if(entry.event.getCaught() instanceof Item item && ServerThreads.owns(item)) {
                String pool=FishingLootOrigin.consume(item,entry.hook);
                if(pool!=null && config.sources().fishingCategoriesEnabled())xp=config.sources().fishingXp(pool);
            }
            skills.award(player, "fishing", xp);
    }

    private record Pending(PlayerFishEvent event, Player player, PlayerProfile profile, UUID world, UUID hook, long revision, double xp) { }
}
