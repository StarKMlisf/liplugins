package net.liplugins.liskills.internal.manager.ledger;

import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.persistence.PersistentDataType;
import java.io.IOException;
import java.util.Collection;
import java.util.Map;
import java.util.TreeMap;

/** 旧PDC只在首次建账时导入；此后PDC是管理员可查看的镜像，绝不是支付依据。 */
public final class LegacyLedgerData {
    private static final NamespacedKey DAY=new NamespacedKey("liskills","jobs_income_day"),INCOME=new NamespacedKey("liskills","jobs_income");
    private LegacyLedgerData(){ }
    public static LedgerState read(Player player,long today)throws IOException {
        var data=player.getPersistentDataContainer();
        if((data.has(DAY)&&!data.has(DAY,PersistentDataType.LONG)) || (data.has(INCOME)&&!data.has(INCOME,PersistentDataType.DOUBLE)))
            throw new IOException("invalid-legacy-income-type");
        Map<String,Integer> rewards=new TreeMap<>();
        for(var key:data.getKeys())if(key.getNamespace().equals("liskills") && key.getKey().startsWith("reward_")) {
            if(!LedgerState.validRewardKey(key.getKey()) || !data.has(key,PersistentDataType.INTEGER))throw new IOException("invalid-legacy-reward-type");
            int high=data.get(key,PersistentDataType.INTEGER);
            if(high<0 || high>1000 || rewards.size()>=LedgerState.MAX_REWARDS)throw new IOException("invalid-legacy-reward-value");
            rewards.put(key.getKey(),Math.max(1,high));
        }
        try{return new LedgerState(data.getOrDefault(DAY,PersistentDataType.LONG,today),data.getOrDefault(INCOME,PersistentDataType.DOUBLE,0.0),rewards);}
        catch(IllegalArgumentException error){throw new IOException("invalid-legacy-income-value",error);}
    }
    public static void mirrorIncome(Player player,LedgerState state){
        var data=player.getPersistentDataContainer();data.set(DAY,PersistentDataType.LONG,state.incomeDay());data.set(INCOME,PersistentDataType.DOUBLE,state.income());
    }
    public static void mirrorRewards(Player player,LedgerState state,Collection<String> keys){
        for(String key:keys){Integer high=state.rewardHighWatermarks().get(key);if(high!=null)player.getPersistentDataContainer().set(new NamespacedKey("liskills",key),PersistentDataType.INTEGER,high);}
    }
}
