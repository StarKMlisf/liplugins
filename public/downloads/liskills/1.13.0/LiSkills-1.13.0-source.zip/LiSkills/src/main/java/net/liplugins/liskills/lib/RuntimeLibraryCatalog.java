package net.liplugins.liskills.lib;

import java.util.List;

/** 与 Paper 26.1.2 默认 Adventure 版本一致的固定依赖闭包。 */
public final class RuntimeLibraryCatalog {
    private RuntimeLibraryCatalog() {
    }

    public static List<RuntimeLibrary> libraries() {
        return List.of(
                new RuntimeLibrary("net.kyori", "adventure-api", "4.26.1", "551e536b9ea868f30e72c7900a309b35124ee7d4889fa3b3aed0910299751a26"),
                new RuntimeLibrary("net.kyori", "adventure-key", "4.26.1", "eec172d63db77b40eb7abeeb25f65eedea89bd30264d057b68b12fecb731be5e"),
                new RuntimeLibrary("net.kyori", "adventure-text-minimessage", "4.26.1", "1d43451e9af473252dc8af3e8084238d5ce68ad43af0e3b7383eb3d4b63fff9f"),
                new RuntimeLibrary("net.kyori", "adventure-text-serializer-legacy", "4.26.1", "721107bc213572454df1bfbe438dba630e30457550c750b7a154b35dc3264aa8"),
                new RuntimeLibrary("net.kyori", "examination-api", "1.3.0", "c9237ffecb05428f6eff86216246ac70ce0b47b04c08ea7ca35020fde57f8492"),
                new RuntimeLibrary("net.kyori", "examination-string", "1.3.0", "7d01fc25a4bb3af0e1662685455f4541fbf4626216ea5846e455c1491e156b8c"),
                new RuntimeLibrary("org.jetbrains", "annotations", "26.0.2-1", "2037be378980d3ba9333e97955f3b2cde392aa124d04ca73ce2eee6657199297")
        );
    }
}
