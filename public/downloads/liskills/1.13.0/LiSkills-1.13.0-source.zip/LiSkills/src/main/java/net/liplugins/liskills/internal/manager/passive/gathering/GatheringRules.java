package net.liplugins.liskills.internal.manager.passive.gathering;

/** 幸运、饱和与牵引的有限值边界；与 Bukkit 实体无关，可独立验证。 */
public final class GatheringRules {
    private GatheringRules() { }
    public static int extraDrops(double luck, double random) {
        if (!Double.isFinite(luck) || luck <= 0 || !Double.isFinite(random) || random < 0 || random >= 1) return 0;
        double bounded = Math.min(6400, luck);
        int guaranteed = (int) (bounded / 100);
        return guaranteed + (random < (bounded - guaranteed * 100) / 100 ? 1 : 0);
    }
    public static double poolChance(double base, double perLuck, double luck, double ability) {
        return poolChance(base, perLuck, luck, ability, false);
    }
    public static double poolChance(double base, double perLuck, double luck, double ability, boolean scaleBase) {
        if (!Double.isFinite(base) || !Double.isFinite(perLuck) || !Double.isFinite(luck) || !Double.isFinite(ability)) return 0;
        double common = base + perLuck * Math.max(0, luck);
        double modified = scaleBase ? common * (1 + Math.max(0, ability) / 100) : common + Math.max(0, ability);
        return Math.max(0, Math.min(100, modified)) / 100;
    }
    public static float saturation(float current, int food, double value) {
        if (!Float.isFinite(current) || !Double.isFinite(value) || value <= 0) return current;
        // 已有饱和高于饥饿值时不降低第三方结果，也不继续添加非法高值。
        return (float) Math.max(current, Math.min(Math.max(0, Math.min(20, food)), current + value / 10));
    }
    public static double pullFactor(double value) {
        return Double.isFinite(value) && value > 0 ? 0.004 + value / 25000 : 0;
    }
    public static boolean safeVelocity(double x, double y, double z) {
        return Double.isFinite(x) && Double.isFinite(y) && Double.isFinite(z)
                && Math.abs(x) <= 4 && Math.abs(y) <= 4 && Math.abs(z) <= 4;
    }
}
