package net.liplugins.liskills.internal.storage;

public record SkillProgress(int level,double xp) {
    public SkillProgress {
        if(level<1 || level>1000 || !Double.isFinite(xp) || xp<0) throw new IllegalArgumentException("skill progress");
    }
}
