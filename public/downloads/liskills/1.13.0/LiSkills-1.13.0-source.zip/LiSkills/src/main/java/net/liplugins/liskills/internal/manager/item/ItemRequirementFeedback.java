package net.liplugins.liskills.internal.manager.item;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.entity.Player;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/** 失败提示独立限频；不改变事件、玩家背包或条件判断结果。 */
public final class ItemRequirementFeedback {
    private final ConfigManager config;
    private final TextService text;
    private final Map<UUID, Long> lastMessages = new LinkedHashMap<>();

    public ItemRequirementFeedback(ConfigManager config, TextService text) { this.config = config; this.text = text; }
    public synchronized void denied(Player player, ItemDenial denial) {
        long now = System.nanoTime();
        long interval = config.items().messageCooldownMillis() * 1_000_000L;
        Long previous = lastMessages.get(player.getUniqueId());
        if (previous != null && now - previous >= 0 && now - previous < interval) return;
        if (lastMessages.size() >= 4096 && !lastMessages.containsKey(player.getUniqueId())) lastMessages.remove(lastMessages.keySet().iterator().next());
        lastMessages.put(player.getUniqueId(), now);
        ItemRequirement failure = denial.requirement();
        if (failure.reason() == ItemRequirement.Reason.ITEM_DATA_INVALID) {
            text.send(player, "items.invalid-data", Map.of());
            return;
        }
        var skill = config.skill(failure.skill());
        text.send(player, "items.denied", Map.of("item", text.plain(denial.rule().name()), "rule", denial.rule().id(),
                "skill", skill == null ? failure.skill() : text.plain(skill.name()), "required", failure.required(),
                "current", failure.current(), "reason", text.plain(text.text("items.reason." + failure.reason().name().toLowerCase(Locale.ROOT)))));
    }
    public synchronized void clear(UUID player) { lastMessages.remove(player); }
    public synchronized void clear() { lastMessages.clear(); }
}
