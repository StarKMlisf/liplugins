package net.liplugins.liskills.internal.hook;

import org.bukkit.Bukkit;
import org.bukkit.plugin.Plugin;

/** 只探测 Vault 经济提供者，不创建账户、不收款、不发放奖励。 */
final class VaultHook {
    boolean available() {
        Plugin vault = Bukkit.getPluginManager().getPlugin("Vault");
        if (vault == null || !vault.isEnabled()) return false;
        try {
            Class<?> economyType = Class.forName("net.milkbowl.vault.economy.Economy", false, vault.getClass().getClassLoader());
            return Bukkit.getServicesManager().getRegistration(economyType) != null;
        } catch (ClassNotFoundException | LinkageError ignored) {
            return false;
        }
    }
}
