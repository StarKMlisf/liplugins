package net.liplugins.liskills.internal.manager.passive.combat;

import net.liplugins.liskills.internal.manager.PassiveAbilityManager;
import net.liplugins.liskills.internal.hook.LiRealEnchantHook;
import org.bukkit.enchantments.Enchantment;
import net.liplugins.liskills.lib.scheduler.ServerThreads;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityCombustByEntityEvent;
import org.bukkit.event.entity.PotionSplashEvent;
import org.bukkit.potion.PotionEffectTypeCategory;

/** 负面抗性只拦本次喷溅/火焰附加，不删除已有药水或第三方稍后施加的燃烧。 */
final class DefensePotionListener implements Listener {
    private final PassiveAbilityManager passives;
    private final LiRealEnchantHook enchantments;
    DefensePotionListener(PassiveAbilityManager passives,LiRealEnchantHook enchantments){this.passives=passives;this.enchantments=enchantments;}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)
    public void onSplash(PotionSplashEvent event) {
        if(event.getPotion().getEffects().stream().noneMatch(effect->effect.getType().getCategory()==PotionEffectTypeCategory.HARMFUL)) return;
        for(LivingEntity entity:event.getAffectedEntities()) {
            if(entity instanceof Player player && ServerThreads.owns(player) && event.getIntensity(player)>0 && passives.roll(player,"no_debuff")) event.setIntensity(player,0);
        }
    }
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)
    public void onFireAspect(EntityCombustByEntityEvent event) {
        if(!(event.getEntity() instanceof Player player) || !(event.getCombuster() instanceof LivingEntity source)
                || !ServerThreads.owns(player) || !ServerThreads.owns(source) || source.getEquipment()==null || SecondaryDamageContext.active() || (enchantments!=null && enchantments.isSecondaryDamage())) return;
        if(source.getEquipment().getItemInMainHand().getEnchantmentLevel(Enchantment.FIRE_ASPECT)>0 && passives.roll(player,"no_debuff")) event.setCancelled(true);
    }
}
