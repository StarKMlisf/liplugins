package net.liplugins.liskills.internal.manager.passive.gathering;

import net.liplugins.liskills.lib.scheduler.ServerThreads;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.event.player.PlayerItemDamageEvent;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** 护甲耐久减免与斧碎甲只修改当前原生耐久事件，不直接修改背包里的盔甲。 */
final class GatheringArmorListener implements Listener {
    private final GatheringContext context;
    private final Map<UUID, AxeHit> hits = new java.util.concurrent.ConcurrentHashMap<>();
    GatheringArmorListener(GatheringContext context) { this.context = context; }

    @EventHandler(priority = EventPriority.MONITOR)
    public void attack(EntityDamageEvent damage) {
        if (!(damage.getEntity() instanceof Player victim)) return;
        // 同一tick的新攻击必须清掉旧斧击，不能把上一名攻击者的碎甲套到后续剑击/环境伤害。
        hits.remove(victim.getUniqueId());
        if (!(damage instanceof EntityDamageByEntityEvent event) || event.isCancelled()
                || !(event.getDamager() instanceof Player attacker) || !ServerThreads.owns(attacker)
                || event.getCause() != DamageCause.ENTITY_ATTACK || context.secondaryDamage()
                || !attacker.getInventory().getItemInMainHand().getType().name().endsWith("_AXE")) return;
        var actor = context.capture(attacker, "foraging");
        if (actor == null || hits.size() >= 2048 || !Double.isFinite(event.getFinalDamage()) || event.getFinalDamage() <= 0) return;
        AxeHit hit = new AxeHit(event, actor, attacker.getInventory().getItemInMainHand().getType());
        UUID victimId = victim.getUniqueId();
        hits.put(victimId, hit);
        if (!context.tasks().defer(victim, () -> hits.remove(victimId, hit), () -> hits.remove(victimId, hit))) hits.remove(victimId, hit);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void durability(PlayerItemDamageEvent event) {
        if (!armor(event.getItem().getType()) || event.getDamage() <= 0 || !context.tasks().claim(event)) return;
        Player victim = event.getPlayer();
        if (context.permitted(victim, "mining") && context.passives().roll(victim, "hardened_armor")) {
            event.setCancelled(true); return;
        }
        AxeHit hit = hits.get(victim.getUniqueId());
        if (hit == null || hit.event.isCancelled() || !context.valid(hit.actor)
                || hit.actor.player().getInventory().getItemInMainHand().getType() != hit.tool
                || !context.passives().roll(hit.actor.player(), "shredder")) return;
        event.setDamage((int) Math.min(Integer.MAX_VALUE, (long) event.getDamage() * 3));
    }
    static boolean armor(Material material) {
        String name = material.name();
        return name.endsWith("_HELMET") || name.endsWith("_CHESTPLATE") || name.endsWith("_LEGGINGS") || name.endsWith("_BOOTS");
    }
    private record AxeHit(EntityDamageByEntityEvent event, GatheringContext.Actor actor, Material tool) { }
}
