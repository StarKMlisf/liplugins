package net.liplugins.liskills.internal.manager.passive.combat;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.manager.PassiveAbilityManager;
import net.liplugins.liskills.internal.manager.ProfileManager;
import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.plugin.java.JavaPlugin;
import net.liplugins.liskills.lib.scheduler.TaskHandle;
import net.liplugins.liskills.lib.scheduler.TaskScheduler;
import net.liplugins.liskills.lib.scheduler.ServerThreads;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** 一个有界定时器管理流血，不强清无敌帧，不绕过原生伤害保护事件。 */
final class BleedManager implements AutoCloseable {
    private final ConfigManager config;
    private final ProfileManager profiles;
    private final PassiveAbilityManager passives;
    private final DeferredPassiveEffects effects;
    private final TextService text;
    private final Map<UUID,Bleed> bleeding=new java.util.concurrent.ConcurrentHashMap<>();
    private final TaskScheduler scheduler;
    private final net.liplugins.liskills.internal.manager.EntityWorkQueue work = new net.liplugins.liskills.internal.manager.EntityWorkQueue();
    private final TaskHandle task;
    private volatile long tick;
    BleedManager(JavaPlugin plugin,ConfigManager config,ProfileManager profiles,PassiveAbilityManager passives,DeferredPassiveEffects effects,TextService text) {
        this.config=config;this.profiles=profiles;this.passives=passives;this.effects=effects;this.text=text;
        task=(scheduler = new TaskScheduler(plugin)).globalTimer(this::tick,1,1);
    }
    void afterHit(Player player,LivingEntity target,EntityDamageByEntityEvent event) {
        if(!ServerThreads.owns(player) || !ServerThreads.owns(target) || !passives.roll(player,"bleed")) return;
        PassiveSession session=PassiveSession.capture(player,profiles,config);
        effects.submit(player.getUniqueId(),()->{
            if(!session.valid(profiles,config) || passives.value(player,"bleed")<=0 || event.isCancelled() || !(event.getFinalDamage()>0)
                    || !ServerThreads.owns(target) || !target.isValid() || target.isDead() || !target.getWorld().equals(player.getWorld())) return;
            int maximum=(int)Math.clamp(passives.option("bleed","max_ticks",11),1,100);
            Bleed old=bleeding.get(target.getUniqueId());
            if(old!=null && old.session.valid(profiles,config)) {
                old.remaining=Math.min(maximum,old.remaining+(int)Math.clamp(passives.option("bleed","added_ticks",2),0,100));
                return;
            }
            if(bleeding.size()>=512) return;
            int rounds=(int)Math.clamp(passives.option("bleed","base_ticks",3),1,maximum);
            int period=(int)Math.clamp(passives.option("bleed","tick_period",40),10,1200);
            double damage=Math.clamp(passives.secondary(player,"bleed"),0,100);
            if(damage<=0) return;
            bleeding.put(target.getUniqueId(),new Bleed(session,target,rounds,period,damage,tick+period));
            if(passives.flag("bleed","enable_enemy_message",true)) text.send(player,"passive.bleed-enemy");
            if(target instanceof Player victim && passives.flag("bleed","enable_self_message",true)) text.send(victim,"passive.bleed-self");
        });
    }
    private void tick() {
        tick++;
        for(Bleed bleed:List.copyOf(bleeding.values())) {
            work.dispatch(scheduler,bleed,bleed.target,()->tick(bleed),()->bleeding.remove(bleed.target.getUniqueId(),bleed));
        }
    }
    private void tick(Bleed bleed) {
            if(bleeding.get(bleed.target.getUniqueId())!=bleed)return;
            LivingEntity target=bleed.target;
            if(!bleed.session.valid(profiles,config) || passives.value(bleed.session.player(),"bleed")<=0
                    || !target.isValid() || target.isDead() || !target.getWorld().getUID().equals(bleed.session.world())
                    || !target.getWorld().isChunkLoaded(target.getLocation().getBlockX()>>4,target.getLocation().getBlockZ()>>4)) {
                bleeding.remove(target.getUniqueId(),bleed);return;
            }
            if(tick<bleed.next) return;
            bleed.next=tick+bleed.period;
            double before=target.getHealth();
            SecondaryDamageContext.run(bleed.session.player(),()->target.damage(bleed.damage));
            if(target.isValid() && target.getHealth()<before && passives.flag("bleed","show_particles",true)) {
                target.getWorld().spawnParticle(Particle.BLOCK,target.getLocation().add(0,target.getHeight()*.6,0),12,.2,.2,.2,Material.REDSTONE_BLOCK.createBlockData());
            }
            if(--bleed.remaining<=0) {
                bleeding.remove(target.getUniqueId(),bleed);
                if(target instanceof Player victim && victim.isOnline() && passives.flag("bleed","enable_stop_message",true)) text.send(victim,"passive.bleed-stop");
            }
    }
    @Override public void close(){task.cancel();scheduler.cancelAll();bleeding.clear();}
    private static final class Bleed {
        final PassiveSession session;final LivingEntity target;final int period;final double damage;
        int remaining;long next;
        Bleed(PassiveSession session,LivingEntity target,int remaining,int period,double damage,long next) {
            this.session=session;this.target=target;this.remaining=remaining;this.period=period;this.damage=damage;this.next=next;
        }
    }
}
