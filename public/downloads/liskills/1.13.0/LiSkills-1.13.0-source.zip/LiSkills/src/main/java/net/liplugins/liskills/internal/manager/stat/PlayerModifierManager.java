package net.liplugins.liskills.internal.manager.stat;

import net.liplugins.liskills.internal.config.StatsSettings;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.persistence.PersistentDataType;
import java.util.*;

/** 命名的永久玩家属性加成；只保存自己的PDC字段，不改装备、外部修饰符或基础技能等级。 */
public final class PlayerModifierManager {
    private static final String PREFIX="modifier_";
    public Map<String,Double> values(Player player) {
        Map<String,Double> result=new HashMap<>();
        entries(player).values().forEach(value->result.merge(value.stat(),value.amount(),Double::sum));
        return Map.copyOf(result);
    }
    public record Modifier(String stat,double amount) { }
    public Map<String,Modifier> entries(Player player) {
        Map<String,Modifier> result=new TreeMap<>();var data=player.getPersistentDataContainer();
        for(NamespacedKey key:data.getKeys()){
            if(!key.getNamespace().equals("liskills")||!key.getKey().startsWith(PREFIX)||!data.has(key,PersistentDataType.STRING))continue;
            String raw=data.get(key,PersistentDataType.STRING);if(raw==null)continue;
            String[] parts=raw.split(":",2);if(parts.length!=2||!StatsSettings.IDS.contains(parts[0]))continue;
            try{double amount=Double.parseDouble(parts[1]);if(Double.isFinite(amount)&&Math.abs(amount)<=1e6)result.put(key.getKey().substring(PREFIX.length()),new Modifier(parts[0],amount));}catch(NumberFormatException ignored){ }
        }
        return Collections.unmodifiableMap(result);
    }
    public boolean set(Player player,String name,String stat,double amount) {
        if(!validName(name)||!StatsSettings.IDS.contains(stat)||!Double.isFinite(amount)||Math.abs(amount)>1e6)return false;
        var key=new NamespacedKey("liskills",PREFIX+name);
        if(entries(player).size()>=64&&!player.getPersistentDataContainer().has(key))return false;
        player.getPersistentDataContainer().set(key,PersistentDataType.STRING,stat+":"+amount);return true;
    }
    public boolean remove(Player player,String name){if(!validName(name))return false;player.getPersistentDataContainer().remove(new NamespacedKey("liskills",PREFIX+name));return true;}
    public static boolean validName(String name){return name!=null&&name.matches("[a-z][a-z0-9_-]{0,47}");}
}
