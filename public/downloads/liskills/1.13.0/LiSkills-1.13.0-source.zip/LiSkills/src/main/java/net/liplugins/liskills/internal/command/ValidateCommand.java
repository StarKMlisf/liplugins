package net.liplugins.liskills.internal.command;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;

import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

final class ValidateCommand implements Subcommand {
    private final ConfigManager config;
    private final SenderChecks checks;
    private final TextService text;
    private final Supplier<String> compatibility;
    ValidateCommand(ConfigManager config, SenderChecks checks, TextService text,Supplier<String> compatibility) {
        this.config = config; this.checks = checks; this.text = text;
        this.compatibility=compatibility;
    }
    public String name() { return "validate"; }
    public String permission() { return "liskills.admin"; }
    public void execute(CommandSender sender, String[] arguments) {
        if (arguments.length != 0) { checks.usage(sender, "command.usage-validate"); return; }
        text.send(sender, "command.validate-title");
        List<String> problems = config.validate();
        if (problems.isEmpty()) text.send(sender, "command.validate-ok");
        else problems.forEach(problem -> text.send(sender, "command.validate-line", Map.of("detail", problem)));
        status(sender, "Vault", "hook.vault-status");
        status(sender, "PlaceholderAPI", "hook.placeholderapi-status");
        String state=compatibility.get();if(!state.isBlank())text.sendRendered(sender,java.util.List.of(state));
    }

    private void status(CommandSender sender, String plugin, String key) {
        String state = ChatColor.stripColor(text.text(Bukkit.getPluginManager().isPluginEnabled(plugin) ? "hook.detected" : "hook.unavailable"));
        text.send(sender, key, Map.of("state", state));
    }
}
