package net.liplugins.liskills.internal.manager.passive.gathering;

import org.bukkit.Material;
import java.util.Set;

/** Aura 2.3.12 DOUBLE_DROP只适用九种基础地形；每个来源独立掷一次概率，矿石和宝藏不参与。 */
final class DoubleDropRules {
    private static final Set<Material> SOURCES = Set.of(Material.STONE, Material.COBBLESTONE, Material.SAND,
            Material.GRAVEL, Material.DIRT, Material.GRASS_BLOCK, Material.ANDESITE, Material.DIORITE, Material.GRANITE);
    private DoubleDropRules() { }
    static boolean roll(Material material, double percent, double random) {
        return SOURCES.contains(material) && Double.isFinite(percent) && percent > 0
                && Double.isFinite(random) && random >= 0 && random < 1 && random < Math.min(100, percent) / 100;
    }
}
