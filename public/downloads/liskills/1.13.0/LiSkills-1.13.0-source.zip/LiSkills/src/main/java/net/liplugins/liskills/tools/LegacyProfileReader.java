package net.liplugins.liskills.tools;

import net.liplugins.liskills.internal.storage.SkillProgress;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** 仅解析 AuraSkills 玩家等级与本级经验；绝不加载或解释旧版属性、指令等奖励数据。 */
final class LegacyProfileReader {
    private static final String UUID_PATTERN = "[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}";
    // AuraSkills 2.x 默认11项之外，legacy预设的4项仍是独立档案；保留原ID，不能合并或丢弃。
    private static final Set<String> SUPPORTED = Set.of("farming", "foraging", "mining", "fishing", "excavation",
            "archery", "defense", "fighting", "agility", "alchemy", "enchanting",
            "endurance", "healing", "forging", "sorcery");
    private final MigrationMessages messages;

    LegacyProfileReader(MigrationMessages messages) {
        this.messages = messages;
    }

    ImportCandidate read(Path source) throws Exception {
        String fileName = source.getFileName().toString();
        String stem = fileName.substring(0, fileName.length() - 4);
        if (!stem.matches(UUID_PATTERN)) throw new IOException(messages.text("invalid.filename"));
        UUID uuid = UUID.fromString(stem);
        YamlConfiguration yaml = new YamlConfiguration();
        yaml.load(source.toFile());
        Object storedUuid = yaml.get("uuid");
        if (!(storedUuid instanceof String value) || !value.matches(UUID_PATTERN)
                || !uuid.equals(UUID.fromString(value))) {
            throw new IOException(messages.text("invalid.uuid"));
        }
        ConfigurationSection section = yaml.getConfigurationSection("skills");
        if (section == null) throw new IOException(messages.text("invalid.skills"));
        Map<String, SkillProgress> result = new LinkedHashMap<>();
        List<String> ignored = new ArrayList<>();
        for (String original : section.getKeys(false)) {
            String id = normalize(original);
            if (id == null || !SUPPORTED.contains(id)) {
                ignored.add(original);
                continue;
            }
            if (result.containsKey(id)) throw new IOException(messages.text("invalid.duplicate-skill", id));
            ConfigurationSection skill = section.getConfigurationSection(original);
            if (skill == null) throw new IOException(messages.text("invalid.skill-section", original));
            Object levelValue = skill.get("level");
            Object xpValue = skill.get("xp");
            if (!(levelValue instanceof Number level) || !Double.isFinite(level.doubleValue())
                    || level.doubleValue() != Math.rint(level.doubleValue()) || level.doubleValue() < 1
                    || level.doubleValue() > 1000) {
                throw new IOException(messages.text("invalid.level", original));
            }
            if (!(xpValue instanceof Number xp) || !Double.isFinite(xp.doubleValue()) || xp.doubleValue() < 0) {
                throw new IOException(messages.text("invalid.xp", original));
            }
            result.put(id, new SkillProgress(level.intValue(), xp.doubleValue()));
        }
        String name = yaml.get("name") instanceof String storedName && !storedName.isBlank() ? storedName : uuid.toString();
        return new ImportCandidate(source, uuid, name, result, ignored);
    }

    private String normalize(String id) {
        if (id.startsWith("auraskills/")) return id.substring("auraskills/".length());
        if (id.startsWith("auraskills:")) return id.substring("auraskills:".length());
        return null;
    }
}
