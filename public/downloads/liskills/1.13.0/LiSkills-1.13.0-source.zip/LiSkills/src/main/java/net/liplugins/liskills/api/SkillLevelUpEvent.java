package net.liplugins.liskills.api;

import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

/** 经验结算完成后同步发布；管理设置等级不发布，不可取消。 */
public final class SkillLevelUpEvent extends Event {
    private static final HandlerList HANDLERS=new HandlerList();
    private final Player player;
    private final String skill;
    private final int oldLevel,newLevel;
    private final boolean natural;
    public SkillLevelUpEvent(Player player,String skill,int oldLevel,int newLevel){this(player,skill,oldLevel,newLevel,true);}
    public SkillLevelUpEvent(Player player,String skill,int oldLevel,int newLevel,boolean natural){this.player=player;this.skill=skill;this.oldLevel=oldLevel;this.newLevel=newLevel;this.natural=natural;}
    public Player getPlayer(){return player;}
    public String getSkill(){return skill;}
    public int getOldLevel(){return oldLevel;}
    public int getNewLevel(){return newLevel;}
    public boolean isNatural(){return natural;}
    public HandlerList getHandlers(){return HANDLERS;}
    public static HandlerList getHandlerList(){return HANDLERS;}
}
