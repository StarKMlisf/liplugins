package net.liplugins.liskills.internal.config;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import java.util.Map;

/** 仅将完全未改动的历史主动能力模板升级；任何自定义字段或注释都保留。 */
final class SkillConfigUpgrade {
    private SkillConfigUpgrade() { }

    static boolean apply(YamlConfiguration file) {
        if (!file.contains("skills")) return false;
        Object revision=file.get("config-version");
        if(revision!=null && (!(revision instanceof Number n) || (n.doubleValue()!=1.0 && n.doubleValue()!=2.0)))return false;
        if(revision==null || ((Number)revision).intValue()==1) {
            update(file,"farming","丰收补给","SATURATION","REPLENISH","丰收补种");
            update(file,"excavation","大地挖掘","HASTE","TERRAFORM","地形开拓");
        }
        update(file,"archery","游击步伐","SPEED","CHARGED_SHOT","蓄力射击");
        update(file,"fishing","幸运垂钓","LUCK","QUICK_FISH","快速咬钩");
        update(file,"defense","坚韧护体","RESISTANCE","MANA_SHIELD","魔力护盾");
        file.set("config-version",3);
        return true;
    }

    private static void update(YamlConfiguration file,String id,String oldName,String effect,String type,String name) {
        String path="skills."+id;
        if (!Boolean.TRUE.equals(file.get(path+".enabled"))) return;
        ConfigurationSection active=file.getConfigurationSection(path+".active");
        if(active==null)return;
        Map<String,Object> expected=Map.of("enabled",true,"type","POTION","name",oldName,"effect",effect,
                "amplifier",0,"duration-seconds",10,"cooldown-seconds",60,"unlock-level",5,"mana-cost",20.0);
        if(!active.getKeys(false).equals(expected.keySet()))return;
        for(var entry:expected.entrySet()) {
            Object actual=active.get(entry.getKey()),value=entry.getValue();
            boolean same=actual instanceof Number a && value instanceof Number b
                    ? Double.compare(a.doubleValue(),b.doubleValue())==0 : value.equals(actual);
            if(!same)return;
        }
        // set 不替换节点注释；只有整个旧模板一致才修改类型与名称。
        active.set("type",type);
        active.set("name",name);
    }
}
