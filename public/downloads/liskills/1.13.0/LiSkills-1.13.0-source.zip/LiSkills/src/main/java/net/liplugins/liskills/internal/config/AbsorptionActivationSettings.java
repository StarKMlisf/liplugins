package net.liplugins.liskills.internal.config;

import org.bukkit.configuration.ConfigurationSection;
import java.util.Locale;

/** 吸收的交互方式与准备窗口；手动指令始终可用，原版模式只对自然首次受击自动启动。 */
public record AbsorptionActivationSettings(Mode mode,int readySeconds) {
    public enum Mode { MANUAL, SHIELD_RIGHT_CLICK, AURA_READY }
    public static AbsorptionActivationSettings defaults(){return new AbsorptionActivationSettings(Mode.AURA_READY,4);}
    public static AbsorptionActivationSettings parse(ConfigurationSection root) {
        String raw=root.getString("absorption.activation-mode","AURA_READY");Mode mode;
        try{mode=Mode.valueOf(raw.toUpperCase(Locale.ROOT));}catch(IllegalArgumentException error){throw new IllegalArgumentException("absorption.activation-mode：应为 MANUAL、SHIELD_RIGHT_CLICK 或 AURA_READY");}
        Object seconds=root.get("absorption.ready-seconds",4);
        if(!(seconds instanceof Number value) || !Double.isFinite(value.doubleValue()) || value.doubleValue()!=Math.rint(value.doubleValue()) || value.intValue()<1 || value.intValue()>10)
            throw new IllegalArgumentException("absorption.ready-seconds：应为1至10的整数");
        return new AbsorptionActivationSettings(mode,((Number)seconds).intValue());
    }
}
