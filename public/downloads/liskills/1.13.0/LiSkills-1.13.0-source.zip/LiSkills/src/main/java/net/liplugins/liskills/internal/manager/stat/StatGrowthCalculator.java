package net.liplugins.liskills.internal.manager.stat;

import net.liplugins.liskills.internal.config.SkillDefinition;
import net.liplugins.liskills.internal.config.StatDefinition;
import net.liplugins.liskills.internal.config.StatGrowth;
import net.liplugins.liskills.internal.config.StatsSettings;
import net.liplugins.liskills.internal.storage.SkillProgress;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Predicate;

/** 只根据不可变技能快照累计成长；不读 Bukkit、不读写磁盘。 */
public final class StatGrowthCalculator {
    private StatGrowthCalculator() { }

    public static Map<String, Double> calculate(StatsSettings settings, Map<String, SkillDefinition> skills,
                                                 Map<String, SkillProgress> progress, Predicate<String> allowed) {
        Map<String, Double> result = new LinkedHashMap<>();
        settings.definitions().forEach((id, definition) -> result.put(id, definition.enabled() ? definition.base() : 0));
        for (SkillDefinition skill : skills.values()) {
            if (!skill.enabled() || !allowed.test(skill.id())) continue;
            int level = Math.min(skill.maxLevel(), progress.getOrDefault(skill.id(), new SkillProgress(1, 0)).level());
            for (StatGrowth growth : settings.growthFor(skill.id())) {
                StatDefinition definition = settings.definitions().get(growth.stat());
                if (definition == null || !definition.enabled()) continue;
                double reward = StatGrowthMath.awards(level, settings.rewardStartLevel(), growth.interval()) * growth.value();
                result.computeIfPresent(growth.stat(), (id, value) -> Math.min(definition.maximum(), value + reward));
            }
        }
        return Collections.unmodifiableMap(result);
    }
}
