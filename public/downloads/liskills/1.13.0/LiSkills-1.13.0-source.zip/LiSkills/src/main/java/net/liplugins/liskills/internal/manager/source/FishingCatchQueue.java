package net.liplugins.liskills.internal.manager.source;

import net.liplugins.liskills.lib.scheduler.TaskScheduler;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;

/** 钓获结算排到玩家的下一tick；全局时钟只清理去重记录，不能提前结算经验。 */
public final class FishingCatchQueue {
    private static final int MAX_PENDING = 2048;
    private final TaskScheduler scheduler;
    private final Set<UUID> pending = new HashSet<>();
    private final Map<UUID, Long> seen = new HashMap<>();
    private long tick;

    public FishingCatchQueue(TaskScheduler scheduler) {
        this.scheduler = Objects.requireNonNull(scheduler);
        scheduler.globalTimer(this::expire, 1, 1);
    }

    public boolean submit(UUID hook, Player player, Runnable settlement) {
        Objects.requireNonNull(hook); Objects.requireNonNull(player); Objects.requireNonNull(settlement);
        if (!reserve(hook)) return false;
        try {
            // 采集监听器先排同一玩家的掉落事务，本回调随后排队；不能用全局timer+entityNow抢先执行。
            scheduler.entity(player, () -> {
                try { settlement.run(); }
                finally { release(hook); }
            }, () -> release(hook));
            return true;
        } catch (RuntimeException | Error failure) { release(hook); throw failure; }
    }

    private synchronized boolean reserve(UUID hook) {
        if (pending.size() >= MAX_PENDING || seen.size() >= MAX_PENDING * 2 || seen.containsKey(hook)) return false;
        pending.add(hook); seen.put(hook, tick + 40); return true;
    }
    private synchronized void release(UUID hook) { pending.remove(hook); }
    private synchronized void expire() {
        tick++;
        // 区域停滞超过去重期限时仍保留正在排队的鱼钩，不能为同一钓获再提交一次。
        seen.entrySet().removeIf(entry -> entry.getValue() <= tick && !pending.contains(entry.getKey()));
    }
}
