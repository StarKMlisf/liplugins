package net.liplugins.liskills.internal.listener.stat;

import net.liplugins.liskills.api.SkillLevelUpEvent;
import net.liplugins.liskills.internal.manager.stat.StatManager;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerGameModeChangeEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.plugin.java.JavaPlugin;
import net.liplugins.liskills.lib.scheduler.TaskScheduler;

/** 只处理属性的玩家生命周期；装备/药水和权限变动由共享每秒刷新兜底。 */
public final class StatLifecycleListener implements Listener {
    private final JavaPlugin plugin;
    private final StatManager stats;

    public StatLifecycleListener(JavaPlugin plugin, StatManager stats) { this.plugin = plugin; this.stats = stats; }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onJoin(PlayerJoinEvent event) { stats.clear(event.getPlayer()); }
    // 普通 ProfileListener 先结清护盾预留并存档，之后才移除影响魔力上限的瞬时智慧。
    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent event) { stats.clear(event.getPlayer()); }
    @EventHandler(priority = EventPriority.MONITOR)
    public void onDeath(PlayerDeathEvent event) { stats.clear(event.getEntity()); }
    @EventHandler(priority = EventPriority.MONITOR)
    public void onWorld(PlayerChangedWorldEvent event) { stats.refresh(event.getPlayer()); }
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onMode(PlayerGameModeChangeEvent event) { later(event.getPlayer()); }
    @EventHandler(priority = EventPriority.MONITOR)
    public void onRespawn(PlayerRespawnEvent event) { later(event.getPlayer()); }
    @EventHandler(priority = EventPriority.MONITOR)
    public void onLevel(SkillLevelUpEvent event) { stats.refresh(event.getPlayer()); }

    private void later(Player player) {
        new TaskScheduler(plugin).entity(player, () -> { if (player.isOnline()) stats.refresh(player); });
    }
}
