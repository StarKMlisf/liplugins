package net.liplugins.liskills.tools;

import java.nio.file.Path;
import java.util.List;

record ImportPlan(Path source, Path target, List<ImportCandidate> candidates, List<String> errors) {
    ImportPlan {
        candidates = List.copyOf(candidates);
        errors = List.copyOf(errors);
    }

    boolean valid() {
        return errors.isEmpty();
    }
}
