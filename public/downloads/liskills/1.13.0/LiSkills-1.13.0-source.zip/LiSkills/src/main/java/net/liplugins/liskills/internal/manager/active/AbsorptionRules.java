package net.liplugins.liskills.internal.manager.active;

/** 全额吸收的费用规则；不足以完整抵消或会耗尽魔力时，保留正常伤害。 */
public final class AbsorptionRules {
    private AbsorptionRules() { }
    public static double cost(double damage,double available,double manaPerDamage,double maximumDamage) {
        if(!Double.isFinite(damage) || damage<=0 || !Double.isFinite(available) || available<=0
                || !Double.isFinite(manaPerDamage) || manaPerDamage<=0 || !Double.isFinite(maximumDamage)
                || maximumDamage<=0 || damage>maximumDamage) return 0;
        double cost=damage*manaPerDamage;
        return Double.isFinite(cost) && cost>0 && available>cost?cost:0;
    }
}
