package net.liplugins.liskills.internal.command;

import net.liplugins.liskills.internal.config.SkillDefinition;
import net.liplugins.liskills.internal.manager.AbilityManager;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

final class CastCommand implements Subcommand {
    private final SenderChecks checks;
    private final AbilityManager abilities;
    CastCommand(SenderChecks checks, AbilityManager abilities) { this.checks = checks; this.abilities = abilities; }
    public String name() { return "cast"; }
    public String permission() { return "liskills.use"; }
    public void execute(CommandSender sender, String[] arguments) {
        if (arguments.length != 1) { checks.usage(sender, "command.usage-cast"); return; }
        Player player = checks.player(sender);
        if (player == null) return;
        SkillDefinition skill = checks.skill(sender, arguments[0]);
        if (skill != null && checks.profile(sender, player) != null) abilities.activate(player, skill.id());
    }
}
