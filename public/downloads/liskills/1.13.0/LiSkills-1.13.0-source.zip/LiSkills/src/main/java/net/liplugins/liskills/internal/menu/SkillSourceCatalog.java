package net.liplugins.liskills.internal.menu;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.config.SkillDefinition;
import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.Material;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** 聊天来源与分页 GUI 共享同一查询结果，只列实际监听器消费的配置项。 */
final class SkillSourceCatalog {
    private static final Map<String, String> CROP_ITEMS = Map.ofEntries(
            Map.entry("CARROTS", "CARROT"), Map.entry("POTATOES", "POTATO"), Map.entry("BEETROOTS", "BEETROOT"),
            Map.entry("COCOA", "COCOA_BEANS"), Map.entry("KELP_PLANT", "KELP"),
            Map.entry("CAVE_VINES", "GLOW_BERRIES"), Map.entry("CAVE_VINES_PLANT", "GLOW_BERRIES"),
            Map.entry("SWEET_BERRY_BUSH", "SWEET_BERRIES"), Map.entry("PITCHER_CROP", "PITCHER_POD"));
    private final ConfigManager config;
    private final TextService text;
    private final MenuMaterials materials;

    SkillSourceCatalog(ConfigManager config, TextService text) {
        this.config = config; this.text = text; this.materials = new MenuMaterials(config);
    }

    List<SkillSource> sources(SkillDefinition skill) {
        if(!skill.enabled())return List.of();
        List<SkillSource> result = new ArrayList<>();
        ConfiguredSourceEntries.materials(skill,config.sources()).forEach(entry->result.add(render(entry)));
        skill.mobs().entrySet().stream()
                .filter(entry -> entry.getValue() > 0).sorted(Map.Entry.comparingByKey())
                .forEach(entry -> result.add(new SkillSource(entry.getKey().name(), name("entities", entry.getKey().name()),
                        "mob", entry.getValue(), mobIcon(entry.getKey().name()),unit("kill",Map.of()),details("mob",Map.of()))));
        ConfiguredSourceEntries.legacyEvents(skill,config.settings().damageCooldownSeconds()).forEach(entry->result.add(render(entry)));
        ConfiguredSourceEntries.routed(skill.id(),config.sourceRouting(),config.sources().agility(),config.alchemySources(),config.enchantingSources())
                .forEach(entry->result.add(render(entry)));
        if(skill.id().equals("fishing"))ConfiguredSourceEntries.fishing(skill,config.sources()).forEach(entry->result.add(render(entry)));
        if(skill.id().equals("sorcery") && config.mana().enabled())ConfiguredSourceEntries.sorcery(config.sorcerySources()).forEach(entry->result.add(render(entry)));
        ConfiguredSourceEntries.loot(skill,config.sources(),config.loot(),config.passives(),config.progressionEnabled()).forEach(entry->result.add(render(entry)));
        if (skill.id().equals("farming") && config.customCrops().enabled()
                && org.bukkit.Bukkit.getPluginManager().isPluginEnabled("CustomCrops"))
            customSources(result, config.customCrops().cropXp(), config.customCrops().defaultXp(), "custom-crop", Material.WHEAT);
        if (skill.id().equals("fishing") && config.customFishing().enabled()
                && org.bukkit.Bukkit.getPluginManager().isPluginEnabled("CustomFishing"))
            customSources(result, config.customFishing().lootXp(), config.customFishing().defaultXp(), "custom-fish", Material.FISHING_ROD);
        return List.copyOf(result);
    }

    private void customSources(List<SkillSource> result, Map<String, Double> rates, double fallback, String kind, Material icon) {
        String unit=unit(kind.equals("custom-crop")?"block":"catch",Map.of());List<String> details=details("custom-content",Map.of());
        if (fallback > 0) result.add(new SkillSource("*", text.plain(text.text("custom-content.default-source")), kind, fallback, icon,unit,details));
        rates.entrySet().stream().filter(entry -> entry.getValue() > 0).sorted(Map.Entry.comparingByKey())
                .forEach(entry -> result.add(new SkillSource(entry.getKey(), entry.getKey(), kind, entry.getValue(), icon,unit,details)));
    }

    private SkillSource render(SourceSpec entry) {
        Map<String,Object> values=new java.util.LinkedHashMap<>();
        entry.values().forEach((key,value)->values.put(key,value instanceof Double number?text.format(number):value instanceof String string?text.plain(string):value));
        if(values.containsKey("item"))values.put("item",name("materials",String.valueOf(values.get("item"))));
        if(values.containsKey("pool"))values.put("pool",text.plain(text.text("source-guide.pools."+values.get("pool"))));
        String display=entry.nameType().isEmpty()?text.plain(text.text("source-guide.names."+entry.label(),values)):name(entry.nameType(),entry.label());
        return new SkillSource(entry.id(),display,entry.kind(),entry.experience(),materialIcon(entry.icon()),unit(entry.unit(),values),details(entry.condition(),values));
    }
    private String unit(String key,Map<String,?> values) { return text.plain(text.text("source-guide.units."+key,values)); }
    private List<String> details(String key,Map<String,?> values) { return text.lines("source-guide.conditions."+key,values).stream().map(text::plain).toList(); }

    private String name(String type, String id) {
        return text.plain(config.menu().getString("source-names." + type + "." + id, id));
    }

    private Material materialIcon(Material material) {
        Material candidate = Material.matchMaterial(CROP_ITEMS.getOrDefault(material.name(), material.name()));
        return candidate != null && candidate.isItem() && !candidate.isAir() ? candidate
                : materials.get("details.icons.source-fallback", Material.PAPER);
    }

    private Material mobIcon(String entity) {
        Material egg = Material.matchMaterial(entity + "_SPAWN_EGG");
        return egg != null && egg.isItem() ? egg : materials.get("details.icons.mob-fallback", Material.BONE);
    }
}
