package net.liplugins.liskills.internal.menu;

import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.inventory.ItemStack;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

/** 聊天与物品共用来源计量信息；新增行独立于旧lore，升级不覆盖管理员列表。 */
final class SourcePresentation {
    private final TextService text;
    SourcePresentation(TextService text) { this.text=text; }
    Map<String,Object> values(SkillSource source) {
        Map<String,Object> values=new LinkedHashMap<>();values.put("source",source.name());values.put("source_id",source.id());
        values.put("source_kind",text.plain(text.text("menu.details.kind-"+source.kind())));values.put("xp",text.format(source.experience()));values.put("unit",source.unit());
        return values;
    }
    Map<String,Object> commandValues(SkillSource source) {
        Map<String,Object> values=values(source);
        values.put("source",text.plain(text.text("source-guide.command-name",values)));
        return values;
    }
    void append(ItemStack item,SkillSource source) {
        var meta=item.getItemMeta();if(meta==null)return;
        var lore=new ArrayList<>(meta.hasLore()?meta.getLore():java.util.List.of());
        lore.add(text.text("source-guide.unit-line",values(source)));
        for(String detail:source.details())lore.add(text.text("source-guide.condition-line",Map.of("condition",detail)));
        meta.setLore(lore);item.setItemMeta(meta);
    }
}
