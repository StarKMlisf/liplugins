package net.liplugins.liskills.internal.menu;

import org.bukkit.inventory.ItemStack;
import java.util.ArrayList;
import java.util.List;

/** 在原有管理员按钮说明后追加成长提示，不替换原来的文本列表。 */
final class RpgMenuItems {
    private RpgMenuItems() { }
    static void append(ItemStack item,List<String> extra) {
        if(item==null || extra.isEmpty())return;
        var meta=item.getItemMeta();
        if(meta==null)return;
        List<String> lore=new ArrayList<>(meta.hasLore()?meta.getLore():List.of());
        lore.addAll(extra);meta.setLore(lore);item.setItemMeta(meta);
    }
}
