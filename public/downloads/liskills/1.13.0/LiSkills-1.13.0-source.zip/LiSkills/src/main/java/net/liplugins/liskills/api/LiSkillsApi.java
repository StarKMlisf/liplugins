package net.liplugins.liskills.api;

import java.util.Set;
import java.util.UUID;
import java.util.Map;

/** 通过Bukkit ServicesManager获取；写入和实时装备/魔力查询仅限玩家所属实体线程及已加载在线玩家（普通 Bukkit 为主线程）；getSkills/getProgress可跨线程读取同步快照。 */
public interface LiSkillsApi {
    Set<String> getSkills();
    SkillView getProgress(UUID player,String skill);
    boolean addExperience(UUID player,String skill,double amount);
    /** 自然来源入口：调用方负责证明实际成功来源；会经过倍率、门槛、可取消预事件和职业收益。 */
    default boolean awardNaturalExperience(UUID player,String skill,double amount){return false;}
    /** 管理设置不重复发放自然经验收入，返回false表示线程、档案或参数不满足。 */
    default boolean setLevel(UUID player,String skill,int level){return false;}
    default boolean setExperience(UUID player,String skill,double amount){return false;}
    /** 实际属性快照，只在玩家所属实体线程读取在线档案；不可用时为空映射。 */
    default Map<String,Double> getStats(UUID player){return Map.of();}
    default Map<String,Double> getTraits(UUID player){return Map.of();}
    /** 返回当前与上限魔力，不可用时为null。 */
    default ManaView getMana(UUID player){return null;}
    /** 与玩家指令使用同一施法校验，不绕过工具、权限、消耗或冷却。 */
    default boolean activateAbility(UUID player,String skill){return false;}
    default AbilityView getAbility(UUID player,String skill){return null;}
    record SkillView(int level,double xp,double requiredXp) { }
    record ManaView(double current,double maximum) { }
    record AbilityView(String type,int rank,double activationMana,int durationSeconds,long cooldownRemainingMillis,long activeRemainingMillis) { }
}
