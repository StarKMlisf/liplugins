package net.liplugins.liskills.internal.manager.source;

import org.bukkit.Material;
import java.util.Set;

/** Aura默认原版渔获分类；鱼类与管理员显式材料XP由skills.yml优先处理。 */
public final class FishingSourceRules {
    private static final Set<Material> TREASURE=Set.of(Material.BOW,Material.ENCHANTED_BOOK,Material.NAME_TAG,Material.NAUTILUS_SHELL,Material.SADDLE);
    private static final Set<Material> JUNK=Set.of(Material.LILY_PAD,Material.BOWL,Material.LEATHER,Material.LEATHER_BOOTS,Material.ROTTEN_FLESH,
            Material.STICK,Material.STRING,Material.BONE,Material.INK_SAC,Material.TRIPWIRE_HOOK,Material.POTION);
    private FishingSourceRules() { }
    public static String category(Material material,boolean enchanted) {
        if(material==Material.FISHING_ROD)return enchanted?"treasure":"junk";
        if(TREASURE.contains(material))return "treasure";
        return JUNK.contains(material)?"junk":null;
    }
}
