package net.liplugins.liskills.internal.manager.passive.combat;

import net.liplugins.liskills.lib.scheduler.ServerThreads;
import org.bukkit.Location;

/** 范围战斗先确认搜索矩形内的每个区块都属于当前线程，不跨区域扫描实体列表。 */
final class OwnedCombatArea {
    private OwnedCombatArea() { }
    static boolean owns(Location origin, double radius) {
        if (!ServerThreads.folia()) return ServerThreads.owns(origin);
        int firstX = ((int)Math.floor(origin.getX() - radius)) >> 4;
        int lastX = ((int)Math.floor(origin.getX() + radius)) >> 4;
        int firstZ = ((int)Math.floor(origin.getZ() - radius)) >> 4;
        int lastZ = ((int)Math.floor(origin.getZ() + radius)) >> 4;
        for (int x = firstX; x <= lastX; x++) for (int z = firstZ; z <= lastZ; z++) {
            if (!ServerThreads.owns(new Location(origin.getWorld(), x * 16 + 8, origin.getY(), z * 16 + 8))) return false;
        }
        return true;
    }
}
