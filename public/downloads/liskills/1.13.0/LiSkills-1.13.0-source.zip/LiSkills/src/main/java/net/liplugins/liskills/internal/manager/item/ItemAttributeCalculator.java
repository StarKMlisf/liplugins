package net.liplugins.liskills.internal.manager.item;

import net.liplugins.liskills.internal.config.ItemRule;
import net.liplugins.liskills.internal.config.ItemSlot;
import net.liplugins.liskills.internal.config.ItemModifier;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** 每件已装备物品按槽位结算一次；堆叠数量不参与属性乘法。 */
public final class ItemAttributeCalculator {
    private ItemAttributeCalculator() { }
    public static Map<String, Double> calculate(Map<ItemSlot, List<ItemRule>> equipment) {
        Map<String, Double> result = new LinkedHashMap<>();
        equipment.forEach((slot, rules) -> rules.stream().filter(rule -> rule.enabled() && rule.slots().contains(slot))
                .forEach(rule -> rule.attributes().forEach((id, value) -> result.merge(id, value, Double::sum))));
        return Collections.unmodifiableMap(result);
    }

    public static ItemEffectSnapshot effects(Map<ItemSlot, List<ItemRule>> equipment) {
        Map<String, List<ItemModifier>> stats = new LinkedHashMap<>(), traits = new LinkedHashMap<>();
        Map<String, Double> xp = new LinkedHashMap<>();
        equipment.forEach((slot, rules) -> rules.stream().filter(rule -> rule.enabled() && rule.slots().contains(slot)).forEach(rule -> {
            var ids = new LinkedHashSet<>(rule.attributes().keySet());
            ids.addAll(rule.statMultipliers().keySet()); ids.addAll(rule.statPercentAdditions().keySet());
            for (String id : ids) stats.computeIfAbsent(id, ignored -> new ArrayList<>()).add(new ItemModifier(
                    rule.attributes().getOrDefault(id, 0.0), rule.statMultipliers().getOrDefault(id, 1.0), rule.statPercentAdditions().getOrDefault(id, 0.0)));
            rule.traits().forEach((id, modifier) -> traits.computeIfAbsent(id, ignored -> new ArrayList<>()).add(modifier));
            rule.skillXpMultipliers().forEach((id, amount) -> xp.merge(id, amount, Double::sum));
        }));
        Map<String, ItemModifier> statResults = new LinkedHashMap<>(), traitResults = new LinkedHashMap<>();
        stats.forEach((id, values) -> statResults.put(id, ItemModifier.aggregate(values)));
        traits.forEach((id, values) -> traitResults.put(id, ItemModifier.aggregate(values)));
        return new ItemEffectSnapshot(statResults, traitResults, xp);
    }
}
