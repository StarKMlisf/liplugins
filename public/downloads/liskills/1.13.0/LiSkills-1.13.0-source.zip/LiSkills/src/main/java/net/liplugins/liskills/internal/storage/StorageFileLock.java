package net.liplugins.liskills.internal.storage;

import java.io.IOException;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.channels.OverlappingFileLockException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;

/** 生命周期独占锁；不放到ProfileStore里，独立只读导出工具不需要争抢玩家目录锁。 */
public final class StorageFileLock implements AutoCloseable {
    private final FileChannel channel;
    private final FileLock lock;
    private StorageFileLock(FileChannel channel,FileLock lock){this.channel=channel;this.lock=lock;}
    public static StorageFileLock acquire(Path file)throws IOException{
        Files.createDirectories(file.toAbsolutePath().getParent());
        FileChannel channel=FileChannel.open(file,StandardOpenOption.CREATE,StandardOpenOption.WRITE);
        try{FileLock lock=channel.tryLock();if(lock==null)throw new IOException("storage-in-use");return new StorageFileLock(channel,lock);}
        catch(IOException|OverlappingFileLockException error){channel.close();throw new IOException("storage-in-use",error);}
    }
    @Override public void close()throws IOException{try{if(lock.isValid())lock.release();}finally{channel.close();}}
}
