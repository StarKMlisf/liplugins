package net.liplugins.liskills.tools;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

/** 迁移计划阶段只读；任何档案错误或目标冲突都会阻止整个批次进入写入阶段。 */
final class MigrationPlanner {
    private final MigrationMessages messages;
    private final LegacyProfileReader reader;

    MigrationPlanner(MigrationMessages messages) {
        this.messages = messages;
        this.reader = new LegacyProfileReader(messages);
    }

    ImportPlan plan(Path source, Path target) {
        Path sourcePath = source.toAbsolutePath().normalize();
        Path targetPath = target.toAbsolutePath().normalize();
        List<ImportCandidate> candidates = new ArrayList<>();
        List<String> errors = new ArrayList<>();
        try {
            if (!Files.isDirectory(sourcePath)) throw new IOException(messages.text("invalid.source", sourcePath));
            sourcePath = sourcePath.toRealPath();
            targetPath = canonicalTarget(targetPath);
            if (Files.exists(targetPath) && !Files.isDirectory(targetPath)) throw new IOException(messages.text("invalid.target", targetPath));
            if (targetPath.startsWith(sourcePath) || sourcePath.startsWith(targetPath)) throw new IOException(messages.text("invalid.overlap"));
            List<Path> files;
            try (var stream = Files.list(sourcePath)) {
                files = stream.filter(path -> path.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".yml"))
                        .sorted().toList();
            }
            if (files.isEmpty()) throw new IOException(messages.text("invalid.empty"));
            Set<UUID> identifiers = new HashSet<>();
            for (Path file : files) {
                try {
                    if (!Files.isRegularFile(file, LinkOption.NOFOLLOW_LINKS)) throw new IOException(messages.text("invalid.not-file"));
                    ImportCandidate candidate = reader.read(file);
                    if (!identifiers.add(candidate.uuid())) throw new IOException(messages.text("invalid.duplicate-player", candidate.uuid()));
                    Path destination = targetPath.resolve(candidate.uuid() + ".yml");
                    if (Files.exists(destination, LinkOption.NOFOLLOW_LINKS)) throw new IOException(messages.text("invalid.exists", destination));
                    candidates.add(candidate);
                } catch (Exception failure) {
                    errors.add(messages.text("error.file", file.getFileName(), describe(failure)));
                }
            }
        } catch (Exception failure) {
            errors.add(describe(failure));
        }
        return new ImportPlan(sourcePath, targetPath, candidates, errors);
    }

    private Path canonicalTarget(Path path) throws IOException {
        Path existing = path;
        while (existing != null && !Files.exists(existing)) existing = existing.getParent();
        if (existing == null) throw new IOException(messages.text("invalid.target", path));
        return existing.toRealPath().resolve(existing.relativize(path)).normalize();
    }

    private String describe(Exception failure) {
        String message = failure.getMessage();
        return message == null ? failure.getClass().getSimpleName() : message;
    }
}
