package net.liplugins.liskills.internal.command;

import net.liplugins.liskills.internal.config.SkillDefinition;
import net.liplugins.liskills.internal.manager.SkillManager;
import net.liplugins.liskills.internal.menu.SkillDisplay;
import net.liplugins.liskills.internal.storage.PlayerProfile;
import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Map;

final class LevelCommand implements Subcommand {
    private final SenderChecks checks;
    private final SkillManager skills;
    private final TextService text;
    LevelCommand(SenderChecks checks, SkillManager skills, TextService text) {
        this.checks = checks; this.skills = skills; this.text = text;
    }
    public String name() { return "level"; }
    public String permission() { return "liskills.admin"; }
    public void execute(CommandSender sender, String[] arguments) {
        if (arguments.length != 4 || !arguments[0].equalsIgnoreCase("set")) {
            checks.usage(sender, "command.usage-level"); return;
        }
        Player player = checks.online(sender, arguments[1]);
        if (player == null) return;
        checks.onPlayer(player, () -> {
        PlayerProfile profile = checks.profile(sender, player);
        SkillDefinition skill = checks.skill(sender, arguments[2]);
        if (profile == null || skill == null) return;
        Integer level = CommandNumbers.level(arguments[3], skill.maxLevel());
        if (level == null || !skills.setLevel(player, skill.id(), level)) {
            text.send(sender, "command.invalid-number"); return;
        }
        Map<String, Object> values = SkillDisplay.values(skill, profile.progress(skill.id()), text);
        values.put("player", player.getName());
        text.send(sender, "command.level-updated", values);
        });
    }
}
