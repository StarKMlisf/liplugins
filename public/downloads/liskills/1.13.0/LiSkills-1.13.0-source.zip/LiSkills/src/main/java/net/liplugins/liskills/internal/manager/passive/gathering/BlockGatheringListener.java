package net.liplugins.liskills.internal.manager.passive.gathering;

import net.liplugins.liskills.lib.scheduler.ServerThreads;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.data.Ageable;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.type.CaveVinesPlant;
import org.bukkit.entity.Item;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockDropItemEvent;
import org.bukkit.event.player.PlayerHarvestBlockEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.enchantments.Enchantment;
import net.liplugins.liskills.internal.manager.source.BlockHarvestSources;
import net.liplugins.liskills.internal.listener.HarvestMaturity;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

/** 只给经过原生掉落事件的成功采集添加幸运件数；预检和自定义模型不参与。 */
final class BlockGatheringListener implements Listener {
    private static final Set<Material> AGE_CROPS = Set.of(Material.WHEAT, Material.POTATOES, Material.CARROTS,
            Material.BEETROOTS, Material.NETHER_WART, Material.COCOA, Material.SWEET_BERRY_BUSH,
            Material.PITCHER_CROP, Material.TORCHFLOWER_CROP);
    private final GatheringContext context;
    private final GatheringLoot loot;
    private final Map<Position, BreakAttempt> breaks = new java.util.concurrent.ConcurrentHashMap<>();
    BlockGatheringListener(GatheringContext context, GatheringLoot loot) { this.context = context; this.loot = loot; }

    @EventHandler(priority = EventPriority.LOWEST)
    public void capture(BlockBreakEvent event) {
        if (!ServerThreads.owns(event.getPlayer()) || !ServerThreads.owns(event.getBlock())) return;
        Block block = event.getBlock();
        if (context.secondaryBreak() || context.customBlock().test(block) || breaks.size() >= 4096) return;
        Material material = block.getType();
        if (!context.config().sources().silkTouchMineralLuck() && BlockHarvestSources.mineralOre(material)
                && event.getPlayer().getInventory().getItemInMainHand().getEnchantmentLevel(Enchantment.SILK_TOUCH)>0) return;
        BlockData data = block.getBlockData();
        boolean placed = context.placed().contains(block);
        List<GatheringContext.Actor> actors = new ArrayList<>();
        for (String skill : List.of("farming", "foraging", "mining", "excavation")) {
            var definition = context.config().skill(skill);
            if (definition == null || !definition.blocks().containsKey(material)) continue;
            boolean crop = skill.equals("farming") && mature(material, data);
            if (skill.equals("farming") && !harvestable(material, data)) continue;
            // 放置矿石/原木等资源没有奖励；真正成熟的玩家作物仍保留正常收获。
            if (placed && !crop) continue;
            var actor = context.capture(event.getPlayer(), skill);
            if (actor != null) actors.add(actor);
        }
        if (actors.isEmpty()) return;
        Position key = Position.of(block, event.getPlayer().getUniqueId());
        BreakAttempt attempt = new BreakAttempt(event, material, data.clone(), context.placed().stamp(block), List.copyOf(actors));
        // 同坐标同玩家重入时不猜测哪一个破坏取得了掉落。
        if (breaks.putIfAbsent(key, attempt) != null) { breaks.remove(key); return; }
        if (!context.tasks().defer(event.getPlayer(), () -> breaks.remove(key, attempt), () -> breaks.remove(key, attempt))) breaks.remove(key, attempt);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void drops(BlockDropItemEvent event) {
        if (!ServerThreads.owns(event.getPlayer()) || !ServerThreads.owns(event.getBlock()) || !context.tasks().claim(event)) return;
        Position key = Position.of(event.getBlock(), event.getPlayer().getUniqueId());
        BreakAttempt attempt = breaks.remove(key);
        if (attempt == null || attempt.material != event.getBlockState().getType() || event.getItems().isEmpty()) return;
        List<Item> originals = List.copyOf(event.getItems());
        var location = event.getBlockState().getLocation().add(0.5, 0.5, 0.5);
        context.tasks().defer(event.getPlayer(), () -> {
            if (event.isCancelled() || attempt.event.isCancelled() || !attempt.event.isDropItems()
                    || !GatheringContext.loaded(location) || context.customBlock().test(location.getBlock())
                    || !context.placed().unchanged(event.getBlock(), attempt.stamp)
                    || event.getBlock().getBlockData().matches(attempt.data)) return;
            List<GatheringContext.Actor> eligible = attempt.actors.stream().filter(context::valid).toList();
            if (eligible.isEmpty() || !context.placed().claimBonus(event.getBlock(), attempt.stamp)) return;
            List<ItemStack> unique = new ArrayList<>();
            List<ItemStack> baseDrops = new ArrayList<>();
            for (Item item : originals) {
                if (!ServerThreads.owns(item) || !item.isValid() || !event.getItems().contains(item) || item.getItemStack().getType().isAir()
                        || !context.tasks().claimSource(item.getUniqueId())) continue;
                ItemStack stack = item.getItemStack();
                baseDrops.add(stack.clone());
                // 只使用成功落地且尚存在的实际物品，不重新计算时运，也不复制同类整个堆叠。
                if (unique.stream().noneMatch(existing -> existing.isSimilar(stack))) unique.add(stack.clone());
            }
            if (unique.isEmpty()) return;
            for (GatheringContext.Actor actor : eligible) {
                for (ItemStack item : unique) {
                    int extra = GatheringRules.extraDrops(context.luck(actor.player(), actor.skill()), ThreadLocalRandom.current().nextDouble());
                    loot.drop(location, item, extra);
                }
                if (actor.skill().equals("excavation")) {
                    var treasure = loot.select(actor.player(), "excavation", attempt.material, false);
                    if (treasure == null) continue;
                    ItemStack item = loot.create(treasure);
                    boolean delivered = loot.drop(location, item, item.getAmount());
                    if (delivered && treasure.experience() > 0) context.skills().award(actor.player(), "excavation", treasure.experience());
                }
            }
            // 原版DOUBLE_DROP独立于五类幸运：只翻倍白名单地形的基础掉落，不再次复制幸运件数或宝藏。
            if (context.valid(eligible.getFirst()) && context.placed().unchanged(event.getBlock(), attempt.stamp)
                    && DoubleDropRules.roll(attempt.material, context.stats().trait(event.getPlayer(), "double-drop"), ThreadLocalRandom.current().nextDouble()))
                for (ItemStack base : baseDrops) loot.drop(location, base, base.getAmount());
        });
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void harvest(PlayerHarvestBlockEvent event) {
        if (!ServerThreads.owns(event.getPlayer()) || !ServerThreads.owns(event.getHarvestedBlock())) return;
        Block block = event.getHarvestedBlock();
        if (!context.tasks().claim(event) || event.getItemsHarvested().isEmpty() || context.customBlock().test(block)
                || !mature(block.getType(), block.getBlockData())) return;
        var definition = context.config().skill("farming");
        var actor = context.capture(event.getPlayer(), "farming");
        if (actor == null || definition == null || !definition.blocks().containsKey(block.getType())) return;
        long stamp = context.placed().stamp(block);
        Material material = block.getType();
        var location = block.getLocation().add(0.5, 0.5, 0.5);
        context.tasks().defer(event.getPlayer(), () -> {
            if (event.isCancelled() || !context.valid(actor) || !GatheringContext.loaded(location)
                    || context.customBlock().test(block) || block.getType() != material
                    // 与来源经验采用同一采后状态；只改变年龄但仍可采摘不代表真正完成收获。
                    || !context.placed().unchanged(block, stamp) || !HarvestMaturity.harvestedState(material, block.getBlockData())
                    || event.getItemsHarvested().isEmpty() || !context.placed().claimBonus(block, stamp)) return;
            List<ItemStack> unique = new ArrayList<>();
            for (ItemStack item : event.getItemsHarvested()) {
                if (item.getType().isAir() || item.getAmount() <= 0 || unique.stream().anyMatch(existing -> existing.isSimilar(item))) continue;
                unique.add(item);
                int extra = GatheringRules.extraDrops(context.luck(actor.player(), "farming"), ThreadLocalRandom.current().nextDouble());
                loot.drop(location, item, extra);
            }
        });
    }

    static boolean harvestable(Material material, BlockData data) {
        if (AGE_CROPS.contains(material)) return mature(material, data);
        return !(data instanceof CaveVinesPlant vines) || vines.isBerries();
    }
    static boolean mature(Material material, BlockData data) {
        if (material == Material.SWEET_BERRY_BUSH) return data instanceof Ageable age && age.getAge() >= 2;
        if (AGE_CROPS.contains(material)) return data instanceof Ageable age && age.getAge() == age.getMaximumAge();
        return data instanceof CaveVinesPlant vines && vines.isBerries();
    }
    private record BreakAttempt(BlockBreakEvent event, Material material, BlockData data, long stamp, List<GatheringContext.Actor> actors) { }
    private record Position(UUID world, int x, int y, int z, UUID player) {
        static Position of(Block block, UUID player) { return new Position(block.getWorld().getUID(), block.getX(), block.getY(), block.getZ(), player); }
    }
}
