package net.liplugins.liskills.internal.manager.item;

import net.liplugins.liskills.internal.config.ItemModifier;
import net.liplugins.liskills.internal.config.ItemModifierOperation;
import net.liplugins.liskills.internal.config.ItemRule;
import net.liplugins.liskills.internal.config.ItemSlot;
import net.liplugins.liskills.internal.config.ItemUse;
import java.util.EnumSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/** 一个命名规则的不可变编辑器；等级要求和其他已有加成随单项编辑保留。 */
public final class ItemRuleEditor {
    private ItemRuleEditor() { }
    public static ItemRule named(String name, Set<ItemSlot> slots) {
        return new ItemRule(name, name, true, Set.of(), "", "", slots, Map.of(), Map.of(), EnumSet.allOf(ItemUse.class));
    }
    public static ItemRule stat(ItemRule rule, String stat, ItemModifierOperation operation, double value) {
        Map<String, Double> add = new LinkedHashMap<>(rule.attributes());
        Map<String, Double> multiply = new LinkedHashMap<>(rule.statMultipliers());
        Map<String, Double> percent = new LinkedHashMap<>(rule.statPercentAdditions());
        switch (operation) { case ADD -> add.put(stat, value); case MULTIPLY -> multiply.put(stat, value); case ADD_PERCENT -> percent.put(stat, value); }
        return copy(rule, add, multiply, percent, rule.traits(), rule.skillXpMultipliers(), rule.requirements());
    }
    public static ItemRule trait(ItemRule rule, String trait, ItemModifierOperation operation, double value) {
        Map<String, ItemModifier> modifiers = new LinkedHashMap<>(rule.traits());
        ItemModifier old = modifiers.getOrDefault(trait, ItemModifier.NONE);
        modifiers.put(trait, switch (operation) {
            case ADD -> new ItemModifier(value, old.multiply(), old.addPercent());
            case MULTIPLY -> new ItemModifier(old.add(), value, old.addPercent());
            case ADD_PERCENT -> new ItemModifier(old.add(), old.multiply(), value);
        });
        return copy(rule, rule.attributes(), rule.statMultipliers(), rule.statPercentAdditions(), modifiers, rule.skillXpMultipliers(), rule.requirements());
    }
    public static ItemRule experience(ItemRule rule, String skill, double percent) {
        Map<String, Double> xp = new LinkedHashMap<>(rule.skillXpMultipliers()); xp.put(skill, percent);
        return copy(rule, rule.attributes(), rule.statMultipliers(), rule.statPercentAdditions(), rule.traits(), xp, rule.requirements());
    }
    public static ItemRule requirement(ItemRule rule, String skill, int level) {
        Map<String, Integer> requirements = new LinkedHashMap<>(rule.requirements()); requirements.put(skill, level);
        return copy(rule, rule.attributes(), rule.statMultipliers(), rule.statPercentAdditions(), rule.traits(), rule.skillXpMultipliers(), requirements);
    }
    private static ItemRule copy(ItemRule rule, Map<String, Double> attributes, Map<String, Double> multiply,
                                 Map<String, Double> percent, Map<String, ItemModifier> traits, Map<String, Double> xp,
                                 Map<String, Integer> requirements) {
        return new ItemRule(rule.id(), rule.name(), rule.enabled(), rule.materials(), rule.pdcKey(), rule.pdcValue(), rule.slots(),
                attributes, requirements, rule.uses(), multiply, percent, traits, xp);
    }
}
