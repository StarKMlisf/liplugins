package net.liplugins.liskills.lib;

import java.util.List;

/** 固定官方Maven工件；摘要来自实际下载文件校验，不接受任意配置下载地址。 */
public final class StorageDriverCatalog {
    private StorageDriverCatalog(){ }
    public static List<RuntimeLibrary> mysql(){return List.of(
            new RuntimeLibrary("com.mysql","mysql-connector-j","9.7.0","0353648eaa1c91e0f4020c959abf756bc866ffd583df22ae6b6f6e0cbd43eb44"),
            new RuntimeLibrary("com.google.protobuf","protobuf-java","4.31.1","d60dfe7c68a0d38a248cca96924f289dc7e1966a887ee7cae397701af08575ae"));}
    public static List<RuntimeLibrary> sqlite(){return List.of(new RuntimeLibrary("org.xerial","sqlite-jdbc","3.53.2.0","dc320e4102884c135ccc30c3c6fc3fb190b750e1586a100e3aba3be783cf33a9"));}
}
