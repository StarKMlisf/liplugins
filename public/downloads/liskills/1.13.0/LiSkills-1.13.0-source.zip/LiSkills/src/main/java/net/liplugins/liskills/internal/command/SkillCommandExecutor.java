package net.liplugins.liskills.internal.command;

import net.liplugins.liskills.internal.menu.SkillMenu;
import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import net.liplugins.liskills.lib.scheduler.ServerThreads;

import java.util.Arrays;
import java.util.Locale;
import java.util.Map;

/** 根指令只分发，不处理具体业务或补全。 */
final class SkillCommandExecutor implements CommandExecutor {
    private final Map<String, Subcommand> commands;
    private final SenderChecks checks;
    private final SkillMenu menu;
    private final TextService text;

    SkillCommandExecutor(Map<String, Subcommand> commands, SenderChecks checks, SkillMenu menu, TextService text) {
        this.commands = Map.copyOf(commands); this.checks = checks; this.menu = menu; this.text = text;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] arguments) {
        if(sender instanceof Player player && !ServerThreads.owns(player)) {
            String[] captured=arguments.clone();
            checks.onPlayer(player,()->onCommand(sender,command,label,captured));
            return true;
        }
        if (arguments.length == 0) {
            if (!checks.permission(sender, "liskills.use")) return true;
            Player player = checks.player(sender);
            if (player != null) menu.open(player);
            return true;
        }
        Subcommand subcommand = commands.get(arguments[0].toLowerCase(Locale.ROOT));
        if (subcommand == null) { text.send(sender, "command.unknown-subcommand"); return true; }
        if (!checks.permission(sender, subcommand.permission())) return true;
        subcommand.execute(sender, Arrays.copyOfRange(arguments, 1, arguments.length));
        return true;
    }
}
