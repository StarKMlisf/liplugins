package net.liplugins.liskills.api;

/** 启动器与业务层之间的稳定生命周期接口，不暴露任何公共库类型。 */
public interface PluginRuntime {
    void start() throws Exception;

    void stop() throws Exception;
}
