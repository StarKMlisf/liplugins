package net.liplugins.liskills.internal.config;

import java.util.Collection;

/** Aura的三种运算：(基础值+加法和)×乘积×(1+百分比和/100)，最后应用安全边界。 */
public record ItemModifier(double add, double multiply, double addPercent) {
    public static final double MAXIMUM_FACTOR = 100;
    public static final double MAXIMUM_VALUE = 1_000_000_000;
    public static final ItemModifier NONE = new ItemModifier(0, 1, 0);

    public ItemModifier {
        if (!Double.isFinite(add) || !Double.isFinite(multiply) || !Double.isFinite(addPercent) || multiply < 0)
            throw new IllegalArgumentException("物品修饰值必须有限，乘法不得小于0");
    }
    public double factor() {
        double percentFactor = 1 + addPercent / 100;
        if (multiply == 0 || percentFactor <= 0) return 0;
        // 先合并两个倍率再限制，避免先截断乘积后再乘负百分比造成顺序依赖。
        return Math.min(MAXIMUM_FACTOR, Math.exp(Math.min(Math.log(MAXIMUM_FACTOR), Math.log(multiply) + Math.log(percentFactor))));
    }
    public double apply(double base) {
        if (!Double.isFinite(base)) return 0;
        double value = base + add;
        if (!Double.isFinite(value)) value = Math.copySign(Double.MAX_VALUE, value);
        double result = value * factor();
        return Math.clamp(result, -MAXIMUM_VALUE, MAXIMUM_VALUE);
    }
    public static ItemModifier aggregate(Collection<ItemModifier> modifiers) {
        double add = 0, percent = 0, logProduct = 0;
        boolean zero = false;
        for (ItemModifier modifier : modifiers) {
            add = Math.clamp(add + modifier.add, -MAXIMUM_VALUE, MAXIMUM_VALUE);
            percent = Math.clamp(percent + modifier.addPercent, -MAXIMUM_VALUE, MAXIMUM_VALUE);
            if (modifier.multiply == 0) zero = true;
            else logProduct += Math.log(modifier.multiply);
        }
        return new ItemModifier(add, zero ? 0 : Math.exp(Math.min(700, logProduct)), percent);
    }
}
