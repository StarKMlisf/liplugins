package net.liplugins.liskills.internal.config;

/** 技能升级按固定间隔给予的属性点；首次奖励由全局起始等级决定。 */
public record StatGrowth(String stat, double value, int interval) { }
