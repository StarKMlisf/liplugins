package net.liplugins.liskills.internal.manager.passive.combat;

/** 技能经验转换保留小数余量，非法或过量输入不能溢出原版经验整数。 */
public final class XpConversion {
    private XpConversion(){ }
    public record Result(int experience,double remainder){ }
    public static Result convert(double previous,double gained,double threshold) {
        if(!Double.isFinite(gained) || gained<=0 || !Double.isFinite(threshold) || threshold<.01) return new Result(0,0);
        double saved=Double.isFinite(previous)?Math.clamp(previous,0,Math.nextDown(threshold)):0;
        double total=saved+Math.min(gained,1_000_000_000);
        int experience=(int)Math.min(100_000,Math.floor(total/threshold));
        double remainder=total%threshold;
        return new Result(experience,Double.isFinite(remainder)?Math.max(0,remainder):0);
    }
}
