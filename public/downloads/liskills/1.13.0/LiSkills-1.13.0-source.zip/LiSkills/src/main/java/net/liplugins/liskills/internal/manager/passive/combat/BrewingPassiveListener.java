package net.liplugins.liskills.internal.manager.passive.combat;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.config.SkillDefinition;
import net.liplugins.liskills.internal.manager.PassiveAbilityManager;
import net.liplugins.liskills.internal.manager.SkillManager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.BrewEvent;
import org.bukkit.inventory.ItemStack;

/** 只修改原生酿造结果；经验由独立取药来源负责，绝不在完成事件重复奖励。 */
final class BrewingPassiveListener implements Listener {
    private final ConfigManager config;
    private final SkillManager skills;
    private final PassiveAbilityManager passives;
    private final BrewingOwnership ownership;
    private final PotionEnhancer enhancer;
    BrewingPassiveListener(ConfigManager config,SkillManager skills,PassiveAbilityManager passives,
                           BrewingOwnership ownership,PotionEnhancer enhancer) {
        this.config=config;this.skills=skills;this.passives=passives;this.ownership=ownership;this.enhancer=enhancer;
    }
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)
    public void onBrew(BrewEvent event) {
        int count=Math.min(3,event.getResults().size());
        // 第三方若在再酿造时保留自有元数据，先校正旧效果；原版纯净结果不认领，仍由下方合格玩家首次增强。
        for(int i=0;i<count;i++) {
            ItemStack original=event.getResults().get(i);
            ItemStack corrected=enhancer.rebase(event.getContents().getItem(i),original);
            if(corrected!=original) event.getResults().set(i,corrected);
        }
        PassiveSession session=ownership.owner(event.getBlock());
        if(session==null) return;
        SkillDefinition skill=config.skill("alchemy");
        if(skill==null || !skill.enabled() || !skills.eligible(session.player())) return;
        double percent=passives.value(session.player(),"alchemist");
        for(int i=0;i<count;i++) {
            ItemStack original=event.getResults().get(i);
            ItemStack result=enhancer.enhance(original,percent,passives.flag("alchemist","add_item_lore",true));
            if(result!=original) event.getResults().set(i,result);
        }
    }
}
