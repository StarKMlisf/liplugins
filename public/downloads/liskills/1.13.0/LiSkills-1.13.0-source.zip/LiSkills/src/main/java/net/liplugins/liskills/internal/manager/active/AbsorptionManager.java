package net.liplugins.liskills.internal.manager.active;

import net.liplugins.liskills.internal.config.ActiveSkill;
import net.liplugins.liskills.internal.config.AbsorptionActivationSettings;
import net.liplugins.liskills.internal.config.AuraManaSettings;
import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.hook.LiRealEnchantHook;
import net.liplugins.liskills.internal.manager.AbilityManager;
import net.liplugins.liskills.internal.manager.ActiveAbilityHandler;
import net.liplugins.liskills.internal.manager.ActiveSkillProgression;
import net.liplugins.liskills.internal.manager.ManaManager;
import net.liplugins.liskills.internal.manager.ProfileManager;
import net.liplugins.liskills.internal.manager.SkillAbilityWindows;
import net.liplugins.liskills.internal.manager.source.SorceryManaExperienceSource;
import net.liplugins.liskills.internal.manager.passive.combat.SecondaryDamageContext;
import net.liplugins.liskills.internal.util.TextService;
import net.liplugins.liskills.internal.util.ToolIdentity;
import net.liplugins.liskills.internal.storage.PlayerProfile;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Event;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;
import net.liplugins.liskills.lib.scheduler.TaskHandle;
import net.liplugins.liskills.lib.scheduler.TaskScheduler;
import net.liplugins.liskills.lib.scheduler.ServerThreads;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.Supplier;

/** 原版吸收语义：短时窗口内有足够魔力则全额抵消当前攻击；与旧部分减伤护盾独立。 */
public final class AbsorptionManager implements ActiveAbilityHandler,Listener,AutoCloseable {
    private final ConfigManager config;
    private final ProfileManager profiles;
    private final SkillAbilityWindows windows;
    private final TextService text;
    private final LiRealEnchantHook enchantments;
    private final Supplier<AuraManaSettings> settings;
    private final Supplier<AbsorptionActivationSettings> activationSettings;
    private final Map<UUID,Shield> shields=new java.util.concurrent.ConcurrentHashMap<>();
    private final Map<EntityDamageEvent,Pending> pending=new java.util.concurrent.ConcurrentHashMap<>();
    private final Map<UUID,Prepared> ready=new java.util.concurrent.ConcurrentHashMap<>();
    private final Map<UUID,Gesture> gestures=new java.util.concurrent.ConcurrentHashMap<>();
    private final Map<UUID,Automatic> automatic=new java.util.concurrent.ConcurrentHashMap<>();
    private final TaskScheduler scheduler;
    private final net.liplugins.liskills.lib.scheduler.PlayerTasks settlement;
    private volatile AbilityManager abilities;
    public AbsorptionManager(JavaPlugin plugin,ConfigManager config,ProfileManager profiles,SkillAbilityWindows windows,
                             TextService text,LiRealEnchantHook enchantments,Supplier<AuraManaSettings> settings) {
        this(plugin,config,profiles,windows,text,enchantments,settings,AbsorptionActivationSettings::defaults);
    }
    public AbsorptionManager(JavaPlugin plugin,ConfigManager config,ProfileManager profiles,SkillAbilityWindows windows,
                             TextService text,LiRealEnchantHook enchantments,Supplier<AuraManaSettings> settings,Supplier<AbsorptionActivationSettings> activationSettings) {
        this.config=config;this.profiles=profiles;this.windows=windows;this.text=text;this.enchantments=enchantments;this.settings=settings;
        this.activationSettings=activationSettings;
        scheduler = new TaskScheduler(plugin);
        settlement=new net.liplugins.liskills.lib.scheduler.PlayerTasks(plugin,this::tick,1,1);
    }
    public void bind(AbilityManager abilities){this.abilities=abilities;}
    @Override public boolean activate(Player player,ActiveSkill active) {
        if(!ServerThreads.owns(player))return false;
        if(!config.mana().enabled()){text.send(player,"ability.shield-mana-disabled");return false;}
        EquipmentSlot hand=player.getInventory().getItemInMainHand().getType()==Material.SHIELD?EquipmentSlot.HAND:
                player.getInventory().getItemInOffHand().getType()==Material.SHIELD?EquipmentSlot.OFF_HAND:null;
        if(hand==null){text.send(player,"ability.absorption-tool");return false;}
        if(windows.active(player,"defense")){text.send(player,"ability.window-active");return false;}
        if(shields.size()>=2048)return false;
        // 共用窗口仍锁住施放时的主手；副手盾另保存身份，换盾、掉盾、换武器都不能沿用旧窗口。
        if(!windows.open(player,"defense","ABSORPTION",active,Set.of(player.getInventory().getItemInMainHand().getType())))return false;
        shields.put(player.getUniqueId(),new Shield(hand,ToolIdentity.snapshot(player.getInventory().getItem(hand))));return true;
    }
    @Override public long remainingMillis(Player player){return active(player)?windows.remainingMillis(player,"defense"):0;}
    private boolean active(Player player) {
        Shield shield=shields.get(player.getUniqueId());
        return ServerThreads.owns(player) && shield!=null && windows.active(player,"defense")
                && shield.item().isSimilar(ToolIdentity.snapshot(player.getInventory().getItem(shield.hand())));
    }
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)
    public void onDamage(EntityDamageEvent event) {
        if(!config.mana().enabled() || !(event.getEntity() instanceof Player player) || !ServerThreads.owns(player)
                || pending.size()>=4096 || pending.containsKey(event) || SecondaryDamageContext.active()
                || (enchantments!=null && enchantments.isSecondaryDamage()))return;
        var policy=settings.get().absorption();
        if(!allowed(event.getCause(),policy.allowEnvironmentalDamage()) || !Double.isFinite(event.getFinalDamage()) || event.getFinalDamage()<=0)return;
        if(!active(player))startPrepared(player,event);
        if(!active(player))return;
        var profile=profiles.get(player.getUniqueId());if(profile==null)return;
        double cost=AbsorptionRules.cost(event.getDamage(),ManaManager.available(profile,config),policy.manaPerDamage(),policy.maximumDamagePerHit());
        if(cost<=0)return;
        var reservation=new AbilityManager.ManaReservation(cost,()->ManaManager.available(profile,config),
                ()->ManaManager.maximum(profile,config),profile::mana,()->ManaManager.spend(profile,config,cost));
        try {
            // 用当前事件的零伤害表达吸收，不借用取消标记；这样后续保护取消仍能准确退款。
            event.setDamage(0);pending.put(event,new Pending(reservation,windows.token(player,"defense")));
        } catch(RuntimeException failure){reservation.close();throw failure;}
    }
    private static boolean allowed(EntityDamageEvent.DamageCause cause,boolean environmental) {
        if(cause==EntityDamageEvent.DamageCause.ENTITY_ATTACK || cause==EntityDamageEvent.DamageCause.ENTITY_SWEEP_ATTACK
                || cause==EntityDamageEvent.DamageCause.PROJECTILE)return true;
        return environmental && cause!=EntityDamageEvent.DamageCause.VOID && cause!=EntityDamageEvent.DamageCause.SUICIDE
                && cause!=EntityDamageEvent.DamageCause.CUSTOM && cause!=EntityDamageEvent.DamageCause.THORNS
                && !cause.name().equals("KILL");
    }
    public void settleFor(UUID player) {
        var iterator=pending.entrySet().iterator();
        while(iterator.hasNext()) {
            var entry=iterator.next();if(!entry.getKey().getEntity().getUniqueId().equals(player))continue;
            finish(entry.getKey(),entry.getValue());iterator.remove();
        }
        Automatic activation=automatic.remove(player);if(activation!=null)finishAutomatic(activation);
    }
    private void finish(EntityDamageEvent event,Pending pending) {
        // 后续插件恢复伤害时，此次全额吸收没有被采纳，同样不收取费用。
        if(!event.isCancelled() && Double.isFinite(event.getDamage()) && event.getDamage()==0) {
            pending.reservation().commit();Automatic activation=automatic.get(event.getEntity().getUniqueId());
            if(activation!=null && activation.token==pending.token())activation.used=true;
        }
        pending.reservation().close();
    }
    private void tick(Player player) {
        UUID id=player.getUniqueId();settleFor(id);
        Shield shield=shields.get(id);if(shield!=null && !active(player))shields.remove(id,shield);
        Prepared prepared=ready.get(id);if(prepared!=null && !valid(player,prepared))ready.remove(id,prepared);
        Gesture gesture=gestures.remove(id);
        if(gesture!=null) {
            if(!valid(player,gesture.prepared()) || gesture.event().useItemInHand()==Event.Result.DENY
                    || (gesture.event().getClickedBlock()!=null && gesture.event().useInteractedBlock()==Event.Result.DENY))return;
            if(activationSettings.get().mode()==AbsorptionActivationSettings.Mode.SHIELD_RIGHT_CLICK){if(abilities!=null)abilities.activate(player,"defense");}
            else if(activationSettings.get().mode()==AbsorptionActivationSettings.Mode.AURA_READY && !active(player) && !ready.containsKey(player.getUniqueId())){
                if(gesture.prepared().profile().cooldown("defense")>System.currentTimeMillis())return;
                ready.put(player.getUniqueId(),gesture.prepared());text.send(player,"ability.absorption-ready");
            }
        }
    }
    @EventHandler(priority=EventPriority.MONITOR)
    public void onInteract(PlayerInteractEvent event) {
        if(!ServerThreads.owns(event.getPlayer()) || (event.getClickedBlock()!=null && !ServerThreads.owns(event.getClickedBlock()))
                || abilities==null || activationSettings.get().mode()==AbsorptionActivationSettings.Mode.MANUAL || gestures.size()>=2048
                || (ready.size()>=2048 && !ready.containsKey(event.getPlayer().getUniqueId())))return;
        Player player=event.getPlayer();var skill=config.skill("defense");var profile=profiles.get(player.getUniqueId());
        if(skill==null || !skill.active().type().equals("ABSORPTION") || profile==null || (event.getClickedBlock()!=null && event.getClickedBlock().getType().isInteractable()))return;
        EquipmentSlot shieldHand=player.getInventory().getItemInMainHand().getType()==Material.SHIELD?EquipmentSlot.HAND:
                player.getInventory().getItemInOffHand().getType()==Material.SHIELD?EquipmentSlot.OFF_HAND:null;
        if(shieldHand==null)return;
        boolean allowed=activationSettings.get().mode()==AbsorptionActivationSettings.Mode.AURA_READY
                ? event.getHand()==EquipmentSlot.HAND && (event.getAction()==Action.LEFT_CLICK_AIR || event.getAction()==Action.LEFT_CLICK_BLOCK)
                : event.getHand()==shieldHand && (event.getAction()==Action.RIGHT_CLICK_AIR || event.getAction()==Action.RIGHT_CLICK_BLOCK);
        if(!allowed)return;
        Prepared prepared=new Prepared(profile,config.revision(),player.getWorld().getUID(),player.getInventory().getHeldItemSlot(),
                ToolIdentity.snapshot(player.getInventory().getItemInMainHand()),new Shield(shieldHand,ToolIdentity.snapshot(player.getInventory().getItem(shieldHand))),
                System.currentTimeMillis()+activationSettings.get().readySeconds()*1000L);
        gestures.put(player.getUniqueId(),new Gesture(event,prepared));
    }
    private boolean valid(Player player,Prepared prepared) {
        if(!ServerThreads.owns(player))return false;
        var skill=config.skill("defense");
        return player.isOnline() && player.isValid() && !player.isDead() && player.hasPermission("liskills.use") && player.hasPermission("liskills.skill.defense")
                && !config.settings().disabledWorlds().contains(player.getWorld().getName()) && prepared.expires()>System.currentTimeMillis()
                && (!config.settings().survivalOnly() || player.getGameMode()==org.bukkit.GameMode.SURVIVAL || player.getGameMode()==org.bukkit.GameMode.ADVENTURE)
                && config.revision()==prepared.revision() && profiles.get(player.getUniqueId())==prepared.profile()
                && player.getWorld().getUID().equals(prepared.world()) && player.getInventory().getHeldItemSlot()==prepared.slot()
                && prepared.main().isSimilar(ToolIdentity.snapshot(player.getInventory().getItemInMainHand()))
                && prepared.shield().item().isSimilar(ToolIdentity.snapshot(player.getInventory().getItem(prepared.shield().hand())))
                && skill!=null && skill.enabled() && skill.active().enabled() && skill.active().type().equals("ABSORPTION")
                && ActiveSkillProgression.rank(config,skill,prepared.profile())>0;
    }
    private void startPrepared(Player player,EntityDamageEvent event) {
        Prepared prepared=ready.get(player.getUniqueId());
        if(abilities==null || activationSettings.get().mode()!=AbsorptionActivationSettings.Mode.AURA_READY || prepared==null
                || !valid(player,prepared) || automatic.containsKey(player.getUniqueId()))return;
        var active=ActiveSkillProgression.resolve(config,config.skill("defense"),prepared.profile());long beforeCooldown=prepared.profile().cooldown("defense");
        var experience=abilities.captureManaExperience(player,active.manaCost());
        if(!abilities.activateWithoutManaExperience(player,"defense"))return;
        ready.remove(player.getUniqueId());automatic.put(player.getUniqueId(),new Automatic(player,event,prepared.profile(),active.manaCost(),
                beforeCooldown,prepared.profile().cooldown("defense"),windows.token(player,"defense"),shields.get(player.getUniqueId()),experience));
    }
    private void finishAutomatic(Automatic activation) {
        // 同tick另一次未取消攻击实际用到窗口时，激活仍然成立；仅首击全被保护且无人使用时退激活费。
        if(!activation.event.isCancelled() || activation.used) {
            if(abilities!=null && ServerThreads.owns(activation.player))abilities.completeManaExperience(activation.experience);
            return;
        }
        synchronized(activation.profile) {
            activation.profile.mana(Math.min(ManaManager.maximum(activation.profile,config),ManaManager.available(activation.profile,config)+activation.cost));
            if(activation.profile.cooldown("defense")==activation.cooldown)activation.profile.cooldown("defense",activation.beforeCooldown);
        }
        if(ServerThreads.owns(activation.player) && windows.token(activation.player,"defense")==activation.token)windows.remove(activation.player,"defense");
        if(shields.get(activation.player.getUniqueId())==activation.shield)shields.remove(activation.player.getUniqueId());
    }
    @EventHandler(priority=EventPriority.LOWEST)
    public void onQuit(PlayerQuitEvent event){UUID player=event.getPlayer().getUniqueId();settleFor(player);shields.remove(player);ready.remove(player);gestures.remove(player);}
    @Override public void close(){
        settlement.close();scheduler.cancelAll();
        for(var entry:pending.entrySet()){
            if(ServerThreads.owns(entry.getKey().getEntity()))finish(entry.getKey(),entry.getValue());
            else entry.getValue().reservation().close();
        }
        pending.clear();
        // 未归属玩家只结算 Java 档案退款；不操作窗口、玩家实体或发送经验事件。
        for(Automatic activation:automatic.values())finishAutomatic(activation);
        automatic.clear();shields.clear();ready.clear();gestures.clear();abilities=null;
    }
    private record Shield(EquipmentSlot hand,ItemStack item) { }
    private record Pending(AbilityManager.ManaReservation reservation,long token) { }
    private record Prepared(PlayerProfile profile,long revision,UUID world,int slot,ItemStack main,Shield shield,long expires) { }
    private record Gesture(PlayerInteractEvent event,Prepared prepared) { }
    private static final class Automatic {
        private final Player player;private final EntityDamageEvent event;private final PlayerProfile profile;private final double cost;
        private final long beforeCooldown,cooldown,token;private final Shield shield;private volatile boolean used;
        private final SorceryManaExperienceSource.Receipt experience;
        private Automatic(Player player,EntityDamageEvent event,PlayerProfile profile,double cost,long beforeCooldown,long cooldown,long token,Shield shield,SorceryManaExperienceSource.Receipt experience) {
            this.player=player;this.event=event;this.profile=profile;this.cost=cost;this.beforeCooldown=beforeCooldown;this.cooldown=cooldown;this.token=token;this.shield=shield;
            this.experience=experience;
        }
    }
}
