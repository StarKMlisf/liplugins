package net.liplugins.liskills.internal.listener.item;

import net.liplugins.liskills.internal.config.ItemSlot;
import net.liplugins.liskills.internal.config.ItemUse;
import net.liplugins.liskills.internal.manager.item.ItemEquipmentSlots;
import net.liplugins.liskills.internal.manager.item.ItemRequirementFeedback;
import net.liplugins.liskills.internal.manager.item.ItemRuleManager;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockDispenseArmorEvent;
import org.bukkit.event.entity.EntityToggleGlideEvent;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.ItemStack;

/** 仅预测将穿入的护甲，不移动背包物品；脱下、丢弃和转移到箱子始终允许。 */
public final class ItemArmorRequirementListener implements Listener {
    private final ItemRuleManager rules;
    private final ItemRequirementFeedback feedback;
    public ItemArmorRequirementListener(ItemRuleManager rules, ItemRequirementFeedback feedback) { this.rules = rules; this.feedback = feedback; }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player) || event.getClickedInventory() == null || !rules.active(player)) return;
        if (event.getClickedInventory().equals(player.getInventory()) && event.getSlotType() == InventoryType.SlotType.ARMOR) {
            ItemSlot slot = ItemEquipmentSlots.inventorySlot(event.getSlot());
            ItemStack incoming = switch (event.getAction()) {
                case PLACE_ALL, PLACE_ONE, PLACE_SOME, SWAP_WITH_CURSOR -> event.getCursor();
                case HOTBAR_SWAP, HOTBAR_MOVE_AND_READD -> event.getClick() == ClickType.SWAP_OFFHAND
                        ? player.getInventory().getItemInOffHand()
                        : event.getHotbarButton() >= 0 ? player.getInventory().getItem(event.getHotbarButton()) : null;
                default -> null;
            };
            if (incoming != null) check(player, incoming, slot, event);
            return;
        }
        // 只有自身背包界面的Shift点击会自动穿甲；箱子界面的普通转移不能被误当成穿戴。
        if (event.getAction() != InventoryAction.MOVE_TO_OTHER_INVENTORY
                || event.getView().getTopInventory().getType() != InventoryType.CRAFTING
                || !event.getClickedInventory().equals(player.getInventory())) return;
        ItemStack incoming = event.getCurrentItem();
        ItemSlot slot = ItemEquipmentSlots.armorSlot(incoming);
        if (slot == null) return;
        ItemStack existing = player.getInventory().getItem(slot.equipmentSlot());
        if (existing == null || existing.getType().isAir()) check(player, incoming, slot, event);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onDrag(InventoryDragEvent event) {
        if (!(event.getWhoClicked() instanceof Player player) || !rules.active(player)) return;
        for (var change : event.getNewItems().entrySet()) {
            int rawSlot = change.getKey();
            if (event.getView().getSlotType(rawSlot) != InventoryType.SlotType.ARMOR
                    || !player.getInventory().equals(event.getView().getInventory(rawSlot))) continue;
            if (check(player, change.getValue(), ItemEquipmentSlots.inventorySlot(event.getView().convertSlot(rawSlot)), event)) return;
        }
    }
    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onDispense(BlockDispenseArmorEvent event) {
        if (event.getTargetEntity() instanceof Player player) check(player, event.getItem(), ItemEquipmentSlots.armorSlot(event.getItem()), event);
    }
    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onGlide(EntityToggleGlideEvent event) {
        if (event.isGliding() && event.getEntity() instanceof Player player)
            check(player, player.getInventory().getChestplate(), ItemSlot.CHEST, event);
    }
    private boolean check(Player player, ItemStack item, ItemSlot slot, Cancellable event) {
        if (slot == null || !slot.armor()) return false;
        var failure = rules.denial(player, item, slot, ItemUse.EQUIP);
        if (failure.isEmpty()) return false;
        event.setCancelled(true);
        feedback.denied(player, failure.get());
        return true;
    }
}
