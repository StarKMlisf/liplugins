package net.liplugins.liskills.internal.manager.active;

/** 锐钩只对正常范围且真正损失生命/吸收生命的原生伤害收费。 */
public final class SharpHookRules {
    private SharpHookRules() { }
    public static boolean withinRange(double distanceSquared,double maximumDistance) {
        return Double.isFinite(distanceSquared) && distanceSquared>=0 && Double.isFinite(maximumDistance)
                && maximumDistance>0 && distanceSquared<=maximumDistance*maximumDistance;
    }
    public static boolean damaged(double healthBefore,double absorptionBefore,double healthAfter,double absorptionAfter) {
        if(!Double.isFinite(healthBefore) || !Double.isFinite(absorptionBefore) || !Double.isFinite(healthAfter)
                || !Double.isFinite(absorptionAfter) || healthBefore<0 || healthAfter<0 || absorptionBefore<0 || absorptionAfter<0)return false;
        return healthAfter<healthBefore || absorptionAfter<absorptionBefore;
    }
}
