package net.liplugins.liskills.internal.manager;

import org.bukkit.Material;
import org.bukkit.block.data.Ageable;
import org.bukkit.block.data.BlockData;

/** 只定义补种作物、种子和土壤规则，不处理事件或库存。 */
final class CropReplantRules {
    private CropReplantRules() { }

    static Material seed(Material crop) {
        return switch (crop) {
            case WHEAT -> Material.WHEAT_SEEDS;
            case CARROTS -> Material.CARROT;
            case POTATOES -> Material.POTATO;
            case BEETROOTS -> Material.BEETROOT_SEEDS;
            case NETHER_WART -> Material.NETHER_WART;
            default -> null;
        };
    }

    static boolean mature(Material crop, BlockData data) {
        return seed(crop) != null && data instanceof Ageable age && age.getAge() == age.getMaximumAge();
    }

    static boolean supports(Material crop, Material soil) {
        return seed(crop) != null && soil == (crop == Material.NETHER_WART ? Material.SOUL_SAND : Material.FARMLAND);
    }

    static BlockData seedling(BlockData harvested) {
        BlockData copy = harvested.clone();
        if (!(copy instanceof Ageable age) || seed(copy.getMaterial()) == null)
            throw new IllegalArgumentException("unsupported crop");
        age.setAge(0);
        return copy;
    }

    static boolean isHoe(Material material) { return material.name().endsWith("_HOE"); }
}
