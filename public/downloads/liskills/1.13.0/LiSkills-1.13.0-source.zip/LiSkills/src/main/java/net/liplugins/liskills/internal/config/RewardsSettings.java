package net.liplugins.liskills.internal.config;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import java.util.*;

/** 等级奖励定义；奖励键是稳定的领取标识，不能通过降级再次领取。 */
public record RewardsSettings(boolean enabled,boolean adminExperience,int maximumPerEvent,List<Rule> rules) {
    public record Rule(String id,String skill,int start,int interval,int end,Material material,int amount,double money,List<String> commands) {
        public Rule { commands=List.copyOf(commands); }
        public boolean matches(String candidate,int level){return (skill.equals("all")||skill.equals(candidate))&&level>=start&&level<=end&&(level-start)%interval==0;}
    }
    public RewardsSettings { rules=List.copyOf(rules); }
    public static RewardsSettings parse(ConfigurationSection root,Set<String> skills){
        var section=ConfigValues.section(root,"rules");if(section.getKeys(false).size()>128)throw ConfigValues.invalid("rewards.rules","最多128项");
        List<Rule> rules=new ArrayList<>();
        for(String id:section.getKeys(false)){
            var c=ConfigValues.section(section,id);if(!id.matches("[a-z][a-z0-9_-]{0,47}"))throw ConfigValues.invalid("rewards."+id,"小写标识符");
            if(!ConfigValues.bool(c,"enabled"))continue;
            String skill=ConfigValues.text(c,"skill");if(!skill.equals("all")&&!skills.contains(skill))throw ConfigValues.invalid("rewards."+id+".skill","all或已注册技能");
            Material material;try{material=Material.valueOf(ConfigValues.text(c,"item").toUpperCase(Locale.ROOT));}catch(IllegalArgumentException ex){throw ConfigValues.invalid("rewards."+id+".item","Bukkit物品名或AIR");}
            if(material!=Material.AIR&&!material.isItem())throw ConfigValues.invalid("rewards."+id+".item","可发放物品或AIR");
            int start=ConfigValues.integer(c,"start",2,1000),end=ConfigValues.integer(c,"end",start,1000);
            Object raw=c.get("commands");if(!(raw instanceof List<?> list)||list.size()>8||list.stream().anyMatch(v->!(v instanceof String s)||s.length()>512||s.contains("\n")||s.contains("\r")))throw ConfigValues.invalid("rewards."+id+".commands","最多8条单行控制台命令");
            rules.add(new Rule(id,skill,start,ConfigValues.integer(c,"interval",1,1000),end,material,ConfigValues.integer(c,"amount",1,64),ConfigValues.number(c,"money",0,1e6),c.getStringList("commands")));
        }
        return new RewardsSettings(ConfigValues.bool(root,"enabled"),ConfigValues.bool(root,"allow-admin-experience"),ConfigValues.integer(root,"maximum-per-event",1,128),rules);
    }
}
