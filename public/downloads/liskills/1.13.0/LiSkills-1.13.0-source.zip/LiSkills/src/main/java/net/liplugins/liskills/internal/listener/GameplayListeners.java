package net.liplugins.liskills.internal.listener;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.manager.ProfileManager;
import net.liplugins.liskills.internal.manager.SkillManager;
import net.liplugins.liskills.internal.util.TextService;
import net.liplugins.liskills.internal.hook.LiRealEnchantHook;
import org.bukkit.event.Listener;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;

/** 仅负责组装并注册游戏监听器，业务规则分别封装。 */
public final class GameplayListeners {
    private GameplayListeners() { }

    public static void register(JavaPlugin plugin, ConfigManager config, ProfileManager profiles, SkillManager skills, TextService text) {
        register(plugin,config,profiles,skills,text,new PlacedBlockTracker(plugin),null);
    }
    public static void register(JavaPlugin plugin,ConfigManager config,ProfileManager profiles,SkillManager skills,TextService text,
                                PlacedBlockTracker placed,LiRealEnchantHook enchantments) {
        register(plugin,config,profiles,skills,text,placed,enchantments,block -> false,event -> false);
    }
    public static void register(JavaPlugin plugin,ConfigManager config,ProfileManager profiles,SkillManager skills,TextService text,
                                PlacedBlockTracker placed,LiRealEnchantHook enchantments,
                                java.util.function.Predicate<org.bukkit.block.Block> customBlock,
                                java.util.function.Predicate<org.bukkit.event.player.PlayerFishEvent> customFishing) {
        MobOriginListener origins = new MobOriginListener(plugin);
        PluginManager events = plugin.getServer().getPluginManager();
        BlockExperienceListener blockListener=new BlockExperienceListener(config,skills,placed,enchantments,customBlock);
        Listener[] listeners = {
                placed, origins,
                blockListener,
                new HarvestExperienceListener(config, profiles, skills, placed, customBlock),
                new CombatModifierListener(config, skills,enchantments),
                new CombatExperienceListener(plugin, config, profiles, skills, origins),
                new DamageExperienceListener(config, profiles, skills, origins),
                new FishingExperienceListener(plugin, config, profiles, skills, customFishing),
                new AgilityExperienceListener(plugin, config, profiles, skills)
        };
        for (Listener listener : listeners) events.registerEvents(listener, plugin);
        if(enchantments!=null)enchantments.register(blockListener,skills);
    }
}
