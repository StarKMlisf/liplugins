package net.liplugins.liskills.lib.customfishing;

import org.bukkit.entity.FishHook;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.player.PlayerEvent;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.plugin.Plugin;

import java.lang.reflect.Method;
import java.util.Optional;

/** 只反射 CustomFishing 公开 API；缺少依赖时不会链接它的实现类或 NMS。 */
public final class CustomFishingAccess {
    private static final String API = "net.momirealms.customfishing.api.";
    private final Class<? extends Event> resultEvent, rodEvent, effectEvent;
    private final Class<?> syntheticEvent;
    private final Method result, resultLoot, resultHook, resultAmount, lootId, rodSource;
    private final Method effectStage, effectValue, effectHook, hookEntity, hookContext, contextHolder;
    private final Method waitGet, waitSet, managerHook;
    private final Object manager;

    public CustomFishingAccess(Plugin owner) throws ReflectiveOperationException {
        ClassLoader loader = owner.getClass().getClassLoader();
        resultEvent = type(loader, "event.FishingResultEvent").asSubclass(Event.class);
        rodEvent = type(loader, "event.RodCastEvent").asSubclass(Event.class);
        effectEvent = type(loader, "event.FishingEffectApplyEvent").asSubclass(Event.class);
        syntheticEvent = type(loader, "event.CustomPlayerFishEvent");
        result = resultEvent.getMethod("getResult");
        resultLoot = resultEvent.getMethod("getLoot");
        resultHook = resultEvent.getMethod("getFishHook");
        resultAmount = resultEvent.getMethod("getAmount");
        lootId = type(loader, "mechanic.loot.Loot").getMethod("id");
        rodSource = rodEvent.getMethod("getBukkitPlayerFishEvent");
        effectStage = effectEvent.getMethod("getStage");
        effectValue = effectEvent.getMethod("getEffect");
        effectHook = effectEvent.getMethod("getHook");
        Class<?> hook = type(loader, "mechanic.fishing.CustomFishingHook");
        hookEntity = hook.getMethod("getHookEntity");
        hookContext = hook.getMethod("getContext");
        contextHolder = type(loader, "mechanic.context.Context").getMethod("holder");
        Class<?> effect = type(loader, "mechanic.effect.Effect");
        waitGet = effect.getMethod("waitTimeMultiplier");
        waitSet = effect.getMethod("waitTimeMultiplier", double.class);
        Class<?> pluginApi = type(loader, "BukkitCustomFishingPlugin");
        Object api = pluginApi.getMethod("getInstance").invoke(null);
        if (api == null) throw new IllegalStateException("CustomFishing API unavailable");
        manager = pluginApi.getMethod("getFishingManager").invoke(api);
        if (manager == null) throw new IllegalStateException("CustomFishing manager unavailable");
        managerHook = type(loader, "mechanic.fishing.FishingManager").getMethod("getFishHook", java.util.UUID.class);
    }

    private static Class<?> type(ClassLoader loader, String name) throws ClassNotFoundException {
        return Class.forName(API + name, false, loader);
    }

    public Class<? extends Event> resultEvent() { return resultEvent; }
    public Class<? extends Event> rodEvent() { return rodEvent; }
    public Class<? extends Event> effectEvent() { return effectEvent; }
    public boolean synthetic(PlayerFishEvent event) { return syntheticEvent.isInstance(event); }
    public PlayerFishEvent rodSource(Event event) throws ReflectiveOperationException {
        return (PlayerFishEvent) rodSource.invoke(event);
    }
    public ResultView result(Event event) throws ReflectiveOperationException {
        Object loot = resultLoot.invoke(event);
        return new ResultView(((PlayerEvent) event).getPlayer(), (FishHook) resultHook.invoke(event),
                "SUCCESS".equals(String.valueOf(result.invoke(event))),
                loot == null ? null : (String) lootId.invoke(loot), ((Number) resultAmount.invoke(event)).intValue());
    }
    public EffectView effect(Event event) throws ReflectiveOperationException {
        Object hook = effectHook.invoke(event);
        Object context = hookContext.invoke(hook);
        return new EffectView((Player) contextHolder.invoke(context), (FishHook) hookEntity.invoke(hook),
                String.valueOf(effectStage.invoke(event)), effectValue.invoke(event));
    }
    public double multiplier(Object effect) throws ReflectiveOperationException {
        return ((Number) waitGet.invoke(effect)).doubleValue();
    }
    public void multiplier(Object effect, double value) throws ReflectiveOperationException { waitSet.invoke(effect, value); }
    public boolean owns(FishHook hook) throws ReflectiveOperationException {
        if (!(hook.getShooter() instanceof Player player)) return false;
        Object result = managerHook.invoke(manager, player.getUniqueId());
        if (!(result instanceof Optional<?> optional) || optional.isEmpty()) return false;
        FishHook current = (FishHook) hookEntity.invoke(optional.get());
        return current != null && current.getUniqueId().equals(hook.getUniqueId());
    }

    public record ResultView(Player player, FishHook hook, boolean success, String lootId, int amount) { }
    public record EffectView(Player player, FishHook hook, String stage, Object effect) { }
}
