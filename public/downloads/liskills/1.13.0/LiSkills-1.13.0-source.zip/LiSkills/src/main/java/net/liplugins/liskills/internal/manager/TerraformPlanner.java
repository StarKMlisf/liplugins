package net.liplugins.liskills.internal.manager;

import net.liplugins.liskills.lib.scheduler.ServerThreads;
import org.bukkit.Location;

import net.liplugins.liskills.internal.config.TerraformSettings;
import net.liplugins.liskills.internal.listener.PlacedBlockTracker;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.function.Predicate;

/** 只读规划同一高度、同一材质的四邻连通地形，绝不加载区块或改变方块。 */
final class TerraformPlanner {
    record Position(int x, int y, int z) { }

    // 白名单不能由配置扩展到容器、矿物、建筑材料、耕地或道路，避免误配扩大拆除范围。
    private static final Set<Material> SHOVEL_TERRAIN = Set.of(
            Material.DIRT, Material.GRASS_BLOCK, Material.COARSE_DIRT, Material.PODZOL,
            Material.ROOTED_DIRT, Material.MYCELIUM, Material.SAND, Material.RED_SAND,
            Material.GRAVEL, Material.CLAY, Material.SOUL_SAND, Material.SOUL_SOIL, Material.MUD);
    private static final int[][] OFFSETS = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
    private final Predicate<Block> placed;

    TerraformPlanner(PlacedBlockTracker placed) { this(placed::contains); }
    TerraformPlanner(Predicate<Block> placed) { this.placed = placed; }

    List<Position> plan(Block origin, TerraformSettings settings, Map<Material, Double> sources) {
        World world = origin.getWorld();
        Set<Material> allowed = allowedMaterials(sources);
        return scan(position(origin), settings, allowed, position -> {
            Block block = loadedBlock(world, position);
            return block == null || placed.test(block) ? null : block.getType();
        });
    }

    static Set<Material> allowedMaterials(Map<Material, Double> sources) {
        Set<Material> allowed = new HashSet<>();
        sources.forEach((material, experience) -> {
            if (SHOVEL_TERRAIN.contains(material) && experience != null
                    && Double.isFinite(experience) && experience > 0) allowed.add(material);
        });
        return Set.copyOf(allowed);
    }

    /** null 表示不允许访问或人工方块；这些格只算一次扫描，不能作为通向另一侧的路径。 */
    static List<Position> scan(Position origin, TerraformSettings settings, Set<Material> allowed,
                               Function<Position, Material> materialAt) {
        if (settings.maxBlocks() < 1 || settings.maxScans() < 1 || settings.radius() < 1) {
            throw new IllegalArgumentException("terraform limits");
        }
        Material original = materialAt.apply(origin);
        if (original == null || !SHOVEL_TERRAIN.contains(original) || !allowed.contains(original)) return List.of();
        ArrayDeque<Position> queue = new ArrayDeque<>();
        Set<Position> visited = new HashSet<>();
        List<Position> result = new ArrayList<>();
        queue.add(origin);
        visited.add(origin);
        int scans = 0;
        while (!queue.isEmpty() && scans < settings.maxScans() && result.size() < settings.maxBlocks()) {
            Position current = queue.removeFirst();
            scans++;
            // 起始格已读取过，避免对它执行第二次 PDC / 世界查询。
            Material material = current.equals(origin) ? original : materialAt.apply(current);
            if (material != original) continue;
            result.add(current);
            for (int[] offset : OFFSETS) {
                if (visited.size() >= settings.maxScans()) break;
                long x = (long) current.x() + offset[0];
                long z = (long) current.z() + offset[1];
                if (Math.abs(x - origin.x()) > settings.radius() || Math.abs(z - origin.z()) > settings.radius()
                        || x < Integer.MIN_VALUE || x > Integer.MAX_VALUE
                        || z < Integer.MIN_VALUE || z > Integer.MAX_VALUE) continue;
                Position next = new Position((int) x, origin.y(), (int) z);
                if (visited.add(next)) queue.addLast(next);
            }
        }
        return List.copyOf(result);
    }

    static Block loadedBlock(World world, Position position) {
        return loadedBlock(world, position, ServerThreads::owns);
    }
    static Block loadedBlock(World world, Position position, Predicate<Location> ownership) {
        if (position.y() < world.getMinHeight() || position.y() >= world.getMaxHeight()
                || !ownership.test(new Location(world, position.x(), position.y(), position.z()))
                || !world.isChunkLoaded(position.x() >> 4, position.z() >> 4)) return null;
        return world.getBlockAt(position.x(), position.y(), position.z());
    }

    static Position position(Block block) {
        return new Position(block.getX(), block.getY(), block.getZ());
    }
}
