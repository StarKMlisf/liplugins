package net.liplugins.liskills.internal.menu;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

import java.util.Map;
import java.util.LinkedHashMap;
import java.util.UUID;

/** 不根据标题识别菜单，避免误伤其他插件或普通容器。 */
public final class SkillMenuHolder implements InventoryHolder {
    enum Screen { OVERVIEW, DETAIL, PASSIVES, STATS }
    private final UUID owner;
    private final Screen screen;
    private final String selectedSkill;
    private final int page;
    private final long revision;
    private final Map<Integer, MenuAction> actions;
    private final int closeSlot;
    private boolean transitioning;
    private Inventory inventory;

    SkillMenuHolder(UUID owner, Map<Integer, String> skills, int closeSlot) {
        this(owner, Screen.OVERVIEW, null, 0, -1, overviewActions(skills, closeSlot), closeSlot);
    }

    SkillMenuHolder(UUID owner, Screen screen, String selectedSkill, int page, long revision,
                    Map<Integer, MenuAction> actions, int closeSlot) {
        this.owner = owner;
        this.screen = screen;
        this.selectedSkill = selectedSkill;
        this.page = page;
        this.revision = revision;
        this.actions = Map.copyOf(actions);
        this.closeSlot = closeSlot;
    }

    static Map<Integer, MenuAction> overviewActions(Map<Integer, String> skills, int closeSlot) {
        Map<Integer, MenuAction> result = new LinkedHashMap<>();
        skills.forEach((slot, id) -> result.put(slot, new MenuAction(MenuAction.Type.DETAIL, id, 0)));
        if (closeSlot >= 0) result.put(closeSlot, new MenuAction(MenuAction.Type.CLOSE, null, 0));
        return result;
    }

    void inventory(Inventory inventory) { this.inventory = inventory; }
    UUID owner() { return owner; }
    String skill(int slot) { MenuAction action = actions.get(slot); return action == null ? null : action.skill(); }
    Map<Integer, MenuAction> actions() { return actions; }
    MenuAction action(int slot) { return actions.get(slot); }
    Screen screen() { return screen; }
    String selectedSkill() { return selectedSkill; }
    int page() { return page; }
    long revision() { return revision; }
    void transitioning(boolean value) { transitioning = value; }
    boolean transitioning() { return transitioning; }
    int closeSlot() { return closeSlot; }
    @Override public Inventory getInventory() { return inventory; }
}
