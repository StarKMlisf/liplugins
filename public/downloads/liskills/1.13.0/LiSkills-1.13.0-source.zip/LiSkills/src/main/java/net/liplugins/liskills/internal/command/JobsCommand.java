package net.liplugins.liskills.internal.command;

import net.liplugins.liskills.internal.manager.jobs.JobsManager;
import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.command.CommandSender;
import java.util.Map;

/** 职业指令只负责参数与反馈，持久化及收入均由职业服务处理。 */
final class JobsCommand implements Subcommand {
    private final SenderChecks checks;private final JobsManager jobs;private final TextService text;
    JobsCommand(SenderChecks checks,JobsManager jobs,TextService text){this.checks=checks;this.jobs=jobs;this.text=text;}
    public String name(){return "jobs";}public String permission(){return "liskills.use";}
    public void execute(CommandSender sender,String[] args){
        var player=checks.player(sender);if(player==null||checks.profile(sender,player)==null)return;
        if(args.length==0||(args.length==1&&args[0].equals("list"))){var selection=jobs.selection(player);text.send(sender,selection.valid()?"extended.job-list":"extended.job-invalid",Map.of("jobs",String.join(", ",selection.skills())));return;}
        if(args.length!=2||(!args[0].equals("join")&&!args[0].equals("leave"))){checks.usage(sender,"extended.usage-jobs");return;}
        text.send(sender,"extended.job-"+jobs.change(player,args[1],args[0].equals("join")),Map.of("skill",args[1]));
    }
}
