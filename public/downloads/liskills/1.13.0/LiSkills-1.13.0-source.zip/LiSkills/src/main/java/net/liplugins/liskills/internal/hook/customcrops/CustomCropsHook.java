package net.liplugins.liskills.internal.hook.customcrops;

import net.liplugins.liskills.lib.scheduler.ServerThreads;
import net.liplugins.liskills.lib.scheduler.TaskScheduler;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.manager.ProfileManager;
import net.liplugins.liskills.internal.manager.SkillManager;
import net.liplugins.liskills.internal.storage.PlayerProfile;
import net.liplugins.liskills.internal.util.TextService;
import net.liplugins.liskills.lib.customcrops.CustomCropsApi;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerHarvestBlockEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.WeakHashMap;

/** 将已成熟、有真实产出且状态确实改变的 CustomCrops 收获结算为一次农耕经验。 */
public final class CustomCropsHook implements Listener, AutoCloseable {
    private static final int MAX_CANDIDATES = 2048;
    private static final int MAX_RECENT_BLOCKS = 4096;
    private static final int MAX_SEEN_EVENTS = 32768;
    private final JavaPlugin plugin;
    private final ConfigManager config;
    private final SkillManager skills;
    private final TextService text;
    private final ProfileManager profiles;
    private final Map<Position, Candidate> candidates = new java.util.concurrent.ConcurrentHashMap<>();
    private final Set<Position> processing = java.util.concurrent.ConcurrentHashMap.newKeySet();
    private final CropHarvestClaims<BlockPosition> locationOwners = new CropHarvestClaims<>();
    private final Map<BlockPosition, Long> recentBlocks = new java.util.concurrent.ConcurrentHashMap<>();
    private final Set<Event> seen = Collections.synchronizedSet(Collections.newSetFromMap(new WeakHashMap<>()));
    private CustomCropsApi api;
    private Plugin crops;
    private final TaskScheduler scheduler;
    private volatile boolean failed, closed;
    private volatile long ticks;
    private volatile long guardSaturatedUntil = -1;
    private volatile long seenSaturatedUntil = -1;

    public CustomCropsHook(JavaPlugin plugin, ConfigManager config, SkillManager skills, TextService text, ProfileManager profiles) {
        this.plugin = plugin; this.config = config; this.skills = skills; this.text = text; this.profiles = profiles;
        this.scheduler = new TaskScheduler(plugin);
    }

    public void register() {
        if (api != null || failed) return;
        crops = Bukkit.getPluginManager().getPlugin("CustomCrops");
        if (crops == null || !crops.isEnabled()) return;
        try {
            api = new CustomCropsApi(crops);
            for (Class<? extends Event> type : api.primaryEvents()) register(type, this::primary);
            for (Class<? extends Event> type : api.outputEvents()) register(type, this::output);
            Bukkit.getPluginManager().registerEvents(this, plugin);
            scheduler.globalTimer(this::tick, 1L, 1L);
            text.send(Bukkit.getConsoleSender(), "custom-content.ready", Map.of("plugin", "CustomCrops", "version", crops.getDescription().getVersion()));
        } catch (ReflectiveOperationException | RuntimeException | LinkageError error) { fail(error); }
    }

    private void register(Class<? extends Event> type, EventConsumer consumer) {
        Bukkit.getPluginManager().registerEvent(type, this, EventPriority.MONITOR, (ignored, event) -> {
            if (event.isAsynchronous() || !available() || !firstSeen(event)) return;
            try { consumer.accept(event); }
            catch (ReflectiveOperationException | RuntimeException | LinkageError error) { fail(error); }
        }, plugin, false);
    }

    private void primary(Event event) throws ReflectiveOperationException {
        CustomCropsApi.Primary primary = api.primary(event);
        if (primary == null || !ServerThreads.owns(primary.player()) || !loaded(primary.location())) return;
        remember(primary.location());
        if (!active()) return;
        Position position = Position.of(primary.player(), primary.location());
        Candidate existing = candidates.get(position);
        // 右键动作中的 break 会再发 ACTION 事件，只附着于原操作，不建立第二份奖励。
        if (primary.reason().equals("ACTION")) {
            if (existing != null && existing.primary.interaction() && existing.primary.state() == primary.state()
                    && existing.sources.size() < 4) existing.sources.add(event);
            else if (existing != null) existing.attempt.invalidate();
            return;
        }
        if (!primary.reason().equals("BREAK") && !primary.interaction()) return;
        if (existing != null) { existing.attempt.competingPrimary(event); return; }
        if (locationOwners.conflict(BlockPosition.of(primary.location()))) {
            // 一个成长状态只能对应一次收获；两名玩家交错操作同一位置时，两份奖励都不猜测归属。
            return;
        }
        Player player = primary.player();
        PlayerProfile profile = profiles.get(player.getUniqueId());
        if (profile == null || !player.isOnline() || player.isDead() || !skills.eligible(player)
                || !player.hasPermission("liskills.skill.farming")
                || !CropHarvestAttempt.mature(primary.point(), primary.maximum())
                || primary.cropId() == null || primary.cropId().isBlank()
                || config.customCrops().xp(primary.cropId()) <= 0 || candidates.size() >= MAX_CANDIDATES) return;
        if (api.stateAt(primary.location()) != primary.state()) return;
        Candidate candidate = new Candidate(primary, profile, config.revision(), event, ticks);
        if (!locationOwners.reserve(BlockPosition.of(primary.location()), candidate.attempt)) return;
        candidates.put(position, candidate);
    }

    private void output(Event event) throws ReflectiveOperationException {
        if (!active()) return;
        CustomCropsApi.Output output = api.output(event);
        if (output == null || !ServerThreads.owns(output.player()) || !loaded(output.location())) return;
        Candidate candidate = candidates.get(Position.of(output.player(), output.location()));
        if (candidate == null || candidate.primary.player() != output.player() || !valid(candidate)) return;
        if (candidate.attempt.attach(event, output.context(), ticks)) candidate.outputs.add(event);
    }

    private void tick() {
        ticks++;
        recentBlocks.entrySet().removeIf(entry -> ticks > entry.getValue());
        if (seenSaturatedUntil >= 0 && ticks > seenSaturatedUntil) { seen.clear(); seenSaturatedUntil = -1; }
        if (!active()) { clearCandidates(); return; }
        // 单个全服队列；每份候选和每份产出都有固定上限，不为每个作物创建独立定时器。
        for (Map.Entry<Position, Candidate> entry : List.copyOf(candidates.entrySet())) {
            Candidate candidate = entry.getValue();
            if (candidate.attempt.expired(ticks)) { remove(entry.getKey(), candidate); continue; }
            if (!processing.add(entry.getKey())) continue;
            scheduler.entityNow(candidate.primary.player(), () -> {
                try { process(entry.getKey(), candidate); } finally { processing.remove(entry.getKey()); }
            }, () -> { processing.remove(entry.getKey()); remove(entry.getKey(), candidate); });
        }
    }

    private void process(Position position, Candidate candidate) {
            if (candidates.get(position) != candidate) return;
            if (!valid(candidate) || candidate.attempt.expired(ticks)) { remove(position, candidate); return; }
            try {
                boolean accepted = candidate.sources.stream().noneMatch(CustomCropsHook::cancelled);
                boolean output = false;
                for (Event event : candidate.outputs) {
                    if (!cancelled(event) && api.hasOutput(event)) { output = true; break; }
                }
                if (!candidate.attempt.commit(ticks, accepted, output, output && api.harvested(candidate.primary))) return;
                // 发奖前移除候选，升级/经验事件里的重入不能重复结算当前作物。
                remove(position, candidate);
                skills.award(candidate.primary.player(), "farming", config.customCrops().xp(candidate.primary.cropId()));
            } catch (ReflectiveOperationException | RuntimeException | LinkageError error) { fail(error); return; }
    }

    private boolean valid(Candidate candidate) {
        Player player = candidate.primary.player();
        return active() && ServerThreads.owns(player) && player.isOnline() && !player.isDead() && Bukkit.getPlayer(player.getUniqueId()) == player
                && profiles.get(player.getUniqueId()) == candidate.profile && candidate.revision == config.revision()
                && player.getWorld().equals(candidate.primary.location().getWorld()) && loaded(candidate.primary.location())
                && skills.eligible(player) && player.hasPermission("liskills.skill.farming");
    }

    /** enabled 只控制经验；关闭额外奖励仍必须避让第三方管理的模型和盆栽。 */
    public boolean owns(Block block) {
        if (closed) return false;
        if (crops == null || !crops.isEnabled()) return false;
        if (failed || api == null) return true;
        if (!ServerThreads.owns(block)) return true;
        if (ticks <= guardSaturatedUntil || recentBlocks.containsKey(BlockPosition.of(block.getLocation()))) return true;
        try {
            boolean owned = api.owns(block);
            if (owned) remember(block.getLocation());
            return owned;
        }
        catch (ReflectiveOperationException | RuntimeException | LinkageError error) { fail(error); return true; }
    }

    private void remember(Location location) {
        BlockPosition key = BlockPosition.of(location);
        if (recentBlocks.containsKey(key) || recentBlocks.size() < MAX_RECENT_BLOCKS) recentBlocks.put(key, ticks + 4);
        // 极端批量破坏超出缓存时短暂保守避让，不能为了有限内存放行自定义方块重复结算。
        else guardSaturatedUntil = ticks + 4;
    }

    private synchronized boolean firstSeen(Event event) {
        if (seen.contains(event) || ticks <= seenSaturatedUntil) return false;
        if (seen.size() >= MAX_SEEN_EVENTS) {
            // 弱引用集合仍设硬上限；候选清空后等待旧动作最长窗口过去，再接收新奖励事件。
            clearCandidates();
            seenSaturatedUntil = ticks + CropHarvestAttempt.LIFETIME_TICKS;
            guardSaturatedUntil = Math.max(guardSaturatedUntil, seenSaturatedUntil);
            return false;
        }
        return seen.add(event);
    }

    private void clearCandidates() { candidates.clear(); locationOwners.clear(); processing.clear(); }
    private void remove(Position position, Candidate candidate) {
        candidates.remove(position, candidate);
        locationOwners.release(new BlockPosition(position.world, position.x, position.y, position.z), candidate.attempt);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void observeBreak(BlockBreakEvent event) { if (available()) owns(event.getBlock()); }
    @EventHandler(priority = EventPriority.LOWEST)
    public void observeHarvest(PlayerHarvestBlockEvent event) { if (available()) owns(event.getHarvestedBlock()); }

    private boolean available() { return !closed && !failed && api != null && crops != null && crops.isEnabled(); }
    private boolean active() { return available() && config.customCrops().enabled(); }
    public String status() {
        String key = failed ? "failed-state" : crops == null || !crops.isEnabled() || api == null ? "absent"
                : config.customCrops().enabled() ? "connected" : "disabled";
        return text.text("custom-content.status", Map.of("plugin", "CustomCrops", "state", text.plain(text.text("custom-content." + key))));
    }

    private synchronized void fail(Throwable error) {
        if (failed) return;
        failed = true;
        clearCandidates();
        HandlerList.unregisterAll(this);
        scheduler.cancelAll();
        text.send(Bukkit.getConsoleSender(), "custom-content.failed", Map.of("plugin", "CustomCrops", "error", error.getClass().getSimpleName()));
    }

    private static boolean loaded(Location location) {
        return location.getWorld() != null && ServerThreads.owns(location)
                && location.getWorld().isChunkLoaded(location.getBlockX() >> 4, location.getBlockZ() >> 4);
    }
    private static boolean cancelled(Event event) { return event instanceof Cancellable cancellable && cancellable.isCancelled(); }
    @EventHandler public void quit(PlayerQuitEvent event) { remove(event.getPlayer()); }
    @EventHandler public void world(PlayerChangedWorldEvent event) { remove(event.getPlayer()); }
    private void remove(Player player) {
        for (Map.Entry<Position, Candidate> entry : List.copyOf(candidates.entrySet())) {
            if (entry.getKey().player.equals(player.getUniqueId())) remove(entry.getKey(), entry.getValue());
        }
    }
    @Override public void close() {
        closed = true;
        HandlerList.unregisterAll(this);
        scheduler.cancelAll();
        clearCandidates(); recentBlocks.clear(); seen.clear();
    }

    private record Position(UUID player, UUID world, int x, int y, int z) {
        static Position of(Player player, Location location) {
            return new Position(player.getUniqueId(), location.getWorld().getUID(), location.getBlockX(), location.getBlockY(), location.getBlockZ());
        }
    }
    private record BlockPosition(UUID world, int x, int y, int z) {
        static BlockPosition of(Location location) {
            return new BlockPosition(location.getWorld().getUID(), location.getBlockX(), location.getBlockY(), location.getBlockZ());
        }
    }
    private static final class Candidate {
        final CustomCropsApi.Primary primary;
        final PlayerProfile profile;
        final long revision;
        final CropHarvestAttempt attempt;
        final List<Event> sources = new java.util.concurrent.CopyOnWriteArrayList<>();
        final List<Event> outputs = new java.util.concurrent.CopyOnWriteArrayList<>();
        Candidate(CustomCropsApi.Primary primary, PlayerProfile profile, long revision, Event event, long tick) {
            this.primary = primary; this.profile = profile; this.revision = revision;
            this.attempt = new CropHarvestAttempt(event, tick); sources.add(event);
        }
    }
    @FunctionalInterface private interface EventConsumer { void accept(Event event) throws ReflectiveOperationException; }
}
