package net.liplugins.liskills.internal.storage;

import java.util.List;
import java.util.UUID;

/** 只由ProfileManager的同一IO队列访问；异常必须传给调用者，不能返回空档代替损坏数据。 */
public interface ProfileRepository extends AutoCloseable {
    ProfileSnapshot load(UUID uuid,String name)throws Exception;
    List<ProfileSnapshot> loadAll()throws Exception;
    void save(ProfileSnapshot snapshot)throws Exception;
    /** 离线迁移专用：只创建缺失档案；相同快照返回false，不同快照必须拒绝。 */
    default boolean insertIfAbsent(ProfileSnapshot snapshot)throws Exception{throw new UnsupportedOperationException("insert-if-absent");}
    @Override default void close()throws Exception { }
}
