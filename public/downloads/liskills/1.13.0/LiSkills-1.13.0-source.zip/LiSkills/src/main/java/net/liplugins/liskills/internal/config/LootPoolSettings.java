package net.liplugins.liskills.internal.config;

import java.util.List;

/** 顺序越高越先判定；一项收获最多选中一个宝藏池。 */
public record LootPoolSettings(String id, boolean enabled, double baseChance, double chancePerLuck,
                               int priority, boolean requireOpenWater, List<LootEntrySettings> entries) {
    public LootPoolSettings { entries = List.copyOf(entries); }
}
