package net.liplugins.liskills.internal.hook.customcrops;

import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Set;

/** 单次收获的时序和身份约束；不依赖服务器、插件 API 或可变世界。 */
final class CropHarvestAttempt {
    static final int LIFETIME_TICKS = 8;
    static final int MAX_OUTPUTS = 16;
    private final Object primary;
    private final long created;
    private final Set<Object> outputs = Collections.newSetFromMap(new IdentityHashMap<>());
    private Object context;
    private long latestOutput;
    private boolean invalid;
    private boolean committed;

    CropHarvestAttempt(Object primary, long created) { this.primary = primary; this.created = created; }

    synchronized void competingPrimary(Object event) { if (primary != event) invalid = true; }
    synchronized void invalidate() { invalid = true; }
    boolean expired(long tick) { return tick - created > LIFETIME_TICKS; }
    synchronized boolean attach(Object output, Object context, long tick) {
        if (invalid || committed || expired(tick) || outputs.contains(output)) return false;
        // 同一玩家同一位置也可能存在不同动作链，不能把前一次延迟产出归给后一次点击。
        if (context == null || (this.context != null && this.context != context) || outputs.size() >= MAX_OUTPUTS) {
            invalid = true;
            return false;
        }
        this.context = context;
        latestOutput = tick;
        return outputs.add(output);
    }

    synchronized boolean commit(long tick, boolean acceptedPrimary, boolean acceptedOutput, boolean changedState) {
        if (invalid || committed || expired(tick) || outputs.isEmpty() || tick <= latestOutput
                || !acceptedPrimary || !acceptedOutput || !changedState) return false;
        committed = true;
        return true;
    }

    static boolean mature(int point, int maximum) { return maximum > 0 && point >= maximum; }
}
