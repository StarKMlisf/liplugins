package net.liplugins.liskills.internal.manager.source;

import net.liplugins.liskills.internal.config.NaturalSourcesSettings;
import net.liplugins.liskills.internal.listener.PlacedBlockTracker;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.Ageable;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.type.SeaPickle;
import java.util.*;
import java.util.function.Predicate;

/** 记录真实玩家破坏前的有限植物列及状态；只描述来源，不改变世界或自行发经验。 */
public final class BlockHarvestSources {
    private BlockHarvestSources() { }
    /** 幽匿无精准采集时本来就不掉方块物品；是否确实为空仍由破坏前Bukkit战利品表核验。 */
    public static boolean isSculkSource(Material material) {
        return switch(material) {case SCULK,SCULK_CATALYST,SCULK_SHRIEKER,SCULK_VEIN,SCULK_SENSOR->true;default->false;};
    }
    public static List<Part> capture(Block origin,PlacedBlockTracker placed,NaturalSourcesSettings settings,Predicate<Block> custom) {
        List<Part> parts=new ArrayList<>(); add(parts,origin,placed);
        Material type=origin.getType();
        if(!settings.verticalPlantsEnabled() || !vertical(type))return List.copyOf(parts);
        int maximum=type==Material.SUGAR_CANE?Math.min(3,settings.maximumPlantBlocks()):settings.maximumPlantBlocks();
        Block next=origin;
        for(int count=1;count<maximum && next.getY()+1<origin.getWorld().getMaxHeight();count++) {
            next=next.getRelative(BlockFace.UP);
            if(!sameFamily(type,next.getType()) || custom.test(next))break;
            add(parts,next,placed);
        }
        return List.copyOf(parts);
    }
    private static void add(List<Part> parts,Block block,PlacedBlockTracker placed) {
        parts.add(new Part(block,block.getType(),block.getBlockData().clone(),placed.contains(block),placed.stamp(block)));
    }
    static boolean vertical(Material material) { return material==Material.SUGAR_CANE || material==Material.BAMBOO || material==Material.CACTUS || material==Material.KELP_PLANT || material==Material.KELP; }
    static boolean sameFamily(Material first,Material second) {
        return first==second || (first==Material.KELP || first==Material.KELP_PLANT) && (second==Material.KELP || second==Material.KELP_PLANT);
    }
    public static double multiplier(Material material,BlockData data,NaturalSourcesSettings settings) {
        if(settings.berryStateMultiplier() && material==Material.SWEET_BERRY_BUSH && data instanceof Ageable age)return Math.max(0,Math.min(2,age.getAge()-1));
        if(settings.pickleStateMultiplier() && material==Material.SEA_PICKLE && data instanceof SeaPickle pickle)return Math.max(1,Math.min(4,pickle.getPickles()));
        return 1;
    }
    public static boolean mineralOre(Material material) {
        return material==Material.COAL_ORE || material==Material.DEEPSLATE_COAL_ORE || material==Material.IRON_ORE || material==Material.DEEPSLATE_IRON_ORE
                || material==Material.COPPER_ORE || material==Material.DEEPSLATE_COPPER_ORE || material==Material.GOLD_ORE || material==Material.DEEPSLATE_GOLD_ORE
                || material==Material.REDSTONE_ORE || material==Material.DEEPSLATE_REDSTONE_ORE || material==Material.LAPIS_ORE || material==Material.DEEPSLATE_LAPIS_ORE
                || material==Material.DIAMOND_ORE || material==Material.DEEPSLATE_DIAMOND_ORE || material==Material.EMERALD_ORE || material==Material.DEEPSLATE_EMERALD_ORE
                || material==Material.NETHER_QUARTZ_ORE || material==Material.NETHER_GOLD_ORE;
    }
    public record Part(Block block,Material material,BlockData data,boolean placed,long stamp) { }
}
