package net.liplugins.liskills.internal.manager.passive.combat;

import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.entity.LivingEntity;
import org.bukkit.inventory.EquipmentSlotGroup;
import net.liplugins.liskills.lib.scheduler.ServerThreads;

/** 每种临时效果只使用自己的命名键，不覆盖基础速度或其他插件的modifier。 */
final class TemporaryMovementModifiers {
    private TemporaryMovementModifiers(){ }
    static void apply(LivingEntity entity,NamespacedKey key,double ratio) {
        if(!ServerThreads.owns(entity))return;
        AttributeInstance attribute=entity.getAttribute(Attribute.MOVEMENT_SPEED);
        if(attribute==null) return;
        AttributeModifier existing=attribute.getModifiers().stream().filter(modifier->modifier.getKey().equals(key)).findFirst().orElse(null);
        if(existing!=null && existing.getAmount()==ratio) return;
        if(existing!=null) attribute.removeModifier(existing);
        net.liplugins.liskills.lib.scheduler.AttributeModifiers.add(attribute,new AttributeModifier(key,ratio,AttributeModifier.Operation.ADD_SCALAR,EquipmentSlotGroup.ANY));
    }
    static void remove(LivingEntity entity,NamespacedKey key) {
        if(!ServerThreads.owns(entity))return;
        AttributeInstance attribute=entity.getAttribute(Attribute.MOVEMENT_SPEED);
        if(attribute==null) return;
        for(AttributeModifier modifier:attribute.getModifiers()) if(modifier.getKey().equals(key)) attribute.removeModifier(modifier);
    }
}
