package net.liplugins.liskills.internal.menu;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.config.SkillDefinition;
import net.liplugins.liskills.internal.manager.AbilityManager;
import net.liplugins.liskills.internal.manager.ProfileManager;
import net.liplugins.liskills.internal.manager.SkillManager;
import net.liplugins.liskills.internal.storage.PlayerProfile;
import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.plugin.java.JavaPlugin;
import net.liplugins.liskills.lib.scheduler.ServerThreads;
import net.liplugins.liskills.lib.scheduler.TaskScheduler;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/** 菜单导航与安全事件入口；绘制、声音、分页来源各由独立组件负责。 */
public final class SkillMenu implements Listener {
    private final JavaPlugin plugin;
    private final ConfigManager config;
    private final ProfileManager profiles;
    private final AbilityManager abilities;
    private final TextService text;
    private final SkillOverviewPage overview;
    private final SkillDetailPage details;
    private final PassiveAbilityPage passives;
    private final StatOverviewPage stats;
    private final GuiSoundService sounds;
    private final Set<UUID> viewers = java.util.concurrent.ConcurrentHashMap.newKeySet();
    private final Set<UUID> refreshing = java.util.concurrent.ConcurrentHashMap.newKeySet();
    private final TaskScheduler tasks;

    public SkillMenu(JavaPlugin plugin, ConfigManager config, ProfileManager profiles, SkillManager skills,
                     AbilityManager abilities, TextService text) {
        this.plugin = plugin; this.config = config; this.profiles = profiles; this.abilities = abilities; this.text = text;
        tasks = new TaskScheduler(plugin);
        SkillPresentation presentation = new SkillPresentation(config, text, abilities);
        overview = new SkillOverviewPage(config, text, presentation);
        details = new SkillDetailPage(config, text, presentation);
        passives=new PassiveAbilityPage(config,text,presentation);
        stats=new StatOverviewPage(config,text);
        sounds = new GuiSoundService(config, text);
        // 仅刷新正在查看的菜单，冷却和魔力每秒变化，不遍历全服玩家或重开窗口。
        tasks.globalTimer(this::refreshViewers, 20L, 20L);
    }

    public void open(Player player) { openOverview(player, GuiSoundService.Cue.OPEN); }
    public void openPassives(Player player,String id) {
        openPassives(player,id,0,GuiSoundService.Cue.OPEN);
    }
    private void openPassives(Player player,String id,int page,GuiSoundService.Cue cue) {
        // 一次绘制期间固定配置快照，禁止重载把新槽位写入旧尺寸菜单。
        synchronized(config) {
        PlayerProfile profile=ready(player);
        SkillDefinition skill=config.skill(id);
        if(profile!=null && skill!=null && skill.enabled())show(player,passives.create(profile,skill,page),cue);
        }
    }
    public void openStats(Player player) {
        // 一次绘制期间固定配置快照，禁止重载把新槽位写入旧尺寸菜单。
        synchronized(config) {
        PlayerProfile profile=ready(player);
        if(profile!=null)show(player,stats.create(profile),GuiSoundService.Cue.OPEN);
        }
    }

    private PlayerProfile ready(Player player) {
        if (!ServerThreads.owns(player)) return null;
        if (!player.hasPermission("liskills.use")) { text.send(player, "command.no-permission"); return null; }
        PlayerProfile profile = profiles.get(player.getUniqueId());
        if (profile == null) text.send(player, "command.profile-loading");
        return profile;
    }

    private void openOverview(Player player, GuiSoundService.Cue cue) {
        // 一次绘制期间固定配置快照，禁止重载把新槽位写入旧尺寸菜单。
        synchronized(config) {
        PlayerProfile profile = ready(player);
        if (profile != null) show(player, overview.create(profile), cue);
        }
    }

    private void openDetails(Player player, String id, int page, GuiSoundService.Cue cue) {
        // 一次绘制期间固定配置快照，禁止重载把新槽位写入旧尺寸菜单。
        synchronized(config) {
        PlayerProfile profile = ready(player);
        if (profile == null) return;
        SkillDefinition skill = config.skill(id);
        if (skill == null || !skill.enabled()) { openOverview(player, cue); return; }
        show(player, details.create(profile, skill, page), cue);
        }
    }

    private void show(Player player, Inventory inventory, GuiSoundService.Cue cue) {
        SkillMenuHolder previous = player.getOpenInventory().getTopInventory().getHolder() instanceof SkillMenuHolder holder ? holder : null;
        if (previous != null) previous.transitioning(true);
        player.openInventory(inventory);
        if (player.getOpenInventory().getTopInventory() != inventory) {
            if (previous != null) previous.transitioning(false);
            return; // 其他插件阻止打开时不记录查看者，也不播放成功打开的音效。
        }
        viewers.add(player.getUniqueId());
        sounds.play(player, cue);
    }

    private void refreshViewers() {
        for (UUID uuid : Set.copyOf(viewers)) {
            Player player = Bukkit.getPlayer(uuid);
            if (player == null) { viewers.remove(uuid); continue; }
            if (!refreshing.add(uuid)) continue;
            tasks.entityNow(player, () -> {
                try { refresh(player); } finally { refreshing.remove(uuid); }
            }, () -> refreshing.remove(uuid));
        }
    }

    private void refresh(Player player) {
        // 一次绘制期间固定配置快照，禁止重载把新槽位写入旧尺寸菜单。
        synchronized(config) {
            UUID uuid=player.getUniqueId();
            if (!(player.getOpenInventory().getTopInventory().getHolder() instanceof SkillMenuHolder holder)
                    || !uuid.equals(holder.owner())) { viewers.remove(uuid); return; }
            PlayerProfile profile = profiles.get(uuid);
            if (profile == null || !player.hasPermission("liskills.use")) { player.closeInventory(); return; }
            if (holder.revision() != config.revision()) {
                reopen(player, holder, GuiSoundService.Cue.SILENT);
            } else if (holder.screen() == SkillMenuHolder.Screen.OVERVIEW) {
                overview.refresh(holder.getInventory(), holder, profile);
            } else if(holder.screen()==SkillMenuHolder.Screen.DETAIL)details.refresh(holder.getInventory(), holder, profile);
            else if(holder.screen()==SkillMenuHolder.Screen.PASSIVES)passives.refresh(holder.getInventory(),holder,profile);
            else stats.refresh(holder.getInventory(),holder,profile);
        }
    }

    private void reopen(Player player, SkillMenuHolder holder, GuiSoundService.Cue cue) {
        // 一次绘制期间固定配置快照，禁止重载把新槽位写入旧尺寸菜单。
        synchronized(config) {
        if (holder.screen() == SkillMenuHolder.Screen.OVERVIEW) openOverview(player, cue);
        else if(holder.screen()==SkillMenuHolder.Screen.DETAIL)openDetails(player, holder.selectedSkill(), holder.page(), cue);
        else if(holder.screen()==SkillMenuHolder.Screen.PASSIVES) {
            var profile=ready(player);var skill=config.skill(holder.selectedSkill());
            if(profile!=null && skill!=null && skill.enabled())show(player,passives.create(profile,skill,holder.page()),cue);else openOverview(player,cue);
        } else {var profile=ready(player);if(profile!=null)show(player,stats.create(profile),cue);}
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
    public void click(InventoryClickEvent event) {
        if (!(event.getView().getTopInventory().getHolder() instanceof SkillMenuHolder holder)) return;
        // 连玩家背包区域也取消，覆盖 shift、数字键、双击收集、拖入和丢弃路径。
        event.setCancelled(true);
        if (!(event.getWhoClicked() instanceof Player player) || !holder.owner().equals(player.getUniqueId())) return;
        if (event.getRawSlot() < 0 || event.getRawSlot() >= event.getView().getTopInventory().getSize()) return;
        if (event.isShiftClick() || (!event.isLeftClick() && !event.isRightClick())) return;
        MenuAction action = holder.action(event.getRawSlot());
        if (action == null) return;
        boolean right = event.isRightClick();
        // 关闭或替换窗口要延后到下一 tick，并再次验证玩家仍处于同一个窗口。
        tasks.entity(player, () -> {
            synchronized(config) {
            if (!player.isOnline() || player.getOpenInventory().getTopInventory().getHolder() != holder) return;
            if (action.type() == MenuAction.Type.CLOSE) { player.closeInventory(); return; }
            if (ready(player) == null) return;
            if (action.type() == MenuAction.Type.CAST || action.type() == MenuAction.Type.DETAIL && right) {
                boolean success = abilities.activate(player, action.skill());
                reopen(player, holder, success ? GuiSoundService.Cue.SUCCESS : GuiSoundService.Cue.DENY);
                return;
            }
            switch (action.type()) {
                case DETAIL -> openDetails(player, action.skill(), 0, GuiSoundService.Cue.CLICK);
                case PASSIVES -> openPassives(player,action.skill(),action.page(),GuiSoundService.Cue.PAGE);
                case STATS -> openStats(player);
                case BACK -> openOverview(player, GuiSoundService.Cue.CLICK);
                case PREVIOUS, NEXT -> openDetails(player, action.skill(), action.page(), GuiSoundService.Cue.PAGE);
                case REFRESH -> reopen(player, holder, GuiSoundService.Cue.CLICK);
                default -> { }
            }
            }
        });
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
    public void drag(InventoryDragEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof SkillMenuHolder) event.setCancelled(true);
    }

    @EventHandler
    public void close(InventoryCloseEvent event) {
        if (!(event.getInventory().getHolder() instanceof SkillMenuHolder holder) || holder.transitioning()) return;
        viewers.remove(event.getPlayer().getUniqueId());
        if (event.getPlayer() instanceof Player player && player.isOnline()) sounds.play(player, GuiSoundService.Cue.CLOSE);
    }
}
