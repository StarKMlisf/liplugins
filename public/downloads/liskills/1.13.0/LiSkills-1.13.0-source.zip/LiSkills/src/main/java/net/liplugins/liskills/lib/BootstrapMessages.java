package net.liplugins.liskills.lib;

import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Map;

/** 在文本库加载前读取启动消息；仅使用 Bukkit 自带的 YAML 能力。 */
public final class BootstrapMessages {
    private final YamlConfiguration defaults;
    private final YamlConfiguration custom;

    public BootstrapMessages(JavaPlugin plugin) {
        defaults = new YamlConfiguration();
        try (InputStream resource = plugin.getResource("messages.yml")) {
            if (resource != null) {
                defaults.load(new InputStreamReader(resource, StandardCharsets.UTF_8));
            }
        } catch (IOException | InvalidConfigurationException ignored) {
            // 资源打包错误仍保留消息键作为诊断，不让启动消息读取导致二次异常。
        }
        File file = new File(plugin.getDataFolder(), "messages.yml");
        custom = new YamlConfiguration();
        if (file.isFile()) {
            try {
                custom.load(file);
            } catch (IOException | InvalidConfigurationException ignored) {
                // 用户 YAML 的具体错误由业务配置校验报告，启动器先使用内置默认消息。
            }
        }
    }

    public String text(String key) {
        return text(key, Map.of());
    }

    public String text(String key, Map<String, ?> values) {
        String path = "boot." + key;
        String message = custom.getString(path, defaults.getString(path, path));
        for (Map.Entry<String, ?> value : values.entrySet()) {
            message = message.replace("{" + value.getKey() + "}", String.valueOf(value.getValue()));
        }
        return message;
    }
}
