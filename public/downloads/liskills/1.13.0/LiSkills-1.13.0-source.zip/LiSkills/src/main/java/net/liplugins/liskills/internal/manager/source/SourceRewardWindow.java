package net.liplugins.liskills.internal.manager.source;

import java.util.HashMap;
import java.util.Map;

/** 一位玩家一种技能的有限奖励窗口；只有真实经验提交成功才消费额度。 */
final class SourceRewardWindow {
    private long start=-1;
    private volatile long lastActivity;
    private double spent;
    private final Map<String,Long> next=new HashMap<>();
    double available(String source,double requested,double maximum,long now) {
        if(start<0 || now<start || now-start>=60_000){start=now;spent=0;}
        lastActivity=now;
        if(!Double.isFinite(requested) || requested<=0 || !Double.isFinite(maximum) || maximum<=0 || now<next.getOrDefault(source,0L))return 0;
        return Math.min(requested,Math.max(0,maximum-spent));
    }
    void commit(String source,double amount,int cooldownTicks,long now) {
        spent+=amount;next.put(source,now+cooldownTicks*50L);lastActivity=now;
    }
    long lastActivity(){return lastActivity;}
}
