package net.liplugins.liskills.internal.listener;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Predicate;

/** 短期位置世代账本；容量耗尽时拒绝证明来源，绝不把未知状态当作天然方块。 */
final class BlockOriginLedger<K> {
    private final int maximum;
    private final Map<K, Entry> entries = new HashMap<>();
    private long tick, sequence, uncertainUntil = -1;
    BlockOriginLedger(int maximum) { if (maximum < 1) throw new IllegalArgumentException("maximum"); this.maximum = maximum; }
    synchronized long capture(K key) {
        Entry entry = entries.get(key);
        if (entry != null) { entries.put(key, new Entry(entry.version, tick + 4, entry.claims)); return uncertainUntil >= tick ? -1 : entry.version; }
        return change(key);
    }
    synchronized long change(K key) {
        if (!entries.containsKey(key) && entries.size() >= maximum) { uncertainUntil = tick + 4; return -1; }
        long version = ++sequence; entries.put(key, new Entry(version, tick + 4, 0));
        return uncertainUntil >= tick ? -1 : version;
    }
    synchronized boolean unchanged(K key, long version) {
        Entry entry = entries.get(key);
        return version >= 0 && uncertainUntil < tick && entry != null && entry.version == version;
    }
    synchronized void invalidate(Predicate<K> predicate) {
        entries.replaceAll((key, entry) -> predicate.test(key) ? new Entry(++sequence, tick + 4, 0) : entry);
    }
    synchronized boolean claim(K key, long version, int channel) {
        if (!unchanged(key, version)) return false;
        Entry entry = entries.get(key);
        if ((entry.claims & channel) != 0) return false;
        entries.put(key, new Entry(entry.version, entry.expires, entry.claims | channel)); return true;
    }
    synchronized void advance() { tick++; entries.values().removeIf(entry -> entry.expires < tick); }
    private record Entry(long version, long expires, int claims) { }
}
