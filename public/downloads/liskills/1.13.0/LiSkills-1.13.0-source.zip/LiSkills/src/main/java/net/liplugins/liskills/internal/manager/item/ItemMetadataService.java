package net.liplugins.liskills.internal.manager.item;

import net.liplugins.liskills.internal.config.ItemRule;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** 命名物品管理API：返回副本，只修改liskills标签，不改显示名、Lore、附魔或外部PDC。 */
public final class ItemMetadataService {
    public static final NamespacedKey IDENTITY_KEY = new NamespacedKey("liskills", "item_id");
    public static final NamespacedKey RULES_KEY = new NamespacedKey("liskills", "item_rules");
    private final ItemRuleCodec codec = new ItemRuleCodec();
    private final Map<String, ReadResult> cache = new LinkedHashMap<>();

    public record ReadResult(boolean present, boolean valid, List<ItemRule> rules) {
        public ReadResult { rules = List.copyOf(rules); }
    }
    public ReadResult read(ItemStack item) {
        if (item == null || item.getAmount() <= 0 || !item.hasItemMeta()) return new ReadResult(false, true, List.of());
        var data = item.getItemMeta().getPersistentDataContainer();
        if (!data.has(RULES_KEY)) return new ReadResult(false, true, List.of());
        if (!data.has(RULES_KEY, PersistentDataType.STRING)) return new ReadResult(true, false, List.of());
        String encoded = data.get(RULES_KEY, PersistentDataType.STRING);
        synchronized (cache) {
            ReadResult previous = cache.get(encoded);
            if (previous != null) return previous;
            ReadResult result;
            try { result = new ReadResult(true, true, codec.decode(encoded)); }
            catch (IllegalArgumentException error) { result = new ReadResult(true, false, List.of()); }
            // 超长外来标签不放缓存，避免占用与输入长度相乘的内存。
            if (encoded != null && encoded.length() <= ItemRuleCodec.MAXIMUM_LENGTH) {
                if (cache.size() >= 256) cache.remove(cache.keySet().iterator().next());
                cache.put(encoded, result);
            }
            return result;
        }
    }
    public String identity(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return "";
        var data = item.getItemMeta().getPersistentDataContainer();
        return data.has(IDENTITY_KEY, PersistentDataType.STRING) ? data.get(IDENTITY_KEY, PersistentDataType.STRING) : "";
    }
    public ItemStack identify(ItemStack original, String identity) {
        if (identity == null || !identity.matches("[a-z][a-z0-9_/-]{0,127}")) throw new IllegalArgumentException("item-identity");
        ItemStack copy = copy(original); ItemMeta meta = copy.getItemMeta();
        meta.getPersistentDataContainer().set(IDENTITY_KEY, PersistentDataType.STRING, identity);
        copy.setItemMeta(meta); return copy;
    }
    public ItemStack putRule(ItemStack original, ItemRule rule) {
        List<ItemRule> rules = mutableRules(original);
        rules.removeIf(existing -> existing.id().equals(rule.id())); rules.add(rule);
        return write(original, rules);
    }
    public ItemStack removeRule(ItemStack original, String name) {
        List<ItemRule> rules = mutableRules(original); rules.removeIf(rule -> rule.id().equals(name));
        return write(original, rules);
    }
    /** 显式修复/清除只删除自身规则键；不会清掉物品标识和第三方数据。 */
    public ItemStack clearRules(ItemStack original) {
        ItemStack copy = copy(original); ItemMeta meta = copy.getItemMeta();
        meta.getPersistentDataContainer().remove(RULES_KEY); copy.setItemMeta(meta); return copy;
    }
    public ItemStack appendRules(ItemStack original, List<ItemRule> additions) {
        List<ItemRule> rules = mutableRules(original);
        if (additions.stream().anyMatch(addition -> rules.stream().anyMatch(rule -> rule.id().equals(addition.id()))))
            throw new IllegalArgumentException("item-rule-conflict");
        rules.addAll(additions); return write(original, rules);
    }
    private List<ItemRule> mutableRules(ItemStack original) {
        ReadResult read = read(original);
        if (!read.valid()) throw new IllegalArgumentException("item-data-invalid");
        return new ArrayList<>(read.rules());
    }
    private ItemStack write(ItemStack original, List<ItemRule> rules) {
        if (rules.isEmpty()) return clearRules(original);
        String encoded = codec.encode(rules);
        ItemStack copy = copy(original); ItemMeta meta = copy.getItemMeta();
        meta.getPersistentDataContainer().set(RULES_KEY, PersistentDataType.STRING, encoded);
        copy.setItemMeta(meta); return copy;
    }
    private static ItemStack copy(ItemStack original) {
        if (original == null || original.getAmount() <= 0 || original.getType().isAir() || original.getItemMeta() == null)
            throw new IllegalArgumentException("item-required");
        return original.clone();
    }
}
