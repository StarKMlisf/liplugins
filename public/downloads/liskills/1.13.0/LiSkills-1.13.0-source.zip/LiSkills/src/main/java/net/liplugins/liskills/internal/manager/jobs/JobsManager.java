package net.liplugins.liskills.internal.manager.jobs;

import net.liplugins.liskills.api.SkillExperienceGainEvent;
import net.liplugins.liskills.api.SkillExperiencePreGainEvent;
import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.config.JobsSettings;
import net.liplugins.liskills.internal.hook.VaultEconomyBridge;
import net.liplugins.liskills.internal.manager.ledger.*;
import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import java.io.IOException;
import java.util.*;
import java.util.function.Supplier;

/** 仅消费已提交的自然经验；选职限制在预事件，收益在成功事件，并受每日持久限额约束。 */
public final class JobsManager implements Listener {
    private final Supplier<JobsSettings> settings;private final ConfigManager config;
    private final VaultEconomyBridge economy;private final TextService text;private final JobSelectionStore selections=new JobSelectionStore();
    private final PlayerRewardLedger ledger;private final LedgerFailureReporter failures;
    private final Map<UUID,Long> warned=new java.util.concurrent.ConcurrentHashMap<>();
    public JobsManager(Supplier<JobsSettings> settings,ConfigManager config,VaultEconomyBridge economy,TextService text,
                       PlayerRewardLedger ledger,LedgerFailureReporter failures){
        this.settings=settings;this.config=config;this.economy=economy;this.text=text;this.ledger=ledger;this.failures=failures;
    }
    public JobSelectionStore.Selection selection(Player player){return selections.read(player);}
    public String change(Player player,String skill,boolean join){
        var rules=settings.get();if(!rules.enabled())return "disabled";
        var selected=selection(player);if(!selected.valid())return "invalid";
        if(System.currentTimeMillis()<selected.nextChange())return "cooldown";
        var definition=config.skill(skill);if(join&&(definition==null||!definition.enabled()||!player.hasPermission("liskills.skill."+skill)))return "unknown";
        Set<String> next=new LinkedHashSet<>(selected.skills());
        if(join){if(next.contains(skill))return "already";if(next.size()>=rules.maximumJobs())return "full";next.add(skill);}
        else if(!next.remove(skill))return "missing";
        selections.save(player,next,System.currentTimeMillis()+rules.changeCooldownSeconds()*1000L);return "saved";
    }
    @EventHandler(priority=EventPriority.LOWEST,ignoreCancelled=true)
    public void beforeExperience(SkillExperiencePreGainEvent event){
        var rules=settings.get();if(rules.enabled()&&rules.selectionRequired()&&rules.disableUnselectedXp()){
            var selection=selection(event.getPlayer());if(!selection.valid()||!selection.skills().contains(event.getSkill()))event.setCancelled(true);
        }
    }
    @EventHandler(priority=EventPriority.MONITOR)
    public void afterExperience(SkillExperienceGainEvent event){
        var rules=settings.get();if(!rules.enabled()||rules.dailyLimit()<=0)return;
        Player player=event.getPlayer();var selection=selection(player);
        if(!selection.valid()||(rules.selectionRequired()&&!selection.skills().contains(event.getSkill())))return;
        double amount=event.getAmount()*rules.moneyPerXp().getOrDefault(event.getSkill(),0.0);
        if(!Double.isFinite(amount)||amount<=0)return;
        long day=Math.floorDiv(System.currentTimeMillis(),86_400_000L);
        try{
            var reserved=ledger.reserveIncome(player.getUniqueId(),day,amount,rules.dailyLimit(),()->LegacyLedgerData.read(player,day));
            // PDC只是查看镜像；Bukkit saveData不返回保存结果，不能拿它证明支付限额已持久化。
            LegacyLedgerData.mirrorIncome(player,reserved.state());amount=reserved.amount();
        }catch(IOException error){failures.failed(player,error);return;}
        if(amount<=0)return;
        // 独立账本已force并原子替换成功；经济端失败仍消费此次额度，绝不自动重试不确定的付款。
        if(!economy.deposit(player,amount)&&System.currentTimeMillis()-warned.getOrDefault(player.getUniqueId(),0L)>=60_000){
            warned.put(player.getUniqueId(),System.currentTimeMillis());text.send(player,"extended.job-income-failed");
        }
    }
    @EventHandler public void quit(org.bukkit.event.player.PlayerQuitEvent event){warned.remove(event.getPlayer().getUniqueId());}
}
