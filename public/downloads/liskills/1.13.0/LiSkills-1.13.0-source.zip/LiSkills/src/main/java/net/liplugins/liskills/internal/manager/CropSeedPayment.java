package net.liplugins.liskills.internal.manager;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

/** 仅从普通储物栏扣除一枚原版种子；不触碰盔甲、副手或带自定义资料的物品。 */
final class CropSeedPayment {
    private CropSeedPayment() { }

    static boolean available(PlayerInventory inventory, Material seed) {
        return slot(inventory.getStorageContents(), seed) >= 0;
    }

    static boolean consume(PlayerInventory inventory, Material seed) {
        // 事件可能移动或消耗种子，因此提交时重新选择，不写回事件前的整份库存快照。
        ItemStack[] contents = inventory.getStorageContents();
        int slot = slot(contents, seed);
        if (slot < 0) return false;
        ItemStack remainder = contents[slot].clone();
        remainder.setAmount(remainder.getAmount() - 1);
        inventory.setItem(slot, remainder.getAmount() == 0 ? null : remainder);
        return true;
    }

    static int slot(ItemStack[] contents, Material seed) {
        for (int slot = 0; slot < contents.length; slot++) {
            ItemStack item = contents[slot];
            if (item != null && item.getType() == seed && item.getAmount() > 0 && !item.hasItemMeta()) return slot;
        }
        return -1;
    }
}
