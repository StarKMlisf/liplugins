package net.liplugins.liskills.internal.menu;

import net.liplugins.liskills.internal.config.ConfigManager;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** 读取详情页槽位；配置层已验证，此处仍避开重复及越界槽位。 */
final class DetailLayout {
    private final int size;
    private final Map<String, Integer> controls = new LinkedHashMap<>();
    private final List<Integer> sources = new ArrayList<>();

    DetailLayout(ConfigManager config) {
        size = Math.max(27, Math.min(54, config.menu().getInt("details.size", 54) / 9 * 9));
        add(config, "summary", 4);
        add(config, "previous", size - 9);
        add(config, "page", size - 8);
        add(config, "back", size - 6);
        add(config, "ability", size - 5);
        add(config, "refresh", size - 4);
        add(config, "next", size - 1);
        for (int slot : config.menu().getIntegerList("details.source-slots")) {
            if (slot >= 0 && slot < size && !controls.containsValue(slot) && !sources.contains(slot)) sources.add(slot);
        }
        if (sources.isEmpty()) {
            for (int slot = 9; slot < size - 9; slot++) if (!controls.containsValue(slot)) sources.add(slot);
        }
    }

    private void add(ConfigManager config, String name, int fallback) {
        int slot = config.menu().getInt("details." + name + "-slot", fallback);
        if (slot < 0 || slot >= size || controls.containsValue(slot)) slot = fallback;
        if (controls.containsValue(slot)) {
            for (int index = 0; index < size; index++) if (!controls.containsValue(index)) { slot = index; break; }
        }
        controls.put(name, slot);
    }

    int size() { return size; }
    int slot(String control) { return controls.get(control); }
    List<Integer> sources() { return List.copyOf(sources); }
}
