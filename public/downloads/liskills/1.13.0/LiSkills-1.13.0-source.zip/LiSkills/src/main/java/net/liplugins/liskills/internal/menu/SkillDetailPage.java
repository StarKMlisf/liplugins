package net.liplugins.liskills.internal.menu;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.config.SkillDefinition;
import net.liplugins.liskills.internal.storage.PlayerProfile;
import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.inventory.Inventory;

import java.util.LinkedHashMap;
import java.util.ArrayList;
import java.util.Locale;
import java.util.List;
import java.util.Map;

/** 单个技能详情页：成长摘要、分页来源和主动能力操作分别占用独立位置。 */
final class SkillDetailPage {
    private final ConfigManager config;
    private final TextService text;
    private final SkillSourceCatalog catalog;
    private final SkillPresentation presentation;
    private final MenuItems items;
    private final MenuMaterials materials;
    private final SourcePresentation sourcePresentation;

    SkillDetailPage(ConfigManager config, TextService text, SkillPresentation presentation) {
        this.config = config; this.text = text; this.presentation = presentation;
        this.catalog = new SkillSourceCatalog(config, text);
        this.items = new MenuItems(text); this.materials = new MenuMaterials(config);
        this.sourcePresentation=new SourcePresentation(text);
    }

    Inventory create(PlayerProfile profile, SkillDefinition skill, int requestedPage) {
        DetailLayout layout = new DetailLayout(config);
        List<SkillSource> sources = catalog.sources(skill);
        List<Integer> sourceSlots = layout.sources();
        int pages = Math.max(1, (sources.size() + sourceSlots.size() - 1) / sourceSlots.size());
        int page = Math.clamp(requestedPage, 0, pages - 1);
        Map<Integer, MenuAction> actions = new LinkedHashMap<>();
        actions.put(layout.slot("back"), new MenuAction(MenuAction.Type.BACK, skill.id(), page));
        actions.put(layout.slot("ability"), new MenuAction(MenuAction.Type.CAST, skill.id(), page));
        actions.put(layout.slot("refresh"), new MenuAction(MenuAction.Type.REFRESH, skill.id(), page));
        actions.put(layout.slot("summary"),new MenuAction(MenuAction.Type.PASSIVES,skill.id(),0));
        if (page > 0) actions.put(layout.slot("previous"), new MenuAction(MenuAction.Type.PREVIOUS, skill.id(), page - 1));
        if (page + 1 < pages) actions.put(layout.slot("next"), new MenuAction(MenuAction.Type.NEXT, skill.id(), page + 1));
        SkillMenuHolder holder = new SkillMenuHolder(profile.uuid(), SkillMenuHolder.Screen.DETAIL,
                skill.id(), page, config.revision(), actions, -1);
        Map<String, Object> values = presentation.values(skill, profile);
        values.put("page", page + 1);
        values.put("pages", pages);
        values.put("sources", sources.size());
        Inventory inventory = Bukkit.createInventory(holder, layout.size(), text.text("menu.details.title", values));
        holder.inventory(inventory);
        if (config.menu().getBoolean("fill", true)) {
            Material filler = materials.get("filler-material", Material.GRAY_STAINED_GLASS_PANE);
            for (int slot = 0; slot < layout.size(); slot++) inventory.setItem(slot, items.item(filler, "menu.filler-name", null, Map.of()));
        }
        for (int index = 0; index < sourceSlots.size(); index++) {
            int position = page * sourceSlots.size() + index;
            if (position >= sources.size()) break;
            SkillSource source = sources.get(position);
            var item=items.item(source.icon(),"menu.details.source-name","menu.details.source-lore",sourcePresentation.values(source));
            sourcePresentation.append(item,source);inventory.setItem(sourceSlots.get(index),item);
        }
        if (sources.isEmpty()) inventory.setItem(sourceSlots.getFirst(), items.item(materials.get("details.icons.empty", Material.BARRIER),
                "menu.details.empty-name", "menu.details.empty-lore", values));
        control(inventory, layout, "previous", Material.ARROW, page > 0 ? "previous" : "no-previous", values);
        control(inventory, layout, "next", Material.ARROW, page + 1 < pages ? "next" : "no-next", values);
        control(inventory, layout, "page", Material.PAPER, "page", values);
        control(inventory, layout, "back", Material.OAK_DOOR, "back", values);
        control(inventory, layout, "refresh", Material.CLOCK, "refresh", values);
        refresh(inventory, holder, profile);
        return inventory;
    }

    void refresh(Inventory inventory, SkillMenuHolder holder, PlayerProfile profile) {
        SkillDefinition skill = config.skill(holder.selectedSkill());
        if (skill == null || !skill.enabled()) return;
        DetailLayout layout = new DetailLayout(config);
        Map<String, Object> values = presentation.values(skill, profile);
        inventory.setItem(layout.slot("summary"), items.item(skill.icon(), "menu.details.summary-name", "menu.details.summary-lore", values));
        var summary=inventory.getItem(layout.slot("summary"));var summaryMeta=summary.getItemMeta();
        List<String> summaryLore=new ArrayList<>(summaryMeta.hasLore()?summaryMeta.getLore():List.of());
        summaryLore.addAll(text.lines(config.progressionEnabled()?"rpg.passives-entry":"passive-guide."+skill.id(),values));
        summaryMeta.setLore(summaryLore);summary.setItemMeta(summaryMeta);
        control(inventory, layout, "ability", Material.BLAZE_POWDER, "ability", values);
        // 新能力说明使用独立节点，升级时不覆盖管理员已经定制的原有按钮 lore 列表。
        var button=inventory.getItem(layout.slot("ability"));
        var meta=button.getItemMeta();
        List<String> lore=new ArrayList<>(meta.hasLore()?meta.getLore():List.of());
        lore.addAll(text.lines("ability-guide."+skill.active().type().toLowerCase(Locale.ROOT),values));
        meta.setLore(lore);
        button.setItemMeta(meta);
    }

    private void control(Inventory inventory, DetailLayout layout, String control, Material fallback,
                         String textKey, Map<String, ?> values) {
        inventory.setItem(layout.slot(control), items.item(materials.get("details.icons." + control, fallback),
                "menu.details." + textKey + "-name", "menu.details." + textKey + "-lore", values));
    }
}
