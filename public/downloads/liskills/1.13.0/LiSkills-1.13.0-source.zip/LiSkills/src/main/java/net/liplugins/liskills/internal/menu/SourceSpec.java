package net.liplugins.liskills.internal.menu;

import org.bukkit.Material;
import java.util.Map;

/** 配置来源的未渲染描述；单位和条件使用消息键，不在代码里固定玩家文本。 */
record SourceSpec(String id,String nameType,String label,String kind,double experience,Material icon,
                  String unit,String condition,Map<String,Object> values) {
    SourceSpec { values=Map.copyOf(values); }
}
