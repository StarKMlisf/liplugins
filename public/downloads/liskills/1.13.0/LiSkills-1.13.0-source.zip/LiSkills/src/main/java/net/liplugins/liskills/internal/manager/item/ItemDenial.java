package net.liplugins.liskills.internal.manager.item;

import net.liplugins.liskills.internal.config.ItemRule;

/** 将未满足的条件与可配置物品名称关联，消息层不重复判断规则。 */
public record ItemDenial(ItemRule rule, ItemRequirement requirement) { }
