package net.liplugins.liskills.internal.listener.stat;

import net.liplugins.liskills.internal.manager.stat.AnvilDiscountLease;
import net.liplugins.liskills.internal.manager.stat.StatManager;
import net.liplugins.liskills.internal.manager.stat.StatTraits;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.PrepareAnvilEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.view.AnvilView;

import java.util.Map;
import java.util.WeakHashMap;

/** 智慧只调整原版铁砧正数费用；不覆盖结果物品，不提高过于昂贵阈值，不进入自定义附魔菜单。 */
public final class StatAnvilListener implements Listener {
    private final StatManager stats;
    private final Map<AnvilView, AnvilDiscountLease> leases = java.util.Collections.synchronizedMap(new WeakHashMap<>());

    public StatAnvilListener(StatManager stats) { this.stats = stats; }

    @EventHandler(priority = EventPriority.HIGH)
    public void onPrepare(PrepareAnvilEvent event) {
        AnvilView view = event.getView();
        int cost = view.getRepairCost();
        ItemStack result = event.getResult();
        if (result == null || result.getType().isAir() || cost <= 0) { leases.remove(view); return; }
        Signature signature = new Signature(copy(event.getInventory().getItem(0)), copy(event.getInventory().getItem(1)),
                copy(result), view.getRenameText());
        AnvilDiscountLease previous = leases.get(view);
        int original = previous == null ? cost : previous.originalFor(signature, cost);
        double discount = view.getPlayer() instanceof Player player && stats.active(player)
                ? stats.trait(player, "anvil-discount") : 0;
        if (discount <= 0) {
            if (previous != null && previous.owns(signature, cost)) view.setRepairCost(original);
            leases.remove(view);
            return;
        }
        int applied = StatTraits.anvilCost(original, discount);
        if (applied != cost) view.setRepairCost(applied);
        leases.put(view, new AnvilDiscountLease(signature, original, applied));
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onClose(InventoryCloseEvent event) {
        if (event.getView() instanceof AnvilView view) leases.remove(view);
    }

    /** 重载或撤权时恢复仍由自己持有的折扣；其他插件已改过的费用不碰。 */
    public void refresh(Player player) {
        if (!(player.getOpenInventory() instanceof AnvilView view)) return;
        AnvilDiscountLease previous = leases.get(view);
        if (previous == null) return;
        Signature signature = current(view);
        int cost = view.getRepairCost();
        if (!previous.owns(signature, cost)) { leases.remove(view); return; }
        double discount = stats.active(player) ? stats.trait(player, "anvil-discount") : 0;
        int applied = StatTraits.anvilCost(previous.original(), discount);
        if (applied != cost) view.setRepairCost(applied);
        if (discount > 0) leases.put(view, new AnvilDiscountLease(signature, previous.original(), applied));
        else leases.remove(view);
    }

    public void restore(Player player) {
        if (!(player.getOpenInventory() instanceof AnvilView view)) return;
        AnvilDiscountLease previous = leases.remove(view);
        if (previous != null && previous.owns(current(view), view.getRepairCost())) view.setRepairCost(previous.original());
    }

    private Signature current(AnvilView view) {
        var inventory = view.getTopInventory();
        return new Signature(copy(inventory.getItem(0)), copy(inventory.getItem(1)), copy(inventory.getItem(2)), view.getRenameText());
    }

    private ItemStack copy(ItemStack item) { return item == null ? null : item.clone(); }
    private record Signature(ItemStack first, ItemStack second, ItemStack result, String rename) { }
}
