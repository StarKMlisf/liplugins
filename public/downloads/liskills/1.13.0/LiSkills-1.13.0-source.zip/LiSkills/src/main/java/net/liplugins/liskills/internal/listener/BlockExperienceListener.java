package net.liplugins.liskills.internal.listener;

import net.liplugins.liskills.lib.scheduler.ServerThreads;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.config.SkillDefinition;
import net.liplugins.liskills.internal.manager.SkillManager;
import net.liplugins.liskills.internal.hook.LiRealEnchantHook;
import net.liplugins.liskills.internal.manager.source.BlockHarvestSources;
import net.liplugins.liskills.internal.manager.source.PlantColumnProgress;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.Waterlogged;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockDropItemEvent;
import java.util.*;
import java.util.function.Predicate;

/** 记录破坏前来源，下一tick核对最终结果；玩家放置资源永远不能通过取消或回调重放洗白。 */
public final class BlockExperienceListener implements Listener {
    private static final int MAX_PENDING = 8192;
    private final ConfigManager config;
    private final SkillManager skills;
    private final PlacedBlockTracker placed;
    private final LiRealEnchantHook enchantments;
    private final Predicate<Block> customBlock;
    private final Map<BlockBreakEvent, Attempt> seen = Collections.synchronizedMap(new IdentityHashMap<>());
    private final Map<Position, Attempt> natural = new java.util.concurrent.ConcurrentHashMap<>(), secondary = new java.util.concurrent.ConcurrentHashMap<>();
    private final Map<Block,Attempt> columns=new java.util.concurrent.ConcurrentHashMap<>();

    public BlockExperienceListener(ConfigManager config, SkillManager skills, PlacedBlockTracker placed) { this(config, skills, placed, null); }
    public BlockExperienceListener(ConfigManager config, SkillManager skills, PlacedBlockTracker placed, LiRealEnchantHook enchantments) { this(config, skills, placed, enchantments, block -> false); }
    public BlockExperienceListener(ConfigManager config, SkillManager skills, PlacedBlockTracker placed, LiRealEnchantHook enchantments, Predicate<Block> customBlock) {
        this.config = config; this.skills = skills; this.placed = placed; this.enchantments = enchantments; this.customBlock = customBlock;
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onBreak(BlockBreakEvent event) {
        if (!ServerThreads.owns(event.getPlayer()) || !ServerThreads.owns(event.getBlock())
                || seen.containsKey(event) || seen.size() >= MAX_PENDING || customBlock.test(event.getBlock())) return;
        Block block = event.getBlock();
        Attempt occupied=columns.get(block);
        if(occupied!=null)occupied.conflicted=true; // 另一玩家/新事件接管原列时，不归因给更早的根事务。
        Attempt attempt = new Attempt(event, block.getType(), block.getBlockData().clone(), placed.stamp(block), config.revision(),
                BlockHarvestSources.capture(block,placed,config.sources(),customBlock),
                BlockHarvestSources.isSculkSource(block.getType()) && block.getDrops(event.getPlayer().getInventory().getItemInMainHand(),event.getPlayer()).isEmpty());
        if(occupied!=null)attempt.conflicted=true;
        boolean checking = enchantments != null && enchantments.checkingSecondaryBreak();
        Map<Position, Attempt> index = checking ? secondary : natural;
        Position position = Position.of(event.getPlayer(), block);
        Attempt earlier = index.put(position, attempt);
        if (earlier != null) { earlier.conflicted = true; attempt.conflicted = true; }
        seen.put(event, attempt);
        if(attempt.column!=null) {
            if(columns.size()+attempt.parts.size()>32768)attempt.conflicted=true;
            else for(var part:attempt.parts) {
                Attempt earlierColumn=columns.putIfAbsent(part.block(),attempt);
                if(earlierColumn!=null) { earlierColumn.conflicted=true;attempt.conflicted=true; }
            }
        }
        if (!placed.defer(event.getPlayer(), () -> {
            if(!checking)advance(attempt,true);
            else if(!attempt.completed)release(attempt);
        }, () -> release(attempt)))release(attempt);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onDrop(BlockDropItemEvent event) {
        Attempt attempt = natural.get(Position.of(event.getPlayer(), event.getBlock()));
        if (attempt == null || attempt.material != event.getBlockState().getType()) return;
        if (attempt.drop != null && attempt.drop != event) attempt.conflicted = true;
        else attempt.drop = event;
    }

    public void completed(Player player, Block block, Material material, BlockData data) { completed(player, block, material, data, true); }
    public void completed(Player player, Block block, Material material, BlockData data, boolean awardXp) {
        if (!ServerThreads.owns(player) || !ServerThreads.owns(block)) return;
        // LRE v201 的完成事件必须对应其此前同步发出的保护预检；裸完成回调不是来源证据。
        Attempt attempt = secondary.remove(Position.of(player, block));
        if (attempt == null || attempt.material != material || !attempt.data.matches(data)) return;
        attempt.completed=true;
        if(!placed.defer(player, () -> advance(attempt,awardXp), () -> release(attempt)))release(attempt);
    }
    private void advance(Attempt attempt,boolean awardXp) {
        if(attempt.column==null) { try { settle(attempt,awardXp,attempt.parts); } finally { release(attempt); } return; }
        if(attempt.conflicted || attempt.event.isCancelled() || attempt.revision!=config.revision()) { release(attempt);return; }
        List<PlantColumnProgress.State> states=new ArrayList<>();
        for(var part:attempt.parts) {
            if(!placed.unchanged(part.block(),part.stamp()) || customBlock.test(part.block())) { release(attempt);return; }
            // 延长原世代的短事务有效期，不创建新世代、不清除已领取标志；卸载/放置仍令旧世代失效。
            placed.stamp(part.block());
            var current=part.block().getBlockData();
            boolean removed=current.getMaterial().isAir() || current.getMaterial()==Material.WATER
                    && (part.material()==Material.KELP || part.material()==Material.KELP_PLANT);
            states.add(removed?PlantColumnProgress.State.REMOVED:current.matches(part.data())?PlantColumnProgress.State.ORIGINAL:PlantColumnProgress.State.INVALID);
        }
        var decision=attempt.column.observe(states);
        if(decision.finished()) {
            try { if(decision.confirmedParts()>0)settle(attempt,awardXp,attempt.parts.subList(0,decision.confirmedParts())); }
            finally { release(attempt); }
        } else if(!placed.defer(attempt.event.getPlayer(), ()->advance(attempt,awardXp), () -> release(attempt)))release(attempt);
    }
    private void release(Attempt attempt) {
        seen.remove(attempt.event);Position position=attempt.position;
        natural.remove(position,attempt);secondary.remove(position,attempt);
        if(attempt.column!=null)for(var part:attempt.parts)columns.remove(part.block(),attempt);
    }
    private void settle(Attempt attempt, boolean awardXp,List<BlockHarvestSources.Part> confirmed) {
        Block block = attempt.event.getBlock(); Player player = attempt.event.getPlayer();
        if (attempt.conflicted || attempt.event.isCancelled() || !placed.unchanged(block, attempt.stamp)
                || block.getBlockData().matches(attempt.data) || customBlock.test(block)
                || attempt.nativeEmptyDrops && !removedItemlessBlock(attempt.data,block.getType())) return;
        // 标记清理不改变位置世代，同一成功收获的经验和幸运可以各结算一次。
        boolean reward = awardXp && attempt.revision == config.revision() && attempt.event.isDropItems()
                && !(attempt.drop != null && (attempt.drop.isCancelled() || attempt.drop.getItems().isEmpty() && !attempt.nativeEmptyDrops))
                && player.isOnline() && !player.isDead() && player.getWorld().equals(block.getWorld()) && skills.eligible(player);
        Map<String,Double> totals=new LinkedHashMap<>();
        for(BlockHarvestSources.Part part:confirmed) {
            if(!placed.unchanged(part.block(),part.stamp()) || part.block().getBlockData().matches(part.data()) || customBlock.test(part.block()))continue;
            placed.clearIfUnchanged(part.block(),part.stamp());
            if(!reward || !placed.claimExperience(part.block(),part.stamp()))continue;
            for (SkillDefinition definition : config.skills().values()) {
                String id=definition.id();
                // fishing.blocks是钓获物表；其他已注册技能可通过自己的材料表接入真实玩家采集。
                if (id.equals("fishing") || !definition.enabled() || definition.blocks().isEmpty()) continue;
                Double xp = definition.blocks().get(part.material());
                if (xp == null || id.equals("farming") && !HarvestMaturity.mayHarvest(part.material(), part.data())) continue;
                boolean grownCrop = id.equals("farming") && HarvestMaturity.matureCrop(part.material(), part.data());
                // 按每一格自己的来源核对；人工底部不计分，上方真正生长且已倒下的植物仍可计分。
                if (part.placed() && !grownCrop) continue;
                totals.merge(id,xp*BlockHarvestSources.multiplier(part.material(),part.data(),config.sources()),Double::sum);
            }
        }
        totals.forEach((id,xp)->{ if(attempt.revision==config.revision())skills.award(player,id,xp); });
    }
    private static boolean removedItemlessBlock(BlockData before,Material current) {
        // 原版无物品的幽匿仍需真正消失；只改状态/替换其他固体不能冒充破坏，含水方块允许留下水。
        return current.isAir() || current==Material.WATER && before instanceof Waterlogged data && data.isWaterlogged();
    }
    private static final class Attempt {
        final BlockBreakEvent event;
        final Position position;
        final Material material;
        final BlockData data;
        final long stamp, revision;
        final List<BlockHarvestSources.Part> parts;
        final PlantColumnProgress column;
        final boolean nativeEmptyDrops;
        volatile boolean conflicted,completed;
        volatile BlockDropItemEvent drop;
        Attempt(BlockBreakEvent event, Material material, BlockData data, long stamp, long revision, List<BlockHarvestSources.Part> parts,boolean nativeEmptyDrops) {
            this.event = event; this.material = material; this.data = data; this.stamp = stamp; this.revision = revision; this.parts=parts;
            this.position = Position.of(event.getPlayer(),event.getBlock());
            this.column=parts.size()>1?new PlantColumnProgress(parts.size()):null;
            this.nativeEmptyDrops=nativeEmptyDrops;
        }
    }
    private record Position(UUID world, int x, int y, int z, UUID player) {
        static Position of(Player player, Block block) { return new Position(block.getWorld().getUID(), block.getX(), block.getY(), block.getZ(), player.getUniqueId()); }
    }
}
