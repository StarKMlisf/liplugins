package net.liplugins.liskills.internal.config;

import org.bukkit.Material;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/** 一个命名物品规则；集合均为不可变快照，重载不修改正在读取的旧规则。 */
public record ItemRule(String id, String name, boolean enabled, Set<Material> materials,
                       String pdcKey, String pdcValue, Set<ItemSlot> slots,
                       Map<String, Double> attributes, Map<String, Integer> requirements, Set<ItemUse> uses,
                       Map<String, Double> statMultipliers, Map<String, Double> statPercentAdditions,
                       Map<String, ItemModifier> traits, Map<String, Double> skillXpMultipliers) {
    public ItemRule(String id, String name, boolean enabled, Set<Material> materials, String pdcKey, String pdcValue,
                    Set<ItemSlot> slots, Map<String, Double> attributes, Map<String, Integer> requirements, Set<ItemUse> uses) {
        this(id, name, enabled, materials, pdcKey, pdcValue, slots, attributes, requirements, uses, Map.of(), Map.of(), Map.of(), Map.of());
    }
    public ItemRule {
        materials = Set.copyOf(materials);
        slots = Set.copyOf(slots);
        attributes = Collections.unmodifiableMap(new LinkedHashMap<>(attributes));
        requirements = Collections.unmodifiableMap(new LinkedHashMap<>(requirements));
        uses = Set.copyOf(uses);
        statMultipliers = Map.copyOf(statMultipliers);
        statPercentAdditions = Map.copyOf(statPercentAdditions);
        traits = Map.copyOf(traits);
        skillXpMultipliers = Map.copyOf(skillXpMultipliers);
    }
}
