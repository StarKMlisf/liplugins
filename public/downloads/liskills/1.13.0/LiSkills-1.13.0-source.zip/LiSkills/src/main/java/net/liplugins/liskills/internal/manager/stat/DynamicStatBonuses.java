package net.liplugins.liskills.internal.manager.stat;

import net.liplugins.liskills.internal.manager.PassiveAbilityManager;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** 装备和药水带来的瞬时属性；每次计算读取当前状态，不向物品写永久属性。 */
final class DynamicStatBonuses {
    private final PassiveAbilityManager passives;

    DynamicStatBonuses(PassiveAbilityManager passives) { this.passives = passives; }

    void apply(Player player, Map<String, Double> values) {
        ItemStack held = player.getInventory().getItemInMainHand();
        String material = held.getType().name();
        if (material.endsWith("_AXE")) add(values, "strength", Math.floor(passives.value(player, "valor")));
        if (material.endsWith("_PICKAXE")) add(values, "toughness", Math.floor(passives.value(player, "stamina")));
        double enchantedStrength = passives.value(player, "enchanted_strength");
        if (enchantedStrength > 0 && !held.getEnchantments().isEmpty()) {
            Set<String> excluded = excludedEnchantments();
            long count = held.getEnchantments().keySet().stream().filter(enchantment -> {
                String key = enchantment.getKey().getKey();
                return !excluded.contains(key) && !excluded.contains(enchantment.getKey().toString());
            }).count();
            add(values, "strength", count * enchantedStrength);
        }
        long effects = player.getActivePotionEffects().stream().map(effect -> effect.getType().getKey()).distinct().count();
        add(values, "wisdom", effects * passives.value(player, "wise_effect"));
    }

    private Set<String> excludedEnchantments() {
        var definition = passives.definition("enchanted_strength");
        if (definition == null) return Set.of();
        Object raw = definition.options().get("excluded_enchantments");
        if (!(raw instanceof List<?> entries)) return Set.of();
        Set<String> result = new HashSet<>();
        for (Object entry : entries) if (entry instanceof String text) result.add(text.toLowerCase(java.util.Locale.ROOT));
        return result;
    }

    private void add(Map<String, Double> values, String stat, double amount) {
        if (Double.isFinite(amount) && amount > 0) values.computeIfPresent(stat, (id, value) -> value + amount);
    }
}
