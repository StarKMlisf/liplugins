package net.liplugins.liskills.internal.manager.passive.combat;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.hook.LiRealEnchantHook;
import net.liplugins.liskills.internal.manager.PassiveAbilityManager;
import net.liplugins.liskills.internal.manager.ProfileManager;
import net.liplugins.liskills.internal.manager.SkillManager;
import net.liplugins.liskills.internal.manager.stat.StatManager;
import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.NamespacedKey;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.plugin.java.JavaPlugin;
import java.util.List;

/** 仅装配战斗、箭术、敏捷、炼金和附魔的被动；运行逻辑分散到职责独立的组件。 */
public final class RpgCombatModule implements AutoCloseable {
    private final JavaPlugin plugin;
    private final DeferredPassiveEffects effects;
    private final ParryManager parry;
    private final BleedManager bleed;
    private final ArcheryPassiveManager archery;
    private final AgilityPassiveManager agility;
    private final BrewingOwnership ownership;
    private final EnchantingPassiveManager enchanting;
    private final RevivalPassiveManager revival;
    private final DisenchantingPassiveListener disenchanting;
    private final PotionDurationPassiveListener potionDuration;
    private final List<Listener> listeners;
    private boolean registered;
    public RpgCombatModule(JavaPlugin plugin,ConfigManager config,ProfileManager profiles,SkillManager skills,
                           PassiveAbilityManager passives,StatManager stats,LiRealEnchantHook enchantments,TextService text) {
        this.plugin=plugin;
        effects=new DeferredPassiveEffects(plugin);
        parry=new ParryManager(config,profiles,passives,effects,text);
        bleed=new BleedManager(plugin,config,profiles,passives,effects,text);
        var first=new FirstStrikeManager(config,profiles,passives,effects,text);
        archery=new ArcheryPassiveManager(plugin,config,profiles,passives,effects,enchantments);
        agility=new AgilityPassiveManager(plugin,config,profiles,passives,effects,enchantments);
        ownership=new BrewingOwnership(config,profiles,skills,effects);
        enchanting=new EnchantingPassiveManager(plugin,config,profiles,passives,effects);
        revival=new RevivalPassiveManager(plugin,config,profiles,passives,stats,text,effects);
        disenchanting=new DisenchantingPassiveListener(config,profiles,passives,effects);
        potionDuration=new PotionDurationPassiveListener(config,profiles,passives,effects);
        var enhancer=new PotionEnhancer(new NamespacedKey(plugin,"alchemist_duration"),text);
        listeners=List.of(effects,parry,new CombatPassiveManager(config,skills,passives,stats,enchantments,first,parry,bleed),
                archery,new DefensePotionListener(passives,enchantments),agility,new VitalityPassiveListener(passives,enchantments),ownership,
                new BrewingPassiveListener(config,skills,passives,ownership,enhancer),
                enchanting,new ExperienceConversionListener(plugin,passives),revival,new RestorationPassiveListener(passives),
                new VanillaExperiencePassiveListener(passives),potionDuration,
                new ForgingRepairListener(passives),new SkillMendingListener(passives),
                disenchanting.receiptListener(),disenchanting);
    }
    public void register() {
        if(registered)return;
        registered=true;listeners.forEach(listener->plugin.getServer().getPluginManager().registerEvents(listener,plugin));
    }
    @Override public void close() {
        listeners.forEach(HandlerList::unregisterAll);
        effects.close();parry.close();bleed.close();archery.close();agility.close();ownership.close();enchanting.close();revival.close();disenchanting.close();potionDuration.close();
    }
}
