package net.liplugins.liskills.internal.manager;

import net.liplugins.liskills.internal.config.QuickFishSettings;
import org.bukkit.Location;
import org.bukkit.entity.FishHook;
import org.bukkit.entity.Player;

import java.util.UUID;

/** 记录自己写入的一对等待参数，并在仍持有该对参数时归还原值。 */
record QuickFishHookLease(FishHook hook, UUID player, long token,
                          QuickFishWait.Range original, QuickFishWait.Range adjusted) {
    static QuickFishHookLease apply(FishHook hook, UUID player, long token, QuickFishSettings settings) {
        QuickFishWait.Range original = new QuickFishWait.Range(hook.getMinWaitTime(), hook.getMaxWaitTime());
        QuickFishWait.Range adjusted = QuickFishWait.shorten(original, settings);
        // Bukkit 的成对设置避免先改一端时暂时出现 minimum > maximum。
        hook.setWaitTime(adjusted.minimum(), adjusted.maximum());
        return new QuickFishHookLease(hook, player, token, original, adjusted);
    }

    void restoreIfUnchanged() {
        if (!usable(hook, player)) return;
        if (hook.getMinWaitTime() != adjusted.minimum() || hook.getMaxWaitTime() != adjusted.maximum()) return;
        hook.setWaitTime(original.minimum(), original.maximum());
    }

    boolean matches(FishHook candidate) { return hook.getUniqueId().equals(candidate.getUniqueId()); }

    static boolean usable(FishHook hook, UUID player) {
        if (!hook.isValid() || hook.isDead() || !(hook.getShooter() instanceof Player shooter)
                || !shooter.getUniqueId().equals(player)) return false;
        Location location = hook.getLocation();
        return location.getWorld() != null && location.getWorld().isChunkLoaded(location.getBlockX() >> 4, location.getBlockZ() >> 4);
    }
}
