package net.liplugins.liskills.internal.config;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.util.List;
import java.util.Map;
import java.util.Objects;

/** 仅迁移完整未自定义的旧被动模板；不覆盖任何数值、附加选项或管理员注释。 */
public final class LegacyPassiveUpgrade {
    private static final Map<String, Previous> MOVED = Map.of(
            "golden_heal", new Previous("agility", 4), "meal_steal", new Previous("agility", 6),
            "life_steal", new Previous("alchemy", 4), "golden_heart", new Previous("alchemy", 5),
            "anvil_master", new Previous("enchanting", 4));

    private LegacyPassiveUpgrade() { }

    public static boolean apply(YamlConfiguration current, YamlConfiguration defaults) {
        boolean changed = false;
        for (var entry : MOVED.entrySet()) {
            String path = "abilities." + entry.getKey();
            ConfigurationSection actual = current.getConfigurationSection(path);
            ConfigurationSection expected = defaults.getConfigurationSection(path);
            Previous previous = entry.getValue();
            if (actual == null || expected == null || !matches(actual, expected, previous)
                    || !current.getInlineComments(path).equals(defaults.getInlineComments(path))) continue;
            List<String> comments = current.getComments(path);
            if (!comments.equals(List.of(previous.skill + "技能被动；按此ID由专属监听器执行。"))
                    && !comments.equals(defaults.getComments(path))) continue;
            actual.set("skill", expected.getString("skill"));
            actual.set("unlock-level", expected.getInt("unlock-level"));
            // 只有已验证为原模板的注释才升级；其他部分仍由通用缺省补全处理。
            current.setComments(path, defaults.getComments(path));
            actual.setComments("skill", expected.getComments("skill"));
            changed = true;
        }
        return changed;
    }

    private static boolean matches(ConfigurationSection actual, ConfigurationSection expected, Previous previous) {
        if (!actual.getKeys(true).equals(expected.getKeys(true))) return false;
        for (String key : expected.getKeys(true)) {
            Object a = actual.get(key), b = expected.get(key);
            if ("skill".equals(key)) b = previous.skill;
            if ("unlock-level".equals(key)) b = previous.unlock;
            if (a instanceof ConfigurationSection && b instanceof ConfigurationSection) {
                // 子配置节本身无数值，其叶节点在同一遍历中严格比较。
            } else if (a instanceof Number first && b instanceof Number second) {
                if (Double.compare(first.doubleValue(), second.doubleValue()) != 0) return false;
            } else if (!Objects.equals(a, b)) return false;
            List<String> comments = actual.getComments(key);
            if (!comments.equals(expected.getComments(key)) && !("skill".equals(key)
                    && comments.equals(List.of("所属技能ID；内置11种之一。")))) return false;
            if (!actual.getInlineComments(key).equals(expected.getInlineComments(key))) return false;
        }
        return true;
    }

    private record Previous(String skill, int unlock) { }
}
