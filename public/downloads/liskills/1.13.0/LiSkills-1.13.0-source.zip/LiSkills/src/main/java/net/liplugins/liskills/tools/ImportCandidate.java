package net.liplugins.liskills.tools;

import net.liplugins.liskills.internal.storage.SkillProgress;

import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** 完整校验后的不可变迁移快照，执行阶段不再重新读取来源文件。 */
record ImportCandidate(Path source, UUID uuid, String name, Map<String, SkillProgress> skills,
                       List<String> ignoredSkills) {
    ImportCandidate {
        skills = Map.copyOf(skills);
        ignoredSkills = List.copyOf(ignoredSkills);
    }
}
