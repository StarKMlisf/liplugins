package net.liplugins.liskills.internal.manager;

/** 原生添加调用结束后，以实际药水状态确认效果；API返回成功并不足以证明未被事件取消。 */
final class PotionApplicationRules {
    private PotionApplicationRules() { }
    static boolean applied(boolean accepted,int requestedAmplifier,int requestedTicks,
                           boolean present,int actualAmplifier,int actualTicks,boolean infinite) {
        return accepted && requestedAmplifier>=0 && requestedTicks>0 && present
                && actualAmplifier==requestedAmplifier && (infinite || actualTicks>=requestedTicks);
    }
}
