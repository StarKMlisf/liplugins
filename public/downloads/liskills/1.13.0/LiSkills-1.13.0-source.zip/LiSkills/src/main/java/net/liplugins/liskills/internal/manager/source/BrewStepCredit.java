package net.liplugins.liskills.internal.manager.source;

/** 单瓶真实酿造步骤凭据；最多累计有限次数，重新放入人工成品不会调用append。 */
record BrewStepCredit(int steps,double experience) {
    static BrewStepCredit first(double experience){return new BrewStepCredit(1,Math.max(0,experience));}
    BrewStepCredit append(double extra,int maximum) {
        if(steps>=maximum)return this;
        return new BrewStepCredit(steps+1,experience+Math.max(0,extra));
    }
}
