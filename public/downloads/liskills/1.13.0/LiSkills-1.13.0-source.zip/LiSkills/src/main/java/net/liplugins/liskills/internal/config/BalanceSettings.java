package net.liplugins.liskills.internal.config;

import org.bukkit.configuration.ConfigurationSection;
import java.util.*;

/** 在原版基础配置之上生成保守生存服快照，不改写管理员的原始属性/能力文件。 */
public record BalanceSettings(boolean enabled,Map<String,Scale> stats,Map<String,Scale> passives,ActiveLimits active) {
    public record Scale(double multiplier,double maximum,double secondaryMultiplier,double secondaryMaximum) { }
    public record ActiveLimits(int maximumDurationSeconds,int minimumCooldownSeconds,int maximumRank) {
        public ActiveLimits {
            if(maximumDurationSeconds<1 || maximumDurationSeconds>120 || minimumCooldownSeconds<1 || minimumCooldownSeconds>86400
                    || maximumRank<1 || maximumRank>1000)throw new IllegalArgumentException("active：主动平衡上限超出允许范围");
        }
        public static ActiveLimits defaults(){return new ActiveLimits(20,120,10);}
    }
    public BalanceSettings { stats=Map.copyOf(stats);passives=Map.copyOf(passives);Objects.requireNonNull(active); }
    public BalanceSettings(boolean enabled,Map<String,Scale> stats,Map<String,Scale> passives) {
        this(enabled,stats,passives,ActiveLimits.defaults());
    }
    public static BalanceSettings parse(ConfigurationSection root) {
        ConfigurationSection limits=root.getConfigurationSection("active");
        if(root.contains("active") && limits==null)throw ConfigValues.invalid("active","主动平衡配置节");
        ActiveLimits active=limits==null?ActiveLimits.defaults():new ActiveLimits(
                ConfigValues.integer(limits,"maximum-duration-seconds",1,120),
                ConfigValues.integer(limits,"minimum-cooldown-seconds",1,86400),
                ConfigValues.integer(limits,"maximum-rank",1,1000));
        return new BalanceSettings(ConfigValues.bool(root,"enabled"),scales(root,"stats",Set.copyOf(StatsSettings.IDS)),scales(root,"passives",null),active);
    }
    /** 阶级先限幅再计算所有成长，伤害、耗魔和菜单不会各用一套等级。 */
    public int activeRankLimit(){return enabled?active.maximumRank():Integer.MAX_VALUE;}
    /** 瞬发锐钩与逐箭开关没有持续窗口，不应用常规持续/冷却上下限。 */
    public ActiveSkill apply(ActiveSkill input) {
        if(!enabled || !ActiveTimingRules.hasWindow(input.type()))return input;
        int duration=Math.min(input.durationSeconds(),active.maximumDurationSeconds());
        int cooldown=Math.max(input.cooldownSeconds(),Math.max(duration,active.minimumCooldownSeconds()));
        return new ActiveSkill(input.enabled(),input.name(),input.effect(),input.amplifier(),duration,cooldown,
                input.unlockLevel(),input.manaCost(),input.type());
    }
    private static Map<String,Scale> scales(ConfigurationSection root,String path,Set<String> allowed) {
        Map<String,Scale> result=new LinkedHashMap<>();
        ConfigurationSection section=ConfigValues.section(root,path);
        for(String id:section.getKeys(false)) {
            if((allowed!=null&&!allowed.contains(id))||!id.matches("[a-z][a-z0-9_]{0,47}"))throw ConfigValues.invalid(path+"."+id,"有效标识符");
            ConfigurationSection c=ConfigValues.section(section,id);
            result.put(id,new Scale(ConfigValues.number(c,"multiplier",0,100),ConfigValues.number(c,"maximum",0,1e6),
                    c.contains("secondary-multiplier")?ConfigValues.number(c,"secondary-multiplier",0,100):1,
                    c.contains("secondary-maximum")?ConfigValues.number(c,"secondary-maximum",0,1e6):1e6));
        }
        return result;
    }
    public Map<String,PassiveDefinition> apply(Map<String,PassiveDefinition> input) {
        if(!enabled)return input;
        Map<String,PassiveDefinition> result=new LinkedHashMap<>();
        input.forEach((id,d)->{
            Scale scale=passives.get(id);
            if(scale==null){result.put(id,d);return;}
            Map<String,Object> options=new HashMap<>(d.options());
            options.put("maximum_value",Math.min(d.numberOption("maximum_value",1e6),scale.maximum()));
            options.put("maximum_secondary_value",Math.min(d.numberOption("maximum_secondary_value",1e6),scale.secondaryMaximum()));
            result.put(id,new PassiveDefinition(d.id(),d.skill(),d.name(),d.description(),d.enabled(),d.unlockLevel(),d.levelInterval(),d.maxLevel(),
                    d.baseValue()*scale.multiplier(),d.perLevel()*scale.multiplier(),d.secondaryBase()*scale.secondaryMultiplier(),d.secondaryPerLevel()*scale.secondaryMultiplier(),options));
        });
        return Collections.unmodifiableMap(result);
    }
    public StatsSettings apply(StatsSettings input) {
        if(!enabled)return input;
        Map<String,StatDefinition> definitions=new LinkedHashMap<>();
        input.definitions().forEach((id,d)->{
            Scale scale=stats.get(id);double cap=scale==null?d.maximum():Math.min(d.maximum(),scale.maximum());
            definitions.put(id,new StatDefinition(id,d.name(),d.enabled(),Math.min(cap,d.base()*(scale==null?1:scale.multiplier())),cap));
        });
        Map<String,List<StatGrowth>> growth=new LinkedHashMap<>();
        input.growth().forEach((skill,rules)->growth.put(skill,rules.stream().map(rule->{
            Scale scale=stats.get(rule.stat());return new StatGrowth(rule.stat(),rule.value()*(scale==null?1:scale.multiplier()),rule.interval());
        }).toList()));
        return new StatsSettings(input.rewardStartLevel(),definitions,growth,input.traits(),input.damageReductionBase(),input.anvilDiscountBase(),
                input.maximumHealthBonus(),input.maximumSpeedBonus());
    }
}
