package net.liplugins.liskills.tools;

import java.io.PrintStream;
import java.nio.file.Files;
import java.nio.file.Path;

/** AuraSkills YAML 离线迁移命令行入口；默认只做预检，第三个参数 --apply 才执行新建。 */
public final class AuraSkillsImporter {
    private AuraSkillsImporter() {
    }

    public static void main(String[] args) {
        int result = run(args, System.out, System.err);
        if (result != 0) System.exit(result);
    }

    public static int run(String[] args, PrintStream output, PrintStream error) {
        MigrationMessages messages = new MigrationMessages();
        if (args.length < 2 || args.length > 3 || args.length == 3 && !args[2].equals("--apply")) {
            error.println(messages.text("usage"));
            return 2;
        }
        boolean apply = args.length == 3;
        try {
            ImportPlan plan = new MigrationPlanner(messages).plan(Path.of(args[0]), Path.of(args[1]));
            output.println(messages.text("source", plan.source()));
            output.println(messages.text("target", plan.target()));
            output.println(messages.text(apply ? "mode.apply" : "mode.preview"));
            for (ImportCandidate candidate : plan.candidates()) {
                output.println(messages.text("candidate", candidate.source().getFileName(), candidate.skills().size()));
                for (String ignored : candidate.ignoredSkills()) {
                    output.println(messages.text("ignored", candidate.source().getFileName(), ignored));
                }
            }
            if (!plan.valid()) {
                for (String issue : plan.errors()) error.println(messages.text("error", issue));
                error.println(messages.text("batch.rejected", plan.errors().size()));
                return 1;
            }
            if (!apply) {
                output.println(messages.text("preview.complete", plan.candidates().size()));
                return 0;
            }
            Files.createDirectories(plan.target());
            // 在写入前再次检查整个批次；CREATE_NEW 还会在每个真正落盘操作时阻止覆盖。
            for (ImportCandidate candidate : plan.candidates()) {
                Path target = plan.target().resolve(candidate.uuid() + ".yml");
                if (Files.exists(target, java.nio.file.LinkOption.NOFOLLOW_LINKS)) {
                    error.println(messages.text("invalid.exists", target));
                    error.println(messages.text("batch.rejected", 1));
                    return 1;
                }
            }
            NewProfileWriter writer = new NewProfileWriter(messages);
            int written = 0;
            for (ImportCandidate candidate : plan.candidates()) {
                try {
                    Path target = writer.write(plan.target(), candidate);
                    written++;
                    output.println(messages.text("written", target));
                } catch (Exception failure) {
                    error.println(messages.text("write.failed", candidate.uuid(), failure.getMessage(), written));
                    return 1;
                }
            }
            output.println(messages.text("apply.complete", written));
            return 0;
        } catch (Exception failure) {
            error.println(messages.text("error", failure.getMessage() == null ? failure.getClass().getSimpleName() : failure.getMessage()));
            return 1;
        }
    }
}
