package net.liplugins.liskills.internal.storage;

import net.liplugins.liskills.internal.config.ItemModifier;
import java.util.*;

/** 写操作在玩家所属实体线程；同步快照供异步存档与占位符读取，绝不把可变集合交给工作线程。 */
public final class PlayerProfile {
    private final UUID uuid;
    private final String name;
    private final Map<String,SkillProgress> skills;
    private final Map<String,Long> cooldowns;
    private double mana;
    // 只在当前会话存在的属性快照，供异步占位符安全读取；不写入 ProfileSnapshot。
    private Map<String,Double> statValues = Map.of();
    private Map<String,ItemModifier> itemTraitSnapshot = Map.of();
    private long statRevision = -1;
    private long previousStatRevision = -1;
    private boolean statsSuppressed;
    public PlayerProfile(ProfileSnapshot snapshot) {
        uuid=snapshot.uuid(); name=snapshot.name();
        skills=new HashMap<>(snapshot.skills()); cooldowns=new HashMap<>(snapshot.cooldowns());
        mana=snapshot.mana();
    }
    public UUID uuid(){return uuid;}
    public String name(){return name;}
    public synchronized SkillProgress progress(String skill){return skills.getOrDefault(skill,new SkillProgress(1,0));}
    public synchronized void progress(String skill,SkillProgress value){
        SkillProgress previous=skills.put(skill,value);
        if(!statsSuppressed && (previous==null?1:previous.level())!=value.level())statRevision=-1;
    }
    public synchronized Map<String,SkillProgress> skills(){return Map.copyOf(skills);}
    public synchronized long cooldown(String skill){return cooldowns.getOrDefault(skill,0L);}
    public synchronized void cooldown(String skill,long expires){cooldowns.put(skill,expires);}
    public synchronized double mana(){return mana;}
    public synchronized void mana(double value){if(!Double.isFinite(value)||value<0)throw new IllegalArgumentException("mana");mana=value;}
    public synchronized Map<String,Double> statValues(long revision){return statRevision==revision?statValues:null;}
    public synchronized Map<String,Double> previousStatValues(long revision){return previousStatRevision==revision?statValues:null;}
    public synchronized void statValues(long revision,Map<String,Double> values){statValues(revision,values,false);}
    public synchronized void statValues(long revision,Map<String,Double> values,boolean suppressed){
        statValues(revision,values,Map.of(),suppressed);
    }
    public synchronized void statValues(long revision,Map<String,Double> values,Map<String,ItemModifier> traits,boolean suppressed){
        statValues=Map.copyOf(values);itemTraitSnapshot=Map.copyOf(traits);
        statRevision=revision;previousStatRevision=revision;statsSuppressed=suppressed;
    }
    // 一次锁内读取统计值与装备效果，避免异步PAPI读到换装前后的混合快照。
    public synchronized AttributeSnapshot attributeSnapshot(long revision){return statRevision==revision?new AttributeSnapshot(statValues,itemTraitSnapshot):null;}
    public synchronized AttributeSnapshot previousAttributeSnapshot(long revision){return previousStatRevision==revision?new AttributeSnapshot(statValues,itemTraitSnapshot):null;}
    public record AttributeSnapshot(Map<String,Double> values,Map<String,ItemModifier> itemTraits) { }
    public synchronized boolean statsSuppressed(){return statsSuppressed;}
    public synchronized ProfileSnapshot snapshot(){return new ProfileSnapshot(uuid,name,skills,cooldowns,mana);}
}
