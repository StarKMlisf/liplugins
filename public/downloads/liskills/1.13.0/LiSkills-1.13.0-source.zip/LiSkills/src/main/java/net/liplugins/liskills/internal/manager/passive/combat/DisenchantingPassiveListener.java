package net.liplugins.liskills.internal.manager.passive.combat;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.manager.PassiveAbilityManager;
import net.liplugins.liskills.internal.manager.ProfileManager;
import net.liplugins.liskills.internal.manager.source.SourceItemRules;
import net.liplugins.liskills.internal.manager.source.SourceContainerChanges;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.GrindstoneInventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.EnchantmentStorageMeta;

import java.util.LinkedHashMap;
import java.util.Map;

/** 祛魔必须同时证明输入消耗与结果收货；同一砂轮在待结算期间只认领一次。 */
final class DisenchantingPassiveListener implements Listener, AutoCloseable {
    private final ConfigManager config;
    private final ProfileManager profiles;
    private final PassiveAbilityManager passives;
    private final DeferredPassiveEffects effects;
    private final SourceContainerChanges receipts = new SourceContainerChanges();

    DisenchantingPassiveListener(ConfigManager config, ProfileManager profiles, PassiveAbilityManager passives, DeferredPassiveEffects effects) {
        this.config = config; this.profiles = profiles; this.passives = passives; this.effects = effects;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onTake(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player) || !(event.getView().getTopInventory() instanceof GrindstoneInventory inventory)
                || event.getRawSlot() != 2 || !SourceItemRules.take(event.getAction()) || !passives.enabled(player, "disenchanter")) return;
        ItemStack first = SourceItemRules.copy(inventory.getItem(0)), second = SourceItemRules.copy(inventory.getItem(1));
        ItemStack result = SourceItemRules.copy(event.getCurrentItem());
        if (SourceItemRules.empty(result) || passives.flag("disenchanter", "ignore_custom_items", true)
                && (SourceItemRules.custom(first) || SourceItemRules.custom(second) || SourceItemRules.custom(result))) return;
        Map<Enchantment, Integer> enchants = read(first);
        read(second).forEach((enchantment, level) -> enchants.merge(enchantment, level, Math::max));
        read(result).keySet().forEach(enchants::remove);
        int sum = 0;
        for (var entry : enchants.entrySet()) if (!entry.getKey().isCursed() && entry.getKey().getKey().getNamespace().equals("minecraft"))
            sum += GrindstoneExperienceMath.minimum(entry.getKey().getKey().getKey(), Math.min(entry.getValue(), entry.getKey().getMaxLevel()));
        if (sum <= 0) return;
        var receiptGuard = receipts.begin(event);
        if (receiptGuard == null) return;
        int minimumCost = sum, receipt = SourceItemRules.count(player, result);
        PassiveSession session = PassiveSession.capture(player, profiles, config);
        if (!effects.submit(player.getUniqueId(), () -> {
            try {
            if (!receipts.valid(receiptGuard)) return;
            if (event.isCancelled() || !session.valid(profiles, config) || !passives.enabled(player, "disenchanter")
                    || (!SourceItemRules.empty(first) && SourceItemRules.same(first, inventory.getItem(0)))
                    || (!SourceItemRules.empty(second) && SourceItemRules.same(second, inventory.getItem(1)))
                    || SourceItemRules.count(player, result) <= receipt) return;
            int amount = GrindstoneExperienceMath.bonus(minimumCost, passives.value(player, "disenchanter"));
            if (amount > 0) player.giveExp(amount);
            } finally { receipts.finish(receiptGuard); }
        })) receipts.finish(receiptGuard);
    }

    private static Map<Enchantment, Integer> read(ItemStack item) {
        Map<Enchantment, Integer> result = new LinkedHashMap<>();
        if (SourceItemRules.empty(item)) return result;
        result.putAll(item.getEnchantments());
        if (item.getItemMeta() instanceof EnchantmentStorageMeta stored)
            stored.getStoredEnchants().forEach((enchantment, level) -> result.merge(enchantment, level, Math::max));
        return result;
    }
    Listener receiptListener() { return receipts; }
    @Override public void close() { receipts.close(); }
}
