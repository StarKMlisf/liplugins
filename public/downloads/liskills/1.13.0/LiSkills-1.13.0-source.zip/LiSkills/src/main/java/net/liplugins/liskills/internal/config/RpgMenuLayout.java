package net.liplugins.liskills.internal.config;

import org.bukkit.configuration.ConfigurationSection;
import java.util.*;

/** 两类成长页面各自验证布局，槽位不可互相覆盖。 */
public record RpgMenuLayout(int size,List<Integer> slots,int summary,int back,int active) {
    public static RpgMenuLayout parse(ConfigurationSection root,String page,int count) {
        ConfigurationSection s=root.getConfigurationSection("rpg."+page);
        if(s==null)throw new IllegalArgumentException("menu.rpg."+page+"：缺少布局配置");
        int size=integer(s,"size",27,54);
        if(size%9!=0)throw new IllegalArgumentException("menu.rpg."+page+".size：须为9的倍数");
        int summary=integer(s,"summary-slot",0,size-1), back=integer(s,"back-slot",0,size-1);
        int active=page.equals("passives")?integer(s,"active-slot",0,size-1):-1;
        Set<Integer> occupied=new HashSet<>();
        for(int slot:new int[]{summary,back,active})if(slot>=0 && !occupied.add(slot))throw new IllegalArgumentException("menu.rpg."+page+"：按钮槽位重复");
        List<?> raw=s.getList("item-slots");
        if(raw==null || raw.size()!=count)throw new IllegalArgumentException("menu.rpg."+page+".item-slots：须有"+count+"个槽位");
        List<Integer> slots=new ArrayList<>();
        for(Object value:raw) {
            if(!(value instanceof Number n) || n.doubleValue()!=Math.rint(n.doubleValue()) || n.intValue()<0 || n.doubleValue()>=size || !occupied.add(n.intValue()))
                throw new IllegalArgumentException("menu.rpg."+page+".item-slots：须为有效且不重复的槽位");
            slots.add(n.intValue());
        }
        return new RpgMenuLayout(size,List.copyOf(slots),summary,back,active);
    }
    private static int integer(ConfigurationSection s,String key,int min,int max) {
        Object value=s.get(key);
        if(!(value instanceof Number n) || !Double.isFinite(n.doubleValue()) || n.doubleValue()!=Math.rint(n.doubleValue()) || n.doubleValue()<min || n.doubleValue()>max)
            throw new IllegalArgumentException(s.getCurrentPath()+"."+key+"：应为"+min+"至"+max+"的整数");
        return n.intValue();
    }
}
