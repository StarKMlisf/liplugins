package net.liplugins.liskills.internal.menu;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.config.SkillDefinition;
import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.command.CommandSender;

import java.util.Map;

/** 同一份配置驱动技能来源命令及菜单中的详情。 */
public final class SkillDetails {
    private final SkillSourceCatalog catalog;
    private final TextService text;
    private final SourcePresentation presentation;

    public SkillDetails(ConfigManager config, TextService text) {
        this.catalog = new SkillSourceCatalog(config, text);
        this.text = text;
        this.presentation=new SourcePresentation(text);
    }

    public void send(CommandSender sender, SkillDefinition skill) {
        text.send(sender, "command.sources-title", Map.of("skill", text.plain(skill.name())));
        var sources = catalog.sources(skill);
        for (SkillSource source : sources) text.send(sender,"command.sources-line",presentation.commandValues(source));
        sources.stream().flatMap(source->source.details().stream()).distinct()
                .forEach(condition->text.send(sender,"source-guide.condition-line",Map.of("condition",condition)));
        if (sources.isEmpty()) text.send(sender, "command.sources-empty");
        text.send(sender,"source-guide.base-note");
        text.send(sender, "command.sources-note");
    }

}
