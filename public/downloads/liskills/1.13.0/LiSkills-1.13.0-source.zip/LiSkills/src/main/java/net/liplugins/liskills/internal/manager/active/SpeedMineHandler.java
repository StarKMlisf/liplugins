package net.liplugins.liskills.internal.manager.active;

import net.liplugins.liskills.internal.config.ActiveSkill;
import net.liplugins.liskills.internal.config.AuraManaSettings;
import net.liplugins.liskills.internal.manager.ActiveAbilityHandler;
import net.liplugins.liskills.internal.manager.PotionAbilityHandler;
import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.Bukkit;
import net.liplugins.liskills.lib.scheduler.ServerThreads;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffectType;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.function.Supplier;

/** 极速矿工使用原版急迫效果；要求施放时主手持镐，保留较强效果与 Bukkit 药水取消事务。 */
public final class SpeedMineHandler implements ActiveAbilityHandler,AutoCloseable {
    private final PotionAbilityHandler potions;
    private final Supplier<AuraManaSettings> settings;
    private final TextService text;
    private final Map<UUID,Long> expirations=new java.util.concurrent.ConcurrentHashMap<>();
    public SpeedMineHandler(TextService text,Supplier<AuraManaSettings> settings){this.text=text;this.settings=settings;potions=new PotionAbilityHandler(text);}
    @Override public boolean activate(Player player,ActiveSkill active) {
        if(!ServerThreads.owns(player))return false;
        if(!player.getInventory().getItemInMainHand().getType().name().endsWith("_PICKAXE")){text.send(player,"ability.speed-mine-tool");return false;}
        long now=System.currentTimeMillis();expirations.entrySet().removeIf(entry->entry.getValue()<=now);
        if(expirations.size()>=2048 && !expirations.containsKey(player.getUniqueId()))return false;
        ActiveSkill effect=new ActiveSkill(active.enabled(),active.name(),"HASTE",settings.get().speedMine().hasteLevel()-1,
                active.durationSeconds(),active.cooldownSeconds(),active.unlockLevel(),active.manaCost(),active.type());
        if(!potions.activate(player,effect))return false;
        expirations.put(player.getUniqueId(),now+active.durationSeconds()*1000L);return true;
    }
    @Override public long remainingMillis(Player player) {
        long remaining=Math.max(0,expirations.getOrDefault(player.getUniqueId(),0L)-System.currentTimeMillis());
        if(remaining==0 || !player.hasPotionEffect(PotionEffectType.HASTE)){expirations.remove(player.getUniqueId());return 0;}
        return remaining;
    }
    // 与原版SpeedMine一致，急迫由原生剩余时长管理；停止插件不移除玩家可能已有的同类药水。
    @Override public void close(){expirations.clear();}
}
