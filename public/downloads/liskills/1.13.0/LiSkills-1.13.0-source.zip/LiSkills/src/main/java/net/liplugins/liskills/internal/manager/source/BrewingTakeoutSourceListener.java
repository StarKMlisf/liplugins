package net.liplugins.liskills.internal.manager.source;

import net.liplugins.liskills.lib.scheduler.ServerThreads;

import net.liplugins.liskills.internal.config.AlchemySourceSettings;
import org.bukkit.Material;
import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.world.ChunkUnloadEvent;
import org.bukkit.event.inventory.*;
import org.bukkit.inventory.BrewerInventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.PotionMeta;
import java.util.*;
import java.util.function.BooleanSupplier;
import java.util.function.Supplier;

/** 酿造来源只记录已提交配方；由真正取到该瓶药水的玩家消费凭据，自动搬运不奖励。 */
final class BrewingTakeoutSourceListener implements Listener,AutoCloseable {
    private final SourceExperienceService rewards;private final Supplier<AlchemySourceSettings> settings;
    private final Map<Position,Stand> stands=new java.util.concurrent.ConcurrentHashMap<>();
    BrewingTakeoutSourceListener(SourceExperienceService rewards,Supplier<AlchemySourceSettings> settings){this.rewards=rewards;this.settings=settings;}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void onBrew(BrewEvent event) {
        if(!ServerThreads.owns(event.getBlock()))return;
        var policy=settings.get();if(!policy.enabled())return;
        ItemStack ingredient=SourceItemRules.copy(event.getContents().getIngredient());
        String kind=ingredient==null?null:ingredientKind(ingredient.getType());
        if(kind==null || (policy.ignoreCustomItems() && SourceItemRules.custom(ingredient)))return;
        ItemStack[] before=potions(event.getContents());Position position=Position.of(event.getBlock());
        Stand previous=current(position,policy);long revision=previous==null?-1:previous.revision,configRevision=rewards.revision();
        rewards.defer(event.getBlock(), ()->{
            if(event.isCancelled() || rewards.revision()!=configRevision || !settings.get().equals(policy) || !validBlock(event.getBlock()))return;
            ItemStack remaining=event.getContents().getIngredient();
            // 原生在BrewEvent最终通过后才消耗原料。漏斗同tick补满时证据不充分，保守不记本次而不改库存。
            if(!BrewIngredientConsumption.consumed(ingredient.getAmount(),SourceItemRules.empty(remaining)?0:remaining.getAmount(),
                    !SourceItemRules.empty(remaining) && remaining.isSimilar(ingredient)))return;
            Stand live=current(position,policy);
            if((live==null?-1:live.revision)!=revision)return;
            if(live==null && stands.size()>=policy.maximumTrackedStands()){purge(policy);if(stands.size()>=policy.maximumTrackedStands())return;}
            Stand updated=live==null?new Stand(configRevision):live;
            for(int slot=0;slot<3 && slot<event.getResults().size();slot++) {
                ItemStack result=event.getResults().get(slot),actual=event.getContents().getItem(slot);
                if(SourceItemRules.empty(before[slot]) || !(before[slot].getItemMeta() instanceof PotionMeta)
                        || SourceItemRules.empty(result) || result.getAmount()!=1 || !(result.getItemMeta() instanceof PotionMeta)
                        || SourceItemRules.same(before[slot],result) || !SourceItemRules.same(result,actual)
                        || (policy.ignoreCustomItems() && SourceItemRules.custom(result)))continue;
                Credit old=updated.slots[slot];
                BrewStepCredit steps=old!=null && SourceItemRules.same(old.result,before[slot])
                        ?old.steps.append(policy.xp("brew."+kind),policy.maximumBrewingSteps()):BrewStepCredit.first(policy.xp("brew."+kind));
                updated.slots[slot]=new Credit(result.clone(),steps);
            }
            updated.updated=System.currentTimeMillis();updated.revision++;stands.put(position,updated);
        });
    }
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void onClick(InventoryClickEvent event) {
        if(!(event.getWhoClicked() instanceof Player player) || !ServerThreads.owns(player)
                || !(event.getView().getTopInventory() instanceof BrewerInventory inventory))return;
        Location location=inventory.getLocation();if(location==null || !ServerThreads.owns(location))return;
        var policy=settings.get();if(!policy.enabled())return;
        Position position=Position.of(location.getBlock());Stand stand=current(position,policy);
        if(stand==null)return;
        int slot=event.getRawSlot();ItemStack[] before=potions(inventory);
        if(slot>=0 && slot<3 && SourceItemRules.take(event.getAction())) {
            Credit credit=stand.slots[slot];var session=rewards.capture(player,"alchemy");
            if(credit!=null && !credit.pending && session!=null && SourceItemRules.same(credit.result,before[slot])) {
                int received=SourceItemRules.count(player,credit.result);credit.pending=true;
                if(!rewards.defer(player, ()->{
                    credit.pending=false;
                    // 最终取消或未真正收到成品不消费凭据，允许一次后续合法取出。
                    if(!ServerThreads.owns(location) || event.isCancelled() || !rewards.valid(session) || !settings.get().equals(policy)
                            || current(position,policy)!=stand || stand.slots[slot]!=credit
                            || SourceItemRules.same(credit.result,inventory.getItem(slot)) || SourceItemRules.count(player,credit.result)<=received)return;
                    stand.slots[slot]=null;stand.revision++;
                    rewards.award(session,"brew",credit.steps.experience(),0,policy.maximumXpPerMinute());
                },()->credit.pending=false))credit.pending=false;
            }
        }
        observe(inventory,position,stand,before,event::isCancelled,policy);
    }
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void onDrag(InventoryDragEvent event) {
        if(!(event.getView().getTopInventory() instanceof BrewerInventory inventory)
                || event.getRawSlots().stream().noneMatch(slot->slot>=0 && slot<3))return;
        Location location=inventory.getLocation();if(location==null || !ServerThreads.owns(location))return;
        var policy=settings.get();Position position=Position.of(location.getBlock());Stand stand=current(position,policy);
        if(stand!=null)observe(inventory,position,stand,potions(inventory),event::isCancelled,policy);
    }
    private void observe(BrewerInventory inventory,Position position,Stand stand,ItemStack[] before,BooleanSupplier cancelled,AlchemySourceSettings policy) {
        Location location=inventory.getLocation();
        rewards.defer(location, ()->{
            if(!ServerThreads.owns(location) || cancelled.getAsBoolean() || current(position,policy)!=stand)return;
            for(int slot=0;slot<3;slot++) {
                Credit credit=stand.slots[slot];if(credit==null || credit.pending)continue;
                // 重新塞入同款人工药水时，点击前为空/不同的快照同样会使旧槽位凭据失效。
                if(!SourceItemRules.same(before[slot],credit.result) || !SourceItemRules.same(inventory.getItem(slot),credit.result)) {
                    stand.slots[slot]=null;stand.revision++;
                }
            }
        });
    }
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void onHopper(InventoryMoveItemEvent event) {
        if(!(event.getSource() instanceof BrewerInventory inventory))return;
        Location location=inventory.getLocation();if(location==null || !ServerThreads.owns(location))return;
        var policy=settings.get();Position position=Position.of(location.getBlock());Stand stand=current(position,policy);
        if(stand==null)return;ItemStack[] before=potions(inventory);ItemStack moved=SourceItemRules.copy(event.getItem());
        Location destination=event.getDestination().getLocation();
        // 无法确认归属的自动搬运只废弃凭据，不读取另一region或移动实体的库存。
        if(destination==null || !ServerThreads.owns(destination)) { stands.remove(position,stand);return; }
        int destinationBefore=SourceItemRules.count(event.getDestination().getContents(),moved);
        rewards.defer(location, ()->{
            if(!ServerThreads.owns(location) || event.isCancelled() || current(position,policy)!=stand)return;
            if(!ServerThreads.owns(destination)) { stands.remove(position,stand);return; }
            boolean destinationGained=SourceItemRules.count(event.getDestination().getContents(),moved)>destinationBefore;
            for(int slot=0;slot<3;slot++) {
                Credit credit=stand.slots[slot];if(credit==null)continue;
                boolean changed=!SourceItemRules.same(before[slot],inventory.getItem(slot));
                boolean reinserted=destinationGained && !SourceItemRules.empty(moved) && moved.isSimilar(credit.result);
                if(changed || reinserted){stand.slots[slot]=null;stand.revision++;}
            }
        });
    }
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void onBreak(BlockBreakEvent event){if(event.getBlock().getType()==Material.BREWING_STAND)rewards.defer(event.getBlock(),()->{if(!event.isCancelled())stands.remove(Position.of(event.getBlock()));});}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void onPlace(BlockPlaceEvent event){if(event.getBlockPlaced().getType()==Material.BREWING_STAND)rewards.defer(event.getBlockPlaced(),()->{if(!event.isCancelled())stands.remove(Position.of(event.getBlockPlaced()));});}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void onExplosion(BlockExplodeEvent event){rewards.defer(event.getBlock(),()->{if(!event.isCancelled())event.blockList().forEach(block->stands.remove(Position.of(block)));});}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void onExplosion(EntityExplodeEvent event){rewards.defer(event.getLocation(),()->{if(!event.isCancelled())event.blockList().forEach(block->stands.remove(Position.of(block)));});}
    @EventHandler(priority=EventPriority.MONITOR)
    public void onChunkUnload(ChunkUnloadEvent event){stands.keySet().removeIf(key->key.world.equals(event.getWorld().getUID()) && (key.x>>4)==event.getChunk().getX() && (key.z>>4)==event.getChunk().getZ());}
    private Stand current(Position position,AlchemySourceSettings policy) {
        Stand stand=stands.get(position);
        if(stand!=null && (stand.configRevision!=rewards.revision() || System.currentTimeMillis()-stand.updated>policy.claimLifetimeSeconds()*1000L)){stands.remove(position,stand);return null;}
        return stand;
    }
    private void purge(AlchemySourceSettings policy){long now=System.currentTimeMillis();stands.entrySet().removeIf(entry->now-entry.getValue().updated>policy.claimLifetimeSeconds()*1000L);}
    private static ItemStack[] potions(BrewerInventory inventory){return new ItemStack[]{SourceItemRules.copy(inventory.getItem(0)),SourceItemRules.copy(inventory.getItem(1)),SourceItemRules.copy(inventory.getItem(2))};}
    private static boolean validBlock(Block block){return ServerThreads.owns(block) && block.getWorld().isChunkLoaded(block.getX()>>4,block.getZ()>>4) && block.getType()==Material.BREWING_STAND;}
    static String ingredientKind(Material ingredient) {
        return switch(ingredient) {
            case NETHER_WART->"awkward";case REDSTONE->"extended";case GLOWSTONE_DUST->"upgraded";
            case GUNPOWDER->"splash";case DRAGON_BREATH->"lingering";
            case SUGAR,RABBIT_FOOT,BLAZE_POWDER,GLISTERING_MELON_SLICE,SPIDER_EYE,GHAST_TEAR,MAGMA_CREAM,PUFFERFISH,
                    GOLDEN_CARROT,TURTLE_HELMET,PHANTOM_MEMBRANE,FERMENTED_SPIDER_EYE,BREEZE_ROD,SLIME_BLOCK,STONE,COBWEB->"regular";
            default->null;
        };
    }
    @Override public void close(){stands.clear();}
    private static final class Stand {final Credit[] slots=new Credit[3];final long configRevision;volatile long updated=System.currentTimeMillis(),revision;Stand(long revision){configRevision=revision;}}
    private static final class Credit {final ItemStack result;final BrewStepCredit steps;volatile boolean pending;Credit(ItemStack result,BrewStepCredit steps){this.result=result;this.steps=steps;}}
    private record Position(UUID world,int x,int y,int z){static Position of(Block block){return new Position(block.getWorld().getUID(),block.getX(),block.getY(),block.getZ());}}
}
