package net.liplugins.liskills.internal.storage;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** 未确认写入的恢复快照；只能人工处理旧会话遗留，绝不自动导入覆盖数据库。 */
public final class RecoverySnapshotStore {
    private record Pending(long sequence,ProfileSnapshot snapshot){ }
    private final Path directory;
    private final ProfileStore files;
    private final Set<UUID> previous;
    private final Map<UUID,Pending> current=new HashMap<>();
    public RecoverySnapshotStore(Path directory)throws IOException{
        this.directory=directory;files=new ProfileStore(directory);Set<UUID> ids=new HashSet<>();
        if(Files.exists(directory))try(var paths=Files.list(directory)){
            for(Path path:paths.toList()){
                String name=path.getFileName().toString();
                if(name.matches("[0-9a-fA-F-]{36}\\.yml(?:\\.tmp)?"))ids.add(UUID.fromString(name.substring(0,36)));
            }
        }
        previous=Set.copyOf(ids);
    }
    public Set<UUID> previousSessionIds(){return previous;}
    /** 序号由主线程提交顺序决定，关闭时新快照不被旧IO失败回调覆盖。 */
    public synchronized void preserve(ProfileSnapshot snapshot,long sequence)throws IOException{
        if(previous.contains(snapshot.uuid()))throw new IOException("unresolved-previous-recovery: "+snapshot.uuid());
        Pending existing=current.get(snapshot.uuid());if(existing!=null&&existing.sequence()>sequence)return;
        files.save(snapshot);current.put(snapshot.uuid(),new Pending(sequence,snapshot));
    }
    /** 只清除本次确实成功保存的同版快照；旧保存成功不能清掉更新的关闭恢复文件。 */
    public synchronized void acknowledge(ProfileSnapshot snapshot,long sequence)throws IOException{
        Pending existing=current.get(snapshot.uuid());
        if(existing==null||existing.sequence()>sequence||!existing.snapshot().equals(snapshot))return;
        Files.deleteIfExists(directory.resolve(snapshot.uuid()+".yml"));Files.deleteIfExists(directory.resolve(snapshot.uuid()+".yml.tmp"));current.remove(snapshot.uuid());
    }
}
