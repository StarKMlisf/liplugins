package net.liplugins.liskills.internal.manager.passive.gathering;

import net.liplugins.liskills.lib.scheduler.ServerThreads;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.hook.LiRealEnchantHook;
import net.liplugins.liskills.internal.listener.PlacedBlockTracker;
import net.liplugins.liskills.internal.manager.PassiveAbilityManager;
import net.liplugins.liskills.internal.manager.ProfileManager;
import net.liplugins.liskills.internal.manager.SkillManager;
import net.liplugins.liskills.internal.manager.stat.StatManager;
import net.liplugins.liskills.internal.storage.PlayerProfile;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerFishEvent;
import java.util.UUID;
import java.util.function.Predicate;

/** 仅提供采集事务共享的身份、来源与生命周期检查。 */
record GatheringContext(ConfigManager config, ProfileManager profiles, SkillManager skills,
                        PassiveAbilityManager passives, StatManager stats, PlacedBlockTracker placed,
                        LiRealEnchantHook enchantments, Predicate<Block> customBlock,
                        Predicate<PlayerFishEvent> customFishing, GatheringTasks tasks) {
    Actor capture(Player player, String skill) {
        if (!permitted(player, skill)) return null;
        return new Actor(player, profiles.get(player.getUniqueId()), player.getWorld().getUID(), config.revision(), skill);
    }
    boolean permitted(Player player, String skill) {
        var definition = config.skill(skill);
        return ServerThreads.owns(player) && config.progressionEnabled() && definition != null && definition.enabled()
                && player.isOnline() && !player.isDead() && skills.eligible(player)
                && player.hasPermission("liskills.skill." + skill) && profiles.get(player.getUniqueId()) != null;
    }
    boolean valid(Actor actor) {
        return actor != null && ServerThreads.owns(actor.player) && actor.revision == config.revision()
                && actor.player.getWorld().getUID().equals(actor.world)
                && Bukkit.getPlayer(actor.player.getUniqueId()) == actor.player
                && profiles.get(actor.player.getUniqueId()) == actor.profile && permitted(actor.player, actor.skill);
    }
    double luck(Player player, String skill) {
        // StatManager已合并对应被动、旧统一系数与装备trait修饰；这里不能重复加成。
        return stats.trait(player, skill + "-luck");
    }
    boolean secondaryBreak() { return enchantments != null && enchantments.checkingSecondaryBreak(); }
    boolean secondaryDamage() { return enchantments != null && enchantments.isSecondaryDamage(); }
    static boolean loaded(Location location) {
        return location.getWorld() != null && ServerThreads.owns(location)
                && location.getWorld().isChunkLoaded(location.getBlockX() >> 4, location.getBlockZ() >> 4);
    }
    record Actor(Player player, PlayerProfile profile, UUID world, long revision, String skill) { }
}
