package net.liplugins.liskills.internal.config;

import org.bukkit.configuration.ConfigurationSection;

/** 原版逐箭魔力模式的独立策略；旧CHARGED_SHOT窗口及其配置不变。 */
public record AuraChargedShotSettings(double baseManaCost,double manaCostPerLevel,double baseDamagePercentPerMana,
                                     double damagePercentPerManaPerLevel,double maximumBonusPercent,double minimumForce,
                                     boolean alwaysEnabled,boolean showShotMessage,int maxProjectiles,int projectileLifetimeSeconds,int maximumBoostedHits) {
    public static AuraChargedShotSettings defaults(){return new AuraChargedShotSettings(10,5,.5,.1,25,.1,false,false,512,30,1);}
    public static AuraChargedShotSettings parse(ConfigurationSection root) {
        if(root==null || !root.contains("charged-shot"))return defaults();
        return new AuraChargedShotSettings(number(root,"base-mana-cost",0.1,1000),number(root,"mana-cost-per-level",0,1000),
                number(root,"base-damage-percent-per-mana",0.01,10),number(root,"damage-percent-per-mana-per-level",0,10),
                number(root,"maximum-bonus-percent",0.1,200),number(root,"minimum-force",0.01,1),
                bool(root,"always-enabled"),bool(root,"show-shot-message"),integer(root,"max-projectiles",1,8192),
                integer(root,"projectile-lifetime-seconds",1,60),integer(root,"maximum-boosted-hits",1,32));
    }
    public double manaCost(int rank){return rank<=0?0:Math.min(100000,baseManaCost+(rank-1.0)*manaCostPerLevel);}
    public double damagePercentPerMana(int rank){return rank<=0?0:baseDamagePercentPerMana+(rank-1.0)*damagePercentPerManaPerLevel;}
    private static double number(ConfigurationSection root,String key,double min,double max) {
        Object value=root.get("charged-shot."+key);
        if(!(value instanceof Number number) || !Double.isFinite(number.doubleValue()) || number.doubleValue()<min || number.doubleValue()>max)
            throw new IllegalArgumentException("mana_abilities.yml.charged-shot."+key+"：应为 "+min+" 至 "+max+" 的有限数字");
        return number.doubleValue();
    }
    private static int integer(ConfigurationSection root,String key,int min,int max){double value=number(root,key,min,max);if(value!=Math.rint(value))throw new IllegalArgumentException("charged-shot."+key+"：应为整数");return (int)value;}
    private static boolean bool(ConfigurationSection root,String key){if(!(root.get("charged-shot."+key) instanceof Boolean value))throw new IllegalArgumentException("charged-shot."+key+"：应为 true/false");return value;}
}
