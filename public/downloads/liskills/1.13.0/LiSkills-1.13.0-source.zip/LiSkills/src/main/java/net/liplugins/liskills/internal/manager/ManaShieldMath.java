package net.liplugins.liskills.internal.manager;

/** 将可用魔力换算为有上限的基础伤害抵消，不写玩家状态。 */
final class ManaShieldMath {
    private ManaShieldMath() { }
    static Absorption calculate(double damage,double mana,double manaPerDamage,double ratio) {
        if(!Double.isFinite(damage) || damage<=0 || !Double.isFinite(mana) || mana<=0
                || !Double.isFinite(manaPerDamage) || manaPerDamage<=0 || !Double.isFinite(ratio) || ratio<=0 || ratio>=1)
            return new Absorption(0,0);
        double absorbed=Math.min(damage*ratio,mana/manaPerDamage);
        return new Absorption(absorbed,Math.min(mana,absorbed*manaPerDamage));
    }
    record Absorption(double damage,double mana) { }
}
