package net.liplugins.liskills.lib.scheduler;

import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.plugin.IllegalPluginAccessException;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Objects;
import java.util.function.Function;
import java.util.function.Predicate;

/** 按全局、实体和位置选择真实调度器；除entityNow外，零延迟也至少等待下一tick。 */
public final class TaskScheduler implements AutoCloseable {
    private final SchedulerBackend backend;
    private final Predicate<Entity> owns;
    private final TaskScope tasks = new TaskScope();
    private final TaskScope pluginTasks;

    public TaskScheduler(JavaPlugin plugin) {
        this(ServerThreads.folia() ? new FoliaSchedulerBackend(Objects.requireNonNull(plugin)) : new BukkitSchedulerBackend(Objects.requireNonNull(plugin)),
                ServerThreads::owns, SchedulerLifecycle.scope(plugin));
    }

    TaskScheduler(SchedulerBackend backend, Predicate<Entity> owns, TaskScope pluginTasks) {
        this.backend = Objects.requireNonNull(backend);
        this.owns = Objects.requireNonNull(owns);
        this.pluginTasks = Objects.requireNonNull(pluginTasks);
    }

    public TaskHandle global(Runnable action) { return globalLater(action, 1); }
    public TaskHandle globalLater(Runnable action, long ticks) {
        long delay = delay(ticks);
        return submit(false, action, null, task -> backend.global(task::execute, delay, 0));
    }
    public TaskHandle globalTimer(Runnable action, long ticks, long period) {
        long delay = delay(ticks); requirePeriod(period);
        return submit(true, action, null, task -> backend.global(task::execute, delay, period));
    }
    public TaskHandle entity(Entity entity, Runnable action) { return entityLater(entity, action, 1, null); }
    public TaskHandle entity(Entity entity, Runnable action, Runnable retired) { return entityLater(entity, action, 1, retired); }
    public TaskHandle entityLater(Entity entity, Runnable action, long ticks) { return entityLater(entity, action, ticks, null); }
    public TaskHandle entityLater(Entity entity, Runnable action, long ticks, Runnable retired) {
        Objects.requireNonNull(entity); long delay = delay(ticks);
        return submit(false, action, retired, task -> backend.entity(entity, task::execute, task::retire, delay, 0));
    }
    public TaskHandle entityTimer(Entity entity, Runnable action, long ticks, long period) { return entityTimer(entity, action, ticks, period, null); }
    public TaskHandle entityTimer(Entity entity, Runnable action, long ticks, long period, Runnable retired) {
        Objects.requireNonNull(entity); long delay = delay(ticks); requirePeriod(period);
        return submit(true, action, retired, task -> backend.entity(entity, task::execute, task::retire, delay, period));
    }
    public TaskHandle region(Location location, Runnable action) { return regionLater(location, action, 1); }
    public TaskHandle regionLater(Location location, Runnable action, long ticks) {
        Location captured = Objects.requireNonNull(location).clone();
        Objects.requireNonNull(captured.getWorld(), "location.world");
        long delay = delay(ticks);
        return submit(false, action, null, task -> backend.region(captured, task::execute, delay));
    }
    public TaskHandle entityNow(Entity entity, Runnable action) { return entityNow(entity, action, null); }

    /** 仅原生归属检查通过才立即执行；不能用于需要等待事件最终状态的事务。 */
    public TaskHandle entityNow(Entity entity, Runnable action, Runnable retired) {
        Objects.requireNonNull(entity); Objects.requireNonNull(action);
        if (!owns.test(entity)) return entity(entity, action, retired);
        ManagedTask task = managed(false, action, retired);
        // 拥有者可以在正常停用回调里做即时清理，但已cancelAll的实例不可再次使用。
        if (!tasks.add(task)) task.retire();
        else task.execute();
        return task;
    }

    /** retired仅清Java缓存；排队已被拒绝时会在提交线程调用，不能访问实体/方块或调度新玩法。 */
    private TaskHandle submit(boolean repeating, Runnable action, Runnable retired, Function<ManagedTask, Runnable> scheduling) {
        ManagedTask task = managed(repeating, Objects.requireNonNull(action), retired);
        if (!tasks.add(task) || !pluginTasks.add(task) || !backend.enabled()) { task.retire(); return task; }
        try {
            Runnable cancellation = scheduling.apply(task);
            if (cancellation == null) task.retire();
            else task.bind(cancellation);
        } catch (IllegalPluginAccessException disabled) {
            task.retire();
            if (backend.enabled()) throw disabled;
        } catch (RuntimeException | Error error) {
            task.cancel();
            throw error;
        }
        return task;
    }
    private ManagedTask managed(boolean repeating, Runnable action, Runnable retired) {
        return new ManagedTask(repeating, action, retired, task -> { tasks.remove(task); pluginTasks.remove(task); });
    }
    private static long delay(long ticks) {
        if (ticks < 0) throw new IllegalArgumentException("delay must be non-negative");
        return Math.max(1, ticks);
    }
    private static void requirePeriod(long ticks) { if (ticks < 1) throw new IllegalArgumentException("period must be positive"); }
    /** 永久关闭本调度实例，取消所有自有句柄；不会取消其他实例或插件的任务。 */
    public void cancelAll() { tasks.close(); }
    /** 停用入口的最终兜底；即使插件监听器已注销，也能取消所有调度实例的实体/区域/全局任务。 */
    public static void cancelPlugin(JavaPlugin plugin) { SchedulerLifecycle.closePlugin(Objects.requireNonNull(plugin)); }
    @Override public void close() { cancelAll(); }
}
