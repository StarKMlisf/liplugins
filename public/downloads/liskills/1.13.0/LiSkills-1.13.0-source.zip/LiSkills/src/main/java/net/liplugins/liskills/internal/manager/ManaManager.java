package net.liplugins.liskills.internal.manager;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.storage.PlayerProfile;
import net.liplugins.liskills.internal.manager.stat.StatManager;
import net.liplugins.liskills.internal.manager.stat.StatTraits;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import net.liplugins.liskills.lib.scheduler.TaskHandle;
import net.liplugins.liskills.lib.scheduler.TaskScheduler;

/** 全局时钟只分派玩家任务；魔力和动态属性始终在玩家所属线程读取与更新。 */
public final class ManaManager implements AutoCloseable {
    private final ConfigManager config;
    private final ProfileManager profiles;
    private final SkillManager skills;
    private final StatManager stats;
    private final net.liplugins.liskills.lib.scheduler.PlayerTasks task;
    private final TaskScheduler scheduler;
    public ManaManager(JavaPlugin plugin,ConfigManager config,ProfileManager profiles,SkillManager skills) {
        this(plugin,config,profiles,skills,null);
    }
    public ManaManager(JavaPlugin plugin,ConfigManager config,ProfileManager profiles,SkillManager skills,StatManager stats) {
        this.config=config;this.profiles=profiles;this.skills=skills;this.stats=stats;
        scheduler=new TaskScheduler(plugin);
        task=new net.liplugins.liskills.lib.scheduler.PlayerTasks(plugin,this::regenerate,20,20);
    }
    public static double maximum(PlayerProfile profile,ConfigManager config) {
        if(config.progressionEnabled()) {
            return config.mana().baseMaximum()+StatTraits.value(config.stats(),StatManager.snapshotValues(profile,config),"max-mana");
        }
        int wisdom=0;
        for(String id:new String[]{"alchemy","enchanting"}) {
            var definition=config.skill(id);
            if(definition!=null && definition.enabled())wisdom+=Math.max(0,Math.min(profile.progress(id).level(),definition.maxLevel())-1);
        }
        return config.mana().baseMaximum()+wisdom*config.mana().perWisdomLevel();
    }
    public static double regeneration(PlayerProfile profile,ConfigManager config) {
        double bonus=config.progressionEnabled()?StatTraits.value(config.stats(),StatManager.snapshotValues(profile,config),"mana-regen"):0;
        return config.mana().regenPerSecond()+bonus;
    }
    public static double available(PlayerProfile profile,ConfigManager config) {
        return ManaMath.available(profile.mana(),maximum(profile,config));
    }
    public static boolean canAfford(PlayerProfile profile,ConfigManager config,double cost) {
        return Double.isFinite(cost) && cost>=0 && (!config.mana().enabled() || available(profile,config)>=cost);
    }
    public static void spend(PlayerProfile profile,ConfigManager config,double cost) {
        if(!canAfford(profile,config,cost))throw new IllegalArgumentException("mana cost");
        if(config.mana().enabled())profile.mana(ManaMath.spend(profile.mana(),maximum(profile,config),cost));
    }
    private void regenerate(Player player) {
        if(!config.mana().enabled() || player.isDead() || !skills.eligible(player))return;
        PlayerProfile profile=profiles.get(player.getUniqueId());if(profile==null)return;
        if(stats!=null)stats.values(player);
        profile.mana(Math.min(maximum(profile,config),available(profile,config)+regeneration(profile,config)));
    }
    public void close(){task.close();scheduler.cancelAll();}
}
