package net.liplugins.liskills.internal.menu;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.config.SkillDefinition;
import net.liplugins.liskills.internal.storage.PlayerProfile;
import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.inventory.Inventory;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** 仅绘制技能总览，保留已有布局键与槽位顺序。 */
final class SkillOverviewPage {
    private final ConfigManager config;
    private final TextService text;
    private final MenuItems items;
    private final MenuMaterials materials;
    private final SkillPresentation presentation;

    SkillOverviewPage(ConfigManager config, TextService text, SkillPresentation presentation) {
        this.config = config; this.text = text; this.presentation = presentation;
        this.items = new MenuItems(text); this.materials = new MenuMaterials(config);
    }

    Inventory create(PlayerProfile profile) {
        int size = Math.max(27, Math.min(54, config.menu().getInt("size", 54) / 9 * 9));
        int infoSlot = slot(config.menu().getInt("info-slot", size - 5), size);
        int closeSlot = slot(config.menu().getInt("close-slot", size - 1), size);
        List<SkillDefinition> definitions = config.skills().values().stream().filter(SkillDefinition::enabled).toList();
        List<Integer> skillSlots = availableSlots(size, infoSlot, closeSlot);
        Map<Integer, String> mapping = new LinkedHashMap<>();
        for (int index = 0; index < Math.min(definitions.size(), skillSlots.size()); index++) {
            mapping.put(skillSlots.get(index), definitions.get(index).id());
        }
        Map<Integer,MenuAction> actions=SkillMenuHolder.overviewActions(mapping,closeSlot);
        actions.put(infoSlot,new MenuAction(MenuAction.Type.STATS,null,0));
        SkillMenuHolder holder = new SkillMenuHolder(profile.uuid(), SkillMenuHolder.Screen.OVERVIEW,
                null, 0, config.revision(), actions, closeSlot);
        Inventory inventory = Bukkit.createInventory(holder, size, text.text("menu.title", Map.of("player", profile.name())));
        holder.inventory(inventory);
        if (config.menu().getBoolean("fill", true)) {
            Material filler = materials.get("filler-material", Material.GRAY_STAINED_GLASS_PANE);
            for (int index = 0; index < size; index++) inventory.setItem(index, items.item(filler, "menu.filler-name", null, Map.of()));
        }
        if (closeSlot >= 0) inventory.setItem(closeSlot, items.item(materials.get("icons.close", Material.BARRIER),
                "menu.close-name", "menu.close-lore", Map.of()));
        refresh(inventory, holder, profile);
        return inventory;
    }

    void refresh(Inventory inventory, SkillMenuHolder holder, PlayerProfile profile) {
        holder.actions().forEach((slot, action) -> {
            if (action.type() != MenuAction.Type.DETAIL) return;
            SkillDefinition skill = config.skill(action.skill());
            if (skill != null && skill.enabled()) inventory.setItem(slot, items.item(skill.icon(),
                    "menu.skill-name", "menu.skill-lore", presentation.values(skill, profile)));
        });
        int infoSlot = slot(config.menu().getInt("info-slot", inventory.getSize() - 5), inventory.getSize());
        if (infoSlot >= 0) inventory.setItem(infoSlot, items.item(materials.get("icons.info", Material.PLAYER_HEAD),
                "menu.info-name", "menu.info-lore", presentation.overview(profile)));
        if(infoSlot>=0)RpgMenuItems.append(inventory.getItem(infoSlot),text.lines("rpg.stats-entry",Map.of()));
    }

    private List<Integer> availableSlots(int size, int infoSlot, int closeSlot) {
        List<Integer> result = new ArrayList<>();
        for (int slot : config.menu().getIntegerList("skill-slots")) {
            if (slot >= 0 && slot < size && slot != infoSlot && slot != closeSlot && !result.contains(slot)) result.add(slot);
        }
        for (int index = 0; index < size; index++) {
            if (index != infoSlot && index != closeSlot && !result.contains(index)) result.add(index);
        }
        return result;
    }

    private int slot(int slot, int size) { return slot >= 0 && slot < size ? slot : -1; }
}
