package net.liplugins.liskills.internal.manager.hud;

/** 每位玩家只保留最近一种技能的短时经验，避免逐条通知或无限历史缓存。 */
final class HudExperience {
    private String skill;
    private double gain;
    private long expires;

    void add(String skill, double amount, long now, int durationSeconds) {
        if (skill == null || skill.isBlank() || !Double.isFinite(amount) || amount <= 0) return;
        gain = skill.equals(this.skill) && visible(now) ? Math.min(1e15, gain + amount) : Math.min(1e15, amount);
        this.skill = skill;
        expires = now + durationSeconds * 1000L;
    }

    boolean visible(long now) { return skill != null && now < expires; }
    String skill() { return skill; }
    double gain() { return gain; }
    long expires() { return expires; }
}
