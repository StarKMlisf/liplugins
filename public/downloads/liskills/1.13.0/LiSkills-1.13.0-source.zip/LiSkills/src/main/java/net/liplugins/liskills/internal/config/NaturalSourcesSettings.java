package net.liplugins.liskills.internal.config;

import org.bukkit.configuration.ConfigurationSection;
import java.util.Map;

/** 额外自然来源的独立配置；原有材料经验仍来自skills.yml，不覆盖管理员已有经验表。 */
public record NaturalSourcesSettings(boolean verticalPlantsEnabled, int maximumPlantBlocks,
                                     boolean berryStateMultiplier, boolean pickleStateMultiplier,
                                     boolean silkTouchMineralLuck, boolean fishingCategoriesEnabled,
                                     Map<String,Double> fishingExperience, AgilitySourceSettings agility) {
    public NaturalSourcesSettings { fishingExperience = Map.copyOf(fishingExperience); }
    public double fishingXp(String category) { return fishingExperience.getOrDefault(category,0.0); }
    public static NaturalSourcesSettings parse(ConfigurationSection root) {
        if(root==null || integer(root,"config-version",1,1)!=1)throw new IllegalArgumentException("sources.yml配置版本必须为1");
        return new NaturalSourcesSettings(bool(root,"blocks.vertical-plants"),integer(root,"blocks.maximum-plant-blocks",1,256),
                bool(root,"blocks.berry-state-multiplier"),bool(root,"blocks.pickle-state-multiplier"),bool(root,"blocks.silk-touch-mineral-luck"),
                bool(root,"fishing.enabled"),Map.of("treasure",number(root,"fishing.categories.treasure",0,1e9),"junk",number(root,"fishing.categories.junk",0,1e9),
                        "rare",number(root,"fishing.categories.rare",0,1e9),"epic",number(root,"fishing.categories.epic",0,1e9)),
                AgilitySourceSettings.parse(root.getConfigurationSection("agility")));
    }
    static boolean bool(ConfigurationSection root,String path) {
        Object value=root==null?null:root.get(path); if(!(value instanceof Boolean result))throw new IllegalArgumentException("sources.yml "+path+"必须为true/false"); return result;
    }
    static double number(ConfigurationSection root,String path,double min,double max) {
        Object raw=root==null?null:root.get(path); double value=raw instanceof Number number?number.doubleValue():Double.NaN;
        if(!Double.isFinite(value) || value<min || value>max)throw new IllegalArgumentException("sources.yml "+path+"必须为"+min+"～"+max+"的有限数字"); return value;
    }
    static int integer(ConfigurationSection root,String path,int min,int max) {
        double value=number(root,path,min,max); if(value!=Math.rint(value))throw new IllegalArgumentException("sources.yml "+path+"必须为整数"); return (int)value;
    }
}
