package net.liplugins.liskills.internal.config;

import org.bukkit.configuration.ConfigurationSection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** 被动文件独立校验，参与主配置的原子快照，不允许损坏配置替换现有能力。 */
public final class PassiveSettings {
    private PassiveSettings() { }
    public static Map<String,PassiveDefinition> parse(ConfigurationSection root, Set<String> skills) {
        ConfigurationSection section=root.getConfigurationSection("abilities");
        if(section==null)throw invalid("abilities","能力配置节");
        Map<String,PassiveDefinition> result=new LinkedHashMap<>();
        for(String id:section.getKeys(false)) {
            ConfigurationSection node=section.getConfigurationSection(id);
            if(node==null)throw invalid(id,"能力配置节");
            String skill=string(node,"skill");
            if(!skills.contains(skill))throw invalid(id+".skill","已注册技能ID");
            Map<String,Object> options=new LinkedHashMap<>();
            ConfigurationSection values=node.getConfigurationSection("options");
            if(values==null)throw invalid(id+".options","配置节，可用{}");
            for(var entry:values.getValues(false).entrySet()) {
                Object value=entry.getValue();
                if(value instanceof Number n) {
                    if(!Double.isFinite(n.doubleValue()) || Math.abs(n.doubleValue())>1e6)throw invalid(id+"."+entry.getKey(),"绝对值不超过1000000的有限数字");
                } else if(value instanceof List<?> list) {
                    if(list.stream().anyMatch(item->!(item instanceof String)))throw invalid(id+"."+entry.getKey(),"文本列表");
                    value=List.copyOf(list);
                } else if(!(value instanceof Boolean || value instanceof String))throw invalid(id+"."+entry.getKey(),"数字、开关或文本列表");
                options.put(entry.getKey(),value);
            }
            if(!(node.get("enabled") instanceof Boolean enabled))throw invalid(id+".enabled","true/false");
            result.put(id,new PassiveDefinition(id,skill,string(node,"name"),string(node,"description"),enabled,
                    integer(node,"unlock-level",1,1000),integer(node,"level-interval",1,1000),integer(node,"max-level",0,1000),
                    number(node,"base-value",0,1e6),number(node,"per-level",-1e6,1e6),number(node,"secondary-base",0,1e6),
                    number(node,"secondary-per-level",-1e6,1e6),options));
        }
        return java.util.Collections.unmodifiableMap(result);
    }
    private static String string(ConfigurationSection c,String key) {
        if(!(c.get(key) instanceof String text)||text.isBlank())throw invalid(c.getCurrentPath()+"."+key,"非空文本");
        return text;
    }
    private static double number(ConfigurationSection c,String key,double min,double max) {
        if(!(c.get(key) instanceof Number n)||!Double.isFinite(n.doubleValue())||n.doubleValue()<min||n.doubleValue()>max)
            throw invalid(c.getCurrentPath()+"."+key,min+"至"+max+"的有限数字");
        return n.doubleValue();
    }
    private static int integer(ConfigurationSection c,String key,int min,int max) {
        double value=number(c,key,min,max);
        if(value!=Math.rint(value))throw invalid(c.getCurrentPath()+"."+key,"整数");
        return (int)value;
    }
    private static IllegalArgumentException invalid(String key,String expected) { return new IllegalArgumentException(key+"：应为"+expected); }
}
