package net.liplugins.liskills.internal.storage;

import java.io.IOException;
import java.util.List;
import java.util.UUID;

/** 迁移源的接口级只读保护，不能通过常规save或仅缺失插入修改。 */
public final class ReadOnlyProfileRepository implements ProfileRepository {
    private final ProfileRepository delegate;
    public ReadOnlyProfileRepository(ProfileRepository delegate){this.delegate=delegate;}
    public ProfileSnapshot load(UUID uuid,String name)throws Exception{return delegate.load(uuid,name);}
    public List<ProfileSnapshot> loadAll()throws Exception{return delegate.loadAll();}
    public void save(ProfileSnapshot snapshot)throws IOException{throw new IOException("read-only-profile-repository");}
    public boolean insertIfAbsent(ProfileSnapshot snapshot)throws IOException{throw new IOException("read-only-profile-repository");}
    public void close()throws Exception{delegate.close();}
}
