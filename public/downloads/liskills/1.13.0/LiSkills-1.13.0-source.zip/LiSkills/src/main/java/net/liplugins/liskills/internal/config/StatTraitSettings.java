package net.liplugins.liskills.internal.config;

/** 将属性点转换为具体效果的系数；百分比类效果的单位是百分数。 */
public record StatTraitSettings(boolean enabled, double modifier) { }
