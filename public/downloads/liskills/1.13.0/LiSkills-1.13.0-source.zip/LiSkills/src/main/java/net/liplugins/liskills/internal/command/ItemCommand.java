package net.liplugins.liskills.internal.command;

import net.liplugins.liskills.internal.config.*;
import net.liplugins.liskills.internal.manager.item.*;
import net.liplugins.liskills.internal.manager.stat.StatManager;
import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.command.CommandSender;
import org.bukkit.inventory.ItemStack;
import java.util.*;

/** 管理员编辑手持物品副本；所有成功写入都经过相同PDC校验，第三方物品数据保持不变。 */
final class ItemCommand implements Subcommand {
    private final SenderChecks checks;private final TextService text;private final ConfigManager config;
    private final ItemMetadataService metadata;private final StatManager stats;private final AuraItemReader aura=new AuraItemReader();
    ItemCommand(SenderChecks checks,TextService text,ConfigManager config,ItemMetadataService metadata,StatManager stats){this.checks=checks;this.text=text;this.config=config;this.metadata=metadata;this.stats=stats;}
    public String name(){return "item";}public String permission(){return "liskills.admin";}
    public void execute(CommandSender sender,String[] args){
        var player=checks.player(sender);if(player==null||checks.profile(sender,player)==null)return;
        if(args.length==0){checks.usage(sender,"extended.usage-item");return;}
        ItemStack original=player.getInventory().getItemInMainHand();
        if(original.getType().isAir()){text.send(sender,"extended.item-empty");return;}
        String operation=args[0].toLowerCase(Locale.ROOT);
        if(operation.equals("inspect")&&args.length==1){
            var result=metadata.read(original);text.send(sender,"extended.item-inspect",Map.of("identity",metadata.identity(original),"valid",result.valid(),"count",result.rules().size()));
            result.rules().forEach(rule->text.send(sender,"extended.item-rule",Map.of("id",rule.id(),"slots",rule.slots(),"stats",rule.attributes(),"multiply",rule.statMultipliers(),"percent",rule.statPercentAdditions(),"traits",rule.traits(),"xp",rule.skillXpMultipliers(),"requirements",rule.requirements())));return;
        }
        if((operation.equals("legacy-preview")||operation.equals("aura-preview"))&&args.length==1){var preview=aura.preview(original);text.send(sender,"extended.item-aura-preview",Map.of("recognized",preview.recognized(),"complete",preview.complete(),"count",preview.rules().size(),"problems",preview.problems()));return;}
        try{
            ItemStack changed;
            if(operation.equals("clear")&&args.length==1)changed=metadata.clearRules(original);
            else if(operation.equals("remove")&&args.length==2)changed=metadata.removeRule(original,args[1]);
            else if(operation.equals("identify")&&args.length==2)changed=metadata.identify(original,args[1]);
            else if((operation.equals("legacy-migrate")||operation.equals("aura-migrate"))&&args.length==1)changed=aura.migrate(original,metadata);
            else changed=edit(original,operation,args);
            player.getInventory().setItemInMainHand(changed);player.saveData();stats.refreshAll();
            text.send(sender,"extended.item-saved");if(!config.items().enabled())text.send(sender,"extended.item-disabled");
        }catch(IllegalArgumentException error){text.send(sender,"extended.item-invalid");checks.usage(sender,"extended.usage-item");}
    }
    private ItemStack edit(ItemStack original,String operation,String[] args){
        boolean modifier=operation.equals("stat")||operation.equals("trait");
        if(!modifier&&!operation.equals("xp")&&!operation.equals("require"))throw new IllegalArgumentException("operation");
        int expected=modifier?5:4;if(args.length!=expected&&args.length!=expected+1)throw new IllegalArgumentException("arguments");
        var read=metadata.read(original);if(!read.valid())throw new IllegalArgumentException("data");
        Set<ItemSlot> slots=args.length==expected+1?Set.of(ItemSlot.valueOf(args[expected].toUpperCase(Locale.ROOT))):Set.of(ItemSlot.MAIN_HAND);
        ItemRule rule=read.rules().stream().filter(value->value.id().equals(args[1])).findFirst().orElseGet(()->ItemRuleEditor.named(args[1],slots));
        if(args.length==expected+1&&!rule.slots().equals(slots))throw new IllegalArgumentException("existing-slot");
        String id=args[2].toLowerCase(Locale.ROOT);
        if(modifier){
            var math=ItemModifierOperation.valueOf(args[3].toUpperCase(Locale.ROOT));double value=Double.parseDouble(args[4]);
            if(operation.equals("stat")){if(!StatsSettings.IDS.contains(id))throw new IllegalArgumentException("stat");rule=ItemRuleEditor.stat(rule,id,math,value);}
            else{if(!StatsSettings.TRAITS.contains(id))throw new IllegalArgumentException("trait");rule=ItemRuleEditor.trait(rule,id,math,value);}
        }else{
            if(!config.skills().containsKey(id)&&!(operation.equals("xp")&&id.equals("all")))throw new IllegalArgumentException("skill");
            if(operation.equals("xp"))rule=ItemRuleEditor.experience(rule,id,Double.parseDouble(args[3]));
            else rule=ItemRuleEditor.requirement(rule,id,Integer.parseInt(args[3]));
        }
        return metadata.putRule(original,rule);
    }
}
