package net.liplugins.liskills.internal.config;

import org.bukkit.configuration.ConfigurationSection;

/** 法术经验仅统计成功提交的主动能力魔力，不统计回蓝、失败退款或被动护盾扣蓝。 */
public record SorcerySourceSettings(boolean enabled,double manaXpPerPoint,double maximumXpPerMinute) {
    public static SorcerySourceSettings parse(ConfigurationSection section) {
        if(section==null)throw ConfigValues.invalid("legacy.sorcery","法术来源配置节");
        return new SorcerySourceSettings(ConfigValues.bool(section,"enabled"),
                ConfigValues.number(section,"mana-xp-per-point",0,1e9),
                ConfigValues.number(section,"maximum-xp-per-minute",1,1e9));
    }
    public double manaExperience(double spent) {
        if(!enabled || !Double.isFinite(spent) || spent<=0)return 0;
        double experience=spent*manaXpPerPoint;
        return Double.isFinite(experience)?Math.min(experience,maximumXpPerMinute):maximumXpPerMinute;
    }
}
