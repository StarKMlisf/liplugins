package net.liplugins.liskills.internal.manager.source;

import net.liplugins.liskills.lib.scheduler.ServerThreads;
import net.liplugins.liskills.lib.scheduler.TaskScheduler;

import net.liplugins.liskills.internal.config.AlchemySourceSettings;
import net.liplugins.liskills.internal.config.SourceSkillRoutingSettings;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.AreaEffectCloud;
import org.bukkit.entity.Player;
import org.bukkit.entity.ThrownPotion;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.function.Supplier;

/** 喷溅/滞留来源必须关联玩家真正消耗的一次投掷；药云多次扩散只领取一次。 */
final class AlchemySplashSourceListener implements Listener,AutoCloseable {
    private final SourceExperienceService rewards;private final Supplier<AlchemySourceSettings> settings;
    private final Supplier<SourceSkillRoutingSettings> routing;
    private final Map<UUID,Throw> throwsById=new java.util.concurrent.ConcurrentHashMap<>();private final Map<UUID,Cloud> clouds=new java.util.concurrent.ConcurrentHashMap<>();
    private final TaskScheduler scheduler;
    AlchemySplashSourceListener(JavaPlugin plugin,SourceExperienceService rewards,Supplier<AlchemySourceSettings> settings,Supplier<SourceSkillRoutingSettings> routing) {
        this.rewards=rewards;this.settings=settings;this.routing=routing;scheduler=new TaskScheduler(plugin);scheduler.globalTimer(this::cleanup,20,20);
    }
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void onLaunch(ProjectileLaunchEvent event) {
        if(!(event.getEntity() instanceof ThrownPotion potion) || !(potion.getShooter() instanceof Player player))return;
        var policy=settings.get();var session=rewards.capture(player,routing.get().potionThrowSkill());ItemStack item=SourceItemRules.copy(potion.getItem());
        if(!policy.enabled() || session==null || item==null || (item.getType()!=Material.SPLASH_POTION && item.getType()!=Material.LINGERING_POTION)
                || (policy.ignoreCustomItems() && SourceItemRules.custom(item)) || throwsById.containsKey(potion.getUniqueId())
                || throwsById.size()+clouds.size()>=policy.maximumProjectiles())return;
        String kind=SourceItemRules.potionKind(item);if(kind==null)return;
        if(!player.getInventory().getItemInMainHand().isSimilar(item) && !player.getInventory().getItemInOffHand().isSimilar(item))return;
        int before=SourceItemRules.count(player,item);Throw tracked=new Throw(event,session,item,kind,policy);
        throwsById.put(potion.getUniqueId(),tracked);
        if(!rewards.defer(player, ()->{
            tracked.confirmed=ServerThreads.owns(potion) && !event.isCancelled() && rewards.valid(session) && SourceItemRules.count(player,item)<before
                    && potion.getItem().isSimilar(item);
            if(!tracked.confirmed)throwsById.remove(potion.getUniqueId(),tracked);
        }))throwsById.remove(potion.getUniqueId(),tracked);
    }
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void onSplash(PotionSplashEvent event) {
        Throw tracked=throwsById.get(event.getEntity().getUniqueId());
        if(tracked==null || tracked.pending || tracked.item.getType()!=Material.SPLASH_POTION)return;
        tracked.pending=true;
        if(!rewards.defer(tracked.session.player(), ()->{
            throwsById.remove(event.getEntity().getUniqueId(),tracked);
            if(event.isCancelled() || !valid(tracked) || (tracked.policy.requireSplashTarget()
                    && event.getAffectedEntities().stream().noneMatch(entity->event.getIntensity(entity)>0)))return;
            rewards.award(tracked.session,"splash",tracked.policy.xp("splash."+tracked.kind),tracked.policy.splashCooldownTicks(),tracked.policy.maximumXpPerMinute());
        }))tracked.pending=false;
    }
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void onLingering(LingeringPotionSplashEvent event) {
        Throw tracked=throwsById.get(event.getEntity().getUniqueId());
        if(tracked==null || tracked.pending || tracked.item.getType()!=Material.LINGERING_POTION)return;
        tracked.pending=true;
        if(!rewards.defer(event.getAreaEffectCloud(), ()->{
            throwsById.remove(event.getEntity().getUniqueId(),tracked);AreaEffectCloud cloud=event.getAreaEffectCloud();
            if(event.isCancelled() || !cloud.isValid() || cloud.isDead()
                    || cloud.getSource()!=tracked.session.player())return;
            UUID uuid=cloud.getUniqueId();
            rewards.defer(tracked.session.player(),()->{
                if(!valid(tracked))return;
                if(!tracked.policy.requireSplashTarget())awardCloud(tracked);
                else if(clouds.size()<tracked.policy.maximumProjectiles())clouds.put(uuid,new Cloud(cloud,tracked));
            });
        }))tracked.pending=false;
    }
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void onCloudApply(AreaEffectCloudApplyEvent event) {
        Cloud cloud=clouds.get(event.getEntity().getUniqueId());
        if(cloud==null || cloud.pending || event.getAffectedEntities().isEmpty())return;
        cloud.pending=true;
        if(!rewards.defer(cloud.source.session.player(), ()->{
            cloud.pending=false;
            if(event.isCancelled() || event.getAffectedEntities().isEmpty() || !valid(cloud.source))return;
            if(clouds.remove(event.getEntity().getUniqueId(),cloud))awardCloud(cloud.source);
        }))cloud.pending=false;
    }
    private void awardCloud(Throw tracked){rewards.award(tracked.session,"lingering",tracked.policy.xp("lingering."+tracked.kind),tracked.policy.splashCooldownTicks(),tracked.policy.maximumXpPerMinute());}
    private boolean valid(Throw tracked){return tracked.confirmed && !tracked.launch.isCancelled() && rewards.valid(tracked.session) && settings.get().enabled() && !expired(tracked);}
    private boolean expired(Throw tracked){return System.currentTimeMillis()-tracked.created>tracked.policy.projectileLifetimeSeconds()*1000L;}
    private void cleanup(){throwsById.values().removeIf(value->expired(value) || value.session.revision()!=rewards.revision());clouds.values().removeIf(value->expired(value.source) || value.source.session.revision()!=rewards.revision());}
    @Override public void close(){scheduler.cancelAll();throwsById.clear();clouds.clear();}
    private static final class Throw {
        final ProjectileLaunchEvent launch;final SourceExperienceService.Session session;final ItemStack item;final String kind;
        final AlchemySourceSettings policy;final long created=System.currentTimeMillis();volatile boolean confirmed,pending;
        Throw(ProjectileLaunchEvent launch,SourceExperienceService.Session session,ItemStack item,String kind,AlchemySourceSettings policy){this.launch=launch;this.session=session;this.item=item;this.kind=kind;this.policy=policy;}
    }
    private static final class Cloud {final AreaEffectCloud entity;final Throw source;volatile boolean pending;Cloud(AreaEffectCloud entity,Throw source){this.entity=entity;this.source=source;}}
}
