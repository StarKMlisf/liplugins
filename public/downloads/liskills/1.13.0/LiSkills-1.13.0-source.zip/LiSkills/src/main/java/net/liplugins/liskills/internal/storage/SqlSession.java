package net.liplugins.liskills.internal.storage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/** 单IO线程的一条JDBC会话；MySQL锁随连接持有，事务提交不会释放。 */
public final class SqlSession implements AutoCloseable {
    @FunctionalInterface public interface ConnectionFactory { Connection connect()throws SQLException; }
    private final ConnectionFactory factory;
    private final AutoCloseable driver;
    private final String lockName;
    private final int queryTimeout;
    private Connection connection;
    public SqlSession(ConnectionFactory factory,AutoCloseable driver,String lockName,int queryTimeout){this.factory=factory;this.driver=driver;this.lockName=lockName;this.queryTimeout=queryTimeout;}
    public Connection connection()throws SQLException{
        if(connection!=null){try{if(connection.isClosed()||!connection.isValid(Math.min(3,queryTimeout)))invalidate();}catch(SQLException error){invalidate();}}
        if(connection==null){
            Connection opened=factory.connect();
            try{
                opened.setAutoCommit(true);
                if(lockName!=null){try(PreparedStatement statement=opened.prepareStatement("SELECT GET_LOCK(?, 0)")){
                    statement.setQueryTimeout(queryTimeout);statement.setString(1,lockName);
                    try(var result=statement.executeQuery()){if(!result.next()||result.getInt(1)!=1||result.wasNull())throw new SQLException("storage-in-use: MySQL database/table prefix is owned by another server");}
                }}
                connection=opened;
            }catch(SQLException error){try{opened.close();}catch(SQLException close){error.addSuppressed(close);}throw error;}
        }
        if(lockName!=null){
            try(PreparedStatement statement=connection.prepareStatement("SELECT IS_USED_LOCK(?) = CONNECTION_ID()")){
                statement.setQueryTimeout(queryTimeout);statement.setString(1,lockName);
                try(var result=statement.executeQuery()){if(!result.next()||result.getInt(1)!=1||result.wasNull())throw new SQLException("storage-exclusive-lock-lost");}
            }catch(SQLException error){invalidate();throw error;}
        }
        return connection;
    }
    public PreparedStatement prepare(String sql)throws SQLException{
        var statement=connection().prepareStatement(sql);
        try{statement.setQueryTimeout(queryTimeout);return statement;}
        catch(SQLException error){try{statement.close();}catch(SQLException close){error.addSuppressed(close);}throw error;}
    }
    public void invalidate(){if(connection!=null){try{connection.close();}catch(SQLException ignored){}connection=null;}}
    @Override public void close()throws Exception{invalidate();driver.close();}
}
