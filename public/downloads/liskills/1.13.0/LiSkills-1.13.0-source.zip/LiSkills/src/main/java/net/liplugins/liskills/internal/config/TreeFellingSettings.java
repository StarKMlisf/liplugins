package net.liplugins.liskills.internal.config;

/** 砍树任务的硬限制；限制总破坏量、总扫描量、每 tick 工作量及空间范围。 */
public record TreeFellingSettings(int maxBlocks, int maxScans, int blocksPerTick, int radius) { }
