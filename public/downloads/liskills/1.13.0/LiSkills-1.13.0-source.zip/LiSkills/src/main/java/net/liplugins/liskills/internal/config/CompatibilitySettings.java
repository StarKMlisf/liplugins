package net.liplugins.liskills.internal.config;

public record CompatibilitySettings(boolean liRealEnchant,boolean secondaryBlockXp,boolean bedrockEnchantingXp,
                                     boolean skipSecondaryDamageBonus) { }
