package net.liplugins.liskills.internal.util;

import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;

/** 工具身份快照：保留名称/附魔/PDC等资料，忽略数量和正常损耗。 */
public final class ToolIdentity {
    private ToolIdentity() { }
    public static ItemStack snapshot(ItemStack source) {
        ItemStack copy=source.clone();copy.setAmount(1);
        var meta=copy.getItemMeta();
        if(meta instanceof Damageable damage){damage.setDamage(0);copy.setItemMeta(meta);}
        return copy;
    }
}
