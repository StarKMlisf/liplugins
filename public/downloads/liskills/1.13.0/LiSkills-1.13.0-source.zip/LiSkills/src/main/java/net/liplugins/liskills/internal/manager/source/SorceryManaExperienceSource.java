package net.liplugins.liskills.internal.manager.source;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.manager.ProfileManager;
import net.liplugins.liskills.internal.manager.SkillManager;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

/** 主动能力魔力经验的单次凭据；具体施法管理器只在费用不再退款时提交。 */
public final class SorceryManaExperienceSource implements AutoCloseable {
    private final ConfigManager config;
    private final SourceExperienceService rewards;
    private boolean closed;

    public SorceryManaExperienceSource(JavaPlugin plugin,ConfigManager config,ProfileManager profiles,SkillManager skills) {
        this.config=config;rewards=new SourceExperienceService(plugin,config,profiles,skills);
    }
    public Receipt capture(Player player,double consumedMana) {
        var policy=config.sorcerySources();
        if(closed || !config.mana().enabled())return null;
        double experience=policy.manaExperience(consumedMana);
        if(experience<=0)return null;
        var session=rewards.capture(player,"sorcery");
        return session==null?null:new Receipt(this,session,experience,policy.maximumXpPerMinute());
    }
    public void complete(Receipt receipt) {
        if(receipt==null || receipt.owner!=this || receipt.completed || closed)return;
        // 先关闭凭据再发送可被其他插件取消的公开经验事件，防回调重入与重复结算。
        receipt.completed=true;
        rewards.award(receipt.session,"mana-ability",receipt.experience,0,receipt.maximum);
    }
    @Override public void close() { closed=true;rewards.close(); }

    /** 只携带捕获时角色/配置世代，不读取当前施法者资料来替代旧凭据。 */
    public static final class Receipt {
        private final SorceryManaExperienceSource owner;
        private final SourceExperienceService.Session session;
        private final double experience,maximum;
        private boolean completed;
        private Receipt(SorceryManaExperienceSource owner,SourceExperienceService.Session session,double experience,double maximum) {
            this.owner=owner;this.session=session;this.experience=experience;this.maximum=maximum;
        }
    }
}
