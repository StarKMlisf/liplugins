package net.liplugins.liskills.internal.manager;

/** 魔力余额的纯计算；0 是耗尽，只有 -1 表示旧档案尚未初始化。 */
public final class ManaMath {
    private ManaMath() { }
    public static double available(double stored,double maximum) {
        if(!Double.isFinite(maximum) || maximum<=0 || !Double.isFinite(stored) || (stored<0 && stored!=-1))throw new IllegalArgumentException("mana");
        return stored==-1?maximum:Math.min(stored,maximum);
    }
    public static double spend(double stored,double maximum,double cost) {
        double current=available(stored,maximum);
        if(!Double.isFinite(cost) || cost<0 || cost>current)throw new IllegalArgumentException("cost");
        return current-cost;
    }
}
