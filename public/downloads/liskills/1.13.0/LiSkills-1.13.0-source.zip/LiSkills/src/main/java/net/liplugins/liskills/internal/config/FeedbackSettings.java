package net.liplugins.liskills.internal.config;

import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;

/** 原生 BossBar 的短时经验反馈选项。 */
public record FeedbackSettings(boolean enabled,int durationSeconds,BarColor color,BarStyle style) { }
