package net.liplugins.liskills.internal.config;

import org.bukkit.configuration.ConfigurationSection;
import java.util.*;

/** 主动能力等级独立于被动；沿用 skills.yml 的基础值，升级只增加此处配置的差值。 */
public record ActiveGrowth(boolean enabled,int interval,int maximum,double durationPerLevel,
                           double cooldownPerLevel,double manaPerLevel) {
    public int rank(int skillLevel,int unlock) {
        if(skillLevel<unlock)return 0;
        return Math.min(maximum,1+(skillLevel-unlock)/interval);
    }
    public ActiveSkill resolve(ActiveSkill base,int skillLevel) {
        return resolve(base,skillLevel,Integer.MAX_VALUE);
    }
    public ActiveSkill resolve(ActiveSkill base,int skillLevel,int maximumRank) {
        // 逐箭模式的费用由真实射击结算，不能把窗口成长误当作切换费用。
        if(!enabled || ActiveTimingRules.isToggle(base.type()))return base;
        int extra=Math.max(0,Math.min(maximumRank,rank(skillLevel,base.unlockLevel()))-1);
        boolean window=ActiveTimingRules.hasWindow(base.type());
        int duration=window?(int)Math.round(clamp(base.durationSeconds()+extra*durationPerLevel,1,120)):base.durationSeconds();
        int cooldown=(int)Math.round(clamp(base.cooldownSeconds()+extra*cooldownPerLevel,window?duration:1,86400));
        return new ActiveSkill(base.enabled(),base.name(),base.effect(),base.amplifier(),duration,cooldown,
                base.unlockLevel(),clamp(base.manaCost()+extra*manaPerLevel,0,100000),base.type());
    }
    private static double clamp(double n,double min,double max){return Math.max(min,Math.min(max,n));}
    public static Map<String,ActiveGrowth> parse(ConfigurationSection root,Set<String> skills) {
        ConfigurationSection section=root.getConfigurationSection("active-growth");
        if(section==null)throw new IllegalArgumentException("active-growth：应为主动能力成长配置节");
        Map<String,ActiveGrowth> result=new LinkedHashMap<>();
        for(String id:section.getKeys(false)) {
            ConfigurationSection s=section.getConfigurationSection(id);
            if(!skills.contains(id) || s==null)throw new IllegalArgumentException("active-growth."+id+"：技能ID或配置节无效");
            if(!(s.get("enabled") instanceof Boolean enabled))throw new IllegalArgumentException(id+".enabled：应为 true/false");
            result.put(id,new ActiveGrowth(enabled,integer(s,"level-interval",1,1000),integer(s,"max-level",1,1000),
                    number(s,"duration-per-level",0,120),number(s,"cooldown-per-level",-86400,86400),number(s,"mana-per-level",0,100000)));
        }
        return Collections.unmodifiableMap(result);
    }
    private static double number(ConfigurationSection s,String key,double min,double max) {
        Object v=s.get(key);
        if(!(v instanceof Number n) || !Double.isFinite(n.doubleValue()) || n.doubleValue()<min || n.doubleValue()>max)
            throw new IllegalArgumentException(s.getCurrentPath()+"."+key+"：应为 "+min+" 至 "+max+" 的有限数字");
        return n.doubleValue();
    }
    private static int integer(ConfigurationSection s,String key,int min,int max) {
        double n=number(s,key,min,max);
        if(n!=Math.rint(n))throw new IllegalArgumentException(s.getCurrentPath()+"."+key+"：应为整数");
        return (int)n;
    }
}
