package net.liplugins.liskills.internal.command;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.config.SkillDefinition;
import net.liplugins.liskills.internal.manager.ProfileManager;
import net.liplugins.liskills.internal.storage.PlayerProfile;
import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Locale;
import java.util.Map;
import net.liplugins.liskills.lib.scheduler.ServerThreads;
import net.liplugins.liskills.lib.scheduler.TaskScheduler;

/** 统一发送者权限、玩家类型、在线状态和档案就绪检查。 */
public final class SenderChecks {
    private final ConfigManager config;
    private final ProfileManager profiles;
    private final TextService text;

    public SenderChecks(ConfigManager config, ProfileManager profiles, TextService text) {
        this.config = config;
        this.profiles = profiles;
        this.text = text;
    }

    public boolean permission(CommandSender sender, String permission) {
        if (sender.hasPermission(permission)) return true;
        text.send(sender, "command.no-permission");
        return false;
    }

    public Player player(CommandSender sender) {
        if (sender instanceof Player player) return player;
        text.send(sender, "command.player-only");
        return null;
    }

    public Player online(CommandSender sender, String name) {
        Player player = Bukkit.getPlayerExact(name);
        if (player == null) text.send(sender, "command.player-not-found", Map.of("player", name));
        return player;
    }

    public PlayerProfile profile(CommandSender sender, Player player) {
        PlayerProfile profile = profiles.get(player.getUniqueId());
        if (profile == null) text.send(sender, "command.profile-loading");
        return profile;
    }

    /** 权限在发送者线程先检查；目标业务随后在目标玩家所属线程执行。 */
    public void onPlayer(Player player,Runnable action) {
        new TaskScheduler(config.plugin()).entityNow(player,()->{if(player.isOnline())action.run();});
    }

    public void globally(Runnable action) {
        if(ServerThreads.global())action.run();
        else new TaskScheduler(config.plugin()).global(action);
    }

    public SkillDefinition skill(CommandSender sender, String id) {
        SkillDefinition skill = config.skill(id.toLowerCase(Locale.ROOT));
        if (skill == null || !skill.enabled()) {
            text.send(sender, "command.unknown-skill", Map.of("skill", id));
            return null;
        }
        return skill;
    }

    public void usage(CommandSender sender, String key) {
        text.send(sender, "command.usage", Map.of("usage", ChatColor.stripColor(text.text(key))));
    }
}
