package net.liplugins.liskills.internal.storage.migration;

import org.bukkit.configuration.file.YamlConfiguration;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Map;

/** 离线CLI只输出纯文本；独立消息资源，不初始化Bukkit或服务器MiniMessage环境。 */
final class StorageMigrationMessages {
    private final YamlConfiguration messages=new YamlConfiguration();
    StorageMigrationMessages()throws Exception{
        try(var stream=getClass().getResourceAsStream("/storage-tool-messages.yml")){
            if(stream==null)throw new IllegalStateException("storage-tool-messages-missing");
            messages.load(new InputStreamReader(stream,StandardCharsets.UTF_8));
        }
    }
    String text(String key,Map<String,?> values){
        String result=messages.getString(key,key);
        for(var value:values.entrySet())result=result.replace("{"+value.getKey()+"}",String.valueOf(value.getValue()));
        return result;
    }
}
