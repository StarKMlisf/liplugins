package net.liplugins.liskills.internal.menu;

import net.liplugins.liskills.internal.config.ConfigManager;
import org.bukkit.Material;

/** 配置图标必须是非空气物品，最后一道保护避免错误图标使菜单无法打开。 */
final class MenuMaterials {
    private final ConfigManager config;
    MenuMaterials(ConfigManager config) { this.config = config; }

    Material get(String key, Material fallback) {
        Material result = Material.matchMaterial(config.menu().getString(key, fallback.name()));
        return result != null && result.isItem() && !result.isAir() ? result : fallback;
    }
}
