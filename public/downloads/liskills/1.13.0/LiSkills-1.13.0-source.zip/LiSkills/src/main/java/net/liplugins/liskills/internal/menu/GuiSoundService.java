package net.liplugins.liskills.internal.menu;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.entity.Player;

import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** 所有菜单共用音效配置；无效声音只提示一次，不影响安全取消点击。 */
public final class GuiSoundService {
    enum Cue { OPEN, CLICK, PAGE, CLOSE, SUCCESS, DENY, SILENT }
    private final ConfigManager config;
    private final TextService text;
    private final Set<String> warned = new HashSet<>();
    private long revision = -1;

    public GuiSoundService(ConfigManager config, TextService text) {
        this.config = config;
        this.text = text;
    }

    void play(Player player, Cue cue) {
        if (cue == Cue.SILENT || !config.menu().getBoolean("sounds.enabled", true)) return;
        if (revision != config.revision()) { revision = config.revision(); warned.clear(); }
        String path = "sounds." + cue.name().toLowerCase(Locale.ROOT);
        String soundName = config.menu().getString(path + ".sound", "UI_BUTTON_CLICK");
        try {
            Sound sound = Sound.valueOf(soundName.toUpperCase(Locale.ROOT));
            float volume = (float) Math.clamp(config.menu().getDouble(path + ".volume", 0.35), 0, 2);
            float pitch = (float) Math.clamp(config.menu().getDouble(path + ".pitch", 1), 0.5, 2);
            if (Float.isFinite(volume) && Float.isFinite(pitch)) player.playSound(player.getLocation(), sound, volume, pitch);
        } catch (IllegalArgumentException ex) {
            if (warned.add(soundName)) text.send(Bukkit.getConsoleSender(), "menu.sound-invalid", Map.of("sound", soundName));
        }
    }
}
