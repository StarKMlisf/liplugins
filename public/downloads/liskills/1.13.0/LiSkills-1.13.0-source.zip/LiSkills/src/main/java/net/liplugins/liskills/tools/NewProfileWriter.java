package net.liplugins.liskills.tools;

import org.bukkit.configuration.file.YamlConfiguration;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.List;

/** 只使用 CREATE_NEW 创建档案；不会调用覆盖式存储接口，也不会修改源文件。 */
final class NewProfileWriter {
    private final MigrationMessages messages;

    NewProfileWriter(MigrationMessages messages) {
        this.messages = messages;
    }

    Path write(Path targetDirectory, ImportCandidate candidate) throws IOException {
        YamlConfiguration yaml = new YamlConfiguration();
        yaml.set("schema-version", 1);
        yaml.setComments("schema-version", List.of(messages.text("comment.schema")));
        yaml.set("uuid", candidate.uuid().toString());
        yaml.setComments("uuid", List.of(messages.text("comment.uuid")));
        yaml.set("name", candidate.name());
        yaml.setComments("name", List.of(messages.text("comment.name")));
        yaml.createSection("skills");
        yaml.setComments("skills", List.of(messages.text("comment.skills")));
        candidate.skills().entrySet().stream().sorted(java.util.Map.Entry.comparingByKey()).forEach(entry -> {
            String base = "skills." + entry.getKey();
            yaml.set(base + ".level", entry.getValue().level());
            yaml.setComments(base + ".level", List.of(messages.text("comment.level")));
            yaml.set(base + ".xp", entry.getValue().xp());
            yaml.setComments(base + ".xp", List.of(messages.text("comment.xp")));
        });
        yaml.createSection("cooldowns");
        yaml.setComments("cooldowns", List.of(messages.text("comment.cooldowns")));
        Path target = targetDirectory.resolve(candidate.uuid() + ".yml");
        // 操作系统级拒绝覆盖，避免计划检查之后有其他进程创建同名档案。
        Files.writeString(target, yaml.saveToString(), StandardCharsets.UTF_8, StandardOpenOption.CREATE_NEW, StandardOpenOption.WRITE);
        return target;
    }
}
