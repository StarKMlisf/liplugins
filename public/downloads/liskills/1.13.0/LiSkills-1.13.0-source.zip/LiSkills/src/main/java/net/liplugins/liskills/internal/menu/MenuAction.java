package net.liplugins.liskills.internal.menu;

/** 菜单只保存明确动作与上下文，不从物品名称或 Lore 猜测玩家意图。 */
record MenuAction(Type type, String skill, int page) {
    enum Type { DETAIL, CAST, BACK, PREVIOUS, NEXT, REFRESH, CLOSE, PASSIVES, STATS }
}
