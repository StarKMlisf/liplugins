package net.liplugins.liskills.internal.manager.active;

import net.liplugins.liskills.internal.config.ActiveSkill;
import net.liplugins.liskills.internal.config.AuraManaSettings;
import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.manager.ActiveAbilityHandler;
import net.liplugins.liskills.internal.manager.ActiveSkillProgression;
import net.liplugins.liskills.internal.manager.ProfileManager;
import net.liplugins.liskills.internal.manager.SkillAbilityWindows;
import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlotGroup;
import org.bukkit.plugin.java.JavaPlugin;
import net.liplugins.liskills.lib.scheduler.TaskHandle;
import net.liplugins.liskills.lib.scheduler.TaskScheduler;
import net.liplugins.liskills.lib.scheduler.ServerThreads;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.Supplier;
import java.util.stream.Collectors;

/** 闪电之刃沿原版只提高剑的攻击速度，不生成闪电、额外攻击或修改装备属性。 */
public final class LightningBladeManager implements ActiveAbilityHandler,Listener,AutoCloseable {
    private static final Set<Material> SWORDS=Arrays.stream(Material.values()).filter(value->value.name().endsWith("_SWORD")).collect(Collectors.toUnmodifiableSet());
    private final ConfigManager config;
    private final ProfileManager profiles;
    private final SkillAbilityWindows windows;
    private final TextService text;
    private final Supplier<AuraManaSettings> settings;
    private final NamespacedKey modifierKey;
    private final Map<UUID,AttributeModifier> applied=new java.util.concurrent.ConcurrentHashMap<>();
    private final TaskScheduler scheduler;
    private final net.liplugins.liskills.lib.scheduler.PlayerTasks cleanup;

    public LightningBladeManager(JavaPlugin plugin,ConfigManager config,ProfileManager profiles,SkillAbilityWindows windows,
                                 TextService text,Supplier<AuraManaSettings> settings) {
        this.config=config;this.profiles=profiles;this.windows=windows;this.text=text;this.settings=settings;
        modifierKey=new NamespacedKey(plugin,"active_lightning_blade");
        scheduler = new TaskScheduler(plugin);
        cleanup=new net.liplugins.liskills.lib.scheduler.PlayerTasks(plugin,this::tick,1,1);
        Bukkit.getOnlinePlayers().forEach(player -> scheduler.entityNow(player, () -> removeStale(player)));
    }
    @Override public boolean activate(Player player,ActiveSkill active) {
        if(!ServerThreads.owns(player))return false;
        if(!SWORDS.contains(player.getInventory().getItemInMainHand().getType())){text.send(player,"ability.lightning-blade-tool");return false;}
        AttributeInstance attribute=player.getAttribute(Attribute.ATTACK_SPEED);
        var profile=profiles.get(player.getUniqueId());var skill=config.skill("fighting");
        if(attribute==null || profile==null || skill==null)return false;
        double percent=settings.get().lightningBlade().percent(ActiveSkillProgression.rank(config,skill,profile));
        if(!Double.isFinite(percent) || percent<=0 || applied.size()>=2048)return false;
        if(windows.active(player,"fighting")){text.send(player,"ability.window-active");return false;}
        if(!windows.open(player,"fighting","LIGHTNING_BLADE",active,SWORDS))return false;
        removeStale(player);
        AttributeModifier modifier=new AttributeModifier(modifierKey,Math.min(percent,200)/100,
                AttributeModifier.Operation.MULTIPLY_SCALAR_1,EquipmentSlotGroup.ANY);
        try{net.liplugins.liskills.lib.scheduler.AttributeModifiers.add(attribute,modifier);applied.put(player.getUniqueId(),modifier);return true;}
        catch(RuntimeException failure){windows.remove(player,"fighting");throw failure;}
    }
    @Override public long remainingMillis(Player player){return windows.remainingMillis(player,"fighting");}
    private void tick(Player player) {
        if(applied.containsKey(player.getUniqueId()) && !windows.active(player,"fighting"))remove(player);
    }
    private void remove(Player player) {
        if(!ServerThreads.owns(player))return;
        AttributeModifier expected=applied.remove(player.getUniqueId());AttributeInstance attribute=player.getAttribute(Attribute.ATTACK_SPEED);
        if(expected==null || attribute==null)return;
        // 只撤销仍与本次写入一致的自身modifier，不清理别的插件或恢复基础属性旧快照。
        for(AttributeModifier current:attribute.getModifiers())if(current.equals(expected))attribute.removeModifier(current);
    }
    private void removeStale(Player player) {
        if(!ServerThreads.owns(player))return;
        AttributeInstance attribute=player.getAttribute(Attribute.ATTACK_SPEED);
        if(attribute!=null)for(AttributeModifier modifier:attribute.getModifiers())if(modifier.getKey().equals(modifierKey))attribute.removeModifier(modifier);
    }
    @EventHandler public void onJoin(PlayerJoinEvent event){removeStale(event.getPlayer());}
    @EventHandler public void onQuit(PlayerQuitEvent event){remove(event.getPlayer());}
    @EventHandler public void onDeath(PlayerDeathEvent event){remove(event.getEntity());}
    @Override public void close(){cleanup.close();scheduler.cancelAll();Bukkit.getOnlinePlayers().forEach(this::remove);applied.clear();}
}
