package net.liplugins.liskills.internal.manager.jobs;

import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.persistence.PersistentDataType;
import java.util.*;

/** 职业选择独立存于玩家PDC；只处理自身键，损坏数据不自动清空。 */
public final class JobSelectionStore {
    private static final NamespacedKey JOBS=new NamespacedKey("liskills","jobs");
    private static final NamespacedKey CHANGE=new NamespacedKey("liskills","jobs_change");
    public record Selection(boolean valid,Set<String> skills,long nextChange){public Selection{skills=Set.copyOf(skills);}}
    public Selection read(Player player){
        var pdc=player.getPersistentDataContainer();
        if((pdc.has(JOBS)&&!pdc.has(JOBS,PersistentDataType.STRING))||(pdc.has(CHANGE)&&!pdc.has(CHANGE,PersistentDataType.LONG)))return new Selection(false,Set.of(),Long.MAX_VALUE);
        String raw=pdc.getOrDefault(JOBS,PersistentDataType.STRING,"");
        if(raw.length()>3136)return new Selection(false,Set.of(),Long.MAX_VALUE);
        Set<String> result=new LinkedHashSet<>();
        if(!raw.isEmpty())for(String id:raw.split(",",-1))if(!id.matches("[a-z][a-z0-9_]{0,47}")||!result.add(id))return new Selection(false,Set.of(),Long.MAX_VALUE);
        long next=pdc.getOrDefault(CHANGE,PersistentDataType.LONG,0L);
        return new Selection(next>=0&&result.size()<=64,result,next);
    }
    public void save(Player player,Set<String> skills,long next){
        player.getPersistentDataContainer().set(JOBS,PersistentDataType.STRING,String.join(",",new TreeSet<>(skills)));
        player.getPersistentDataContainer().set(CHANGE,PersistentDataType.LONG,next);
        player.saveData();
    }
}
