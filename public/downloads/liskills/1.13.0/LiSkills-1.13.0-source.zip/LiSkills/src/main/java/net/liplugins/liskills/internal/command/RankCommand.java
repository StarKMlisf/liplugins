package net.liplugins.liskills.internal.command;

import net.liplugins.liskills.internal.manager.leaderboard.LeaderboardManager;
import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.command.CommandSender;
import java.util.Map;

/** 查询自己在已缓存排行内的位置。 */
final class RankCommand implements Subcommand {
    private final LeaderboardManager boards;private final SenderChecks checks;private final TextService text;
    RankCommand(LeaderboardManager boards,SenderChecks checks,TextService text){this.boards=boards;this.checks=checks;this.text=text;}
    public String name(){return "rank";}public String permission(){return "liskills.use";}
    public void execute(CommandSender sender,String[] args){if(args.length>1){checks.usage(sender,"extended.usage-rank");return;}var player=checks.player(sender);if(player==null)return;if(!boards.enabled()){text.send(sender,"extended.leaderboard-disabled");return;}String skill=args.length==0?"total":args[0].toLowerCase(java.util.Locale.ROOT);if(!skill.equals("total")&&checks.skill(sender,skill)==null)return;if(!boards.ready()){boards.refresh();text.send(sender,"extended.leaderboard-loading");return;}int rank=boards.rank(player.getUniqueId(),skill);text.send(sender,rank==0?"extended.rank-unavailable":"extended.rank",Map.of("rank",rank,"skill",skill));}
}
