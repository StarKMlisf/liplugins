package net.liplugins.liskills.internal.manager;

/** 单支箭的命中资格事务；只能在本次事件派发结束后的主线程 tick 结算。 */
final class ChargedShotAttempt {
    private enum State { READY, PENDING, CONSUMED }
    private State state = State.READY;

    synchronized boolean begin() {
        if (state != State.READY) return false;
        state = State.PENDING;
        return true;
    }

    synchronized boolean resolve(boolean cancelled, double finalDamage) {
        if (state == State.PENDING) {
            state = !cancelled && Double.isFinite(finalDamage) && finalDamage > 0 ? State.CONSUMED : State.READY;
        }
        return state == State.CONSUMED;
    }
}
