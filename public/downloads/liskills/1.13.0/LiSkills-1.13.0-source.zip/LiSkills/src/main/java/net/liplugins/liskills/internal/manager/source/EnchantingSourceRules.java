package net.liplugins.liskills.internal.manager.source;

import java.util.Map;
import java.util.Set;

/** 附魔来源的纯数值规则；诅咒与未实际写入/移除的附魔均不计数。 */
final class EnchantingSourceRules {
    private EnchantingSourceRules() { }
    static int addedLevels(Map<String,Integer> before,Map<String,Integer> requested,Map<String,Integer> actual,int maximum) {
        long total=0;
        for(var entry:requested.entrySet()) {
            int level=entry.getValue();
            if(level>0 && level>before.getOrDefault(entry.getKey(),0) && actual.getOrDefault(entry.getKey(),0)>=level)total+=level;
        }
        return (int)Math.min(Math.max(0,maximum),total);
    }
    static int removedLevels(Map<String,Integer> left,Map<String,Integer> right,Map<String,Integer> result,Set<String> blocked,int maximum) {
        long total=removed(left,result,blocked)+removed(right,result,blocked);
        return (int)Math.min(Math.max(0,maximum),total);
    }
    private static long removed(Map<String,Integer> input,Map<String,Integer> output,Set<String> blocked) {
        long total=0;
        for(var entry:input.entrySet()) {
            String full=entry.getKey(),shortName=full.substring(full.indexOf(':')+1);
            if(shortName.equals("binding_curse") || shortName.equals("vanishing_curse") || blocked.contains(full) || blocked.contains(shortName))continue;
            total+=Math.max(0,entry.getValue()-output.getOrDefault(full,0));
        }
        return total;
    }
}
