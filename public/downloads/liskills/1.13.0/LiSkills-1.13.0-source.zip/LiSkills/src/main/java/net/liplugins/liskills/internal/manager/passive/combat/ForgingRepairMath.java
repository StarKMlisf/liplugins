package net.liplugins.liskills.internal.manager.passive.combat;

/** 只计算已确认发生的耐久修复增益；不借预览次数、原料堆叠量额外放大。 */
final class ForgingRepairMath {
    private ForgingRepairMath() { }
    static int enhancedDamage(int inputDamage, int resultDamage, double percent) {
        if (inputDamage <= resultDamage || resultDamage < 0 || !Double.isFinite(percent) || percent <= 0) return resultDamage;
        long extra = Math.round((inputDamage - (double) resultDamage) * Math.min(1000, percent) / 100);
        return (int) Math.max(0, resultDamage - extra);
    }
    static int mendingAmount(double experience, int maximum) {
        return !Double.isFinite(experience) || experience <= 0 ? 0
                : (int) Math.clamp(Math.round(experience / 2), 0, Math.clamp(maximum, 1, 10_000));
    }
}
