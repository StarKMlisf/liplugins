package net.liplugins.liskills.internal.config;

/** 蓄力射击的触发阈值、伤害倍率和箭矢追踪硬上限。 */
public record ChargedShotSettings(double minimumForce, double damageMultiplier, int maxProjectiles,
                                  int projectileLifetimeSeconds) {
    public ChargedShotSettings {
        if (!Double.isFinite(minimumForce) || minimumForce < 0.1 || minimumForce > 1.0
                || !Double.isFinite(damageMultiplier) || damageMultiplier < 1.0 || damageMultiplier > 5.0
                || maxProjectiles < 1 || maxProjectiles > 8192
                || projectileLifetimeSeconds < 1 || projectileLifetimeSeconds > 60) {
            throw new IllegalArgumentException("charged shot settings");
        }
    }
}
