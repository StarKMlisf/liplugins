package net.liplugins.liskills.internal.storage;

import java.io.IOException;
import java.util.List;
import java.util.UUID;

/** 尚不存在的预检目标；没有目录、文件、连接或生命周期锁需要初始化。 */
public final class EmptyProfileRepository implements ProfileRepository {
    public ProfileSnapshot load(UUID uuid,String name)throws IOException{throw new IOException("preview-profile-does-not-exist");}
    public List<ProfileSnapshot> loadAll(){return List.of();}
    public void save(ProfileSnapshot snapshot)throws IOException{throw new IOException("read-only-profile-repository");}
    public boolean insertIfAbsent(ProfileSnapshot snapshot)throws IOException{throw new IOException("read-only-profile-repository");}
}
