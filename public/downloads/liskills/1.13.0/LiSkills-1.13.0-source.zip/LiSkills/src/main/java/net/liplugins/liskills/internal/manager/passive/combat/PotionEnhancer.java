package net.liplugins.liskills.internal.manager.passive.combat;

import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionType;
import java.util.List;
import java.util.Map;

/** 用基准服务端支持的 Bukkit 药水效果表达时长，只增强未定制的原版药水一次。 */
final class PotionEnhancer {
    private final PotionEnhancementData data;
    private final TextService text;
    PotionEnhancer(NamespacedKey marker,TextService text){this.data=new PotionEnhancementData(marker);this.text=text;}
    ItemStack enhance(ItemStack source,double percent,boolean lore) {
        if(source==null || percent<=0 || !Double.isFinite(percent) || !(source.getItemMeta() instanceof PotionMeta meta)) return source;
        // 第三方药水、已增强药水及瞬时药水均保持原样，避免改变别的插件的模型/属性契约。
        if(!timed(meta.getBasePotionType()) || externalMetadata(meta) || meta.hasCustomEffects() || meta.hasLore()
                || !meta.getPersistentDataContainer().getKeys().isEmpty()) return source;
        ItemStack result=source.clone();
        percent=Math.min(percent,1000);
        String generatedLore=lore?text.text("passive.alchemist-lore",Map.of("value",text.format(percent))):null;
        apply(meta,percent,generatedLore);
        result.setItemMeta(meta);
        return result;
    }

    /** 兼容第三方保留物品元数据的再酿造：仅重组输入/输出都仍完整归属本模块的增强。 */
    ItemStack rebase(ItemStack input,ItemStack result) {
        if(input==null || result==null || !(input.getItemMeta() instanceof PotionMeta before)
                || !(result.getItemMeta() instanceof PotionMeta after)) return result;
        PotionEnhancementData.Upgrade original=owned(before),current=owned(after);
        if(original==null || !original.equals(current) || before.getBasePotionType()!=original.base()
                || after.getBasePotionType()==null || after.getBasePotionType()==original.base()) return result;
        // 精确指纹已证明这些效果仍是本模块产生的旧效果；不批量清空第三方效果或PDC。
        for(PotionEffect effect:before.getCustomEffects()) after.removeCustomEffect(effect.getType());
        data.remove(after);
        if(original.lore()!=null) after.setLore(null);
        if(timed(after.getBasePotionType())) apply(after,original.bonus(),original.lore());
        ItemStack updated=result.clone();updated.setItemMeta(after);
        return updated;
    }

    private PotionEnhancementData.Upgrade owned(PotionMeta meta) {
        if(externalMetadata(meta)) return null;
        PotionEnhancementData.Upgrade upgrade=data.read(meta);
        if(upgrade==null || !timed(upgrade.base()) || !extended(upgrade.base(),upgrade.bonus()).equals(meta.getCustomEffects())) return null;
        return upgrade;
    }

    private void apply(PotionMeta meta,double percent,String generatedLore) {
        // 实际 Paper 26.1.2 build74 没有 durationScale，不能以不断变化的 Spigot SNAPSHOT 推断运行接口。
        // 保留基础类型以维持物品身份；同类型同等级的自定义效果由原版合并为更长持续时间，不叠加等级。
        extended(meta.getBasePotionType(),percent).forEach(effect->meta.addCustomEffect(effect,true));
        if(generatedLore!=null) meta.setLore(List.of(generatedLore));
        data.write(meta,meta.getBasePotionType(),percent,generatedLore);
    }

    private static List<PotionEffect> extended(PotionType type,double percent) {
        double multiplier=1+Math.min(percent,1000)/100;
        return type.getPotionEffects().stream().map(effect->{
            int duration=effect.getDuration()<=0?effect.getDuration():
                    (int)Math.min(Integer.MAX_VALUE,Math.round(effect.getDuration()*multiplier));
            return new PotionEffect(effect.getType(),duration,effect.getAmplifier(),
                    effect.isAmbient(),effect.hasParticles(),effect.hasIcon());
        }).toList();
    }

    private static boolean timed(PotionType type) {
        return type!=null && !type.getPotionEffects().isEmpty()
                && type.getPotionEffects().stream().noneMatch(effect->effect.getType().isInstant());
    }

    private static boolean externalMetadata(PotionMeta meta) {
        return meta.hasColor() || meta.hasCustomName() || meta.hasDisplayName() || meta.hasItemName()
                || meta.hasCustomModelDataComponent() || meta.hasItemModel() || meta.hasTooltipStyle()
                || meta.hasAttributeModifiers() || meta.hasEnchants();
    }
}
