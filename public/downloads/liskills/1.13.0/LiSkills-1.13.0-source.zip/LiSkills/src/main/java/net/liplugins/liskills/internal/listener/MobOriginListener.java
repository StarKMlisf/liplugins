package net.liplugins.liskills.internal.listener;

import net.liplugins.liskills.lib.scheduler.ServerThreads;

import org.bukkit.NamespacedKey;
import org.bukkit.entity.LivingEntity;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

/** 实体来源跟随实体保存；未知来源默认不当成自然生成。 */
public final class MobOriginListener implements Listener {
    private final NamespacedKey naturalKey;
    private final NamespacedKey awardedKey;

    public MobOriginListener(JavaPlugin plugin) {
        naturalKey = new NamespacedKey(plugin, "natural_spawn_v1");
        awardedKey = new NamespacedKey(plugin, "kill_awarded_v1");
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onSpawn(CreatureSpawnEvent event) {
        boolean natural = event.getSpawnReason() == CreatureSpawnEvent.SpawnReason.NATURAL
                || event.getSpawnReason().name().equals("CHUNK_GEN");
        event.getEntity().getPersistentDataContainer().set(naturalKey, PersistentDataType.BYTE, (byte) (natural ? 1 : 0));
    }

    public boolean natural(LivingEntity entity) {
        return ServerThreads.owns(entity) && entity.getPersistentDataContainer().getOrDefault(naturalKey, PersistentDataType.BYTE, (byte) 0) == 1;
    }

    public boolean markRewarded(LivingEntity entity) {
        if (!ServerThreads.owns(entity) || entity.getPersistentDataContainer().has(awardedKey, PersistentDataType.BYTE)) return false;
        entity.getPersistentDataContainer().set(awardedKey, PersistentDataType.BYTE, (byte) 1);
        return true;
    }
}
