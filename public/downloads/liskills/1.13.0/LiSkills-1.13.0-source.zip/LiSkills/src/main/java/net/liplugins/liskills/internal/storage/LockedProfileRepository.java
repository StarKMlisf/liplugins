package net.liplugins.liskills.internal.storage;

import java.util.List;
import java.util.UUID;

/** 装配文件独占锁，后端关闭完成后才允许另一个服务器打开数据。 */
public final class LockedProfileRepository implements ProfileRepository {
    private final ProfileRepository delegate;
    private final StorageFileLock lock;
    public LockedProfileRepository(ProfileRepository delegate,StorageFileLock lock){this.delegate=delegate;this.lock=lock;}
    public ProfileSnapshot load(UUID uuid,String name)throws Exception{return delegate.load(uuid,name);}
    public List<ProfileSnapshot> loadAll()throws Exception{return delegate.loadAll();}
    public void save(ProfileSnapshot snapshot)throws Exception{delegate.save(snapshot);}
    public boolean insertIfAbsent(ProfileSnapshot snapshot)throws Exception{return delegate.insertIfAbsent(snapshot);}
    public void close()throws Exception{try{delegate.close();}finally{lock.close();}}
}
