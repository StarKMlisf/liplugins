package net.liplugins.liskills.internal.command;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.menu.SkillMenu;
import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/** 能力目录入口；GUI 和能力计算由菜单与管理器负责。 */
final class AbilitiesCommand implements Subcommand {
    private final ConfigManager config;
    private final SenderChecks checks;
    private final SkillMenu menu;
    private final TextService text;

    AbilitiesCommand(ConfigManager config, SenderChecks checks, SkillMenu menu, TextService text) {
        this.config = config; this.checks = checks; this.menu = menu; this.text = text;
    }

    public String name() { return "abilities"; }
    public String permission() { return "liskills.use"; }
    public void execute(CommandSender sender, String[] arguments) {
        if (arguments.length != 1) { checks.usage(sender, "rpg-commands.usage-abilities"); return; }
        Player player = checks.player(sender);
        if (player == null) return;
        var skill = checks.skill(sender, arguments[0]);
        if (skill == null || !checks.permission(sender, "liskills.skill." + skill.id()) || checks.profile(sender, player) == null) return;
        if (!config.progressionEnabled()) { text.send(sender, "rpg-commands.disabled"); return; }
        menu.openPassives(player, skill.id());
    }
}
