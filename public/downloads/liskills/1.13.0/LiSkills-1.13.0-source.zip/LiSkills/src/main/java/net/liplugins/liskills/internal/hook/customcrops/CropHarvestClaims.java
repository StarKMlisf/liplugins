package net.liplugins.liskills.internal.hook.customcrops;

import java.util.HashMap;
import java.util.Map;

/** 按世界坐标而非玩家分配一次收获，防止两名玩家各自消费同一次状态变化。 */
final class CropHarvestClaims<K> {
    private final Map<K, CropHarvestAttempt> claims = new HashMap<>();

    synchronized boolean conflict(K position) {
        CropHarvestAttempt previous = claims.get(position);
        if (previous == null) return false;
        previous.invalidate();
        return true;
    }

    synchronized boolean reserve(K position, CropHarvestAttempt attempt) {
        CropHarvestAttempt previous = claims.putIfAbsent(position, attempt);
        if (previous == null || previous == attempt) return true;
        previous.invalidate();
        attempt.invalidate();
        return false;
    }

    synchronized void release(K position, CropHarvestAttempt attempt) { claims.remove(position, attempt); }
    synchronized void clear() { claims.clear(); }
}
