package net.liplugins.liskills.internal.config;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.EntityType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffectType;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/** 先完整校验所有配置文件，再一次替换内存快照；错误重载不会卸载现有技能。 */
public final class ConfigManager {
    private static final List<String> FILES = List.of("config.yml", "skills.yml", "messages.yml", "menu.yml", "abilities.yml", "stats.yml", "loot.yml", "items.yml", "balance.yml", "mana_abilities.yml", "xp_requirements.yml", "sources.yml", "rewards.yml", "jobs.yml", "leaderboards.yml", "storage.yml");
    private final JavaPlugin plugin;
    private volatile Snapshot snapshot;
    private volatile long revision;

    public ConfigManager(JavaPlugin plugin) { this.plugin = plugin; }
    public JavaPlugin plugin() { return plugin; }
    public Settings settings() { return snapshot.settings; }
    public ManaSettings mana() { return snapshot.mana; }
    public CompatibilitySettings compatibility() { return snapshot.compatibility; }
    public CustomCropsSettings customCrops() { return snapshot.customCrops; }
    public CustomFishingSettings customFishing() { return snapshot.customFishing; }
    public TreeFellingSettings treeFelling() { return snapshot.treeFelling; }
    public TerraformSettings terraform() { return snapshot.terraform; }
    public ReplenishSettings replenish() { return snapshot.replenish; }
    public FeedbackSettings feedback() { return snapshot.feedback; }
    public HudSettings hud() { return snapshot.hud; }
    public ChargedShotSettings chargedShot() { return snapshot.chargedShot; }
    public QuickFishSettings quickFish() { return snapshot.quickFish; }
    public ManaShieldSettings manaShield() { return snapshot.manaShield; }
    public boolean quickCast() { return snapshot.quickCast; }
    public boolean progressionEnabled() { return snapshot.progressionEnabled; }
    public Map<String, PassiveDefinition> passives() { return snapshot.passives; }
    public Map<String, ActiveGrowth> activeGrowth() { return snapshot.activeGrowth; }
    public StatsSettings stats() { return snapshot.stats; }
    public LootSettings loot() { return snapshot.loot; }
    public ItemSettings items() { return snapshot.items; }
    public BalanceSettings balance() { return snapshot.balance; }
    public AuraManaSettings auraMana() { return snapshot.auraMana; }
    public AuraChargedShotSettings auraChargedShot(){return snapshot.auraChargedShot;}
    public AbsorptionActivationSettings absorptionActivation(){return snapshot.absorptionActivation;}
    public NaturalSourcesSettings sources(){return snapshot.sources;}
    public RewardsSettings rewards(){return snapshot.rewards;}
    public JobsSettings jobs(){return snapshot.jobs;}
    public LeaderboardSettings leaderboards(){return snapshot.leaderboards;}
    public StorageSettings storage(){return snapshot.storage;}
    public AlchemySourceSettings alchemySources(){return snapshot.alchemySources;}
    public EnchantingSourceSettings enchantingSources(){return snapshot.enchantingSources;}
    public SourceSkillRoutingSettings sourceRouting(){return snapshot.sourceRouting;}
    public SorcerySourceSettings sorcerySources(){return snapshot.sorcerySources;}
    public Map<String, SkillDefinition> skills() { return snapshot.skills; }
    public SkillDefinition skill(String id) { return snapshot.skills.get(id); }
    public YamlConfiguration messages() { return snapshot.messages; }
    public YamlConfiguration menu() { return snapshot.menu; }
    public long revision() { return revision; }

    public synchronized void reload() throws Exception {
        Map<String, YamlConfiguration> files = readFiles();
        Snapshot next = parse(files);
        compatibleStorage(next);
        // 补全只写缺少的键和默认注释；不改管理员已有的值或注释。全部校验通过后才写盘。
        for (Map.Entry<String, YamlConfiguration> entry : files.entrySet()) {
            if (entry.getValue().getBoolean("__liskills_backfill", false)) {
                entry.getValue().set("__liskills_backfill", null);
                save(entry.getKey(), entry.getValue());
            }
        }
        snapshot = next;
        revision++;
    }

    public synchronized List<String> validate() {
        try { compatibleStorage(parse(readFiles())); return List.of(); }
        catch (Exception ex) { return List.of(ex.getMessage() == null ? ex.getClass().getSimpleName() : ex.getMessage()); }
    }

    private void compatibleStorage(Snapshot next){
        if(snapshot!=null&&!snapshot.storage.equals(next.storage))throw new IllegalArgumentException("storage.yml已更改：存储后端和连接设置必须停服重启后生效，本次重载未发布任何配置。");
    }

    private Map<String, YamlConfiguration> readFiles() throws Exception {
        Map<String, YamlConfiguration> files = new LinkedHashMap<>();
        for (String name : FILES) {
            YamlConfiguration defaults = new YamlConfiguration();
            defaults.options().parseComments(true);
            try (InputStream in = Objects.requireNonNull(plugin.getResource(name), name)) {
                defaults.load(new InputStreamReader(in, StandardCharsets.UTF_8));
            }
            YamlConfiguration current = new YamlConfiguration();
            current.options().parseComments(true);
            Path path = plugin.getDataFolder().toPath().resolve(name);
            if (Files.exists(path)) current.load(path.toFile());
            boolean changed = name.equals("skills.yml") && SkillConfigUpgrade.apply(current);
            if(name.equals("skills.yml"))changed |= AuraTemplateUpgrade.apply(current);
            if(name.equals("skills.yml"))changed |= SkillDescriptionUpgrade.apply(current,defaults);
            if(name.equals("menu.yml"))changed |= LegacyMenuUpgrade.apply(current,defaults);
            if(name.equals("abilities.yml"))changed |= LegacyPassiveUpgrade.apply(current,defaults);
            if(name.equals("messages.yml"))changed |= MessageConfigUpgrade.apply(current,defaults);
            for (String key : defaults.getKeys(true)) {
                if (defaults.isConfigurationSection(key)) {
                    if (current.contains(key) && !current.isConfigurationSection(key)) throw invalid(name + ":" + key, "配置节");
                    if (!current.contains(key)) {
                        current.createSection(key);
                        current.setComments(key, defaults.getComments(key));
                        changed = true;
                    }
                    if(current.getComments(key).isEmpty() && !defaults.getComments(key).isEmpty()) {
                        current.setComments(key,defaults.getComments(key)); changed=true;
                    }
                    continue;
                }
                if (!current.contains(key)) {
                    current.set(key, defaults.get(key));
                    current.setComments(key, defaults.getComments(key));
                    current.setInlineComments(key, defaults.getInlineComments(key));
                    changed = true;
                }
                // 参照 LiPet 的升级约定：已有值不动，缺失注释单独补齐。
                if(current.getComments(key).isEmpty() && !defaults.getComments(key).isEmpty()) {
                    current.setComments(key,defaults.getComments(key)); changed=true;
                }
            }
            if (changed || !Files.exists(path)) current.set("__liskills_backfill", true);
            files.put(name, current);
        }
        return files;
    }

    private Snapshot parse(Map<String, YamlConfiguration> files) {
        YamlConfiguration c = files.get("config.yml");
        if (!c.isList("disabled-worlds") || c.getList("disabled-worlds").stream().anyMatch(v -> !(v instanceof String)))
            throw invalid("disabled-worlds", "世界名称列表");
        Settings settings = new Settings(number(c,"xp-multiplier",0,100), integer(c,"autosave-seconds",10,3600),
                bool(c,"survival-only"), new HashSet<>(c.getStringList("disabled-worlds")),
                bool(c,"anti-exploit.placed-blocks"), bool(c,"anti-exploit.natural-mobs-only"),
                integer(c,"anti-exploit.damage-cooldown-seconds",1,3600), number(c,"max-award",1,1e9),
                number(c,"bonuses.fighting-per-level",0,0.1), number(c,"bonuses.archery-per-level",0,0.1),
                number(c,"bonuses.defense-per-level",0,0.1), number(c,"bonuses.maximum-damage-bonus",0,2),
                number(c,"bonuses.maximum-damage-reduction",0,0.8));
        ManaSettings mana=new ManaSettings(bool(c,"mana.enabled"),number(c,"mana.base-maximum",1,100000),
                number(c,"mana.per-wisdom-level",0,100),number(c,"mana.regen-per-second",0,1000));
        CompatibilitySettings compatibility=new CompatibilitySettings(bool(c,"compatibility.lirealenchant.enabled"),
                bool(c,"compatibility.lirealenchant.secondary-block-xp"),bool(c,"compatibility.lirealenchant.bedrock-enchanting-xp"),
                bool(c,"compatibility.lirealenchant.skip-secondary-damage-bonus"));
        CustomCropsSettings customCrops = new CustomCropsSettings(bool(c,"compatibility.customcrops.enabled"),
                number(c,"compatibility.customcrops.default-xp",0,1e9),CustomExperienceRates.parse(c,"compatibility.customcrops.crop-xp"));
        CustomFishingSettings customFishing = new CustomFishingSettings(bool(c,"compatibility.customfishing.enabled"),
                number(c,"compatibility.customfishing.default-xp",0,1e9),CustomExperienceRates.parse(c,"compatibility.customfishing.loot-xp"),
                bool(c,"compatibility.customfishing.quick-fish"));
        TreeFellingSettings tree=new TreeFellingSettings(integer(c,"tree-felling.max-blocks",1,512),integer(c,"tree-felling.max-scans",1,8192),
                integer(c,"tree-felling.blocks-per-tick",1,16),integer(c,"tree-felling.radius",1,16));
        TerraformSettings terraform=new TerraformSettings(integer(c,"terraform.max-blocks",1,256),integer(c,"terraform.max-scans",1,4096),
                integer(c,"terraform.blocks-per-tick",1,16),integer(c,"terraform.radius",1,16));
        ReplenishSettings replenish=new ReplenishSettings(integer(c,"replenish.delay-ticks",1,40),integer(c,"replenish.max-pending",1,4096),
                integer(c,"replenish.blocks-per-tick",1,64),bool(c,"replenish.consume-seed"),bool(c,"replenish.prevent-unripe-break"));
        FeedbackSettings feedback;
        try {
            feedback=new FeedbackSettings(bool(c,"feedback.enabled"),integer(c,"feedback.duration-seconds",1,30),
                    org.bukkit.boss.BarColor.valueOf(string(c,"feedback.color")),org.bukkit.boss.BarStyle.valueOf(string(c,"feedback.style")));
        }catch(IllegalArgumentException invalidFeedback){throw invalid("feedback", "合法BossBar开关/持续秒数/颜色/样式；详见config.yml注释");}
        ChargedShotSettings chargedShot=new ChargedShotSettings(number(c,"charged-shot.minimum-force",0.1,1),
                number(c,"charged-shot.damage-multiplier",1,5),integer(c,"charged-shot.max-projectiles",1,8192),
                integer(c,"charged-shot.projectile-lifetime-seconds",1,60));
        QuickFishSettings quickFish=new QuickFishSettings(number(c,"quick-fish.wait-multiplier",0.05,1),integer(c,"quick-fish.minimum-wait-ticks",1,1200));
        ManaShieldSettings manaShield=new ManaShieldSettings(number(c,"mana-shield.mana-per-damage",0.1,100),
                number(c,"mana-shield.maximum-absorption-ratio",0.01,0.95));
        integer(files.get("skills.yml"),"config-version",1,4);
        Map<String, SkillDefinition> definitions = new LinkedHashMap<>();
        ConfigurationSection skills = Objects.requireNonNull(files.get("skills.yml").getConfigurationSection("skills"));
        if(skills.getKeys(false).size()>64)throw invalid("skills","最多64种技能");
        XpRequirementsSettings xpRequirements=XpRequirementsSettings.parse(files.get("xp_requirements.yml"),skills.getKeys(false));
        BalanceSettings balance=BalanceSettings.parse(files.get("balance.yml"));
        for (String id : skills.getKeys(false)) {
            if (!id.matches("[a-z][a-z0-9_]{0,47}") || id.equals("total")) throw invalid("skills."+id,"1～48位小写字母/数字/下划线ID（首位字母，不能为total）");
            ConfigurationSection s = skills.getConfigurationSection(id);
            if (s == null) throw invalid("skills."+id,"配置节");
            Material icon = Material.matchMaterial(string(s,"icon"));
            if (icon == null || !icon.isItem() || icon.isAir()) throw invalid(id+".icon","物品材料名");
            int max = integer(s,"max-level",2,1000);
            ConfigurationSection a = s.getConfigurationSection("active");
            if (a == null) throw invalid(id+".active","配置节");
            String effect = string(a,"effect");
            if (PotionEffectType.getByName(effect) == null) throw invalid(id+".active.effect","Bukkit药水效果名");
            String activeType=string(a,"type").toUpperCase(Locale.ROOT);
            boolean specialized=switch(activeType) {
                case "TREECAPITATOR" -> id.equals("foraging");
                case "TERRAFORM" -> id.equals("excavation");
                case "REPLENISH" -> id.equals("farming");
                case "CHARGED_SHOT" -> id.equals("archery");
                case "QUICK_FISH" -> id.equals("fishing");
                case "MANA_SHIELD" -> id.equals("defense");
                case "SPEED_MINE" -> id.equals("mining");
                case "SHARP_HOOK" -> id.equals("fishing");
                case "ABSORPTION" -> id.equals("defense");
                case "LIGHTNING_BLADE" -> id.equals("fighting");
                case "AURA_CHARGED_SHOT" -> id.equals("archery");
                default -> false;
            };
            if(!activeType.equals("POTION") && !specialized)throw invalid(id+".active.type","POTION或对应技能的内置主动类型，详见mana_abilities.yml和主动能力说明");
            ActiveSkill active = new ActiveSkill(bool(a,"enabled"),string(a,"name"),effect,
                    integer(a,"amplifier",0,id.equals("mining") && effect.equalsIgnoreCase("HASTE")?9:4),integer(a,"duration-seconds",1,120),
                    integer(a,"cooldown-seconds",1,86400),integer(a,"unlock-level",1,1000),number(a,"mana-cost",0,100000),activeType);
            if (active.cooldownSeconds()<active.durationSeconds()) throw invalid(id+".active.cooldown-seconds","至少等于持续秒数");
            Map<Material, Double> blocks = new LinkedHashMap<>();
            ConfigurationSection blockSection=s.getConfigurationSection("blocks");
            if(blockSection==null) throw invalid(id+".blocks","材料经验映射（可为空）");
            for(String key:blockSection.getKeys(false)) {
                Material material=Material.matchMaterial(key);
                if(material==null || material.isAir() || (!id.equals("fishing") && !material.isBlock())) throw invalid(id+".blocks."+key,"材料名");
                blocks.put(material,number(blockSection,key,0,1e9));
            }
            Map<EntityType,Double> mobs=new LinkedHashMap<>();
            ConfigurationSection mobSection=s.getConfigurationSection("mobs");
            if(mobSection==null) throw invalid(id+".mobs","生物经验映射（可为空）");
            for(String key:mobSection.getKeys(false)) {
                EntityType type;
                try {type=EntityType.valueOf(key.toUpperCase(Locale.ROOT));} catch(IllegalArgumentException ex) {throw invalid(id+".mobs."+key,"实体类型名");}
                if(type==EntityType.PLAYER || !type.isAlive()) throw invalid(id+".mobs."+key,"非玩家生物类型");
                mobs.put(type,number(mobSection,key,0,1e9));
            }
            definitions.put(id,new SkillDefinition(id,string(s,"name"),string(s,"description"),icon,bool(s,"enabled"),max,
                    number(s,"base-xp",1,1e9),number(s,"growth-xp",0,1e6),blocks,mobs,number(s,"event-xp",0,1e9),active,xpRequirements.curve(id)));
        }
        validateText(files.get("messages.yml"));
        HudSettings hud=HudSettings.parse(c.getConfigurationSection("hud"));
        hud.validateMessages(files.get("messages.yml"));
        YamlConfiguration menu=files.get("menu.yml");
        int size=integer(menu,"size",27,54);
        if(size%9!=0)throw invalid("menu.size","27、36、45 或 54");
        int info=integer(menu,"info-slot",0,size-1),close=integer(menu,"close-slot",0,size-1);
        if(info==close)throw invalid("menu.close-slot","与 info-slot 不同的槽位");
        bool(menu,"fill");
        Material filler=Material.matchMaterial(string(menu,"filler-material"));
        if(filler==null || !filler.isItem() || filler.isAir())throw invalid("menu.filler-material","物品材料名");
        if(!menu.isList("skill-slots"))throw invalid("menu.skill-slots","整数列表");
        Set<Integer> slots=new HashSet<>();
        for(Object value:menu.getList("skill-slots")) {
            if(!(value instanceof Number n) || n.doubleValue()!=Math.rint(n.doubleValue()) || n.doubleValue()<0 || n.doubleValue()>=size
                    || n.intValue()==info || n.intValue()==close || !slots.add(n.intValue()))throw invalid("menu.skill-slots","范围内且不与其他按钮重复的整数槽位");
        }
        if(slots.size()<definitions.values().stream().filter(SkillDefinition::enabled).count())throw invalid("menu.skill-slots","足以展示所有已启用技能的槽位数量");
        validateDetails(menu);
        RpgMenuLayout.parse(menu,"passives",5);
        RpgMenuLayout.parse(menu,"stats",9);
        return new Snapshot(settings,mana,compatibility,customCrops,customFishing,tree,terraform,replenish,feedback,hud,chargedShot,quickFish,manaShield,bool(c,"controls.sneak-right-click"),
                bool(c,"progression.enabled"),balance.apply(PassiveSettings.parse(files.get("abilities.yml"),definitions.keySet())),
                ActiveGrowth.parse(files.get("abilities.yml"),definitions.keySet()),balance.apply(StatsSettings.parse(files.get("stats.yml"),definitions.keySet())),LootSettings.parse(files.get("loot.yml")),ItemSettings.parse(files.get("items.yml")),balance,AuraManaSettings.parse(files.get("mana_abilities.yml")),AuraChargedShotSettings.parse(files.get("mana_abilities.yml")),AbsorptionActivationSettings.parse(files.get("mana_abilities.yml")),
                NaturalSourcesSettings.parse(files.get("sources.yml")),RewardsSettings.parse(files.get("rewards.yml"),definitions.keySet()),
                JobsSettings.parse(files.get("jobs.yml"),definitions.keySet()),LeaderboardSettings.parse(files.get("leaderboards.yml")),
                StorageSettings.parse(files.get("storage.yml")),AlchemySourceSettings.parse(files.get("sources.yml").getConfigurationSection("alchemy")),
                EnchantingSourceSettings.parse(files.get("sources.yml").getConfigurationSection("enchanting")),
                SourceSkillRoutingSettings.parse(files.get("sources.yml").getConfigurationSection("legacy")),
                SorcerySourceSettings.parse(files.get("sources.yml").getConfigurationSection("legacy.sorcery")),
                Collections.unmodifiableMap(definitions),files.get("messages.yml"),files.get("menu.yml"));
    }

    private void validateText(YamlConfiguration yaml) {
        for(String key:yaml.getKeys(true)) {
            if(yaml.isConfigurationSection(key) || key.equals("__liskills_backfill")) continue;
            Object value=yaml.get(key);
            if(value instanceof List<?> list && list.stream().anyMatch(v->!(v instanceof String))) throw invalid(key,"文本列表");
            if(!(value instanceof String || value instanceof Number || value instanceof Boolean || value instanceof List<?>)) throw invalid(key,"文本或数字");
        }
    }

    private void validateDetails(YamlConfiguration menu) {
        int size=integer(menu,"details.size",27,54);
        if(size%9!=0)throw invalid("details.size","27、36、45 或 54");
        Set<Integer> slots=new HashSet<>();
        for(String key:List.of("summary-slot","ability-slot","previous-slot","page-slot","back-slot","refresh-slot","next-slot")) {
            if(!slots.add(integer(menu,"details."+key,0,size-1)))throw invalid("details."+key,"未被其他按钮占用的槽位");
        }
        if(!menu.isList("details.source-slots") || menu.getList("details.source-slots").isEmpty())throw invalid("details.source-slots","非空整数列表");
        for(Object value:menu.getList("details.source-slots")) {
            if(!(value instanceof Number n) || n.doubleValue()!=Math.rint(n.doubleValue()) || n.doubleValue()<0 || n.doubleValue()>=size || !slots.add(n.intValue()))throw invalid("details.source-slots","合法且不重复的槽位");
        }
        for(String path:List.of("icons","details.icons")) {
            ConfigurationSection icons=menu.getConfigurationSection(path);
            if(icons==null)throw invalid(path,"物品图标配置节");
            for(String key:icons.getKeys(false)) {
                Material material=Material.matchMaterial(string(icons,key));
                if(material==null || !material.isItem() || material.isAir())throw invalid(path+"."+key,"物品材料名");
            }
        }
        if(bool(menu,"sounds.enabled"))for(String event:List.of("open","click","page","close","success","deny")) {
            String path="sounds."+event;
            try{org.bukkit.Sound.valueOf(string(menu,path+".sound"));}catch(IllegalArgumentException ex){throw invalid(path+".sound","Bukkit声音名称");}
            number(menu,path+".volume",0,2);number(menu,path+".pitch",0.5,2);
        }
    }

    public void save(String fileName, YamlConfiguration yaml) throws IOException {
        if(!FILES.contains(fileName)) throw new IllegalArgumentException("fileName");
        Path path=plugin.getDataFolder().toPath().resolve(fileName);
        Files.createDirectories(path.getParent());
        Path temp=path.resolveSibling(fileName+".tmp");
        Files.writeString(temp,yaml.saveToString(),StandardCharsets.UTF_8);
        try {Files.move(temp,path,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);}
        catch(AtomicMoveNotSupportedException ex){Files.move(temp,path,StandardCopyOption.REPLACE_EXISTING);}
    }

    private static boolean bool(ConfigurationSection s,String key) {
        if(!(s.get(key) instanceof Boolean b)) throw invalid(s.getCurrentPath()+"."+key,"true/false");
        return b;
    }
    private static String string(ConfigurationSection s,String key) {
        if(!(s.get(key) instanceof String v) || v.isBlank()) throw invalid(s.getCurrentPath()+"."+key,"非空文本");
        return v;
    }
    private static double number(ConfigurationSection s,String key,double min,double max) {
        Object value=s.get(key);
        if(!(value instanceof Number n) || !Double.isFinite(n.doubleValue()) || n.doubleValue()<min || n.doubleValue()>max)
            throw invalid(s.getCurrentPath()+"."+key,min+" 至 "+max+" 的有限数字");
        return n.doubleValue();
    }
    private static int integer(ConfigurationSection s,String key,int min,int max) {
        double n=number(s,key,min,max);
        if(n!=Math.rint(n)) throw invalid(s.getCurrentPath()+"."+key,"整数");
        return (int)n;
    }
    private static IllegalArgumentException invalid(String key,String expected){return new IllegalArgumentException(key+"：应为 "+expected);}
    private record Snapshot(Settings settings,ManaSettings mana,CompatibilitySettings compatibility,
                            CustomCropsSettings customCrops,CustomFishingSettings customFishing,TreeFellingSettings treeFelling,
                            TerraformSettings terraform,ReplenishSettings replenish,FeedbackSettings feedback,HudSettings hud,
                            ChargedShotSettings chargedShot,QuickFishSettings quickFish,ManaShieldSettings manaShield,boolean quickCast,
                            boolean progressionEnabled,Map<String,PassiveDefinition> passives,Map<String,ActiveGrowth> activeGrowth,StatsSettings stats,LootSettings loot,ItemSettings items,BalanceSettings balance,AuraManaSettings auraMana,AuraChargedShotSettings auraChargedShot,AbsorptionActivationSettings absorptionActivation,
                            NaturalSourcesSettings sources,RewardsSettings rewards,JobsSettings jobs,LeaderboardSettings leaderboards,
                            StorageSettings storage,AlchemySourceSettings alchemySources,EnchantingSourceSettings enchantingSources,
                            SourceSkillRoutingSettings sourceRouting,SorcerySourceSettings sorcerySources,
                            Map<String,SkillDefinition> skills,YamlConfiguration messages,YamlConfiguration menu) { }
}
