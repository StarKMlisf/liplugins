package net.liplugins.liskills.internal.menu;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.config.SkillDefinition;
import net.liplugins.liskills.internal.manager.ManaManager;
import net.liplugins.liskills.internal.manager.AbilityManager;
import net.liplugins.liskills.internal.manager.ActiveSkillProgression;
import net.liplugins.liskills.internal.storage.PlayerProfile;
import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.ChatColor;

import java.util.Map;

/** 提供两级菜单一致的主动技能状态与魔力显示，不修改冷却或玩家资料。 */
final class SkillPresentation {
    private final ConfigManager config;
    private final TextService text;
    private final AbilityManager abilities;

    SkillPresentation(ConfigManager config, TextService text) { this(config,text,null); }
    SkillPresentation(ConfigManager config,TextService text,AbilityManager abilities){this.config=config;this.text=text;this.abilities=abilities;}

    Map<String, Object> values(SkillDefinition skill, PlayerProfile profile) {
        Map<String, Object> values = SkillDisplay.values(skill, profile.progress(skill.id()), text);
        values.put("ability_status", abilityStatus(skill, profile));
        values.put("unlock_level", skill.active().unlockLevel());
        var active=ActiveSkillProgression.resolve(config,skill,profile);
        values.put("duration", active.durationSeconds());
        values.put("cooldown", active.cooldownSeconds());
        values.put("ability_level",ActiveSkillProgression.rank(config,skill,profile));
        values.put("mana", text.format(ManaManager.available(profile, config)));
        values.put("max_mana", text.format(ManaManager.maximum(profile, config)));
        values.put("mana_cost", text.format(active.manaCost()));
        boolean shot=active.type().equals("AURA_CHARGED_SHOT"),instant=active.type().equals("SHARP_HOOK");
        values.put("duration_display",plain(shot?"active-ui.toggle":instant?"active-ui.instant":"active-ui.duration",Map.of("seconds",active.durationSeconds())));
        values.put("cooldown_display",plain(shot?"active-ui.no-toggle-cooldown":"active-ui.cooldown",Map.of("seconds",active.cooldownSeconds())));
        values.put("mana_cost_display",shot?plain("active-ui.per-arrow",Map.of()):text.format(active.manaCost()));
        values.put("passive_count",config.passives().values().stream().filter(p->p.skill().equals(skill.id()) && p.enabled()).count());
        values.put("mana_state", plain(config.mana().enabled() ? "menu.mana-enabled" : "menu.mana-disabled", Map.of()));
        values.put("charged_force",text.format(config.chargedShot().minimumForce()*100));
        values.put("charged_bonus",text.format((config.chargedShot().damageMultiplier()-1)*100));
        values.put("fish_wait",text.format(config.quickFish().waitMultiplier()*100));
        values.put("shield_ratio",text.format(config.manaShield().maximumAbsorptionRatio()*100));
        values.put("shield_mana",text.format(config.manaShield().manaPerDamage()));
        int levels=Math.max(0,profile.progress(skill.id()).level()-1);
        double bonus=switch(skill.id()){
            case "fighting" -> Math.min(config.settings().maxDamageBonus(),levels*config.settings().fightingBonusPerLevel());
            case "archery" -> Math.min(config.settings().maxDamageBonus(),levels*config.settings().archeryBonusPerLevel());
            case "defense" -> Math.min(config.settings().maxDamageReduction(),levels*config.settings().defenseReductionPerLevel());
            default -> 0;
        };
        values.put("passive_percent",text.format(bonus*100));
        return values;
    }

    Map<String, Object> overview(PlayerProfile profile) {
        return Map.of("player", profile.name(), "total", SkillDisplay.totalLevel(config, profile),
                "mana", text.format(ManaManager.available(profile, config)),
                "max_mana", text.format(ManaManager.maximum(profile, config)),
                "mana_state", plain(config.mana().enabled() ? "menu.mana-enabled" : "menu.mana-disabled", Map.of()));
    }

    private String abilityStatus(SkillDefinition skill, PlayerProfile profile) {
        var resolved=ActiveSkillProgression.resolve(config,skill,profile);
        if (!skill.active().enabled()) return plain("menu.no-ability", Map.of());
        if(java.util.Set.of("MANA_SHIELD","ABSORPTION","AURA_CHARGED_SHOT").contains(skill.active().type()) && !config.mana().enabled())return plain("menu.ability-needs-mana",Map.of());
        if (profile.progress(skill.id()).level() < skill.active().unlockLevel()) {
            return plain("menu.ability-locked", Map.of("level", skill.active().unlockLevel()));
        }
        if(skill.active().type().equals("AURA_CHARGED_SHOT"))return plain("active-ui.shot-ready",Map.of());
        var player=org.bukkit.Bukkit.getPlayer(profile.uuid());
        long active=player==null || abilities==null?0:abilities.remainingMillis(player,skill.id());
        if(active>0)return plain("menu.ability-active",Map.of("seconds",(active+999)/1000));
        long remaining = Math.max(0L, profile.cooldown(skill.id()) - System.currentTimeMillis());
        if (remaining > 0) return plain("menu.ability-cooldown", Map.of("seconds", (remaining + 999L) / 1000L));
        if (config.mana().enabled() && ManaManager.available(profile, config) < resolved.manaCost()) {
            return plain("menu.ability-mana", Map.of("mana", text.format(ManaManager.available(profile, config)),
                    "cost", text.format(resolved.manaCost())));
        }
        if(skill.active().type().equals("SHARP_HOOK"))return plain("active-ui.hook-ready",Map.of());
        if(skill.active().type().equals("ABSORPTION"))return plain("active-ui.shield-ready",Map.of());
        return plain("menu.ability-ready", Map.of("seconds", resolved.durationSeconds()));
    }

    private String plain(String key, Map<String, ?> replacements) {
        return ChatColor.stripColor(text.text(key, replacements));
    }
}
