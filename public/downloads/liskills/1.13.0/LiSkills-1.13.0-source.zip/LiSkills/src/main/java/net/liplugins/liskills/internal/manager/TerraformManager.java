package net.liplugins.liskills.internal.manager;

import net.liplugins.liskills.lib.scheduler.ServerThreads;
import net.liplugins.liskills.lib.scheduler.TaskScheduler;

import net.liplugins.liskills.internal.config.ActiveSkill;
import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.config.SkillDefinition;
import net.liplugins.liskills.internal.hook.LiRealEnchantHook;
import net.liplugins.liskills.internal.listener.PlacedBlockTracker;
import net.liplugins.liskills.internal.storage.PlayerProfile;
import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerItemBreakEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** 管理平面挖掘的生效窗口和全服有限工作队列；不直接生成掉落或发放经验。 */
public final class TerraformManager implements ActiveAbilityHandler, Listener, AutoCloseable {
    private final ConfigManager config;
    private final ProfileManager profiles;
    private final SkillManager skills;
    private final LiRealEnchantHook lre;
    private final TextService text;
    private final PlacedBlockTracker placed;
    private final TerraformPlanner planner;
    private final java.util.function.Predicate<Block> customBlock;
    private final Map<UUID, Window> windows = new java.util.concurrent.ConcurrentHashMap<>();
    private final Map<UUID, Job> jobs = new java.util.concurrent.ConcurrentHashMap<>();
    private final java.util.concurrent.ConcurrentLinkedDeque<UUID> order = new java.util.concurrent.ConcurrentLinkedDeque<>();
    private final Set<UUID> breaking = java.util.concurrent.ConcurrentHashMap.newKeySet();
    private final TaskScheduler scheduler;
    private volatile boolean closed;

    public TerraformManager(JavaPlugin plugin, ConfigManager config, ProfileManager profiles, SkillManager skills,
                            LiRealEnchantHook lre, TextService text, PlacedBlockTracker placed) {
        this(plugin, config, profiles, skills, lre, text, placed, block -> false);
    }

    public TerraformManager(JavaPlugin plugin, ConfigManager config, ProfileManager profiles, SkillManager skills,
                            LiRealEnchantHook lre, TextService text, PlacedBlockTracker placed,
                            java.util.function.Predicate<Block> customBlock) {
        this.config = config;
        this.profiles = profiles;
        this.skills = skills;
        this.lre = lre;
        this.text = text;
        this.placed = placed;
        this.planner = new TerraformPlanner(placed);
        this.customBlock = customBlock;
        scheduler = new TaskScheduler(plugin);
        scheduler.globalTimer(this::tick, 1L, 1L);
    }

    @Override public boolean activate(Player player, ActiveSkill active) {
        if (closed || !ServerThreads.owns(player) || !allowed(player)) return false;
        ItemStack tool = player.getInventory().getItemInMainHand();
        if (!isShovel(tool)) {
            text.send(player, "ability.terraform-tool");
            return false;
        }
        if (lre.ownsTreeBreaking(tool)) {
            text.send(player, "ability.terraform-lre-owned");
            return false;
        }
        Window existing = windows.get(player.getUniqueId());
        if (validWindow(player, existing)) {
            text.send(player, "ability.terraform-already-active");
            return false;
        }
        stop(player.getUniqueId());
        windows.put(player.getUniqueId(), new Window(player.getWorld().getUID(),
                System.currentTimeMillis() + active.durationSeconds() * 1000L, config.revision(),
                toolIdentity(tool), player.getInventory().getHeldItemSlot()));
        return true;
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        if (closed || !ServerThreads.owns(player) || !ServerThreads.owns(event.getBlock())) return;
        UUID uuid = player.getUniqueId();
        // 附魔的保护探测不是成功破坏；自己的二次破坏也不能递归建立新任务。
        if (breaking.contains(uuid) || lre.checkingSecondaryBreak() || jobs.containsKey(uuid)) return;
        Window window = windows.get(uuid);
        if (window == null) return;
        if (!validWindow(player, window)) {
            stop(uuid);
            return;
        }
        if (customBlock.test(event.getBlock()) || placed.contains(event.getBlock())) return;
        List<TerraformPlanner.Position> positions = planner.plan(event.getBlock(), config.terraform(),
                config.skill("excavation").blocks());
        if (positions.size() < 2) return;
        Job job = new Job(event, event.getBlock().getType(), placed.stamp(event.getBlock()), positions.getFirst(), positions.subList(1, positions.size()));
        jobs.put(uuid, job);
        order.addLast(uuid);
    }

    private void tick() {
        // 全局只清理时间/配置快照，不在这里读取不同区域的玩家状态。
        long now = System.currentTimeMillis();
        windows.forEach((uuid, window) -> { if (window.expires <= now || window.revision != config.revision()) stop(uuid); });
        int budget = config.terraform().blocksPerTick();
        int participants = Math.min(budget, order.size());
        int remaining = budget;
        for (int attempts = 0; attempts < participants && !order.isEmpty(); attempts++) {
            UUID uuid = order.pollFirst();
            if (uuid == null) break;
            Job job = jobs.get(uuid);
            if (job == null) continue;
            Player player = Bukkit.getPlayer(uuid);
            if (player == null) { stop(uuid); continue; }
            int allowance = Math.max(1, remaining / (participants - attempts));
            remaining -= allowance;
            scheduler.entityNow(player, () -> {
                for (int count = 0; count < allowance && jobs.get(uuid) == job; count++) process(player, uuid, job);
                if (!closed && jobs.get(uuid) == job) order.addLast(uuid);
            }, () -> stop(uuid));
        }
    }

    private void process(Player player, UUID uuid, Job job) {
            if (closed || jobs.get(uuid) != job || !ServerThreads.owns(player)) return;
            if (!validWindow(player, windows.get(uuid))) {
                stop(uuid);
                return;
            }
            if (!job.started) {
                job.started = true;
                // HIGHEST 后仍可能被取消；下一 tick 只接受起始格确实变为空气的成功破坏。
                Block origin = TerraformPlanner.loadedBlock(player.getWorld(), job.origin);
                if (origin == null || !placed.unchanged(origin, job.stamp) || !originalSucceeded(job.trigger.isCancelled(), origin.getType())) {
                    jobs.remove(uuid, job);
                    return;
                }
            }
            TerraformPlanner.Position position = job.positions.removeFirst();
            Block block = TerraformPlanner.loadedBlock(player.getWorld(), position);
            // 状态变化、人工填回或卸载都停止整个任务，不能沿旧队列穿过当前已无效的格子。
            if (block == null || block.getType() != job.material || placed.contains(block) || customBlock.test(block)) {
                jobs.remove(uuid, job);
                return;
            }
            breaking.add(uuid);
            try {
                // 完整 Bukkit 玩家破坏链路保留领地检查、耐久、掉落和统一经验监听。
                boolean broken = player.breakBlock(block);
                if (jobs.get(uuid) != job) return;
                Block remaining = TerraformPlanner.loadedBlock(block.getWorld(), position);
                if (!broken || remaining == null || !originalSucceeded(false, remaining.getType())) {
                    jobs.remove(uuid, job);
                    return;
                }
            } catch (RuntimeException failure) {
                jobs.remove(uuid, job);
                text.send(player, "ability.terraform-failed");
                return;
            } finally {
                breaking.remove(uuid);
            }
            // 破坏事件的外部回调可能已经关闭窗口，不能将被取消的旧任务重新排入队列。
            if (jobs.get(uuid) != job) return;
            if (job.positions.isEmpty()) jobs.remove(uuid, job);
    }

    private boolean allowed(Player player) {
        SkillDefinition definition = config.skill("excavation");
        PlayerProfile profile = profiles.get(player.getUniqueId());
        return player.isOnline() && !player.isDead() && skills.eligible(player) && player.hasPermission("liskills.use")
                && player.hasPermission("liskills.skill.excavation") && profile != null
                && definition != null && definition.enabled() && definition.active() != null
                && definition.active().enabled() && definition.active().type().equals("TERRAFORM")
                && profile.progress("excavation").level() >= definition.active().unlockLevel();
    }

    private boolean validWindow(Player player, Window window) {
        if (window == null || window.expires <= System.currentTimeMillis() || window.revision != config.revision()
                || !window.world.equals(player.getWorld().getUID()) || !allowed(player)) return false;
        ItemStack tool = player.getInventory().getItemInMainHand();
        return player.getInventory().getHeldItemSlot() == window.slot && isShovel(tool)
                && window.tool.isSimilar(toolIdentity(tool)) && !lre.ownsTreeBreaking(tool);
    }

    private static ItemStack toolIdentity(ItemStack tool) {
        ItemStack copy = tool.clone();
        ItemMeta meta = copy.getItemMeta();
        // 正常耐久消耗不视作换工具；类型、附魔和其他物品元数据仍必须完全相同。
        if (meta instanceof Damageable damage) { damage.setDamage(0); copy.setItemMeta(meta); }
        return copy;
    }

    private static boolean isShovel(ItemStack tool) { return tool.getType().name().endsWith("_SHOVEL"); }

    static boolean originalSucceeded(boolean cancelled, Material current) {
        return !cancelled && (current == Material.AIR || current == Material.CAVE_AIR || current == Material.VOID_AIR);
    }

    @EventHandler public void onQuit(PlayerQuitEvent event) { stop(event.getPlayer().getUniqueId()); }
    @EventHandler public void onDeath(PlayerDeathEvent event) { stop(event.getEntity().getUniqueId()); }
    @EventHandler public void onWorldChange(PlayerChangedWorldEvent event) { stop(event.getPlayer().getUniqueId()); }
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onToolSlotChange(PlayerItemHeldEvent event) {
        if (event.getNewSlot() != event.getPreviousSlot()) stop(event.getPlayer().getUniqueId());
    }
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onHandSwap(PlayerSwapHandItemsEvent event) { stop(event.getPlayer().getUniqueId()); }
    @EventHandler public void onToolBreak(PlayerItemBreakEvent event) {
        Window window = windows.get(event.getPlayer().getUniqueId());
        if (window != null && window.tool.isSimilar(toolIdentity(event.getBrokenItem()))) stop(event.getPlayer().getUniqueId());
    }

    private void stop(UUID uuid) {
        windows.remove(uuid);
        jobs.remove(uuid);
        order.remove(uuid);
    }

    @Override public void close() {
        closed = true;
        scheduler.cancelAll();
        windows.clear();
        jobs.clear();
        order.clear();
        breaking.clear();
    }

    private record Window(UUID world, long expires, long revision, ItemStack tool, int slot) { }
    private static final class Job {
        private final BlockBreakEvent trigger;
        private final Material material;
        private final long stamp;
        private final TerraformPlanner.Position origin;
        private final ArrayDeque<TerraformPlanner.Position> positions;
        private boolean started;

        private Job(BlockBreakEvent trigger, Material material, long stamp, TerraformPlanner.Position origin,
                    List<TerraformPlanner.Position> positions) {
            this.trigger = trigger;
            this.material = material;
            this.stamp = stamp;
            this.origin = origin;
            this.positions = new ArrayDeque<>(positions);
        }
    }
}
