package net.liplugins.liskills.internal.listener;

import net.liplugins.liskills.lib.scheduler.ServerThreads;
import net.liplugins.liskills.lib.scheduler.TaskScheduler;

import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;
import java.util.LinkedHashMap;
import java.util.Map;

/** 补种事务在事件后撤销为空气时，清掉临时人工来源；普通放置仍立即标记，避免防刷空窗。 */
public final class CropPlacementCleanup implements Listener,AutoCloseable {
    private final JavaPlugin plugin;
    private final PlacedBlockTracker placed;
    private final Map<Block,Long> pending=new java.util.concurrent.ConcurrentHashMap<>();
    private final TaskScheduler scheduler;
    public CropPlacementCleanup(JavaPlugin plugin,PlacedBlockTracker placed){this.plugin=plugin;this.placed=placed;this.scheduler=new TaskScheduler(plugin);}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void onPlace(BlockPlaceEvent event) {
        Material material=event.getBlockPlaced().getType();
        if(material!=Material.WHEAT && material!=Material.CARROTS && material!=Material.POTATOES
                && material!=Material.BEETROOTS && material!=Material.NETHER_WART)return;
        // 同一 tick 合并，极端放置量上限只影响残余标记清理，不放宽即时防刷判断。
        if(pending.size()>=4096)return;
        Block block=event.getBlockPlaced();
        if(pending.put(block,placed.stamp(block))==null)scheduler.region(block.getLocation(),()->clean(block));
    }
    private void clean(Block block) {
            Long stamp=pending.remove(block);
            if(stamp==null || !ServerThreads.owns(block) || !block.getWorld().isChunkLoaded(block.getX()>>4,block.getZ()>>4))return;
            Material current=block.getType();
            if(current==Material.AIR || current==Material.CAVE_AIR || current==Material.VOID_AIR)placed.clearIfUnchanged(block,stamp);
    }
    @Override public void close(){scheduler.cancelAll();pending.clear();}
}
