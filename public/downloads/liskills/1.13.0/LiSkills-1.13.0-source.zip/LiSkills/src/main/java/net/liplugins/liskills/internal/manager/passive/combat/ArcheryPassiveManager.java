package net.liplugins.liskills.internal.manager.passive.combat;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.hook.LiRealEnchantHook;
import net.liplugins.liskills.internal.manager.PassiveAbilityManager;
import net.liplugins.liskills.internal.manager.ProfileManager;
import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.entity.AbstractArrow;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Trident;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityShootBowEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.world.EntitiesLoadEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;
import net.liplugins.liskills.lib.scheduler.TaskHandle;
import net.liplugins.liskills.lib.scheduler.TaskScheduler;
import net.liplugins.liskills.lib.scheduler.ServerThreads;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** 箭矢回收、穿透、眩晕；有界跟踪原箭，不创建复制箭或重新造成命中伤害。 */
final class ArcheryPassiveManager implements Listener,AutoCloseable {
    private final ConfigManager config;
    private final ProfileManager profiles;
    private final PassiveAbilityManager passives;
    private final DeferredPassiveEffects effects;
    private final LiRealEnchantHook enchantments;
    private final NamespacedKey stunKey;
    private final Map<UUID,Retrieval> retrievals=new java.util.concurrent.ConcurrentHashMap<>();
    private final Map<UUID,Stun> stuns=new java.util.concurrent.ConcurrentHashMap<>();
    private final TaskScheduler scheduler;
    private final net.liplugins.liskills.internal.manager.EntityWorkQueue work = new net.liplugins.liskills.internal.manager.EntityWorkQueue();
    private final TaskHandle task;
    private volatile long tick;
    ArcheryPassiveManager(JavaPlugin plugin,ConfigManager config,ProfileManager profiles,PassiveAbilityManager passives,
                          DeferredPassiveEffects effects,LiRealEnchantHook enchantments) {
        this.config=config;this.profiles=profiles;this.passives=passives;this.effects=effects;this.enchantments=enchantments;
        stunKey=new NamespacedKey(plugin,"passive_stun");
        // 清理崩溃前持久化到已加载实体的自身临时减速。
        if(!ServerThreads.folia())Bukkit.getWorlds().forEach(world->world.getLivingEntities().forEach(entity->TemporaryMovementModifiers.remove(entity,stunKey)));
        task=(scheduler = new TaskScheduler(plugin)).globalTimer(this::tick,1,1);
    }
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)
    public void onShoot(EntityShootBowEvent event) {
        if(!(event.getProjectile() instanceof Arrow arrow) || !(event.getEntity() instanceof Player player)
                || !ServerThreads.owns(player) || !ServerThreads.owns(arrow) || !passives.roll(player,"piercing") || arrow.getPierceLevel()>=127) return;
        int before=arrow.getPierceLevel(),after=before+1;
        PassiveSession session=PassiveSession.capture(player,profiles,config);
        if(!effects.submit(player.getUniqueId(),()->{
            if((event.isCancelled() || event.getProjectile()!=arrow || !session.valid(profiles,config) || passives.value(player,"piercing")<=0)
                    && ServerThreads.owns(arrow) && arrow.isValid() && arrow.getPierceLevel()==after) arrow.setPierceLevel(before);
        })) return;
        arrow.setPierceLevel(after);
    }
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)
    public void onHit(EntityDamageByEntityEvent event) {
        if(!ServerThreads.owns(event.getEntity()) || SecondaryDamageContext.active() || (enchantments!=null && enchantments.isSecondaryDamage())
                || !(event.getDamager() instanceof Arrow arrow) || !ServerThreads.owns(arrow) || !(arrow.getShooter() instanceof Player player) || !ServerThreads.owns(player)
                || !(event.getFinalDamage()>0)) return;
        PassiveSession session=PassiveSession.capture(player,profiles,config);
        if(!(event.getEntity() instanceof Player target && target.isBlocking()) && arrow.getPierceLevel()<127 && passives.roll(player,"piercing")) {
            int before=arrow.getPierceLevel(),after=before+1;
            if(effects.submit(player.getUniqueId(),()->{
                if((event.isCancelled() || !(event.getFinalDamage()>0) || !session.valid(profiles,config) || passives.value(player,"piercing")<=0)
                        && ServerThreads.owns(arrow) && arrow.isValid() && arrow.getPierceLevel()==after) arrow.setPierceLevel(before);
            })) arrow.setPierceLevel(after);
        }
        if(event.getEntity() instanceof LivingEntity victim && passives.roll(player,"stun")) {
            effects.submit(player.getUniqueId(),()->{
                if(event.isCancelled() || !(event.getFinalDamage()>0) || !session.valid(profiles,config) || passives.value(player,"stun")<=0
                        || !ServerThreads.owns(victim) || !victim.isValid() || victim.isDead() || !victim.getWorld().equals(player.getWorld())
                        || stuns.containsKey(victim.getUniqueId()) || stuns.size()>=1024) return;
                double reduction=Math.clamp(passives.option("stun","speed_reduction",.2),0,.95);
                TemporaryMovementModifiers.apply(victim,stunKey,-reduction);
                stuns.put(victim.getUniqueId(),new Stun(victim,session,tick+40));
            });
        }
    }
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void onGround(ProjectileHitEvent event) {
        if(event.getHitBlock()==null || event.getHitEntity()!=null || !(event.getEntity() instanceof AbstractArrow arrow)
                || !ServerThreads.owns(arrow) || arrow instanceof Trident || arrow.getPickupStatus()!=AbstractArrow.PickupStatus.ALLOWED
                || !(arrow.getShooter() instanceof Player player) || !ServerThreads.owns(player) || passives.value(player,"retrieval")<=0
                || retrievals.containsKey(arrow.getUniqueId()) || retrievals.size()>=2048) return;
        long delay=(long)Math.ceil(Math.clamp(passives.option("retrieval","delay_sec",3),.05,60)*20);
        retrievals.put(arrow.getUniqueId(),new Retrieval(arrow,PassiveSession.capture(player,profiles,config),event,tick+delay));
    }
    private void tick() {
        tick++;
        for(Stun stun:List.copyOf(stuns.values())) {
            work.dispatch(scheduler,stun,stun.entity,()->tick(stun),()->stuns.remove(stun.entity.getUniqueId(),stun));
        }
        for(Retrieval retrieval:List.copyOf(retrievals.values())) {
            work.dispatch(scheduler,retrieval,retrieval.arrow,()->tick(retrieval),()->retrievals.remove(retrieval.arrow.getUniqueId(),retrieval));
        }
    }
    private void tick(Stun stun) {
            if(stuns.get(stun.entity.getUniqueId())!=stun)return;
            if(tick>=stun.until || !stun.session.valid(profiles,config) || !stun.entity.isValid() || stun.entity.isDead()) {
                TemporaryMovementModifiers.remove(stun.entity,stunKey);
                stuns.remove(stun.entity.getUniqueId(),stun);
            }
    }
    private void tick(Retrieval retrieval) {
            if(retrievals.get(retrieval.arrow.getUniqueId())!=retrieval)return;
            AbstractArrow arrow=retrieval.arrow;
            if(retrieval.event.isCancelled() || !retrieval.session.valid(profiles,config) || !arrow.isValid()
                    || !arrow.getWorld().getUID().equals(retrieval.session.world())) {
                retrievals.remove(arrow.getUniqueId(),retrieval);return;
            }
            if(tick<retrieval.when) return;
            retrievals.remove(arrow.getUniqueId(),retrieval);
            Player player=retrieval.session.player();
            double radius=passives.value(player,"retrieval");
            if(radius<=0 || !arrow.isInBlock() || arrow.getPickupStatus()!=AbstractArrow.PickupStatus.ALLOWED
                    || !arrow.getWorld().isChunkLoaded(arrow.getLocation().getBlockX()>>4,arrow.getLocation().getBlockZ()>>4)
                    || player.getLocation().distanceSquared(arrow.getLocation())>Math.min(512,radius)*Math.min(512,radius)) return;
            // 直接复制服务器保存的原箭ItemStack，保留药水、名称及PDC。
            ItemStack item=arrow.getItem().clone();item.setAmount(1);
            if(item.getType().isAir() || !player.getInventory().addItem(item).isEmpty()) return;
            arrow.remove();
            player.playSound(player.getLocation(),Sound.ENTITY_ITEM_PICKUP,.4f,1.9f);
    }
    @EventHandler(priority=EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent event) {
        TemporaryMovementModifiers.remove(event.getPlayer(),stunKey);
        stuns.remove(event.getPlayer().getUniqueId());
    }
    @EventHandler(priority=EventPriority.MONITOR)
    public void onEntitiesLoad(EntitiesLoadEvent event) {
        for(var entity:event.getEntities()) if(entity instanceof LivingEntity living && !stuns.containsKey(entity.getUniqueId())) TemporaryMovementModifiers.remove(living,stunKey);
    }
    @Override public void close() {
        task.cancel();scheduler.cancelAll();retrievals.clear();
        stuns.values().forEach(stun->TemporaryMovementModifiers.remove(stun.entity,stunKey));stuns.clear();
    }
    private record Retrieval(AbstractArrow arrow,PassiveSession session,ProjectileHitEvent event,long when){ }
    private record Stun(LivingEntity entity,PassiveSession session,long until){ }
}
