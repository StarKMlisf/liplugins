package net.liplugins.liskills;

import net.liplugins.liskills.api.PluginRuntime;
import net.liplugins.liskills.lib.BootstrapMessages;
import net.liplugins.liskills.lib.RuntimeClassLoader;
import net.liplugins.liskills.lib.RuntimeDependencyLoader;
import org.bukkit.plugin.java.JavaPlugin;

import java.lang.reflect.InvocationTargetException;
import net.liplugins.liskills.lib.scheduler.AttributeModifiers;
import java.util.Map;

/** 插件入口只负责生命周期和依赖准备，玩法交由内部业务入口装配。 */
public final class LiSkillsPlugin extends JavaPlugin {
    private PluginRuntime runtime;
    private RuntimeClassLoader runtimeLoader;
    private BootstrapMessages messages;

    @Override
    public void onEnable() {
        messages = new BootstrapMessages(this);
        if (getServer().getPluginManager().getPlugin("AuraSkills") != null) {
            getLogger().severe(messages.text("conflict", Map.of("plugin", "AuraSkills")));
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        if (!AttributeModifiers.supported()) {
            getLogger().severe(messages.text("folia-api-unavailable"));
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        try {
            runtimeLoader = new RuntimeDependencyLoader(this, messages).prepare();
            ClassLoader loader = runtimeLoader == null ? getClass().getClassLoader() : runtimeLoader;
            Class<?> entry = Class.forName("net.liplugins.liskills.internal.LiSkillsRuntime", true, loader);
            runtime = (PluginRuntime) entry.getConstructor(JavaPlugin.class).newInstance(this);
            runtime.start();
            getLogger().info(messages.text("started", Map.of("plugin", getName(), "version", getDescription().getVersion())));
        } catch (Exception | LinkageError failure) {
            getLogger().severe(messages.text("failed", Map.of("error", reason(failure))));
            getServer().getPluginManager().disablePlugin(this);
        }
    }

    @Override
    public void onDisable() {
        if (runtime != null) {
            try {
                runtime.stop();
            } catch (Exception | LinkageError failure) {
                getLogger().severe(messages.text("stop-failed", Map.of("error", reason(failure))));
            } finally {
                runtime = null;
            }
        }
        if (runtimeLoader != null) {
            try {
                runtimeLoader.close();
            } catch (Exception failure) {
                getLogger().warning(messages.text("stop-failed", Map.of("error", reason(failure))));
            } finally {
                runtimeLoader = null;
            }
        }
    }

    private String reason(Throwable failure) {
        Throwable detail = failure;
        if (detail instanceof InvocationTargetException invocation && invocation.getCause() != null) {
            detail = invocation.getCause();
        }
        String text = detail.getMessage();
        String location = java.util.Arrays.stream(detail.getStackTrace())
                .filter(frame -> frame.getClassName().startsWith("net.liplugins.liskills."))
                .findFirst().map(frame -> " [" + frame.getClassName() + ":" + frame.getLineNumber() + "]").orElse("");
        return detail.getClass().getSimpleName() + (text == null || text.isBlank() ? "" : ": " + text) + location;
    }
}
