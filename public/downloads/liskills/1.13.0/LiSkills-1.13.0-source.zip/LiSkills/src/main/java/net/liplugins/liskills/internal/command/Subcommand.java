package net.liplugins.liskills.internal.command;

import org.bukkit.command.CommandSender;

/** 单个子指令只负责自身参数和执行流程。 */
interface Subcommand {
    String name();
    String permission();
    void execute(CommandSender sender, String[] arguments);
}
