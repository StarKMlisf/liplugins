package net.liplugins.liskills.internal;

import net.liplugins.liskills.api.*;
import net.liplugins.liskills.internal.command.CommandRegistrar;
import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.hook.HookManager;
import net.liplugins.liskills.internal.hook.LiRealEnchantHook;
import net.liplugins.liskills.internal.hook.customcrops.CustomCropsHook;
import net.liplugins.liskills.internal.hook.customfishing.CustomFishingHook;
import net.liplugins.liskills.internal.listener.*;
import net.liplugins.liskills.internal.manager.*;
import net.liplugins.liskills.internal.manager.stat.StatManager;
import net.liplugins.liskills.internal.manager.hud.HudManager;
import net.liplugins.liskills.internal.manager.passive.gathering.GatheringPassiveManager;
import net.liplugins.liskills.internal.manager.passive.combat.RpgCombatModule;
import net.liplugins.liskills.internal.manager.active.AuraManaAbilityModule;
import net.liplugins.liskills.internal.manager.item.ItemModule;
import net.liplugins.liskills.internal.manager.source.AlchemyEnchantingSourcesModule;
import net.liplugins.liskills.internal.menu.SkillMenu;
import net.liplugins.liskills.internal.menu.SkillMenuHolder;
import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.Bukkit;
import org.bukkit.event.HandlerList;
import org.bukkit.plugin.ServicePriority;
import org.bukkit.plugin.java.JavaPlugin;
import net.liplugins.liskills.lib.scheduler.TaskHandle;
import net.liplugins.liskills.lib.scheduler.TaskScheduler;
import net.liplugins.liskills.lib.scheduler.ServerThreads;
import java.util.Map;

/** 装配应用服务并管理生命周期；业务分别位于指令、配置、监听、管理器等层。 */
public final class LiSkillsRuntime implements PluginRuntime {
    private final JavaPlugin plugin;
    private ConfigManager config;
    private TextService text;
    private ProfileManager profiles;
    private AbilityManager abilities;
    private HookManager hooks;
    private ManaManager mana;
    private PassiveAbilityManager passives;
    private StatManager stats;
    private GatheringPassiveManager gatheringPassives;
    private RpgCombatModule rpgCombat;
    private LiRealEnchantHook enchantments;
    private CustomCropsHook customCrops;
    private CustomFishingHook customFishing;
    private TreeFellingManager treeFelling;
    private TerraformManager terraform;
    private ReplenishManager replenish;
    private ExperienceFeedback feedback;
    private HudManager hud;
    private CropPlacementCleanup cropCleanup;
    private SkillAbilityWindows windows;
    private ChargedShotManager chargedShot;
    private QuickFishManager quickFish;
    private ManaShieldManager manaShield;
    private AuraManaAbilityModule auraMana;
    private DynamicSkillPermissions dynamicPermissions;
    private ItemModule items;
    private AlchemyEnchantingSourcesModule naturalSources;
    private ExtendedModule extended;
    private TaskHandle autosave;
    public LiSkillsRuntime(JavaPlugin plugin){this.plugin=plugin;}
    public void start() throws Exception {
        config=new ConfigManager(plugin);config.reload();text=new TextService(config);
        dynamicPermissions=new DynamicSkillPermissions(config);dynamicPermissions.refresh();
        profiles=new ProfileManager(plugin,text,config.storage());
        SkillManager skills=new SkillManager(config,profiles,text);
        feedback=new ExperienceFeedback(plugin,config,profiles,skills,text);
        Bukkit.getPluginManager().registerEvents(feedback,plugin);
        passives=new PassiveAbilityManager(config,profiles,skills);
        enchantments=new LiRealEnchantHook(plugin,config,text);
        items=new ItemModule(plugin,config,profiles,skills,enchantments,text);items.register();
        skills.equipmentMultiplier(items.attributes()::skillExperienceMultiplier);
        stats=new StatManager(plugin,config,profiles,skills,passives,items.attributes());
        stats.register();
        mana=new ManaManager(plugin,config,profiles,skills,stats);
        hud=new HudManager(plugin,config,profiles,skills,text);
        Bukkit.getPluginManager().registerEvents(hud,plugin);
        windows=new SkillAbilityWindows(plugin,config,profiles,skills);
        customCrops=new CustomCropsHook(plugin,config,skills,text,profiles);
        customFishing=new CustomFishingHook(plugin,config,skills,windows,text,profiles);
        customCrops.register();
        customFishing.register();
        PlacedBlockTracker placed=new PlacedBlockTracker(plugin);
        gatheringPassives=new GatheringPassiveManager(plugin,config,profiles,skills,passives,stats,placed,enchantments,customCrops::owns,customFishing::skipVanillaExperience);
        gatheringPassives.register();
        rpgCombat=new RpgCombatModule(plugin,config,profiles,skills,passives,stats,enchantments,text);
        rpgCombat.register();
        cropCleanup=new CropPlacementCleanup(plugin,placed);
        Bukkit.getPluginManager().registerEvents(cropCleanup,plugin);
        treeFelling=new TreeFellingManager(plugin,config,profiles,skills,enchantments,text,placed,customCrops::owns);
        terraform=new TerraformManager(plugin,config,profiles,skills,enchantments,text,placed,customCrops::owns);
        replenish=new ReplenishManager(plugin,config,profiles,skills,enchantments,text,placed,customCrops::owns);
        chargedShot=new ChargedShotManager(plugin,config,windows,text,enchantments);
        quickFish=new QuickFishManager(plugin,config,windows,text,customFishing::owns);
        manaShield=new ManaShieldManager(plugin,config,profiles,windows,text,enchantments);
        auraMana=new AuraManaAbilityModule(plugin,config,profiles,skills,windows,enchantments,text,config::auraMana,config::auraChargedShot,config::absorptionActivation,customFishing::owns);
        Map<String,ActiveAbilityHandler> handlers=new java.util.LinkedHashMap<>(Map.of(
                "POTION",new PotionAbilityHandler(text),"TREECAPITATOR",treeFelling::activate,
                "TERRAFORM",terraform,"REPLENISH",replenish,
                "CHARGED_SHOT",chargedShot,"QUICK_FISH",quickFish,"MANA_SHIELD",manaShield));
        handlers.putAll(auraMana.handlers());
        abilities=new AbilityManager(plugin,config,profiles,skills,text,handlers);
        auraMana.register(abilities);
        SkillMenu menu=new SkillMenu(plugin,config,profiles,skills,abilities,text);
        Bukkit.getPluginManager().registerEvents(new ProfileListener(profiles,id->{manaShield.settleFor(id);auraMana.settleFor(id);}),plugin);
        Bukkit.getPluginManager().registerEvents(menu,plugin);
        Bukkit.getPluginManager().registerEvents(treeFelling,plugin);
        Bukkit.getPluginManager().registerEvents(terraform,plugin);
        Bukkit.getPluginManager().registerEvents(replenish,plugin);
        Bukkit.getPluginManager().registerEvents(new AbilityWindowListener(windows),plugin);
        Bukkit.getPluginManager().registerEvents(chargedShot,plugin);
        Bukkit.getPluginManager().registerEvents(quickFish,plugin);
        Bukkit.getPluginManager().registerEvents(new SneakRightClickListener(config,abilities),plugin);
        GameplayListeners.register(plugin,config,profiles,skills,text,placed,enchantments,customCrops::owns,customFishing::skipVanillaExperience);
        naturalSources=new AlchemyEnchantingSourcesModule(plugin,config,profiles,skills,config::alchemySources,config::enchantingSources);naturalSources.register();
        extended=new ExtendedModule(plugin,config,profiles,stats,text);extended.register();
        // 护盾在自家基础战斗加成后处理当前伤害；仍由Bukkit继续经过其他保护监听。
        Bukkit.getPluginManager().registerEvents(manaShield,plugin);
        new CommandRegistrar(plugin,config,profiles,skills,abilities,menu,text,this::reload,this::compatibilityStatus,stats).items(items).extensions(extended).hud(hud).register();
        hooks=new HookManager(plugin,config,profiles,text);hooks.register();
        Bukkit.getConsoleSender().sendMessage(hooks.status());
        Bukkit.getConsoleSender().sendMessage(compatibilityStatus());
        Bukkit.getServicesManager().register(LiSkillsApi.class,new ApiService(skills,stats,profiles,abilities),plugin,ServicePriority.Normal);
        scheduleSave();
        Bukkit.getOnlinePlayers().forEach(player->new TaskScheduler(plugin).entityNow(player,()->profiles.join(player)));
    }
    private synchronized void reload() {
        try{config.reload();dynamicPermissions.refresh();stats.refreshAll();hud.refresh();extended.boards().reload();scheduleSave();}
        catch(Exception ex){plugin.getLogger().warning(text.text("config.reload-failed",Map.of("error",String.valueOf(ex.getMessage()))));throw new IllegalStateException(ex);}
    }
    private String compatibilityStatus() {
        return enchantments.status()+"\n"+customCrops.status()+"\n"+customFishing.status();
    }
    private void scheduleSave(){
        if(autosave!=null)autosave.cancel();
        long ticks=config.settings().autosaveSeconds()*20L;
        autosave=new TaskScheduler(plugin).globalTimer(profiles::saveAll,ticks,ticks);
    }
    public void stop() {
        try {
            stopGameplay();
        } finally {
            // 前置模块关闭失败也必须移除 HUD、恢复属性并保存档案，不能把技能血量留在玩家存档中。
            try {
                if(hud!=null)hud.close();
            } finally {
                try {
                    if(stats!=null)stats.close();
                } finally {
                    try { if(profiles!=null)profiles.close(); }
                    finally { TaskScheduler.cancelPlugin(plugin); }
                }
            }
        }
    }

    private void stopGameplay() {
        if(autosave!=null)autosave.cancel();
        HandlerList.unregisterAll(plugin);
        Bukkit.getServicesManager().unregisterAll(plugin);
        // Folia停止阶段已没有玩家线程；不能借全局关闭回调跨区域读菜单。
        Bukkit.getOnlinePlayers().stream().filter(ServerThreads::owns).filter(p->p.getOpenInventory().getTopInventory().getHolder() instanceof SkillMenuHolder).forEach(p->p.closeInventory());
        if(hooks!=null)hooks.close();
        if(enchantments!=null)enchantments.close();
        if(customCrops!=null)customCrops.close();
        if(customFishing!=null)customFishing.close();
        if(mana!=null)mana.close();
        // 先按仍有效的智慧上限结清护盾退款，再清除临时属性快照。
        if(manaShield!=null)manaShield.close();
        if(auraMana!=null)auraMana.close();
        if(gatheringPassives!=null)gatheringPassives.close();
        if(rpgCombat!=null)rpgCombat.close();
        if(extended!=null)extended.close();
        if(items!=null)items.close();
        if(naturalSources!=null)naturalSources.close();
        if(abilities!=null)abilities.close();
        if(treeFelling!=null)treeFelling.close();
        if(terraform!=null)terraform.close();
        if(replenish!=null)replenish.close();
        if(feedback!=null)feedback.close();
        if(cropCleanup!=null)cropCleanup.close();
        if(chargedShot!=null)chargedShot.close();
        if(quickFish!=null)quickFish.close();
        if(windows!=null)windows.close();
        if(dynamicPermissions!=null)dynamicPermissions.close();
    }
}
