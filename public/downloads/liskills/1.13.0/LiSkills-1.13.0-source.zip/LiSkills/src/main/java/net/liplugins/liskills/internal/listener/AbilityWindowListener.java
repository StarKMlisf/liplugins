package net.liplugins.liskills.internal.listener;

import net.liplugins.liskills.internal.manager.SkillAbilityWindows;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.*;

/** 玩家身份/装备变化时撤销短期窗口；效果执行器下次处理时会再次校验。 */
public final class AbilityWindowListener implements Listener {
    private final SkillAbilityWindows windows;
    public AbilityWindowListener(SkillAbilityWindows windows){this.windows=windows;}
    @EventHandler public void onQuit(PlayerQuitEvent event){windows.removeAll(event.getPlayer());}
    @EventHandler public void onDeath(PlayerDeathEvent event){windows.removeAll(event.getEntity());}
    @EventHandler public void onWorld(PlayerChangedWorldEvent event){windows.removeAll(event.getPlayer());}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void onHeld(PlayerItemHeldEvent event){if(event.getPreviousSlot()!=event.getNewSlot())windows.removeAll(event.getPlayer());}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void onSwap(PlayerSwapHandItemsEvent event){windows.removeAll(event.getPlayer());}
    @EventHandler public void onBreak(PlayerItemBreakEvent event){windows.removeAll(event.getPlayer());}
}
