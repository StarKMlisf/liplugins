package net.liplugins.liskills.internal.command;

import net.liplugins.liskills.internal.config.SkillDefinition;
import net.liplugins.liskills.internal.manager.SkillManager;
import net.liplugins.liskills.internal.menu.SkillDisplay;
import net.liplugins.liskills.internal.storage.PlayerProfile;
import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Map;

final class XpCommand implements Subcommand {
    private final SenderChecks checks;
    private final SkillManager skills;
    private final TextService text;
    XpCommand(SenderChecks checks, SkillManager skills, TextService text) {
        this.checks = checks; this.skills = skills; this.text = text;
    }
    public String name() { return "xp"; }
    public String permission() { return "liskills.admin"; }
    public void execute(CommandSender sender, String[] arguments) {
        if (arguments.length != 4 || !(arguments[0].equalsIgnoreCase("add") || arguments[0].equalsIgnoreCase("set"))) {
            checks.usage(sender, "command.usage-xp"); return;
        }
        Double amount = CommandNumbers.experience(arguments[3], skills.config().settings().maxAward());
        if (amount == null) { text.send(sender, "command.invalid-number"); return; }
        Player player = checks.online(sender, arguments[1]);
        if (player == null) return;
        checks.onPlayer(player, () -> {
        PlayerProfile profile = checks.profile(sender, player);
        SkillDefinition skill = checks.skill(sender, arguments[2]);
        if (profile == null || skill == null) return;
        boolean add = arguments[0].equalsIgnoreCase("add");
        boolean changed = add ? skills.addExperience(player, skill.id(), amount) : skills.setExperience(player, skill.id(), amount);
        if (!changed) { text.send(sender, add ? "command.invalid-number" : "command.invalid-set-xp"); return; }
        Map<String, Object> values = SkillDisplay.values(skill, profile.progress(skill.id()), text);
        values.put("player", player.getName());
        text.send(sender, "command.xp-updated", values);
        });
    }
}
