package net.liplugins.liskills.internal.manager.active;

import net.liplugins.liskills.internal.config.ActiveSkill;
import net.liplugins.liskills.internal.config.AuraManaSettings;
import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.hook.LiRealEnchantHook;
import net.liplugins.liskills.internal.manager.AbilityManager;
import net.liplugins.liskills.internal.manager.ActiveAbilityHandler;
import net.liplugins.liskills.internal.manager.ActiveSkillProgression;
import net.liplugins.liskills.internal.manager.ProfileManager;
import net.liplugins.liskills.internal.manager.SkillManager;
import net.liplugins.liskills.internal.manager.passive.combat.SecondaryDamageContext;
import net.liplugins.liskills.internal.storage.PlayerProfile;
import net.liplugins.liskills.internal.util.TextService;
import net.liplugins.liskills.internal.util.ToolIdentity;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.FishHook;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;
import net.liplugins.liskills.lib.scheduler.TaskHandle;
import net.liplugins.liskills.lib.scheduler.TaskScheduler;
import net.liplugins.liskills.lib.scheduler.ServerThreads;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.function.Predicate;
import java.util.function.Supplier;

/** 锐钩攻击本人的真实挂钩目标；不扫描附近生物、不创建鱼获、不强拉目标或重置无敌帧。 */
public final class SharpHookManager implements ActiveAbilityHandler,Listener,AutoCloseable {
    private static final int CAPACITY=512;
    private final ConfigManager config;
    private final ProfileManager profiles;
    private final SkillManager skills;
    private final LiRealEnchantHook enchantments;
    private final TextService text;
    private final Supplier<AuraManaSettings> settings;
    private final Predicate<FishHook> customHook;
    private final Map<UUID,Cast> casts=new java.util.concurrent.ConcurrentHashMap<>();
    private final Map<UUID,Gesture> gestures=new java.util.concurrent.ConcurrentHashMap<>();
    private final TaskScheduler scheduler;
    private final net.liplugins.liskills.lib.scheduler.PlayerTasks cleanup;
    private volatile AbilityManager abilities;

    public SharpHookManager(JavaPlugin plugin,ConfigManager config,ProfileManager profiles,SkillManager skills,
                            LiRealEnchantHook enchantments,TextService text,Supplier<AuraManaSettings> settings,Predicate<FishHook> customHook) {
        this.config=config;this.profiles=profiles;this.skills=skills;this.enchantments=enchantments;this.text=text;
        this.settings=settings;this.customHook=customHook;scheduler = new TaskScheduler(plugin);
        cleanup=new net.liplugins.liskills.lib.scheduler.PlayerTasks(plugin,this::tick,1,1);
    }
    public void bind(AbilityManager abilities){this.abilities=abilities;}
    @Override public boolean usesStandardActivationMessage(){return false;}
    @Override public boolean activate(Player player,ActiveSkill active) {
        if(!ServerThreads.owns(player) || SecondaryDamageContext.active() || (enchantments!=null && enchantments.isSecondaryDamage()))return false;
        if(player.getInventory().getItemInMainHand().getType()!=Material.FISHING_ROD){text.send(player,"ability.sharp-hook-tool");return false;}
        Cast cast=casts.get(player.getUniqueId());
        if(cast==null || !cast.confirmed || !valid(player,cast) || !(cast.hook.getHookedEntity() instanceof LivingEntity target)
                || !ServerThreads.owns(target) || target.equals(player) || !target.isValid() || target.isDead() || !target.getWorld().equals(player.getWorld())
                || (cast.collision!=null && cast.collision.isCancelled()) || customHook.test(cast.hook)) {
            text.send(player,"ability.sharp-hook-no-target");return false;
        }
        var policy=settings.get().sharpHook();
        if(!SharpHookRules.withinRange(player.getLocation().distanceSquared(target.getLocation()),policy.maximumDistance())) {
            text.send(player,"ability.sharp-hook-no-target");return false;
        }
        if(target instanceof Player && (!policy.allowPvp() || !player.getWorld().getPVP())){text.send(player,"ability.sharp-hook-pvp-disabled");return false;}
        var skill=config.skill("fishing");
        if(skill==null)return false;
        double damage=policy.damage(ActiveSkillProgression.rank(config,skill,cast.profile));
        if(!Double.isFinite(damage) || damage<=0)return false;
        double before=target.getHealth(),absorption=target.getAbsorptionAmount();
        // 真正的原生玩家伤害保留保护插件与PvP归属，强制要求主手鱼竿使LRE普通武器增幅不误套用。
        // 自有上下文让技能的力量/暴击/流血/蓄力/护盾不再次处理；LRE引发的反伤也不会重入此能力。
        SecondaryDamageContext.run(player,()->target.damage(Math.min(damage,100),player));
        boolean applied=SharpHookRules.damaged(before,absorption,target.getHealth(),target.getAbsorptionAmount());
        if(applied)text.send(player,"ability.sharp-hook-activated",Map.of("ability",text.plain(active.name())));
        else text.send(player,"ability.sharp-hook-blocked");
        return applied;
    }
    @EventHandler(priority=EventPriority.MONITOR)
    public void onCast(PlayerFishEvent event) {
        Player player=event.getPlayer();
        if(event.getState()!=PlayerFishEvent.State.FISHING)return;
        var skill=config.skill("fishing");var profile=profiles.get(player.getUniqueId());
        if(event.getHand()!=EquipmentSlot.HAND || skill==null || !skill.active().type().equals("SHARP_HOOK") || profile==null
                || (!casts.containsKey(player.getUniqueId()) && casts.size()>=CAPACITY))return;
        casts.put(player.getUniqueId(),new Cast(event,profile,config.revision(),player.getInventory().getHeldItemSlot(),
                ToolIdentity.snapshot(player.getInventory().getItemInMainHand())));
    }
    @EventHandler(priority=EventPriority.MONITOR)
    public void onHit(ProjectileHitEvent event) {
        if(!(event.getEntity() instanceof FishHook hook) || !ServerThreads.owns(hook) || !(hook.getShooter() instanceof Player player))return;
        Cast cast=casts.get(player.getUniqueId());if(cast!=null && cast.hook.equals(hook))cast.collision=event;
    }
    @EventHandler(priority=EventPriority.MONITOR)
    public void onLeftClick(PlayerInteractEvent event) {
        if(abilities==null || event.getHand()!=EquipmentSlot.HAND || !casts.containsKey(event.getPlayer().getUniqueId())
                || (event.getAction()!=Action.LEFT_CLICK_AIR && event.getAction()!=Action.LEFT_CLICK_BLOCK)
                || event.getPlayer().getInventory().getItemInMainHand().getType()!=Material.FISHING_ROD)return;
        // 延至次tick读最终交互取消结果，避免MONITOR后注册的保护插件被绕过。
        gestures.put(event.getPlayer().getUniqueId(),new Gesture(event,casts.get(event.getPlayer().getUniqueId())));
    }
    private boolean valid(Player player,Cast cast) {
        var skill=config.skill("fishing");
        return ServerThreads.owns(player) && ServerThreads.owns(cast.hook) && player.isOnline() && player.isValid() && !player.isDead() && skills.eligible(player)
                && player.hasPermission("liskills.use") && player.hasPermission("liskills.skill.fishing")
                && profiles.get(player.getUniqueId())==cast.profile && config.revision()==cast.revision
                && skill!=null && skill.enabled() && skill.active().enabled() && skill.active().type().equals("SHARP_HOOK")
                && !cast.launch.isCancelled() && cast.launch.getHand()==EquipmentSlot.HAND
                && cast.hook.isValid() && !cast.hook.isDead() && cast.hook.getWorld().equals(player.getWorld())
                && cast.hook.getShooter() instanceof Player shooter && shooter.getUniqueId().equals(player.getUniqueId())
                && player.getInventory().getHeldItemSlot()==cast.slot
                && player.getInventory().getItemInMainHand().getType()==Material.FISHING_ROD
                && cast.tool.isSimilar(ToolIdentity.snapshot(player.getInventory().getItemInMainHand()));
    }
    private void tick(Player player) {
        UUID id=player.getUniqueId();Cast cast=casts.get(id);
        if(cast!=null && !valid(player,cast)){casts.remove(id,cast);cast=null;}
        if(cast!=null)cast.confirmed=true;
        Gesture gesture=gestures.remove(id);
        if(gesture!=null) {
            PlayerInteractEvent event=gesture.event();
            if(cast==null || cast!=gesture.cast() || !valid(player,cast) || event.useItemInHand()==Event.Result.DENY
                    || (event.getClickedBlock()!=null && event.useInteractedBlock()==Event.Result.DENY))return;
            if(abilities!=null)abilities.activate(player,"fishing");
        }
    }
    @EventHandler public void onQuit(PlayerQuitEvent event){casts.remove(event.getPlayer().getUniqueId());gestures.remove(event.getPlayer().getUniqueId());}
    @Override public void close(){cleanup.close();scheduler.cancelAll();casts.clear();gestures.clear();abilities=null;}
    private record Gesture(PlayerInteractEvent event,Cast cast) { }
    private static final class Cast {
        private final PlayerFishEvent launch;
        private final FishHook hook;
        private final PlayerProfile profile;
        private final long revision;
        private final int slot;
        private final ItemStack tool;
        private volatile ProjectileHitEvent collision;
        private volatile boolean confirmed;
        private Cast(PlayerFishEvent launch,PlayerProfile profile,long revision,int slot,ItemStack tool) {
            this.launch=launch;this.hook=launch.getHook();this.profile=profile;this.revision=revision;this.slot=slot;this.tool=tool;
        }
    }
}
