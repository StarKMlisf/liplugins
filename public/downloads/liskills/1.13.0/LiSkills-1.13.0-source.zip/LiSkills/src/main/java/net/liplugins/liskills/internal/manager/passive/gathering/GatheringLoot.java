package net.liplugins.liskills.internal.manager.passive.gathering;

import net.liplugins.liskills.internal.config.LootEntrySettings;
import net.liplugins.liskills.internal.config.LootPoolSettings;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.PotionMeta;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/** 宝藏池的概率、加权选择、堆叠拆分；不自行创造收获触发。 */
final class GatheringLoot {
    private final GatheringContext context;
    GatheringLoot(GatheringContext context) { this.context = context; }

    LootEntrySettings select(Player player, String skill, Material source, boolean openWater) {
        Selection selected=selectPool(player,skill,source,openWater);
        return selected==null?null:selected.entry;
    }
    Selection selectPool(Player player, String skill, Material source, boolean openWater) {
        for (LootPoolSettings pool : context.config().loot().pools(skill)) {
            String ability = ability(skill, pool.id());
            if (!pool.enabled() || context.passives().level(player, ability) <= 0 || pool.requireOpenWater() && !openWater) continue;
            List<LootEntrySettings> matching = pool.entries().stream().filter(entry -> entry.accepts(source)).toList();
            if (matching.isEmpty()) continue;
            double abilityValue = context.passives().value(player, ability);
            double chance = GatheringRules.poolChance(pool.baseChance(), pool.chancePerLuck(),
                    context.stats().value(player, "luck"), abilityValue,
                    context.passives().flag(ability, "scale_base_value_chance", false));
            if (ThreadLocalRandom.current().nextDouble() >= chance) continue;
            return new Selection(pool.id(),choose(matching, ThreadLocalRandom.current().nextDouble()));
        }
        return null;
    }
    record Selection(String pool,LootEntrySettings entry) { }

    static LootEntrySettings choose(List<LootEntrySettings> entries, double random) {
        if (entries.isEmpty() || !Double.isFinite(random) || random < 0 || random >= 1) return null;
        double total = entries.stream().mapToDouble(LootEntrySettings::weight).sum();
        if (!Double.isFinite(total) || total <= 0) return null;
        double target = random * total;
        for (LootEntrySettings entry : entries) {
            target -= entry.weight();
            if (target < 0) return entry;
        }
        return entries.getLast();
    }

    ItemStack create(LootEntrySettings entry) {
        int amount = ThreadLocalRandom.current().nextInt(entry.minimumAmount(), entry.maximumAmount() + 1);
        ItemStack item = new ItemStack(entry.material(), amount);
        if (entry.potion() != null && item.getItemMeta() instanceof PotionMeta potion) {
            potion.setBasePotionType(entry.potion());
            item.setItemMeta(potion);
        }
        return item;
    }
    boolean drop(Location location, ItemStack template, int amount) {
        if (amount <= 0 || !GatheringContext.loaded(location)) return false;
        boolean delivered = false;
        int remaining = Math.min(64, amount);
        while (remaining > 0) {
            ItemStack portion = template.clone();
            int count = Math.min(remaining, portion.getMaxStackSize());
            portion.setAmount(count);
            delivered |= location.getWorld().dropItemNaturally(location, portion).isValid();
            remaining -= count;
        }
        return delivered;
    }
    static String ability(String skill, String pool) {
        if (skill.equals("fishing")) return pool.equals("rare") ? "treasure_hunter" : "epic_catch";
        return pool.equals("rare") ? "metal_detector" : "lucky_spades";
    }
}
