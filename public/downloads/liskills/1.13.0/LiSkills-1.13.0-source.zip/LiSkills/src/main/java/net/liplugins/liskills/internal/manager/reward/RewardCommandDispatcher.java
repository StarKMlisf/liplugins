package net.liplugins.liskills.internal.manager.reward;

import net.liplugins.liskills.lib.scheduler.ServerThreads;
import net.liplugins.liskills.lib.scheduler.TaskScheduler;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;
import java.util.List;
import java.util.function.Consumer;

/** 奖励只提交已固定的命令文本；Folia控制台命令在全局线程串行执行。 */
public final class RewardCommandDispatcher {
    private final TaskScheduler tasks;
    public RewardCommandDispatcher(JavaPlugin plugin){tasks=new TaskScheduler(plugin);}
    public void dispatch(List<String> commands,Consumer<Boolean> completion){
        List<String> snapshot=List.copyOf(commands);
        Runnable action=()->{
            boolean success=true;
            for(String command:snapshot){
                try { success &= Bukkit.dispatchCommand(Bukkit.getConsoleSender(),command); }
                catch(RuntimeException failure){success=false;}
            }
            completion.accept(success);
        };
        if(snapshot.isEmpty())completion.accept(true);
        else if(ServerThreads.global())action.run();
        else tasks.global(action);
    }
}
