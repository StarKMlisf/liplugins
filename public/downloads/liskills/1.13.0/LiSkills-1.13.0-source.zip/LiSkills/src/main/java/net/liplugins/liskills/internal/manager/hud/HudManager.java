package net.liplugins.liskills.internal.manager.hud;

import net.liplugins.liskills.api.SkillExperienceGainEvent;
import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.config.HudSettings;
import net.liplugins.liskills.internal.manager.ManaManager;
import net.liplugins.liskills.internal.manager.ManaMath;
import net.liplugins.liskills.internal.manager.ProfileManager;
import net.liplugins.liskills.internal.manager.SkillManager;
import net.liplugins.liskills.internal.storage.PlayerProfile;
import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerGameModeChangeEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;
import net.liplugins.liskills.lib.scheduler.PlayerTasks;
import net.liplugins.liskills.lib.scheduler.TaskScheduler;
import net.liplugins.liskills.lib.scheduler.ServerThreads;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** 玩家实体时钟刷新 HUD；不修改生命缩放、经验条、记分板或动作栏。 */
public final class HudManager implements Listener, AutoCloseable {
    private final ConfigManager config;
    private final ProfileManager profiles;
    private final SkillManager skills;
    private final TextService text;
    private final HudPreferenceStore preferences;
    private final Map<UUID, HudDisplay> displays = new java.util.concurrent.ConcurrentHashMap<>();
    private final Map<UUID, Long> displayRevisions = new java.util.concurrent.ConcurrentHashMap<>();
    private final Map<UUID, TickState> ticks = new java.util.concurrent.ConcurrentHashMap<>();
    private final HudExperienceSchedule experienceSchedule = new HudExperienceSchedule();
    private final PlayerTasks task;
    private final TaskScheduler scheduler;
    private volatile boolean closed;

    public HudManager(JavaPlugin plugin, ConfigManager config, ProfileManager profiles, SkillManager skills, TextService text) {
        this.config = config;
        this.profiles = profiles;
        this.skills = skills;
        this.text = text;
        preferences = new HudPreferenceStore(new NamespacedKey(plugin, "hud_enabled"));
        // 玩家区域每 tick 检查经验期限，常驻条仍按配置间隔刷新；慢区域不会积压全局任务。
        scheduler = new TaskScheduler(plugin);
        task = new PlayerTasks(plugin, this::tick, 1, 1);
    }

    /** 全局关闭时返回 false；个人偏好仍然保留，之后重新启用配置会恢复。 */
    public boolean enabled(Player player) {
        return !closed && ServerThreads.owns(player) && config.hud().enabled()
                && preferences.enabled(player.getPersistentDataContainer(), config.hud().defaultEnabled());
    }

    /** 由玩家所属线程的指令调用；关闭时立即移除该玩家的全部 HUD。 */
    public void setEnabled(Player player, boolean enabled) {
        if (closed || !ServerThreads.owns(player)) return;
        preferences.setEnabled(player.getPersistentDataContainer(), enabled);
        if (enabled) refreshPlayer(player, System.currentTimeMillis());
        else remove(player.getUniqueId());
    }

    public boolean toggle(Player player) {
        if (!ServerThreads.owns(player)) return false;
        boolean next = !preferences.enabled(player.getPersistentDataContainer(), config.hud().defaultEnabled());
        setEnabled(player, next);
        return enabled(player);
    }

    private void tick(Player player) {
        if (closed) return;
        TickState state = ticks.computeIfAbsent(player.getUniqueId(), ignored -> new TickState());
        state.tick++;
        long now = System.currentTimeMillis();
        boolean experienceDue = experienceSchedule.drain(player.getUniqueId(), now);
        if (displayRevisions.getOrDefault(player.getUniqueId(), -1L) != config.revision() || state.tick >= state.nextRefresh) {
            refreshPlayer(player, now);
            state.nextRefresh = state.tick + config.hud().updateTicks();
        } else if (experienceDue) refreshExperience(player, now);
    }

    /** 重载入口可以主动调用；刷新所有在线玩家并回收断开的会话。 */
    public void refresh() {
        if (closed) return;
        long now = System.currentTimeMillis();
        for (Player player : Bukkit.getOnlinePlayers()) scheduler.entityNow(player, () -> refreshPlayer(player, now));
        displays.entrySet().removeIf(entry -> {
            if (Bukkit.getPlayer(entry.getKey()) != null) return false;
            experienceSchedule.remove(entry.getKey());
            displayRevisions.remove(entry.getKey());
            return true;
        });
    }

    private boolean visible(Player player) {
        return enabled(player) && player.isOnline() && !player.isDead() && player.hasPermission("liskills.hud")
                && skills.eligible(player);
    }

    private void refreshPlayer(Player player, long now) {
        if (closed || !ServerThreads.owns(player)) return;
        prepareRevision(player);
        // 存储可用状态由 IO 线程更新；只读取一次，避免先判非空、再次读取却已变 null。
        PlayerProfile profile = profiles.get(player.getUniqueId());
        if (profile == null || !visible(player)) {
            remove(player.getUniqueId());
            displayRevisions.put(player.getUniqueId(), config.revision());
            return;
        }
        HudDisplay display = displays.computeIfAbsent(player.getUniqueId(), ignored -> new HudDisplay());
        HudSettings settings = config.hud();
        DisplayValues values = values(player, profile);
        display.render(HudDisplay.Slot.HEALTH, player, settings.health(), text.text(settings.health().message(), values.replacements()),
                HudProgress.fraction(values.health(), values.maximumHealth()));
        if (config.mana().enabled())
            display.render(HudDisplay.Slot.MANA, player, settings.mana(), text.text(settings.mana().message(), values.replacements()),
                    HudProgress.fraction(values.mana(), values.maximumMana()));
        else display.hide(HudDisplay.Slot.MANA);
        renderExperience(player, profile, display, values.replacements(), now);
    }

    private void refreshExperience(Player player, long now) {
            if (closed || !ServerThreads.owns(player)) return;
            UUID uuid = player.getUniqueId();
            prepareRevision(player);
            HudDisplay display = displays.get(uuid);
            PlayerProfile profile = profiles.get(uuid);
            if (display == null || profile == null || !visible(player)) {
                remove(uuid);
                return;
            }
            renderExperience(player, profile, display, values(player, profile).replacements(), now);
    }

    private void prepareRevision(Player player) {
        UUID uuid = player.getUniqueId();
        if (displayRevisions.getOrDefault(uuid, -1L) == config.revision()) return;
        remove(uuid);
        displayRevisions.put(uuid, config.revision());
    }

    private DisplayValues values(Player player, PlayerProfile profile) {
        AttributeInstance health = player.getAttribute(Attribute.MAX_HEALTH);
        double maximumHealth = health == null ? 0 : HudProgress.value(health.getValue());
        double currentHealth = HudProgress.value(player.getHealth());
        double maximumMana = HudProgress.value(ManaManager.maximum(profile, config));
        double currentMana = maximumMana > 0 ? HudProgress.value(ManaMath.available(profile.mana(), maximumMana)) : 0;
        Map<String, Object> values = new HashMap<>();
        values.put("health", text.format(currentHealth));
        values.put("max_health", text.format(maximumHealth));
        values.put("absorption", text.format(HudProgress.value(player.getAbsorptionAmount())));
        values.put("mana", text.format(currentMana));
        values.put("max_mana", text.format(maximumMana));
        return new DisplayValues(currentHealth, maximumHealth, currentMana, maximumMana, values);
    }

    private void renderExperience(Player player, PlayerProfile profile, HudDisplay display, Map<String, Object> values, long now) {
        HudExperience recent = display.experience();
        var definition = recent.skill() == null ? null : config.skill(recent.skill());
        if (!config.hud().skill().enabled() || !recent.visible(now) || definition == null || !definition.enabled()
                || !player.hasPermission("liskills.skill." + recent.skill())) {
            display.hide(HudDisplay.Slot.SKILL);
            return;
        }
        var progress = profile.progress(recent.skill());
        boolean maximum = progress.level() >= definition.maxLevel();
        double required = maximum ? 0 : definition.requiredXp(progress.level());
        values.put("skill", text.plain(definition.name()));
        values.put("level", progress.level());
        values.put("xp", text.format(progress.xp()));
        values.put("required", text.format(required));
        values.put("gain", text.format(recent.gain()));
        String message = maximum ? config.hud().maximumMessage() : config.hud().skill().message();
        display.render(HudDisplay.Slot.SKILL, player, config.hud().skill(), text.text(message, values),
                maximum ? 1 : HudProgress.fraction(progress.xp(), required));
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onGain(SkillExperienceGainEvent event) {
        Player player = event.getPlayer();
        if (!ServerThreads.owns(player) || !config.hud().skill().enabled() || !visible(player)
                || profiles.get(player.getUniqueId()) == null || Bukkit.getPlayer(player.getUniqueId()) != player) return;
        // 重载后的第一笔经验必须属于新快照，不能在下一次刷新时连同旧条一起丢弃。
        prepareRevision(player);
        HudExperience recent = displays.computeIfAbsent(player.getUniqueId(), ignored -> new HudDisplay()).experience();
        recent.add(event.getSkill(), event.getAmount(), System.currentTimeMillis(), config.hud().experienceDurationSeconds());
        experienceSchedule.changed(player.getUniqueId(), recent.expires());
    }

    @EventHandler public void onQuit(PlayerQuitEvent event) { remove(event.getPlayer().getUniqueId()); ticks.remove(event.getPlayer().getUniqueId()); }
    @EventHandler public void onDeath(PlayerDeathEvent event) { remove(event.getEntity().getUniqueId()); }
    @EventHandler public void onWorld(PlayerChangedWorldEvent event) { remove(event.getPlayer().getUniqueId()); }
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onGameMode(PlayerGameModeChangeEvent event) { remove(event.getPlayer().getUniqueId()); }

    private void remove(UUID uuid) {
        experienceSchedule.remove(uuid);
        displayRevisions.remove(uuid);
        HudDisplay display = displays.remove(uuid);
        if (display != null) display.close();
    }

    private void clear() {
        displays.forEach((uuid, display) -> {
            Player player = Bukkit.getPlayer(uuid);
            if (player != null && ServerThreads.owns(player)) display.close();
        });
        displays.clear();
        displayRevisions.clear();
        ticks.clear();
        experienceSchedule.clear();
    }

    private record DisplayValues(double health, double maximumHealth, double mana, double maximumMana,
                                 Map<String, Object> replacements) { }
    private static final class TickState { private long tick; private long nextRefresh; }

    @Override public void close() {
        if (closed) return;
        closed = true;
        task.close();
        scheduler.cancelAll();
        clear();
    }
}
