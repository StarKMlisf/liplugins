package net.liplugins.liskills.internal.config;

import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.configuration.ConfigurationSection;

import java.util.List;
import java.util.Locale;

/** HUD 的完整不可变快照；所有字段通过验证后才允许替换正在使用的配置。 */
public record HudSettings(boolean enabled, boolean defaultEnabled, int updateTicks, int experienceDurationSeconds,
                          Bar health, Bar mana, Bar skill, String maximumMessage) {
    public record Bar(boolean enabled, BarColor color, BarStyle style, String message) { }

    public static HudSettings parse(ConfigurationSection root) {
        if (root == null) throw ConfigValues.invalid("hud", "配置节");
        return new HudSettings(ConfigValues.bool(root, "enabled"), ConfigValues.bool(root, "default-enabled"),
                ConfigValues.integer(root, "update-ticks", 1, 200),
                ConfigValues.integer(root, "experience-duration-seconds", 1, 60),
                bar(root, "health"), bar(root, "mana"), bar(root, "skill"),
                messageKey(root, "skill.maximum-message"));
    }

    /** 提前检查文本引用，避免重载成功后把找不到的消息键展示给玩家。 */
    public void validateMessages(ConfigurationSection messages) {
        for (String key : List.of(health.message(), mana.message(), skill.message(), maximumMessage)) {
            if (messages == null || !(messages.get(key) instanceof String value) || value.isBlank())
                throw ConfigValues.invalid("hud.message." + key, "messages.yml 中已存在的非空文本");
        }
    }

    private static Bar bar(ConfigurationSection root, String path) {
        ConfigurationSection section = ConfigValues.section(root, path);
        BarColor color;
        BarStyle style;
        try { color = BarColor.valueOf(ConfigValues.text(section, "color").toUpperCase(Locale.ROOT)); }
        catch (IllegalArgumentException error) {
            throw ConfigValues.invalid("hud." + path + ".color", "PINK、BLUE、RED、GREEN、YELLOW、PURPLE 或 WHITE");
        }
        try { style = BarStyle.valueOf(ConfigValues.text(section, "style").toUpperCase(Locale.ROOT)); }
        catch (IllegalArgumentException error) {
            throw ConfigValues.invalid("hud." + path + ".style", "SOLID、SEGMENTED_6、SEGMENTED_10、SEGMENTED_12 或 SEGMENTED_20");
        }
        return new Bar(ConfigValues.bool(section, "enabled"), color, style, messageKey(section, "message"));
    }

    private static String messageKey(ConfigurationSection section, String path) {
        String key = ConfigValues.text(section, path);
        if (!key.matches("[a-zA-Z0-9_-]+(?:\\.[a-zA-Z0-9_-]+)*"))
            throw ConfigValues.invalid("hud." + path, "messages.yml 的消息键，例如 hud.health");
        return key;
    }
}
