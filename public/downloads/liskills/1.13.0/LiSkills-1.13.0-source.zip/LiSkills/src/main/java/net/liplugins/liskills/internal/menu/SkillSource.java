package net.liplugins.liskills.internal.menu;

import org.bukkit.Material;
import java.util.List;

/** 单条经验来源的只读展示数据；不携带可执行指令。 */
record SkillSource(String id,String name,String kind,double experience,Material icon,String unit,List<String> details) {
    SkillSource { details=List.copyOf(details); }
}
