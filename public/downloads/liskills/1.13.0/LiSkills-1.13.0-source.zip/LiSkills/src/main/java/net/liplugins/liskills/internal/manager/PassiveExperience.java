package net.liplugins.liskills.internal.manager;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.storage.PlayerProfile;
import java.util.Map;

/** 专精只在自然经验入口计算一次；管理指令和设置等级不会享受倍数。 */
public final class PassiveExperience {
    private static final Map<String,String> SPECIALISTS = Map.ofEntries(
            Map.entry("farming","farmer"),Map.entry("foraging","forager"),Map.entry("mining","miner"),
            Map.entry("fishing","fisher"),Map.entry("excavation","excavator"),Map.entry("archery","archer"),
            Map.entry("defense","defender"),Map.entry("fighting","fighter"),Map.entry("agility","jumper"),
            Map.entry("alchemy","brewer"),Map.entry("enchanting","enchanter"),
            Map.entry("endurance","runner"),Map.entry("healing","healer"),Map.entry("forging","forger"));
    private PassiveExperience() { }
    public static double multiplier(ConfigManager config,PlayerProfile profile,String skill) {
        if(!config.progressionEnabled() || profile==null)return 1;
        var definition=config.passives().get(SPECIALISTS.getOrDefault(skill,""));
        var parent=config.skill(skill);
        if(definition==null || parent==null || !definition.skill().equals(skill))return 1;
        return 1+definition.value(Math.min(parent.maxLevel(),profile.progress(skill).level()))/100;
    }
}
