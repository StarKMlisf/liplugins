package net.liplugins.liskills.internal.config;

/** 魔力规则：离线不回复，变更上限只限制当前值，不重置档案。 */
public record ManaSettings(boolean enabled,double baseMaximum,double perWisdomLevel,double regenPerSecond) { }
