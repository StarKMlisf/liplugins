package net.liplugins.liskills.internal.listener.stat;

import net.liplugins.liskills.internal.manager.stat.StatManager;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityRegainHealthEvent;

/** 再生仅增强原版饱食回血，不处理药水、信标或其他插件的自定义回血。 */
public final class StatRegenerationListener implements Listener {
    private final StatManager stats;
    public StatRegenerationListener(StatManager stats) { this.stats = stats; }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onRegain(EntityRegainHealthEvent event) {
        if (!(event.getEntity() instanceof Player player) || !stats.active(player)
                || event.getRegainReason() != EntityRegainHealthEvent.RegainReason.SATIATED
                || !Double.isFinite(event.getAmount()) || event.getAmount() <= 0) return;
        String trait = player.getSaturation() > 0 ? "saturation-regen"
                : player.getFoodLevel() >= 14 ? "hunger-regen" : null;
        if (trait == null) return;
        double extra = stats.trait(player, trait);
        if (extra > 0 && Double.isFinite(event.getAmount() + extra)) event.setAmount(event.getAmount() + extra);
    }
}
