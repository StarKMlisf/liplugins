package net.liplugins.liskills.internal.manager;

import net.liplugins.liskills.internal.config.*;
import net.liplugins.liskills.internal.storage.PlayerProfile;

/** 菜单与施法共享同一套等级计算，避免显示基础消耗、实际扣除升级消耗。 */
public final class ActiveSkillProgression {
    private ActiveSkillProgression() { }
    public static ActiveSkill resolve(ConfigManager config,SkillDefinition skill,PlayerProfile profile) {
        return resolve(skill.active(),config.activeGrowth().get(skill.id()),config.progressionEnabled(),
                Math.min(skill.maxLevel(),profile.progress(skill.id()).level()),config.balance());
    }
    public static int rank(ConfigManager config,SkillDefinition skill,PlayerProfile profile) {
        return rank(skill.active(),config.activeGrowth().get(skill.id()),config.progressionEnabled(),
                Math.min(skill.maxLevel(),profile.progress(skill.id()).level()),config.balance());
    }
    /** 纯计算入口，同时用于展示、执行和配置规则测试。 */
    public static ActiveSkill resolve(ActiveSkill base,ActiveGrowth growth,boolean progressionEnabled,int skillLevel,BalanceSettings balance) {
        ActiveSkill resolved=!progressionEnabled || growth==null?base:growth.resolve(base,skillLevel,balance.activeRankLimit());
        if(ActiveTimingRules.isToggle(resolved.type())) {
            // 正的持续值仅用于既有配置合法性校验；实际没有窗口，激活费用与冷却均为零。
            return new ActiveSkill(resolved.enabled(),resolved.name(),resolved.effect(),resolved.amplifier(),resolved.durationSeconds(),0,
                    resolved.unlockLevel(),0,resolved.type());
        }
        return balance.apply(resolved);
    }
    public static int rank(ActiveSkill base,ActiveGrowth growth,boolean progressionEnabled,int skillLevel,BalanceSettings balance) {
        int rank=!progressionEnabled || growth==null || !growth.enabled()
                ?(skillLevel>=base.unlockLevel()?1:0):growth.rank(skillLevel,base.unlockLevel());
        return Math.min(rank,balance.activeRankLimit());
    }
}
