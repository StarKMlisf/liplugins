package net.liplugins.liskills.internal.hook.customfishing;

import net.liplugins.liskills.lib.scheduler.ServerThreads;
import net.liplugins.liskills.lib.scheduler.TaskScheduler;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.manager.ProfileManager;
import net.liplugins.liskills.internal.manager.SkillAbilityWindows;
import net.liplugins.liskills.internal.manager.SkillManager;
import net.liplugins.liskills.internal.util.TextService;
import net.liplugins.liskills.lib.customfishing.CustomFishingAccess;
import org.bukkit.Bukkit;
import org.bukkit.entity.FishHook;
import org.bukkit.event.Event;
import org.bukkit.event.EventPriority;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Map;
import java.util.UUID;

/** CustomFishing 可选桥的生命周期和归属查询；经验与加速分别委托独立业务类。 */
public final class CustomFishingHook implements AutoCloseable {
    private static final String PLUGIN = "CustomFishing";
    private final JavaPlugin plugin;
    private final ConfigManager config;
    private final SkillManager skills;
    private final SkillAbilityWindows windows;
    private final TextService text;
    private final ProfileManager profiles;
    private final Listener listener = new Listener() { };
    private final CustomFishingClaims<UUID> managed = new CustomFishingClaims<>(4096, 300_000L);
    private Plugin owner;
    private CustomFishingAccess access;
    private CustomFishingExperience experience;
    private CustomFishingQuickFish quickFish;
    private final TaskScheduler scheduler;
    private volatile boolean failed, closed;

    public CustomFishingHook(JavaPlugin plugin, ConfigManager config, SkillManager skills,
                             SkillAbilityWindows windows, TextService text, ProfileManager profiles) {
        this.plugin = plugin; this.config = config; this.skills = skills;
        this.windows = windows; this.text = text; this.profiles = profiles;
        this.scheduler = new TaskScheduler(plugin);
    }
    public void register() {
        if (closed || access != null || failed) return;
        owner = Bukkit.getPluginManager().getPlugin(PLUGIN);
        if (owner == null || !owner.isEnabled()) return;
        try {
            access = new CustomFishingAccess(owner);
            experience = new CustomFishingExperience(config, skills, profiles, access, scheduler, this::report);
            quickFish = new CustomFishingQuickFish(config, windows, access, scheduler, this::report);
            register(access.rodEvent(), EventPriority.MONITOR, quickFish::cast);
            register(access.resultEvent(), EventPriority.MONITOR, event -> {
                var result = access.result(event);
                if (!ServerThreads.owns(result.player()) || result.hook()!=null && !ServerThreads.owns(result.hook())) return;
                remember(result.hook());
                experience.observe(event, result);
            });
            register(access.effectEvent(), EventPriority.HIGHEST, event -> {
                var effect = access.effect(event);
                if (!ServerThreads.owns(effect.player()) || effect.hook()!=null && !ServerThreads.owns(effect.hook())) return;
                remember(effect.hook());
                quickFish.effect(effect);
            });
            scheduler.globalTimer(this::tick, 1L, 1L);
            text.send(Bukkit.getConsoleSender(), "custom-content.ready", values());
        } catch (ReflectiveOperationException | RuntimeException | LinkageError error) { report(error); }
    }
    private void register(Class<? extends Event> type, EventPriority priority, EventConsumer consumer) {
        Bukkit.getPluginManager().registerEvent(type, listener, priority, (ignored, event) -> {
            if (!available() || event.isAsynchronous()) return;
            try { consumer.accept(event); }
            catch (ReflectiveOperationException | RuntimeException | LinkageError error) { report(error); }
        }, plugin, false);
    }
    private void tick() {
        if (!available()) {
            if (experience != null) experience.clear();
            if (quickFish != null) quickFish.clear();
            return;
        }
        try {
            managed.clean(System.currentTimeMillis());
            experience.tick();
            quickFish.tick();
        } catch (ReflectiveOperationException | RuntimeException | LinkageError error) { report(error); }
    }
    private void remember(FishHook hook) {
        if (hook != null) managed.remember(hook.getUniqueId(), System.currentTimeMillis());
    }
    private boolean available() { return !closed && !failed && access != null && owner != null && owner.isEnabled(); }
    public boolean owns(FishHook hook) {
        if (closed || hook == null || owner == null || !owner.isEnabled()) return false;
        // API 失配时暂时避让钓鱼钩，不继续争夺计时器。
        if (failed || !ServerThreads.owns(hook)) return true;
        if (!available()) return false;
        if (managed.contains(hook.getUniqueId(), System.currentTimeMillis())) return true;
        try {
            boolean owned = access.owns(hook);
            if (owned) remember(hook);
            return owned;
        } catch (ReflectiveOperationException | RuntimeException | LinkageError error) { report(error); return true; }
    }
    public boolean skipVanillaExperience(PlayerFishEvent event) {
        if (closed || owner == null || !owner.isEnabled()) return false;
        if (failed) return true;
        return access != null && (access.synthetic(event) || owns(event.getHook()));
    }
    public String status() {
        String key = owner == null || !owner.isEnabled() ? "custom-content.absent"
                : failed ? "custom-content.failed-state" : !config.customFishing().enabled()
                ? "custom-content.disabled" : "custom-content.connected";
        var values = new java.util.HashMap<>(values());
        values.put("state", text.plain(text.text(key)));
        return text.text("custom-content.status", values);
    }
    private Map<String, Object> values() {
        return Map.of("plugin", PLUGIN, "version", owner == null ? "-" : owner.getDescription().getVersion());
    }
    private synchronized void report(Throwable error) {
        if (failed) return;
        failed = true;
        if (experience != null) experience.clear();
        if (quickFish != null) quickFish.clear();
        var values = new java.util.HashMap<>(values());
        values.put("error", error.getClass().getSimpleName());
        text.send(Bukkit.getConsoleSender(), "custom-content.failed", values);
    }
    @Override public void close() {
        closed = true;
        HandlerList.unregisterAll(listener);
        if (experience != null) experience.clear();
        if (quickFish != null) quickFish.clear();
        scheduler.cancelAll();
        managed.clear();
    }
    @FunctionalInterface private interface EventConsumer { void accept(Event event) throws ReflectiveOperationException; }
}
