package net.liplugins.liskills.internal.manager;

import net.liplugins.liskills.lib.scheduler.ServerThreads;
import net.liplugins.liskills.lib.scheduler.TaskScheduler;
import org.bukkit.Location;

import net.liplugins.liskills.internal.config.ActiveSkill;
import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.config.SkillDefinition;
import net.liplugins.liskills.internal.hook.LiRealEnchantHook;
import net.liplugins.liskills.internal.listener.PlacedBlockTracker;
import net.liplugins.liskills.internal.storage.PlayerProfile;
import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerItemBreakEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** 管理农耕补种的限时窗口和全服有限延时队列；掉落与经验仍走原生破坏链路。 */
public final class ReplenishManager implements ActiveAbilityHandler, Listener, AutoCloseable {
    private final ConfigManager config;
    private final ProfileManager profiles;
    private final SkillManager skills;
    private final LiRealEnchantHook lre;
    private final TextService text;
    private final CropReplantTransaction transaction;
    private final java.util.function.Predicate<Block> customBlock;
    private final Map<UUID, Window> windows = new java.util.concurrent.ConcurrentHashMap<>();
    private final java.util.concurrent.ConcurrentLinkedDeque<Pending> pending = new java.util.concurrent.ConcurrentLinkedDeque<>();
    private final Set<Position> reserved = java.util.concurrent.ConcurrentHashMap.newKeySet();
    private final Map<UUID, Long> notices = new java.util.concurrent.ConcurrentHashMap<>();
    private final TaskScheduler scheduler;
    private volatile long ticks;
    private volatile boolean closed;
    private final ThreadLocal<Boolean> planting = ThreadLocal.withInitial(() -> false);

    public ReplenishManager(JavaPlugin plugin, ConfigManager config, ProfileManager profiles, SkillManager skills,
                            LiRealEnchantHook lre, TextService text, PlacedBlockTracker placed) {
        this(plugin, config, profiles, skills, lre, text, placed, block -> false);
    }

    public ReplenishManager(JavaPlugin plugin, ConfigManager config, ProfileManager profiles, SkillManager skills,
                            LiRealEnchantHook lre, TextService text, PlacedBlockTracker placed,
                            java.util.function.Predicate<Block> customBlock) {
        this.config = config;
        this.profiles = profiles;
        this.skills = skills;
        this.lre = lre;
        this.text = text;
        this.transaction = new CropReplantTransaction(placed);
        this.customBlock = customBlock;
        this.scheduler = new TaskScheduler(plugin);
        scheduler.globalTimer(this::tick, 1L, 1L);
    }

    @Override public boolean activate(Player player, ActiveSkill active) {
        if (closed || !ServerThreads.owns(player) || !allowed(player) || planting.get()) return false;
        ItemStack tool = player.getInventory().getItemInMainHand();
        if (!CropReplantRules.isHoe(tool.getType())) { text.send(player, "ability.replenish-tool"); return false; }
        if (lre.ownsReplanting(tool)) { text.send(player, "ability.replenish-lre-owned"); return false; }
        Window existing = windows.get(player.getUniqueId());
        if (validWindow(player, existing)) { text.send(player, "ability.replenish-already-active"); return false; }
        stop(player.getUniqueId());
        windows.put(player.getUniqueId(), new Window(player.getWorld().getUID(),
                System.currentTimeMillis() + active.durationSeconds() * 1000L, config.revision(),
                toolIdentity(tool), player.getInventory().getHeldItemSlot()));
        return true;
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        if (closed || !ServerThreads.owns(player) || !ServerThreads.owns(event.getBlock())) return;
        UUID uuid = player.getUniqueId();
        // 连锁附魔的预检事件并不意味着真正收获；放置事件重入也不能再次登记补种。
        if (planting.get() || lre.checkingSecondaryBreak()) return;
        Window window = windows.get(uuid);
        if (window == null) return;
        if (!validWindow(player, window)) { stop(uuid); return; }
        Block block = event.getBlock();
        if (customBlock.test(block)) return;
        if (!CropReplantTransaction.loaded(block) || CropReplantRules.seed(block.getType()) == null) return;
        BlockData crop = block.getBlockData();
        if (!CropReplantRules.mature(block.getType(), crop)) {
            if (config.replenish().preventUnripeBreak()) event.setCancelled(true);
            return;
        }
        Position position = new Position(block.getWorld().getUID(), block.getX(), block.getY(), block.getZ());
        if (reserved.contains(position)) return;
        if (pending.size() >= config.replenish().maxPending()) {
            notice(player, "ability.replenish-busy");
            return;
        }
        if (!reserved.add(position)) return;
        pending.addLast(new Pending(uuid, position, crop.clone(), event, ticks + config.replenish().delayTicks(), window));
    }

    private void tick() {
        ticks++;
        // 全局线程只处理时间与配额，工具/位置/库存全部在玩家区域检查。
        long now = System.currentTimeMillis();
        windows.forEach((uuid, window) -> { if (window.expires <= now || window.revision != config.revision()) stop(uuid); });
        int budget = config.replenish().blocksPerTick();
        for (int attempt = 0; attempt < budget && !pending.isEmpty(); attempt++) {
            Pending job = pending.peekFirst();
            if (job == null) break;
            if (job.due > ticks) break;
            if (!pending.remove(job)) continue;
            Player player = Bukkit.getPlayer(job.player);
            if (player == null) { reserved.remove(job.position); continue; }
            scheduler.entityNow(player, () -> { try { process(player, job); } finally { reserved.remove(job.position); } },
                    () -> reserved.remove(job.position));
        }
    }

    private void process(Player player, Pending job) {
            if (closed || !ServerThreads.owns(player) || windows.get(job.player) != job.window || !validWindow(player, job.window)
                    || job.trigger.isCancelled()) return;
            World world = Bukkit.getWorld(job.position.world);
            if (world == null || !ServerThreads.owns(new Location(world, job.position.x, job.position.y, job.position.z))
                    || !world.isChunkLoaded(job.position.x >> 4, job.position.z >> 4)) return;
            Block block = world.getBlockAt(job.position.x, job.position.y, job.position.z);
            // HIGHEST 后的保护插件可以取消，其他插件也可能重新放方块；只有真实腾空才补种。
            if (!block.getType().isAir() || customBlock.test(block)) return;
            planting.set(true);
            try {
                CropReplantTransaction.Result result = transaction.place(player, block, job.crop, config.replenish().consumeSeed(),
                        () -> windows.get(job.player) == job.window && validWindow(player, job.window));
                if (result == CropReplantTransaction.Result.NO_SEED) notice(player, "ability.replenish-no-seed");
                else if (result == CropReplantTransaction.Result.FAILED) notice(player, "ability.replenish-failed");
            } finally {
                planting.remove();
            }
    }

    private boolean allowed(Player player) {
        SkillDefinition definition = config.skill("farming");
        PlayerProfile profile = profiles.get(player.getUniqueId());
        return player.isOnline() && !player.isDead() && skills.eligible(player) && player.hasPermission("liskills.skill.farming")
                && profile != null && definition != null && definition.enabled() && definition.active().enabled()
                && definition.active().type().equals("REPLENISH")
                && profile.progress("farming").level() >= definition.active().unlockLevel();
    }

    private boolean validWindow(Player player, Window window) {
        if (window == null || window.expires <= System.currentTimeMillis() || window.revision != config.revision()
                || !window.world.equals(player.getWorld().getUID()) || !allowed(player)
                || player.getInventory().getHeldItemSlot() != window.slot) return false;
        ItemStack tool = player.getInventory().getItemInMainHand();
        return CropReplantRules.isHoe(tool.getType()) && window.tool.isSimilar(toolIdentity(tool)) && !lre.ownsReplanting(tool);
    }

    private static ItemStack toolIdentity(ItemStack tool) {
        ItemStack copy = tool.clone();
        ItemMeta meta = copy.getItemMeta();
        if (meta instanceof Damageable damage) { damage.setDamage(0); copy.setItemMeta(meta); }
        return copy;
    }

    private void notice(Player player, String key) {
        long now = System.currentTimeMillis();
        if (now - notices.getOrDefault(player.getUniqueId(), 0L) < 3000) return;
        notices.put(player.getUniqueId(), now);
        text.send(player, key);
    }

    @EventHandler public void onQuit(PlayerQuitEvent event) { stop(event.getPlayer().getUniqueId()); }
    @EventHandler public void onDeath(PlayerDeathEvent event) { stop(event.getEntity().getUniqueId()); }
    @EventHandler public void onWorldChange(PlayerChangedWorldEvent event) { stop(event.getPlayer().getUniqueId()); }
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onHeldItem(PlayerItemHeldEvent event) {
        if (event.getNewSlot() != event.getPreviousSlot()) stop(event.getPlayer().getUniqueId());
    }
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onSwapHands(PlayerSwapHandItemsEvent event) { stop(event.getPlayer().getUniqueId()); }
    @EventHandler public void onToolBreak(PlayerItemBreakEvent event) {
        Window window = windows.get(event.getPlayer().getUniqueId());
        if (window != null && window.tool.isSimilar(toolIdentity(event.getBrokenItem()))) stop(event.getPlayer().getUniqueId());
    }

    private void stop(UUID uuid) {
        windows.remove(uuid);
        notices.remove(uuid);
        pending.removeIf(job -> {
            if (!job.player.equals(uuid)) return false;
            reserved.remove(job.position);
            return true;
        });
    }

    @Override public void close() {
        closed = true;
        scheduler.cancelAll();
        windows.clear();
        pending.clear();
        reserved.clear();
        notices.clear();
    }

    private record Window(UUID world, long expires, long revision, ItemStack tool, int slot) { }
    private record Position(UUID world, int x, int y, int z) { }
    private record Pending(UUID player, Position position, BlockData crop, BlockBreakEvent trigger, long due, Window window) { }
}
