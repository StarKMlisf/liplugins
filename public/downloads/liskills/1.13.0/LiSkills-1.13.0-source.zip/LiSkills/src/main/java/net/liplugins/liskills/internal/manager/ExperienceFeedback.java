package net.liplugins.liskills.internal.manager;

import net.liplugins.liskills.api.SkillExperienceGainEvent;
import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.Bukkit;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;
import net.liplugins.liskills.lib.scheduler.TaskHandle;
import net.liplugins.liskills.lib.scheduler.TaskScheduler;
import net.liplugins.liskills.lib.scheduler.ServerThreads;
import java.util.*;

/** 合并短时间内的经验通知，用 Bukkit BossBar 显示；不占聊天栏，不逐次采集发包。 */
public final class ExperienceFeedback implements Listener,AutoCloseable {
    private final ConfigManager config;
    private final ProfileManager profiles;
    private final SkillManager skills;
    private final TextService text;
    private final Map<UUID,Display> displays=new java.util.concurrent.ConcurrentHashMap<>();
    private final net.liplugins.liskills.lib.scheduler.PlayerTasks task;
    private final TaskScheduler scheduler;
    private volatile boolean closed;
    public ExperienceFeedback(JavaPlugin plugin,ConfigManager config,ProfileManager profiles,SkillManager skills,TextService text) {
        this.config=config;this.profiles=profiles;this.skills=skills;this.text=text;
        scheduler=new TaskScheduler(plugin);
        task=new net.liplugins.liskills.lib.scheduler.PlayerTasks(plugin,this::refresh,2,2);
    }
    @EventHandler(priority=EventPriority.MONITOR)
    public void onGain(SkillExperienceGainEvent event) {
        Player player=event.getPlayer();
        if(closed || !ServerThreads.owns(player) || config.hud().enabled() || !config.feedback().enabled() || Bukkit.getPlayer(player.getUniqueId())!=player)return;
        long now=System.currentTimeMillis();
        Display display=displays.computeIfAbsent(player.getUniqueId(),ignored->new Display());
        // 重载与新经验可能发生在刷新计时器之间；先清旧条，避免旧颜色/样式被新版本号掩盖。
        if(display.revision!=config.revision() && display.bar!=null) {
            display.bar.removeAll();display.bar=null;
        }
        boolean combine=event.getSkill().equals(display.skill) && display.expires>now && display.revision==config.revision();
        display.gain=combine?Math.min(1e15,display.gain+event.getAmount()):event.getAmount();
        display.skill=event.getSkill();display.expires=now+config.feedback().durationSeconds()*1000L;
        display.revision=config.revision();
    }
    private void refresh(Player player) {
        Display display=displays.get(player.getUniqueId());
        if(display!=null)refresh(player,display,System.currentTimeMillis());
    }
    private void refresh(Player player,Display display,long now) {
            if(closed || displays.get(player.getUniqueId())!=display)return;
            var profile=profiles.get(player.getUniqueId());var skill=config.skill(display.skill);
            if(config.hud().enabled() || !config.feedback().enabled() || player==null || player.isDead() || profile==null || skill==null || !skill.enabled()
                    || !skills.eligible(player) || !player.hasPermission("liskills.skill."+display.skill)
                    || display.expires<=now || display.revision!=config.revision()) {
                remove(player.getUniqueId());return;
            }
            var progress=profile.progress(display.skill);boolean maximum=progress.level()>=skill.maxLevel();
            double required=maximum?0:skill.requiredXp(progress.level());
            String title=text.text(maximum?"feedback.maximum":"feedback.experience",Map.of(
                    "skill",text.plain(skill.name()),"gain",text.format(display.gain),"level",progress.level(),
                    "xp",text.format(progress.xp()),"required",text.format(required),
                    "mana",text.format(ManaManager.available(profile,config)),"max_mana",text.format(ManaManager.maximum(profile,config))));
            if(display.bar==null) {
                display.bar=Bukkit.createBossBar(title,config.feedback().color(),config.feedback().style());
                display.bar.addPlayer(player);
            }
            display.bar.setTitle(title);display.bar.setProgress(maximum?1:Math.clamp(progress.xp()/required,0,1));
    }
    @EventHandler public void onQuit(PlayerQuitEvent event){remove(event.getPlayer().getUniqueId());}
    @EventHandler public void onDeath(PlayerDeathEvent event){remove(event.getEntity().getUniqueId());}
    @EventHandler public void onWorld(PlayerChangedWorldEvent event){remove(event.getPlayer().getUniqueId());}
    private void remove(UUID uuid){Display display=displays.remove(uuid);if(display!=null && display.bar!=null)display.bar.removeAll();}
    @Override public void close(){closed=true;task.close();scheduler.cancelAll();displays.forEach((uuid,d)->{Player player=Bukkit.getPlayer(uuid);if(player!=null && ServerThreads.owns(player) && d.bar!=null)d.bar.removeAll();});displays.clear();}
    private static final class Display {String skill;double gain;long expires,revision;BossBar bar;}
}
