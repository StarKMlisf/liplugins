package net.liplugins.liskills.lib.scheduler;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

/** 普通Bukkit/Paper仍全部进入主线程；实体有效性只在该线程读取。 */
final class BukkitSchedulerBackend implements SchedulerBackend {
    private final JavaPlugin plugin;
    BukkitSchedulerBackend(JavaPlugin plugin) { this.plugin = plugin; }
    @Override public boolean enabled() { return plugin.isEnabled(); }
    @Override public Runnable global(Runnable run, long delay, long period) {
        BukkitTask task = period > 0 ? Bukkit.getScheduler().runTaskTimer(plugin, run, delay, period)
                : Bukkit.getScheduler().runTaskLater(plugin, run, delay);
        return task::cancel;
    }
    @Override public Runnable entity(Entity entity, Runnable run, Runnable retired, long delay, long period) {
        return global(() -> {
            if (entity instanceof Player player ? player.isOnline() : entity.isValid()) run.run();
            else retired.run();
        }, delay, period);
    }
    @Override public Runnable region(Location location, Runnable run, long delay) { return global(run, delay, 0); }
}
