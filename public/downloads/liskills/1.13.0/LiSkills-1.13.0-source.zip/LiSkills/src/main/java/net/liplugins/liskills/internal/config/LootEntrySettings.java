package net.liplugins.liskills.internal.config;

import org.bukkit.Material;
import org.bukkit.potion.PotionType;
import java.util.Set;

/** 宝藏池中的一项；只保存不可变材料规则，不在配置读取时创建服务器物品。 */
public record LootEntrySettings(Material material, double weight, int minimumAmount, int maximumAmount,
                                double experience, Set<Material> sources, PotionType potion) {
    public LootEntrySettings { sources = Set.copyOf(sources); }
    public boolean accepts(Material source) { return sources.isEmpty() || sources.contains(source); }
}
