package net.liplugins.liskills.internal.manager.stat;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.config.StatsSettings;
import net.liplugins.liskills.internal.config.ItemModifier;
import net.liplugins.liskills.internal.listener.stat.StatAnvilListener;
import net.liplugins.liskills.internal.listener.stat.StatExperienceListener;
import net.liplugins.liskills.internal.listener.stat.StatLifecycleListener;
import net.liplugins.liskills.internal.listener.stat.StatRegenerationListener;
import net.liplugins.liskills.internal.manager.PassiveAbilityManager;
import net.liplugins.liskills.internal.manager.ProfileManager;
import net.liplugins.liskills.internal.manager.SkillManager;
import net.liplugins.liskills.internal.manager.item.ItemAttributeManager;
import net.liplugins.liskills.internal.manager.item.ItemEffectSnapshot;
import net.liplugins.liskills.internal.storage.PlayerProfile;
import net.liplugins.liskills.lib.scheduler.ServerThreads;
import net.liplugins.liskills.lib.scheduler.TaskScheduler;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;

/** 计算九属性并装配各效果组件；不直接处理战斗伤害。 */
public final class StatManager implements AutoCloseable {
    private final JavaPlugin plugin;
    private final TaskScheduler scheduler;
    private final ConfigManager config;
    private final ProfileManager profiles;
    private final SkillManager skills;
    private final DynamicStatBonuses dynamic;
    private final PassiveAbilityManager passives;
    private final ItemAttributeManager items;
    private volatile Function<Player, Map<String, Double>> bonusProvider = player -> Map.of();
    private volatile Function<Player, Map<String, Double>> passiveBonusProvider = player -> Map.of();
    private final StatAttributeManager attributes;
    private final StatAnvilListener anvils;
    private final List<Listener> listeners;
    private boolean registered;

    public StatManager(JavaPlugin plugin, ConfigManager config, ProfileManager profiles, SkillManager skills,
                       PassiveAbilityManager passives) {
        this(plugin, config, profiles, skills, passives, null);
    }

    public StatManager(JavaPlugin plugin, ConfigManager config, ProfileManager profiles, SkillManager skills,
                       PassiveAbilityManager passives, ItemAttributeManager items) {
        this.plugin = plugin;
        this.scheduler = new TaskScheduler(plugin);
        this.config = config;
        this.profiles = profiles;
        this.skills = skills;
        this.items = items;
        this.passives = passives;
        this.dynamic = new DynamicStatBonuses(passives);
        this.attributes = new StatAttributeManager(plugin, this);
        this.anvils = new StatAnvilListener(this);
        this.listeners = List.of(new StatLifecycleListener(plugin, this), new StatRegenerationListener(this),
                new StatExperienceListener(this), anvils);
    }

    public void register() {
        if (registered) return;
        registered = true;
        listeners.forEach(listener -> Bukkit.getPluginManager().registerEvents(listener, plugin));
        attributes.start();
        refreshAll();
    }

    public boolean active(Player player) {
        return player != null && ServerThreads.owns(player) && player.isOnline() && !player.isDead() && config.progressionEnabled()
                && skills.eligible(player) && profiles.get(player.getUniqueId()) != null;
    }

    public double value(Player player, String statId) { return values(player).getOrDefault(statId, 0.0); }
    public double trait(Player player, String id) { return StatTraits.value(config.stats(), values(player), id); }
    public double trait(Map<String, Double> values, String id) { return StatTraits.value(config.stats(), values, id); }

    /** 注册前注入独立的玩家持久加成提供器；允许有限正负值，最终仍受本插件属性开关与上下限约束。 */
    public void bonusProvider(Function<Player, Map<String, Double>> provider) { bonusProvider = Objects.requireNonNull(provider); }

    /** 临时被动加成与持久奖励分别注入；复苏结束时不会清除奖励模块的加成。 */
    public void passiveBonusProvider(Function<Player, Map<String, Double>> provider) { passiveBonusProvider = Objects.requireNonNull(provider); }

    public Map<String, Double> values(Player player) {
        PlayerProfile profile = player == null ? null : profiles.get(player.getUniqueId());
        if (profile == null) return zeroValues();
        // 跨区域只读已发布快照，不访问远端玩家的装备、药水或权限。
        if (!ServerThreads.owns(player)) return snapshotValues(profile, config);
        if (!active(player)) {
            Map<String, Double> empty = zeroValues();
            profile.statValues(config.revision(), empty, true);
            return empty;
        }
        Map<String, Double> result = new LinkedHashMap<>(StatGrowthCalculator.calculate(config.stats(), config.skills(),
                profile.skills(), skill -> player.hasPermission("liskills.skill." + skill)));
        dynamic.apply(player, result);
        ItemEffectSnapshot equipment = items == null ? ItemEffectSnapshot.EMPTY : items.effects(player);
        for (var provider : List.of(bonusProvider, passiveBonusProvider)) {
            Map<String, Double> additional = provider.apply(player);
            if (additional != null) additional.forEach((id, amount) -> {
                if (amount != null && Double.isFinite(amount)) result.computeIfPresent(id, (key, value) -> {
                    double sum = value + amount;
                    return Double.isFinite(sum) ? sum : Math.copySign(Double.MAX_VALUE, sum);
                });
            });
        }
        equipment.applyStats(result);
        config.stats().definitions().forEach((id, definition) -> result.compute(id, (key, amount) ->
                !definition.enabled() || amount == null || !Double.isFinite(amount) ? 0 : Math.min(definition.maximum(), Math.max(0, amount))));
        Map<String, ItemModifier> traitBonuses = new LinkedHashMap<>(equipment.traits());
        Map.of("farming-luck", "bountiful_harvest", "foraging-luck", "lumberjack", "mining-luck", "lucky_miner",
                "fishing-luck", "lucky_catch", "excavation-luck", "bigger_scoop").forEach((trait, passive) -> {
            double value = passives.value(player, passive);
            if (Double.isFinite(value) && value > 0) {
                ItemModifier item = traitBonuses.getOrDefault(trait, ItemModifier.NONE);
                traitBonuses.put(trait, new ItemModifier(item.add() + value, item.multiply(), item.addPercent()));
            }
        });
        Map<String, Double> snapshot = new StatValueSnapshot(result, traitBonuses);
        profile.statValues(config.revision(), snapshot, traitBonuses, false);
        return snapshot;
    }

    /** 无 Bukkit 调用，允许异步占位符读取；不包含主手、药水或在线权限过滤。 */
    public static Map<String, Double> baseValues(PlayerProfile profile, ConfigManager config) {
        if (profile == null || !config.progressionEnabled()) return zeroValues();
        return StatGrowthCalculator.calculate(config.stats(), config.skills(), profile.skills(), ignored -> true);
    }

    /** 当前权限/动态状态的同版本快照优先；升级后尚未刷新时才回退纯档案成长。 */
    public static Map<String, Double> snapshotValues(PlayerProfile profile, ConfigManager config) {
        if (profile == null || !config.progressionEnabled()) return zeroValues();
        var cached = profile.attributeSnapshot(config.revision());
        if (cached != null) return new StatValueSnapshot(cached.values(), cached.itemTraits());
        if (profile.statsSuppressed()) return zeroValues();
        // 等级改变后沿用同规则下最后一次权限过滤结果，等主线程刷新；不能从纯等级重授已撤销技能的加成。
        var previous = profile.previousAttributeSnapshot(config.revision());
        return previous == null ? baseValues(profile, config) : new StatValueSnapshot(previous.values(), previous.itemTraits());
    }

    public static Map<String, Double> zeroValues() {
        Map<String, Double> values = new LinkedHashMap<>();
        StatsSettings.IDS.forEach(id -> values.put(id, 0.0));
        return Collections.unmodifiableMap(values);
    }

    public void refresh(Player player) { scheduler.entityNow(player, () -> { attributes.refresh(player); anvils.refresh(player); }); }
    public void refreshAll() { Bukkit.getOnlinePlayers().forEach(this::refresh); }
    public void clear(Player player) {
        if (!ServerThreads.owns(player)) return;
        PlayerProfile profile = profiles.get(player.getUniqueId());
        if (profile != null) profile.statValues(config.revision(), zeroValues(), true);
        anvils.restore(player);
        attributes.clear(player);
    }
    public void close() {
        listeners.forEach(HandlerList::unregisterAll);
        scheduler.cancelAll();
        attributes.close();
        registered = false;
    }
}
