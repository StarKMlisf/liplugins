package net.liplugins.liskills.internal.command;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.menu.SkillDisplay;
import net.liplugins.liskills.internal.storage.PlayerProfile;
import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Map;

final class StatsCommand implements Subcommand {
    private final ConfigManager config;
    private final SenderChecks checks;
    private final TextService text;

    StatsCommand(ConfigManager config, SenderChecks checks, TextService text) {
        this.config = config;
        this.checks = checks;
        this.text = text;
    }

    public String name() { return "stats"; }
    public String permission() { return "liskills.use"; }
    public void execute(CommandSender sender, String[] arguments) {
        if (arguments.length > 1) { checks.usage(sender, "command.usage-stats"); return; }
        Player player = arguments.length == 0 ? checks.player(sender) : checks.online(sender, arguments[0]);
        if (player == null) return;
        if (!player.equals(sender) && !checks.permission(sender, "liskills.stats.others")) return;
        checks.onPlayer(player, () -> {
        PlayerProfile profile = checks.profile(sender, player);
        if (profile == null) return;
        text.send(sender, "command.stats-title", Map.of("player", player.getName(), "total", SkillDisplay.totalLevel(config, profile)));
        config.skills().values().stream().filter(skill -> skill.enabled()).forEach(skill ->
                text.send(sender, "command.stats-line", SkillDisplay.values(skill, profile.progress(skill.id()), text)));
        });
    }
}
