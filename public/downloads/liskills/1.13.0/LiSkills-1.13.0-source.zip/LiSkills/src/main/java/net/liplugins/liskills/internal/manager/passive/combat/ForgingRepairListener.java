package net.liplugins.liskills.internal.manager.passive.combat;

import net.liplugins.liskills.internal.manager.PassiveAbilityManager;
import net.liplugins.liskills.internal.manager.source.SourceItemRules;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.PrepareAnvilEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;

/** 修复精通只修改铁砧结果中的耐久，不重建输入元数据，不改费用或原料消耗。 */
final class ForgingRepairListener implements Listener {
    private final PassiveAbilityManager passives;
    ForgingRepairListener(PassiveAbilityManager passives) { this.passives = passives; }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPrepare(PrepareAnvilEvent event) {
        if (!(event.getView().getPlayer() instanceof Player player)) return;
        double percent = passives.value(player, "repairing");
        if (percent <= 0) return;
        ItemStack input = event.getInventory().getItem(0), material = event.getInventory().getItem(1), result = event.getResult();
        if (SourceItemRules.empty(input) || SourceItemRules.empty(material) || SourceItemRules.empty(result)
                || input.getType() != result.getType() || !rawMaterial(input.getType(), material.getType())
                || !(input.getItemMeta() instanceof Damageable before) || !(result.getItemMeta() instanceof Damageable after)) return;
        if (passives.flag("repairing", "ignore_custom_items", true)
                && (SourceItemRules.custom(input) || SourceItemRules.custom(material) || SourceItemRules.custom(result))) return;
        int damage = ForgingRepairMath.enhancedDamage(before.getDamage(), after.getDamage(), percent);
        if (damage == after.getDamage()) return;
        ItemStack improved = result.clone();
        after.setDamage(damage); improved.setItemMeta(after); event.setResult(improved);
    }

    private static boolean rawMaterial(Material equipment, Material material) {
        if (equipment.getMaxDurability() <= 0) return false;
        String name = equipment.name();
        if (name.startsWith("DIAMOND_")) return material == Material.DIAMOND;
        if (name.startsWith("NETHERITE_")) return material == Material.NETHERITE_INGOT;
        if (name.startsWith("IRON_") || name.startsWith("CHAINMAIL_")) return material == Material.IRON_INGOT;
        if (name.startsWith("GOLDEN_")) return material == Material.GOLD_INGOT;
        if (name.startsWith("LEATHER_")) return material == Material.LEATHER;
        if (name.startsWith("COPPER_")) return material == Material.COPPER_INGOT;
        if (name.startsWith("WOODEN_")) return material.name().endsWith("_PLANKS");
        if (name.startsWith("STONE_")) return material == Material.COBBLESTONE || material == Material.BLACKSTONE || material == Material.COBBLED_DEEPSLATE;
        return equipment == Material.ELYTRA && material == Material.PHANTOM_MEMBRANE
                || equipment == Material.TURTLE_HELMET && material == Material.TURTLE_SCUTE;
    }
}
