package net.liplugins.liskills.internal.hook;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.config.SkillDefinition;
import net.liplugins.liskills.internal.manager.ProfileManager;
import net.liplugins.liskills.internal.manager.ManaManager;
import net.liplugins.liskills.internal.manager.stat.StatManager;
import net.liplugins.liskills.internal.config.StatsSettings;
import net.liplugins.liskills.internal.menu.SkillDisplay;
import net.liplugins.liskills.internal.storage.PlayerProfile;
import net.liplugins.liskills.internal.storage.SkillProgress;
import org.bukkit.OfflinePlayer;
import org.bukkit.plugin.java.JavaPlugin;

import java.math.BigDecimal;
import java.util.Locale;

/** 只读取已经载入的内存档案，不在 PAPI 请求线程触发磁盘 IO。 */
public final class LiSkillsExpansion extends PlaceholderExpansion {
    private final JavaPlugin plugin;
    private final ConfigManager config;
    private final ProfileManager profiles;

    public LiSkillsExpansion(JavaPlugin plugin, ConfigManager config, ProfileManager profiles) {
        this.plugin = plugin; this.config = config; this.profiles = profiles;
    }

    @Override public String getIdentifier() { return "liskills"; }
    @Override public String getAuthor() { return String.join(", ", plugin.getDescription().getAuthors()); }
    @Override public String getVersion() { return plugin.getDescription().getVersion(); }
    @Override public boolean persist() { return true; }

    @Override
    public String onRequest(OfflinePlayer player, String raw) {
        String parameter = raw.toLowerCase(Locale.ROOT);
        if(parameter.startsWith("stat_")) {
            String id=parameter.substring("stat_".length());
            if(!StatsSettings.IDS.contains(id))return null;
            PlayerProfile profile=player==null?null:profiles.get(player.getUniqueId());
            return number(StatManager.snapshotValues(profile,config).getOrDefault(id,0.0));
        }
        boolean abilityValue=parameter.startsWith("ability_value_");
        if(abilityValue || parameter.startsWith("ability_")) {
            String id=parameter.substring(abilityValue?"ability_value_".length():"ability_".length());
            var ability=config.passives().get(id);
            if(ability==null)return null;
            PlayerProfile profile=player==null?null:profiles.get(player.getUniqueId());
            var skill=config.skill(ability.skill());
            if(profile==null || !config.progressionEnabled() || skill==null || !skill.enabled())return "0";
            int level=Math.min(profile.progress(skill.id()).level(),skill.maxLevel());
            return abilityValue?number(ability.value(level)):Integer.toString(ability.level(level));
        }
        if(parameter.equals("mana") || parameter.equals("max_mana")) {
            PlayerProfile profile=player==null?null:profiles.get(player.getUniqueId());
            if(profile==null || !config.mana().enabled())return "0";
            return number(parameter.equals("mana")?ManaManager.available(profile,config):ManaManager.maximum(profile,config));
        }
        if (parameter.equals("total_level")) {
            PlayerProfile profile = player == null ? null : profiles.get(player.getUniqueId());
            return profile == null ? "0" : Integer.toString(SkillDisplay.totalLevel(config, profile));
        }
        boolean totalExperience = parameter.startsWith("total_xp_");
        if (totalExperience) parameter = parameter.substring("total_".length());
        int separator = parameter.indexOf('_');
        if (separator < 0) return null;
        String field = parameter.substring(0, separator);
        if (!field.equals("level") && !field.equals("xp") && !field.equals("progress") && !field.equals("required")) return null;
        SkillDefinition skill = config.skill(parameter.substring(separator + 1));
        PlayerProfile profile = player == null ? null : profiles.get(player.getUniqueId());
        if (skill == null || !skill.enabled() || profile == null) return "0";
        SkillProgress progress = profile.progress(skill.id());
        return switch (field) {
            case "level" -> Integer.toString(progress.level());
            case "xp" -> number(totalExperience ? SkillDisplay.totalExperience(skill, progress) : progress.xp());
            case "progress" -> number(progress.xp());
            case "required" -> number(progress.level() >= skill.maxLevel() ? 0 : skill.requiredXp(progress.level()));
            default -> null;
        };
    }

    private String number(double value) {
        return Double.isFinite(value) ? BigDecimal.valueOf(value).stripTrailingZeros().toPlainString() : "0";
    }
}
