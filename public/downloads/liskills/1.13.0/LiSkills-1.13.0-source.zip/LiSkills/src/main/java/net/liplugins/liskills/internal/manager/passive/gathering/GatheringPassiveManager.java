package net.liplugins.liskills.internal.manager.passive.gathering;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.hook.LiRealEnchantHook;
import net.liplugins.liskills.internal.listener.PlacedBlockTracker;
import net.liplugins.liskills.internal.manager.PassiveAbilityManager;
import net.liplugins.liskills.internal.manager.ProfileManager;
import net.liplugins.liskills.internal.manager.SkillManager;
import net.liplugins.liskills.internal.manager.stat.StatManager;
import org.bukkit.Bukkit;
import org.bukkit.block.Block;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.plugin.java.JavaPlugin;
import java.util.List;
import java.util.function.Predicate;

/** 采集被动模块的装配与停止；各类触发由独立监听器负责。 */
public final class GatheringPassiveManager implements AutoCloseable {
    private final JavaPlugin plugin;
    private final GatheringTasks tasks = new GatheringTasks();
    private final List<Listener> listeners;
    private boolean registered;
    public GatheringPassiveManager(JavaPlugin plugin, ConfigManager config, ProfileManager profiles, SkillManager skills,
                                   PassiveAbilityManager passives, StatManager stats, PlacedBlockTracker placed,
                                   LiRealEnchantHook enchantments, Predicate<Block> customBlock,
                                   Predicate<PlayerFishEvent> customFishing) {
        this.plugin = plugin;
        GatheringContext context = new GatheringContext(config, profiles, skills, passives, stats, placed,
                enchantments, customBlock, customFishing, tasks);
        GatheringLoot loot = new GatheringLoot(context);
        listeners = List.of(new BlockGatheringListener(context, loot), new FishingGatheringListener(context, loot),
                new PlantFoodListener(context), new GrowthAuraListener(context), new GatheringArmorListener(context));
    }
    public void register() {
        if (registered) return;
        registered = true;
        listeners.forEach(listener -> Bukkit.getPluginManager().registerEvents(listener, plugin));
        tasks.start(plugin);
    }
    @Override public void close() {
        listeners.forEach(HandlerList::unregisterAll);
        tasks.close();
    }
}
