package net.liplugins.liskills.internal.hook;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import java.lang.reflect.Method;

/** Vault公开Economy服务的可选适配；不下载Vault，不依赖其内部实现。 */
public final class VaultEconomyBridge {
    private volatile Object provider;private Method deposit;
    @SuppressWarnings({"unchecked","rawtypes"})
    public synchronized boolean connect(){
        provider=null;deposit=null;var vault=Bukkit.getPluginManager().getPlugin("Vault");if(vault==null||!vault.isEnabled())return false;
        try{
            Class<?> api=Class.forName("net.milkbowl.vault.economy.Economy",false,vault.getClass().getClassLoader());
            var registration=Bukkit.getServicesManager().getRegistration((Class)api);if(registration==null)return false;
            provider=registration.getProvider();deposit=api.getMethod("depositPlayer",OfflinePlayer.class,double.class);return true;
        }catch(ReflectiveOperationException|LinkageError ignored){provider=null;return false;}
    }
    public boolean available(){return provider!=null;}
    public synchronized boolean deposit(OfflinePlayer player,double amount){
        if(!Double.isFinite(amount)||amount<0)return false;if(amount==0)return true;
        if(!available()&&!connect())return false;
        try{Object response=deposit.invoke(provider,player,amount);return Boolean.TRUE.equals(response.getClass().getMethod("transactionSuccess").invoke(response));}
        catch(ReflectiveOperationException|LinkageError ignored){provider=null;return false;}
    }
}
