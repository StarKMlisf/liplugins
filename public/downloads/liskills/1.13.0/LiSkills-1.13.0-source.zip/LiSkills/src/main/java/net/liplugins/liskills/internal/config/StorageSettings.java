package net.liplugins.liskills.internal.config;

import org.bukkit.configuration.ConfigurationSection;
import java.util.Locale;
import java.util.Set;

/** 存储后端只在启动时选择；密码不出现在toString和校验异常中。 */
public record StorageSettings(Type type, int shutdownTimeoutSeconds, Mysql mysql, Sqlite sqlite) {
    public enum Type { YAML, MYSQL, SQLITE }
    public enum SslMode { VERIFY_IDENTITY, VERIFY_CA, REQUIRED, DISABLED }
    public record Mysql(String host, int port, String database, String username, String password, String tablePrefix,
                        SslMode sslMode, boolean allowPublicKeyRetrieval, int connectTimeoutMillis, int socketTimeoutMillis,
                        int queryTimeoutSeconds) {
        @Override public String toString() { return "Mysql[host="+host+",port="+port+",database="+database+",username="+username+",password=<redacted>,tablePrefix="+tablePrefix+"]"; }
    }
    public record Sqlite(String file, int busyTimeoutMillis) { }
    public static StorageSettings defaults() {
        return new StorageSettings(Type.YAML,20,new Mysql("127.0.0.1",3306,"liskills","liskills","","liskills_",SslMode.VERIFY_IDENTITY,false,5000,10000,10),new Sqlite("profiles.sqlite",5000));
    }
    public static StorageSettings parse(ConfigurationSection root) {
        if(root==null)throw invalid("root");
        keys(root,Set.of("type","shutdown-timeout-seconds","mysql","sqlite","__liskills_backfill"));
        Type type=choice(root,"type",Type.class);int shutdown=integer(root,"shutdown-timeout-seconds",5,120);
        ConfigurationSection mysql=section(root,"mysql"),sqlite=section(root,"sqlite");
        keys(mysql,Set.of("host","port","database","username","password","table-prefix","ssl-mode","allow-public-key-retrieval","connect-timeout-millis","socket-timeout-millis","query-timeout-seconds"));
        keys(sqlite,Set.of("file","busy-timeout-millis"));
        String host=string(mysql,"host",1,253),database=string(mysql,"database",1,64),username=string(mysql,"username",1,128),password=string(mysql,"password",0,4096),prefix=string(mysql,"table-prefix",1,32);
        if(!host.matches("[a-zA-Z0-9.:-]+")||!database.matches("[a-zA-Z0-9_]+")||!prefix.matches("[a-z][a-z0-9_]*"))throw invalid("mysql.identifiers");
        String filename=string(sqlite,"file",1,64);
        if(!filename.matches("[a-zA-Z0-9][a-zA-Z0-9_.-]*")||filename.contains(".."))throw invalid("sqlite.file");
        return new StorageSettings(type,shutdown,new Mysql(host,integer(mysql,"port",1,65535),database,username,password,prefix,
                choice(mysql,"ssl-mode",SslMode.class),bool(mysql,"allow-public-key-retrieval"),integer(mysql,"connect-timeout-millis",1000,30000),
                integer(mysql,"socket-timeout-millis",1000,30000),integer(mysql,"query-timeout-seconds",1,30)),new Sqlite(filename,integer(sqlite,"busy-timeout-millis",1000,30000)));
    }
    private static void keys(ConfigurationSection section,Set<String> allowed){if(!allowed.containsAll(section.getKeys(false)))throw invalid(section.getCurrentPath());}
    private static ConfigurationSection section(ConfigurationSection root,String key){var section=root.getConfigurationSection(key);if(section==null)throw invalid(key);return section;}
    private static String string(ConfigurationSection root,String key,int min,int max){Object value=root.get(key);if(!(value instanceof String text)||text.length()<min||text.length()>max)throw invalid(key);return text;}
    private static boolean bool(ConfigurationSection root,String key){if(!(root.get(key) instanceof Boolean value))throw invalid(key);return value;}
    private static int integer(ConfigurationSection root,String key,int min,int max){Object value=root.get(key);if(!(value instanceof Number number)||!Double.isFinite(number.doubleValue())||number.doubleValue()<min||number.doubleValue()>max||number.doubleValue()!=Math.rint(number.doubleValue()))throw invalid(key);return number.intValue();}
    private static <E extends Enum<E>>E choice(ConfigurationSection root,String key,Class<E> type){try{return Enum.valueOf(type,string(root,key,1,64).toUpperCase(Locale.ROOT));}catch(IllegalArgumentException error){throw invalid(key);}}
    private static IllegalArgumentException invalid(String key){return new IllegalArgumentException("storage.yml配置无效："+key);}
}
