package net.liplugins.liskills.internal.manager.passive.combat;

/** AuraSkills祛魔使用原版最低附魔费用估算平均经验；未知/自定义附魔不猜测数值。 */
final class GrindstoneExperienceMath {
    private GrindstoneExperienceMath() { }
    static int minimum(String enchantment, int level) {
        if (level < 1 || level > 255) return 0;
        int[] rule = switch (enchantment) {
            case "protection", "sharpness" -> new int[]{1, 11};
            case "fire_protection" -> new int[]{10, 8};
            case "feather_falling" -> new int[]{5, 6};
            case "blast_protection", "smite", "bane_of_arthropods", "unbreaking" -> new int[]{5, 8};
            case "projectile_protection" -> new int[]{3, 6};
            case "respiration", "depth_strider", "frost_walker", "soul_speed" -> new int[]{10, 10};
            case "aqua_affinity" -> new int[]{1, 0};
            case "thorns", "fire_aspect" -> new int[]{10, 20};
            case "knockback" -> new int[]{5, 20};
            case "looting", "fortune", "luck_of_the_sea", "lure" -> new int[]{15, 9};
            case "sweeping", "sweeping_edge" -> new int[]{5, 9};
            case "power", "efficiency", "piercing" -> new int[]{1, 10};
            case "punch", "quick_charge" -> new int[]{12, 20};
            case "flame", "infinity", "multishot" -> new int[]{20, 0};
            case "silk_touch" -> new int[]{15, 0};
            case "mending", "channeling" -> new int[]{25, 0};
            case "impaling" -> new int[]{1, 8};
            case "loyalty" -> new int[]{12, 7};
            case "riptide" -> new int[]{17, 7};
            default -> new int[]{0, 0};
        };
        return rule[0] + rule[1] * (level - 1);
    }
    static int bonus(int minimumCostSum, double percent) {
        if (minimumCostSum <= 0 || !Double.isFinite(percent) || percent <= 0) return 0;
        double average = (minimumCostSum + Math.ceil(minimumCostSum / 2.0)) / 2.0;
        return (int) Math.clamp(Math.round(average * Math.min(1000, percent) / 100), 0, 100_000);
    }
}
