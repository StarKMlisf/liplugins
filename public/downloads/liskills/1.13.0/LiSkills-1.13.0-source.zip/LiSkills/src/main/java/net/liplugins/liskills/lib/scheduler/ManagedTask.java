package net.liplugins.liskills.lib.scheduler;

import java.util.function.Consumer;

/** 管理取消、退休与执行完成的竞争；原生句柄晚于取消返回时也必须被立即取消。 */
final class ManagedTask implements TaskHandle {
    private final boolean repeating;
    private final Runnable action;
    private final Runnable retired;
    private final Consumer<ManagedTask> finished;
    private Runnable nativeCancel;
    private boolean running, done, cancelled;

    ManagedTask(boolean repeating, Runnable action, Runnable retired, Consumer<ManagedTask> finished) {
        this.repeating = repeating;
        this.action = action;
        this.retired = retired;
        this.finished = finished;
    }

    void bind(Runnable cancellation) {
        boolean cancel;
        synchronized (this) {
            cancel = done;
            if (!cancel) nativeCancel = cancellation;
        }
        if (cancel) cancellation.run();
    }

    void execute() {
        synchronized (this) {
            if (done || running) return;
            running = true;
        }
        boolean failed = true;
        try { action.run(); failed = false; }
        finally {
            try {
                if (failed) cancel();
                else if (!repeating) complete(false, false);
            } finally { synchronized (this) { running = false; } }
        }
    }

    /** 退休回调只能回收Java缓存；已经退休而拒绝排队时可能在提交者线程执行。 */
    void retire() { complete(true, true); }
    @Override public void cancel() { complete(true, false); }

    private void complete(boolean wasCancelled, boolean retirement) {
        Runnable cancellation;
        synchronized (this) {
            if (done) return;
            done = true;
            cancelled = wasCancelled;
            cancellation = nativeCancel;
            nativeCancel = null;
        }
        try {
            // 完成和退休时也取消底层周期任务，避免已失效的回调继续占用队列。
            if (cancellation != null) cancellation.run();
        } finally {
            try { finished.accept(this); }
            finally { if (retirement && retired != null) retired.run(); }
        }
    }

    @Override public synchronized boolean isCancelled() { return cancelled; }
    @Override public synchronized boolean isDone() { return done; }
}
