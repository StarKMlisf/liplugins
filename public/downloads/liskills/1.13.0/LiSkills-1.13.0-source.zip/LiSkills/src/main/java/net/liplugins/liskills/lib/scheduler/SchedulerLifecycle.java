package net.liplugins.liskills.lib.scheduler;

import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.server.PluginDisableEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** 每插件仅一个停用监听，集中取消Folia实体任务；不读取或修改任何实体世界数据。 */
final class SchedulerLifecycle implements Listener {
    private static final Map<JavaPlugin, SchedulerLifecycle> PLUGINS = new ConcurrentHashMap<>();
    private final JavaPlugin plugin;
    private final TaskScope scope = new TaskScope();
    private SchedulerLifecycle(JavaPlugin plugin) { this.plugin = plugin; }

    static TaskScope scope(JavaPlugin plugin) {
        return PLUGINS.computeIfAbsent(plugin, key -> {
            var lifecycle = new SchedulerLifecycle(key);
            key.getServer().getPluginManager().registerEvents(lifecycle, key);
            return lifecycle;
        }).scope;
    }

    static void closePlugin(JavaPlugin plugin) {
        SchedulerLifecycle lifecycle = PLUGINS.remove(plugin);
        if (lifecycle == null) return;
        try { lifecycle.scope.close(); }
        finally { HandlerList.unregisterAll(lifecycle); }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onDisable(PluginDisableEvent event) {
        if (event.getPlugin() != plugin) return;
        try { scope.close(); }
        finally { PLUGINS.remove(plugin, this); HandlerList.unregisterAll(this); }
    }
}
