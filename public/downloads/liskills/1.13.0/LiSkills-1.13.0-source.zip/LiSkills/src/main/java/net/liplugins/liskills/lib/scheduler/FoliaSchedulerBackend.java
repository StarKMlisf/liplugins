package net.liplugins.liskills.lib.scheduler;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

import java.lang.reflect.Method;
import java.util.function.Consumer;

/** 纯Bukkit编译，运行时只反射Folia/Paper公开的三个调度器接口。 */
final class FoliaSchedulerBackend implements SchedulerBackend {
    private final Plugin plugin;
    private final Object global, region;
    private final Method globalLater, globalTimer, entityScheduler, entityLater, entityTimer, regionLater, cancel;

    FoliaSchedulerBackend(JavaPlugin plugin) {
        this(plugin, Bukkit.class, Entity.class);
    }
    FoliaSchedulerBackend(Plugin plugin, Class<?> bukkitApi, Class<?> entityApi) {
        this.plugin = plugin;
        Method globalGetter = SchedulerReflection.required(bukkitApi, "getGlobalRegionScheduler");
        Method regionGetter = SchedulerReflection.required(bukkitApi, "getRegionScheduler");
        global = SchedulerReflection.invoke(globalGetter, null);
        region = SchedulerReflection.invoke(regionGetter, null);
        entityScheduler = SchedulerReflection.required(entityApi, "getScheduler");
        globalLater = SchedulerReflection.required(globalGetter.getReturnType(), "runDelayed", Plugin.class, Consumer.class, long.class);
        globalTimer = SchedulerReflection.required(globalGetter.getReturnType(), "runAtFixedRate", Plugin.class, Consumer.class, long.class, long.class);
        entityLater = SchedulerReflection.required(entityScheduler.getReturnType(), "runDelayed", Plugin.class, Consumer.class, Runnable.class, long.class);
        entityTimer = SchedulerReflection.required(entityScheduler.getReturnType(), "runAtFixedRate", Plugin.class, Consumer.class, Runnable.class, long.class, long.class);
        regionLater = SchedulerReflection.required(regionGetter.getReturnType(), "runDelayed", Plugin.class, Location.class, Consumer.class, long.class);
        cancel = SchedulerReflection.required(globalLater.getReturnType(), "cancel");
    }

    @Override public boolean enabled() { return plugin.isEnabled(); }
    private Consumer<Object> callback(Runnable run) { return ignored -> run.run(); }
    private Runnable cancellation(Object nativeTask) {
        return nativeTask == null ? null : () -> SchedulerReflection.invoke(cancel, nativeTask);
    }
    @Override public Runnable global(Runnable run, long delay, long period) {
        return cancellation(period > 0
                ? SchedulerReflection.invoke(globalTimer, global, plugin, callback(run), delay, period)
                : SchedulerReflection.invoke(globalLater, global, plugin, callback(run), delay));
    }
    @Override public Runnable entity(Entity entity, Runnable run, Runnable retired, long delay, long period) {
        Object scheduler = SchedulerReflection.invoke(entityScheduler, entity);
        return cancellation(period > 0
                ? SchedulerReflection.invoke(entityTimer, scheduler, plugin, callback(run), retired, delay, period)
                : SchedulerReflection.invoke(entityLater, scheduler, plugin, callback(run), retired, delay));
    }
    @Override public Runnable region(Location location, Runnable run, long delay) {
        return cancellation(SchedulerReflection.invoke(regionLater, region, plugin, location, callback(run), delay));
    }
}
