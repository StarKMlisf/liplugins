package net.liplugins.liskills.internal.manager;

import net.liplugins.liskills.lib.scheduler.TaskScheduler;
import org.bukkit.entity.Entity;

import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/** 同一跟踪对象最多保留一份待执行实体工作，慢区域不会被全局轮询重复排队。 */
public final class EntityWorkQueue {
    private final Set<Object> pending = ConcurrentHashMap.newKeySet();

    public void dispatch(TaskScheduler scheduler, Object key, Entity entity, Runnable action, Runnable retired) {
        if (pending.size() >= 8192 || !pending.add(key)) return;
        try {
            scheduler.entityNow(entity, () -> {
                try { action.run(); }
                finally { pending.remove(key); }
            }, () -> {
                pending.remove(key);
                if (retired != null) retired.run();
            });
        } catch (RuntimeException | Error failure) {
            pending.remove(key);
            throw failure;
        }
    }
}
