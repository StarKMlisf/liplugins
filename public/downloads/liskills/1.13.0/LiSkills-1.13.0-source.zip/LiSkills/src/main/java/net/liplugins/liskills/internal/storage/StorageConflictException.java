package net.liplugins.liskills.internal.storage;

import java.io.IOException;

/** 版本冲突不可自动覆盖，必须保留恢复快照并暂停对应档案。 */
public final class StorageConflictException extends IOException {
    public StorageConflictException(String message){super(message);}
}
