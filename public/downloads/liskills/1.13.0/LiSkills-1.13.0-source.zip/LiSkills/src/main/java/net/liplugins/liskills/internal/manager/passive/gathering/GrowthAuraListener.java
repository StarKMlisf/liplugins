package net.liplugins.liskills.internal.manager.passive.gathering;

import net.liplugins.liskills.lib.scheduler.ServerThreads;

import org.bukkit.block.Block;
import org.bukkit.block.data.Ageable;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockGrowEvent;
import java.util.concurrent.ThreadLocalRandom;

/** 自然生长成功后只取附近最高光环，一株作物每次原生生长最多结算一次。 */
final class GrowthAuraListener implements Listener {
    private final GatheringContext context;
    GrowthAuraListener(GatheringContext context) { this.context = context; }
    @EventHandler(priority = EventPriority.MONITOR)
    public void grow(BlockGrowEvent event) {
        Block block = event.getBlock();
        if (!ServerThreads.owns(block) || !(event.getNewState().getBlockData() instanceof Ageable) || context.customBlock().test(block)
                || !context.tasks().claim(event)) return;
        double radius = Math.max(1, Math.min(64, context.passives().option("growth_aura", "radius", 30)));
        GatheringContext.Actor strongest = null;
        double maximum = 0;
        // Bukkit 的跨区域 nearby 查询不能保证每个返回实体都属于当前线程；只读取已拥有的在线玩家。
        for (Player player : org.bukkit.Bukkit.getOnlinePlayers()) {
            if (!ServerThreads.owns(player) || !player.getWorld().equals(block.getWorld())) continue;
            var offset = player.getLocation().toVector().subtract(block.getLocation().toVector());
            if (Math.abs(offset.getX()) > radius || Math.abs(offset.getY()) > radius || Math.abs(offset.getZ()) > radius) continue;
            var actor = context.capture(player, "farming");
            if (actor == null) continue;
            double value = context.passives().value(player, "growth_aura");
            if (value > maximum) { maximum = value; strongest = actor; }
        }
        if (strongest == null) return;
        GatheringContext.Actor actor = strongest;
        context.tasks().defer(actor.player(), () -> {
            if (event.isCancelled() || !context.valid(actor) || !GatheringContext.loaded(block.getLocation())
                    || context.customBlock().test(block) || block.getType() != event.getNewState().getType()
                    || !block.getBlockData().matches(event.getNewState().getBlockData())) return;
            var distance = actor.player().getLocation().toVector().subtract(block.getLocation().toVector());
            if (Math.abs(distance.getX()) > radius || Math.abs(distance.getY()) > radius || Math.abs(distance.getZ()) > radius) return;
            if (!(block.getBlockData() instanceof Ageable age)) return;
            int extra = GatheringRules.extraDrops(context.passives().value(actor.player(), "growth_aura"), ThreadLocalRandom.current().nextDouble());
            if (extra <= 0) return;
            age.setAge(Math.min(age.getMaximumAge(), age.getAge() + extra));
            block.setBlockData(age, true);
        });
    }
}
