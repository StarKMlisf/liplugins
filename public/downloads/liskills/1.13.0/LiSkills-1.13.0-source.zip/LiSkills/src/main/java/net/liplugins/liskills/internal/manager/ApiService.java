package net.liplugins.liskills.internal.manager;

import net.liplugins.liskills.api.LiSkillsApi;
import org.bukkit.Bukkit;
import net.liplugins.liskills.lib.scheduler.ServerThreads;
import org.bukkit.entity.Player;
import java.util.Set;
import java.util.UUID;
import java.util.Map;
import java.util.LinkedHashMap;
import net.liplugins.liskills.internal.manager.stat.StatManager;
import net.liplugins.liskills.internal.config.StatsSettings;

public final class ApiService implements LiSkillsApi {
    private final SkillManager skills;
    private final StatManager stats;private final ProfileManager profiles;private final AbilityManager abilities;
    public ApiService(SkillManager skills){this(skills,null,null,null);}
    public ApiService(SkillManager skills,StatManager stats,ProfileManager profiles,AbilityManager abilities){this.skills=skills;this.stats=stats;this.profiles=profiles;this.abilities=abilities;}
    public Set<String> getSkills(){return Set.copyOf(skills.config().skills().keySet());}
    public SkillView getProgress(UUID player,String skill){
        if(player==null||!known(skill))return null;
        var definition=skills.config().skill(skill);var progress=skills.progress(player,skill);
        return definition==null || progress==null?null:new SkillView(progress.level(),progress.xp(),progress.level()>=definition.maxLevel()?0:definition.requiredXp(progress.level()));
    }
    public boolean addExperience(UUID uuid,String skill,double amount){
        if(uuid==null||!known(skill))return false;
        Player player=online(uuid);
        return player!=null && skills.addExperience(player,skill,amount);
    }
    private Player online(UUID uuid){Player player=uuid==null?null:Bukkit.getPlayer(uuid);return player!=null&&ServerThreads.owns(player)?player:null;}
    private boolean known(String skill){return skill!=null&&skills.config().skill(skill)!=null;}
    public boolean awardNaturalExperience(UUID uuid,String skill,double amount){var player=online(uuid);return player!=null&&known(skill)&&skills.award(player,skill,amount);}
    public boolean setLevel(UUID uuid,String skill,int level){var player=online(uuid);return player!=null&&known(skill)&&skills.setLevel(player,skill,level);}
    public boolean setExperience(UUID uuid,String skill,double amount){var player=online(uuid);return player!=null&&known(skill)&&skills.setExperience(player,skill,amount);}
    public Map<String,Double> getStats(UUID uuid){var player=online(uuid);return player==null||stats==null?Map.of():Map.copyOf(stats.values(player));}
    public Map<String,Double> getTraits(UUID uuid){
        var player=online(uuid);if(player==null||stats==null)return Map.of();var values=stats.values(player);Map<String,Double> traits=new LinkedHashMap<>();
        for(String id:StatsSettings.TRAITS)traits.put(id,stats.trait(values,id));return Map.copyOf(traits);
    }
    public ManaView getMana(UUID uuid){var player=online(uuid);var profile=player==null||profiles==null?null:profiles.get(uuid);return profile==null?null:new ManaView(ManaManager.available(profile,skills.config()),ManaManager.maximum(profile,skills.config()));}
    public boolean activateAbility(UUID uuid,String skill){var player=online(uuid);return player!=null&&known(skill)&&abilities!=null&&abilities.activate(player,skill);}
    public AbilityView getAbility(UUID uuid,String skill){
        if(!known(skill))return null;
        var player=online(uuid);var profile=player==null||profiles==null?null:profiles.get(uuid);var definition=skills.config().skill(skill);
        if(profile==null||definition==null||abilities==null)return null;var active=ActiveSkillProgression.resolve(skills.config(),definition,profile);
        return new AbilityView(active.type(),ActiveSkillProgression.rank(skills.config(),definition,profile),active.manaCost(),active.durationSeconds(),
                Math.max(0,profile.cooldown(skill)-System.currentTimeMillis()),abilities.remainingMillis(player,skill));
    }
}
