package net.liplugins.liskills.lib.scheduler;

import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

/** 任务集合的关闭屏障；与原生调度提交并发时也不会漏掉晚登记的任务。 */
final class TaskScope {
    private final Set<ManagedTask> tasks = ConcurrentHashMap.newKeySet();
    private final AtomicBoolean closed = new AtomicBoolean();
    boolean add(ManagedTask task) {
        if (closed.get()) return false;
        tasks.add(task);
        if (closed.get()) { task.cancel(); return false; }
        return true;
    }
    void remove(ManagedTask task) { tasks.remove(task); }
    boolean closed() { return closed.get(); }
    int size() { return tasks.size(); }
    void close() {
        closed.set(true);
        Throwable failure = null;
        for (ManagedTask task : tasks) {
            try { task.cancel(); }
            catch (RuntimeException | Error error) { if (failure == null) failure = error; else if (failure != error) failure.addSuppressed(error); }
        }
        tasks.clear();
        if (failure instanceof RuntimeException error) throw error;
        if (failure instanceof Error error) throw error;
    }
}
