package net.liplugins.liskills.internal.config;

/** 与AuraSkills的三种运算顺序一致；ADD_PERCENT使用百分数，10表示增加10%。 */
public enum ItemModifierOperation { ADD, MULTIPLY, ADD_PERCENT }
