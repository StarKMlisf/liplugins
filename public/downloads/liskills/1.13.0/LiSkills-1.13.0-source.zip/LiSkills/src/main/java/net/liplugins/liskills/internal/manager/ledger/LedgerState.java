package net.liplugins.liskills.internal.manager.ledger;

import java.util.Collections;
import java.util.Map;
import java.util.TreeMap;

/** 已提交账本的不可变快照：只有一个收入日累计和有限的奖励高水位，不存物品或技能档案。 */
public record LedgerState(long incomeDay,double income,Map<String,Integer> rewardHighWatermarks) {
    public static final int MAX_REWARDS=8192;
    public LedgerState {
        if(incomeDay<0 || !Double.isFinite(income) || income<0 || income>1_000_000 || rewardHighWatermarks.size()>MAX_REWARDS)
            throw new IllegalArgumentException("invalid-ledger-state");
        Map<String,Integer> copy=new TreeMap<>();
        rewardHighWatermarks.forEach((key,value)->{
            if(!validRewardKey(key) || value==null || value<1 || value>1000)throw new IllegalArgumentException("invalid-ledger-reward");
            copy.put(key,value);
        });
        rewardHighWatermarks=Collections.unmodifiableMap(copy);
    }
    public static boolean validRewardKey(String key){return key!=null && key.matches("reward_[a-z][a-z0-9_-]{0,96}");}
    public static String rewardKey(String rule,String skill){
        if(rule==null || !rule.matches("[a-z][a-z0-9_-]{0,47}") || skill==null || !skill.matches("[a-z][a-z0-9_]{0,47}"))
            throw new IllegalArgumentException("invalid-ledger-reward-id");
        return "reward_"+rule+"_"+skill;
    }
}
