package net.liplugins.liskills.internal.storage;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/** 仅在同一 IO 执行器访问：完整读取，写入临时文件，成功后原子替换。 */
public final class ProfileStore implements ProfileRepository {
    private final Path directory;
    public ProfileStore(Path directory){this.directory=directory;}

    public ProfileSnapshot load(UUID uuid,String name) throws Exception {
        Path path=directory.resolve(uuid+".yml");
        if(!Files.exists(path)) {
            if(name==null)throw new IOException("Missing enumerated profile: "+uuid);
            return new ProfileSnapshot(uuid,name,Map.of(),Map.of());
        }
        if(Files.size(path)>ProfileYamlCodec.MAXIMUM_LENGTH*4L)throw new IOException("Profile file too large: "+uuid);
        return ProfileYamlCodec.decode(uuid,name,Files.readString(path,StandardCharsets.UTF_8));
    }

    /** 调用者必须使用同一存储队列；任一损坏档案会使整个读取失败，不悄悄漏榜或导出空档。 */
    public List<ProfileSnapshot> loadAll() throws Exception {
        if(!Files.exists(directory))return List.of();
        List<ProfileSnapshot> snapshots=new ArrayList<>();
        try(var paths=Files.list(directory)){
            for(Path path:paths.filter(p->p.getFileName().toString().matches("[0-9a-fA-F-]{36}\\.yml")).sorted().toList()){
                String file=path.getFileName().toString();UUID uuid=UUID.fromString(file.substring(0,36));snapshots.add(load(uuid,null));
            }
        }
        return List.copyOf(snapshots);
    }

    public void save(ProfileSnapshot snapshot) throws IOException {
        Files.createDirectories(directory);
        String content=ProfileYamlCodec.encode(snapshot);
        Path target=directory.resolve(snapshot.uuid()+".yml");
        Path temp=directory.resolve(snapshot.uuid()+".yml.tmp");
        Files.writeString(temp,content,StandardCharsets.UTF_8);
        if(Files.exists(target)) Files.copy(target,directory.resolve(snapshot.uuid()+".yml.bak"),StandardCopyOption.REPLACE_EXISTING);
        try {Files.move(temp,target,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);}
        catch(AtomicMoveNotSupportedException ex){Files.move(temp,target,StandardCopyOption.REPLACE_EXISTING);}
    }
    /** 迁移创建不能复用覆盖保存；先完整写临时文件，再以硬链接原子占用不存在的名称。 */
    @Override public boolean insertIfAbsent(ProfileSnapshot snapshot)throws Exception{
        String content=ProfileYamlCodec.encode(snapshot);Files.createDirectories(directory);
        Path target=directory.resolve(snapshot.uuid()+".yml");
        if(Files.exists(target))return identicalOrConflict(snapshot);
        Path temporary=Files.createTempFile(directory,".migration-",".tmp");
        try{
            Files.writeString(temporary,content,StandardCharsets.UTF_8);
            // 创建硬链接不能替换既有名称，也避免某些系统move“先检查再rename”的竞争窗口。
            // 不支持硬链接的文件系统安全失败，不能回退到可能覆盖或留下半份目标的写法。
            try{Files.createLink(target,temporary);return true;}
            catch(FileAlreadyExistsException exists){return identicalOrConflict(snapshot);}
        }finally{Files.deleteIfExists(temporary);}
    }
    private boolean identicalOrConflict(ProfileSnapshot snapshot)throws Exception{
        if(load(snapshot.uuid(),null).equals(snapshot))return false;
        throw new StorageConflictException("migration-target-conflict: "+snapshot.uuid());
    }
}
