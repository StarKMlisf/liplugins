package net.liplugins.liskills.lib.scheduler;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/** 仅反射服务器公开API；异常保留原始原因，绝不回退到不安全的Bukkit全局调度。 */
final class SchedulerReflection {
    private SchedulerReflection() { }
    static Method required(Class<?> type, String name, Class<?>... parameters) {
        try { return type.getMethod(name, parameters); }
        catch (ReflectiveOperationException error) { throw new IllegalStateException("缺少兼容调度接口: " + type.getName() + "." + name, error); }
    }
    static Method optional(Class<?> type, String name, Class<?>... parameters) {
        try { return type.getMethod(name, parameters); }
        catch (NoSuchMethodException error) { return null; }
    }
    static Object invoke(Method method, Object instance, Object... arguments) {
        try { return method.invoke(instance, arguments); }
        catch (InvocationTargetException error) {
            Throwable cause = error.getCause();
            if (cause instanceof RuntimeException runtime) throw runtime;
            if (cause instanceof Error fatal) throw fatal;
            throw new IllegalStateException("兼容调度调用失败: " + method.getName(), cause);
        } catch (ReflectiveOperationException error) { throw new IllegalStateException("无法调用兼容调度接口: " + method.getName(), error); }
    }
}
