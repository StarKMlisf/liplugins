package net.liplugins.liskills.internal.config;

/** 补种延时、全服队列预算与耗种规则。 */
public record ReplenishSettings(int delayTicks, int maxPending, int blocksPerTick,
                                boolean consumeSeed, boolean preventUnripeBreak) { }
