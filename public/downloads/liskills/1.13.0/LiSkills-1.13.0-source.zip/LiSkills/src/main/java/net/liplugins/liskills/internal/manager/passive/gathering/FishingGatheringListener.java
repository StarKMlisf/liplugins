package net.liplugins.liskills.internal.manager.passive.gathering;

import net.liplugins.liskills.lib.scheduler.ServerThreads;

import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.inventory.ItemStack;
import java.util.concurrent.ThreadLocalRandom;
import java.util.UUID;
import net.liplugins.liskills.internal.manager.source.FishingLootOrigin;

/** 原版钓获的幸运/宝藏与实体牵引；CustomFishing钩、合成事件始终交由其插件。 */
final class FishingGatheringListener implements Listener {
    private final GatheringContext context;
    private final GatheringLoot loot;
    FishingGatheringListener(GatheringContext context, GatheringLoot loot) { this.context = context; this.loot = loot; }

    @EventHandler(priority = EventPriority.MONITOR)
    public void fish(PlayerFishEvent event) {
        if (!ServerThreads.owns(event.getPlayer()) || !ServerThreads.owns(event.getHook())
                || context.customFishing().test(event) || !context.tasks().claim(event)) return;
        var actor = context.capture(event.getPlayer(), "fishing");
        if (actor == null) return;
        if (event.getState() == PlayerFishEvent.State.CAUGHT_ENTITY && event.getCaught() != null && !(event.getCaught() instanceof Item)) {
            pull(event, actor); return;
        }
        if (event.getState() != PlayerFishEvent.State.CAUGHT_FISH || !(event.getCaught() instanceof Item item) || !ServerThreads.owns(item)
                || event.getExpToDrop() <= 0 || item.getItemStack().getType().isAir()
                || !context.tasks().claimSource(event.getHook().getUniqueId())) return;
        ItemStack original = item.getItemStack().clone();
        UUID hook = event.getHook().getUniqueId();
        boolean openWater = event.getHook().isInOpenWater();
        context.tasks().defer(actor.player(), () -> {
            if (!ServerThreads.owns(item) || event.isCancelled() || context.customFishing().test(event) || !context.valid(actor) || !item.isValid()
                    || !GatheringContext.loaded(item.getLocation()) || !item.getItemStack().equals(original)) return;
            var selected = loot.selectPool(actor.player(), "fishing", original.getType(), openWater);
            var treasure = selected==null?null:selected.entry();
            ItemStack result = treasure == null ? original.clone() : loot.create(treasure);
            int extra = GatheringRules.extraDrops(context.luck(actor.player(), "fishing"), ThreadLocalRandom.current().nextDouble());
            int total = result.getAmount() + extra;
            result.setAmount(Math.min(total, result.getMaxStackSize()));
            // 成功钓获只替换同一个物品实体，不重新抛钩、不发第二次基础钓鱼经验。
            item.setItemStack(result);
            if(selected!=null)FishingLootOrigin.mark(item,hook,selected.pool());
            loot.drop(item.getLocation(), result, total - result.getAmount());
            if (treasure != null && treasure.experience() > 0) context.skills().award(actor.player(), "fishing", treasure.experience());
        });
    }

    private void pull(PlayerFishEvent event, GatheringContext.Actor actor) {
        Entity caught = event.getCaught();
        if (context.passives().value(actor.player(), "grappler") <= 0) return;
        context.tasks().defer(actor.player(), () -> {
            if (event.isCancelled() || context.customFishing().test(event) || !context.valid(actor)
                    || !ServerThreads.owns(caught) || !caught.isValid() || caught.isDead() || !caught.getWorld().equals(actor.player().getWorld())
                    || !GatheringContext.loaded(caught.getLocation())) return;
            var vector = actor.player().getLocation().toVector().subtract(caught.getLocation().toVector())
                    .multiply(GatheringRules.pullFactor(context.passives().value(actor.player(), "grappler")));
            if (GatheringRules.safeVelocity(vector.getX(), vector.getY(), vector.getZ())) caught.setVelocity(vector);
        });
    }
}
