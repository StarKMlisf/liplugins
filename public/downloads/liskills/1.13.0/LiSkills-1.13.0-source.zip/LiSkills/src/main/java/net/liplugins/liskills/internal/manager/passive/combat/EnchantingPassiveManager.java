package net.liplugins.liskills.internal.manager.passive.combat;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.manager.PassiveAbilityManager;
import net.liplugins.liskills.internal.manager.ProfileManager;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.enchantment.EnchantItemEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.inventory.view.AnvilView;
import org.bukkit.plugin.java.JavaPlugin;
import net.liplugins.liskills.lib.scheduler.TaskHandle;
import net.liplugins.liskills.lib.scheduler.TaskScheduler;
import net.liplugins.liskills.lib.scheduler.ServerThreads;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** 幸运附魔台仅修改本次原版附魔结果；铁砧大师只借用自己修改的费用上限。 */
final class EnchantingPassiveManager implements Listener,AutoCloseable {
    private final ConfigManager config;
    private final ProfileManager profiles;
    private final PassiveAbilityManager passives;
    private final DeferredPassiveEffects effects;
    private final Map<AnvilView,Lease> anvils=new java.util.concurrent.ConcurrentHashMap<>();
    private final TaskScheduler scheduler;
    private final net.liplugins.liskills.internal.manager.EntityWorkQueue work = new net.liplugins.liskills.internal.manager.EntityWorkQueue();
    private final TaskHandle task;
    EnchantingPassiveManager(JavaPlugin plugin,ConfigManager config,ProfileManager profiles,PassiveAbilityManager passives,DeferredPassiveEffects effects) {
        this.config=config;this.profiles=profiles;this.passives=passives;this.effects=effects;
        task=(scheduler = new TaskScheduler(plugin)).globalTimer(this::cleanup,1,20);
    }
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)
    public void onEnchant(EnchantItemEvent event) {
        for(var entry:event.getEnchantsToAdd().entrySet()) {
            if(entry.getValue()<entry.getKey().getMaxLevel() && passives.roll(event.getEnchanter(),"lucky_table")) entry.setValue(entry.getValue()+1);
        }
    }
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)
    public void onOpen(InventoryOpenEvent event) {
        if(!(event.getPlayer() instanceof Player player) || !(event.getView() instanceof AnvilView view) || anvils.size()>=1024) return;
        double value=passives.value(player,"anvil_master");
        if(value<=0) return;
        int before=view.getMaximumRepairCost(),after=Math.max(before,(int)Math.clamp(Math.round(value),1,10_000));
        if(after==before) return;
        Lease lease=new Lease(view,PassiveSession.capture(player,profiles,config),before,after);
        if(!effects.submit(player.getUniqueId(),()->{if(event.isCancelled() || !lease.session.valid(profiles,config))restore(lease);} )) return;
        anvils.put(view,lease);view.setMaximumRepairCost(after);
    }
    @EventHandler(priority=EventPriority.MONITOR)
    public void onClose(InventoryCloseEvent event) {
        if(event.getView() instanceof AnvilView view) {Lease lease=anvils.get(view);if(lease!=null)restore(lease);}
    }
    private void cleanup() {
        for(Lease lease:List.copyOf(anvils.values()))work.dispatch(scheduler,lease,lease.session.player(),()->{
            if(!lease.session.valid(profiles,config) || passives.value(lease.session.player(),"anvil_master")<=0
                    || lease.session.player().getOpenInventory()!=lease.view)restore(lease);
        },()->anvils.remove(lease.view,lease));
    }
    private void restore(Lease lease) {
        if(!ServerThreads.owns(lease.session.player()))return;
        if(lease.view.getMaximumRepairCost()==lease.after)lease.view.setMaximumRepairCost(lease.before);
        anvils.remove(lease.view,lease);
    }
    @Override public void close(){task.cancel();scheduler.cancelAll();List.copyOf(anvils.values()).forEach(this::restore);anvils.clear();}
    private record Lease(AnvilView view,PassiveSession session,int before,int after){ }
}
