package net.liplugins.liskills.internal.manager.item;

import net.liplugins.liskills.internal.config.ItemSlot;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

/** 标准玩家护甲槽与原版/公开Equippable组件的对应关系。 */
public final class ItemEquipmentSlots {
    private ItemEquipmentSlots() { }

    public static ItemSlot inventorySlot(int slot) {
        return switch (slot) { case 36 -> ItemSlot.FEET; case 37 -> ItemSlot.LEGS; case 38 -> ItemSlot.CHEST; case 39 -> ItemSlot.HEAD; default -> null; };
    }
    public static ItemSlot armorSlot(ItemStack item) {
        if (item == null || item.getType().isAir()) return null;
        if (item.hasItemMeta()) {
            var meta = item.getItemMeta();
            if (meta != null && meta.hasEquippable()) {
                ItemSlot slot = ItemSlot.from(meta.getEquippable().getSlot());
                return slot != null && slot.armor() ? slot : null;
            }
        }
        return armorSlot(item.getType());
    }
    public static ItemSlot armorSlot(Material material) {
        if (material == null) return null;
        String name = material.name();
        if (name.endsWith("_HELMET") || name.endsWith("_HEAD") || name.endsWith("_SKULL") || material == Material.CARVED_PUMPKIN) return ItemSlot.HEAD;
        if (name.endsWith("_CHESTPLATE") || material == Material.ELYTRA) return ItemSlot.CHEST;
        if (name.endsWith("_LEGGINGS")) return ItemSlot.LEGS;
        if (name.endsWith("_BOOTS")) return ItemSlot.FEET;
        return null;
    }
}
