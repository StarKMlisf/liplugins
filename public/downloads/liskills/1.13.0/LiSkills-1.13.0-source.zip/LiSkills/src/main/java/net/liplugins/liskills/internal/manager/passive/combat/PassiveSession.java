package net.liplugins.liskills.internal.manager.passive.combat;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.manager.ProfileManager;
import net.liplugins.liskills.internal.storage.PlayerProfile;
import org.bukkit.entity.Player;
import net.liplugins.liskills.lib.scheduler.ServerThreads;
import java.util.UUID;

/** 延迟副作用绑定本次档案、世界及配置，退出重连、换世界或重载均不继承旧事务。 */
record PassiveSession(Player player, PlayerProfile profile, UUID world, long revision) {
    static PassiveSession capture(Player player, ProfileManager profiles, ConfigManager config) {
        return new PassiveSession(player, profiles.get(player.getUniqueId()), player.getWorld().getUID(), config.revision());
    }
    boolean valid(ProfileManager profiles, ConfigManager config) {
        return profile != null && ServerThreads.owns(player) && player.isOnline() && player.isValid() && !player.isDead()
                && profiles.get(player.getUniqueId()) == profile && config.revision() == revision
                && player.getWorld().getUID().equals(world) && config.progressionEnabled();
    }
}
