package net.liplugins.liskills.internal.config;

import org.bukkit.configuration.file.YamlConfiguration;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** 首次扩展为十五职业时只追加空闲格；保留已有技能顺序、按钮、格数及注释。 */
final class LegacyMenuUpgrade {
    private LegacyMenuUpgrade() { }

    static boolean apply(YamlConfiguration current, YamlConfiguration defaults) {
        if (current.contains("config-version") || !current.isList("skill-slots")) return false;
        // 缺失按钮/格数稍后由配置层补回；在此采用同一默认值计算空格，不影响已有自定义值。
        Object sizeValue = current.get("size", defaults.get("size")), infoValue = current.get("info-slot", defaults.get("info-slot")),
                closeValue = current.get("close-slot", defaults.get("close-slot"));
        if (!(sizeValue instanceof Number size) || !(infoValue instanceof Number info) || !(closeValue instanceof Number close)) return false;
        if (size.doubleValue() != size.intValue() || size.intValue() < 27 || size.intValue() > 54 || size.intValue() % 9 != 0) return false;
        if (info.doubleValue() != info.intValue() || close.doubleValue() != close.intValue()
                || info.intValue() < 0 || info.intValue() >= size.intValue() || close.intValue() < 0
                || close.intValue() >= size.intValue() || info.intValue() == close.intValue()) return false;
        List<Integer> slots = new ArrayList<>();
        Set<Integer> used = new HashSet<>(Set.of(info.intValue(), close.intValue()));
        for (Object value : current.getList("skill-slots")) {
            if (!(value instanceof Number n) || n.doubleValue() != n.intValue() || n.intValue() < 0
                    || n.intValue() >= size.intValue() || !used.add(n.intValue())) return false;
            slots.add(n.intValue());
        }
        int required = 15;
        List<Integer> candidates = new ArrayList<>(defaults.getIntegerList("skill-slots"));
        for (int slot = 0; slot < size.intValue(); slot++) candidates.add(slot);
        for (int slot : candidates) {
            if (slots.size() >= required) break;
            if (slot >= 0 && slot < size.intValue() && used.add(slot)) slots.add(slot);
        }
        current.set("skill-slots", slots);
        current.set("config-version", 1);
        return true;
    }
}
