package net.liplugins.liskills.internal.manager.stat;

import java.util.Objects;

/** 记住一次铁砧准备的原价，重复准备同一结果不会把自己的折后价再次打折。 */
public record AnvilDiscountLease(Object signature, int original, int applied) {
    public int originalFor(Object currentSignature, int currentCost) {
        return Objects.equals(signature, currentSignature) && currentCost == applied ? original : currentCost;
    }

    public boolean owns(Object currentSignature, int currentCost) {
        return Objects.equals(signature, currentSignature) && currentCost == applied;
    }
}
