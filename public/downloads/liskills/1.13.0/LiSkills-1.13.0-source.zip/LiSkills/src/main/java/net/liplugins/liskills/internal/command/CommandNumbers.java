package net.liplugins.liskills.internal.command;

/** 拒绝非有限数字、科学计数法溢出及不合理的管理参数。 */
final class CommandNumbers {
    private CommandNumbers() { }

    static Double experience(String raw, double maximum) {
        try {
            double value = Double.parseDouble(raw);
            return Double.isFinite(value) && value >= 0 && value <= maximum ? value : null;
        } catch (NumberFormatException ignored) {
            return null;
        }
    }

    static Integer level(String raw, int maximum) {
        try {
            int value = Integer.parseInt(raw);
            return value >= 1 && value <= maximum ? value : null;
        } catch (NumberFormatException ignored) {
            return null;
        }
    }
}
