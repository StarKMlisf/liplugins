package net.liplugins.liskills.internal.manager;

import net.liplugins.liskills.internal.config.ActiveSkill;
import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.hook.LiRealEnchantHook;
import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.plugin.java.JavaPlugin;
import net.liplugins.liskills.lib.scheduler.TaskHandle;
import net.liplugins.liskills.lib.scheduler.TaskScheduler;
import net.liplugins.liskills.lib.scheduler.ServerThreads;
import java.util.*;

/** 魔力护盾只调整当前攻击事件；预留费用留至最终结算，取消则退回本次费用。 */
public final class ManaShieldManager implements ActiveAbilityHandler,Listener,AutoCloseable {
    private final ConfigManager config;
    private final ProfileManager profiles;
    private final SkillAbilityWindows windows;
    private final TextService text;
    private final LiRealEnchantHook enchantments;
    private final Map<EntityDamageEvent,AbilityManager.ManaReservation> pending=new java.util.concurrent.ConcurrentHashMap<>();
    private final TaskScheduler scheduler;
    private final net.liplugins.liskills.lib.scheduler.PlayerTasks settlement;
    public ManaShieldManager(JavaPlugin plugin,ConfigManager config,ProfileManager profiles,SkillAbilityWindows windows,
                             TextService text,LiRealEnchantHook enchantments) {
        this.config=config;this.profiles=profiles;this.windows=windows;this.text=text;this.enchantments=enchantments;
        scheduler = new TaskScheduler(plugin);
        settlement=new net.liplugins.liskills.lib.scheduler.PlayerTasks(plugin,player->settleFor(player.getUniqueId()),1,1);
    }
    @Override public boolean activate(Player player,ActiveSkill active) {
        if(!ServerThreads.owns(player))return false;
        if(!config.mana().enabled()){text.send(player,"ability.shield-mana-disabled");return false;}
        if(player.getInventory().getItemInMainHand().getType()!=Material.SHIELD){text.send(player,"ability.shield-tool");return false;}
        if(windows.active(player,"defense")){text.send(player,"ability.window-active");return false;}
        return windows.open(player,"defense","MANA_SHIELD",active,Set.of(Material.SHIELD));
    }
    @Override public long remainingMillis(Player player){return windows.remainingMillis(player,"defense");}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)
    public void onDamage(EntityDamageByEntityEvent event) {
        if(!config.mana().enabled() || !(event.getEntity() instanceof Player player) || !ServerThreads.owns(player) || pending.containsKey(event)
                || !windows.active(player,"defense","MANA_SHIELD") || pending.size()>=4096
                || (enchantments!=null && enchantments.isSecondaryDamage()))return;
        if(event.getCause()!=EntityDamageEvent.DamageCause.ENTITY_ATTACK
                && event.getCause()!=EntityDamageEvent.DamageCause.ENTITY_SWEEP_ATTACK
                && event.getCause()!=EntityDamageEvent.DamageCause.PROJECTILE)return;
        if(!Double.isFinite(event.getFinalDamage()) || event.getFinalDamage()<=0)return;
        var profile=profiles.get(player.getUniqueId());
        if(profile==null)return;
        var settings=config.manaShield();
        var absorption=ManaShieldMath.calculate(event.getDamage(),ManaManager.available(profile,config),
                settings.manaPerDamage(),settings.maximumAbsorptionRatio());
        if(absorption.damage()<=0)return;
        var reservation=new AbilityManager.ManaReservation(absorption.mana(),()->ManaManager.available(profile,config),
                ()->ManaManager.maximum(profile,config),profile::mana,()->ManaManager.spend(profile,config,absorption.mana()));
        // 不调用 damage/setHealth，不另造攻击，保留当前事件的领地、护甲和受伤归属链。
        try{event.setDamage(Math.max(0,event.getDamage()-absorption.damage()));pending.put(event,reservation);}
        catch(RuntimeException failure){reservation.close();throw failure;}
    }
    /** 退出存档前必须结清该玩家的预留，否则退款可能只落在已移除的旧档案对象。 */
    public void settleFor(UUID player) {
        var iterator=pending.entrySet().iterator();
        while(iterator.hasNext()) {
            var entry=iterator.next();
            if(!entry.getKey().getEntity().getUniqueId().equals(player))continue;
            finish(entry.getKey(),entry.getValue());iterator.remove();
        }
    }
    private void finish(EntityDamageEvent event,AbilityManager.ManaReservation reservation) {
        if(!event.isCancelled())reservation.commit();
        reservation.close();
    }
    @Override public void close(){
        settlement.close();scheduler.cancelAll();
        for(var entry:pending.entrySet())if(pending.remove(entry.getKey(),entry.getValue())){
            if(ServerThreads.owns(entry.getKey().getEntity()))finish(entry.getKey(),entry.getValue());
            else entry.getValue().close();
        }
    }
}
