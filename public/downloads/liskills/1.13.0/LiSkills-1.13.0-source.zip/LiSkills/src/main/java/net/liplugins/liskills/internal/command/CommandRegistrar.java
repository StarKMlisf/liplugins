package net.liplugins.liskills.internal.command;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.manager.AbilityManager;
import net.liplugins.liskills.internal.manager.ProfileManager;
import net.liplugins.liskills.internal.manager.SkillManager;
import net.liplugins.liskills.internal.manager.stat.StatManager;
import net.liplugins.liskills.internal.manager.item.ItemModule;
import net.liplugins.liskills.internal.manager.ExtendedModule;
import net.liplugins.liskills.internal.manager.hud.HudManager;
import net.liplugins.liskills.internal.menu.SkillDetails;
import net.liplugins.liskills.internal.menu.SkillMenu;
import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

/** 集中装配命令组件，执行器与补全器保持独立。 */
public final class CommandRegistrar {
    private final JavaPlugin plugin;
    private final ConfigManager config;
    private final ProfileManager profiles;
    private final SkillManager skills;
    private final AbilityManager abilities;
    private final SkillMenu menu;
    private final TextService text;
    private final Runnable reload;
    private final Supplier<String> compatibility;
    private final StatManager stats;
    private ItemModule items;
    private ExtendedModule extended;
    private HudManager hud;
    public CommandRegistrar items(ItemModule items){this.items=items;return this;}
    public CommandRegistrar extensions(ExtendedModule extended){this.extended=extended;return this;}
    public CommandRegistrar hud(HudManager hud){this.hud=hud;return this;}

    public CommandRegistrar(JavaPlugin plugin, ConfigManager config, ProfileManager profiles, SkillManager skills,
                            AbilityManager abilities, SkillMenu menu, TextService text, Runnable reload) {
        this(plugin,config,profiles,skills,abilities,menu,text,reload,()->"");
    }
    public CommandRegistrar(JavaPlugin plugin,ConfigManager config,ProfileManager profiles,SkillManager skills,
                            AbilityManager abilities,SkillMenu menu,TextService text,Runnable reload,Supplier<String> compatibility) {
        this(plugin,config,profiles,skills,abilities,menu,text,reload,compatibility,null);
    }
    public CommandRegistrar(JavaPlugin plugin,ConfigManager config,ProfileManager profiles,SkillManager skills,
                            AbilityManager abilities,SkillMenu menu,TextService text,Runnable reload,Supplier<String> compatibility,
                            StatManager stats) {
        this.plugin = plugin; this.config = config; this.profiles = profiles; this.skills = skills;
        this.abilities = abilities; this.menu = menu; this.text = text; this.reload = reload;
        this.compatibility=compatibility;
        this.stats=stats;
    }

    public void register() {
        SenderChecks checks = new SenderChecks(config, profiles, text);
        List<Subcommand> subcommands = new java.util.ArrayList<>(List.of(new HelpCommand(text,extended!=null,hud!=null), new StatsCommand(config, checks, text),
                new AttributesCommand(config,checks,text,stats),new AbilitiesCommand(config,checks,menu,text),
                new SourcesCommand(checks, new SkillDetails(config, text)), new CastCommand(checks, abilities),
                new ReloadCommand(reload, checks, text), new ValidateCommand(config, checks, text,compatibility),new ManaCommand(config,checks,text),
                new XpCommand(checks, skills, text), new LevelCommand(checks, skills, text)));
        if(hud!=null)subcommands.add(new HudCommand(config,checks,text,hud));
        if(items!=null)subcommands.add(new ItemCommand(checks,text,config,items.metadata(),stats));
        if(extended!=null)subcommands.addAll(List.of(new TopCommand(extended.boards(),config::leaderboards,checks,text),new RankCommand(extended.boards(),checks,text),
                new ModifierCommand(checks,text,extended.modifiers(),stats),new JobsCommand(checks,extended.jobs(),text),new ExportCommand(plugin,extended.exports(),checks,text)));
        Map<String, Subcommand> commands = new LinkedHashMap<>();
        subcommands.forEach(command -> commands.put(command.name(), command));
        PluginCommand root = plugin.getCommand("liskills");
        if (root == null) throw new IllegalStateException(text.text("command.registration-failed"));
        root.setExecutor(new SkillCommandExecutor(commands, checks, menu, text));
        root.setTabCompleter(new SkillCommandCompleter(config, commands));
    }
}
