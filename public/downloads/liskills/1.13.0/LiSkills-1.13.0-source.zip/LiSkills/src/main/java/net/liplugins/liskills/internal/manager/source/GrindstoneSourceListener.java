package net.liplugins.liskills.internal.manager.source;

import net.liplugins.liskills.internal.config.EnchantingSourceSettings;
import net.liplugins.liskills.internal.config.SourceSkillRoutingSettings;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.GrindstoneInventory;
import org.bukkit.inventory.ItemStack;
import java.util.function.Supplier;

/** 砂轮：只奖励两输入真正移除的非诅咒附魔等级，预览、修理普通物品与失败取出不计数。 */
final class GrindstoneSourceListener implements Listener {
    private final SourceExperienceService rewards;private final Supplier<EnchantingSourceSettings> settings;
    private final Supplier<SourceSkillRoutingSettings> routing;
    GrindstoneSourceListener(SourceExperienceService rewards,Supplier<EnchantingSourceSettings> settings,Supplier<SourceSkillRoutingSettings> routing){this.rewards=rewards;this.settings=settings;this.routing=routing;}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void onTake(InventoryClickEvent event) {
        if(!(event.getWhoClicked() instanceof Player player) || !(event.getView().getTopInventory() instanceof GrindstoneInventory inventory)
                || event.getRawSlot()!=2 || !SourceItemRules.take(event.getAction()))return;
        var policy=settings.get();var session=rewards.capture(player,routing.get().grindstoneSkill());
        ItemStack left=SourceItemRules.copy(inventory.getItem(0)),right=SourceItemRules.copy(inventory.getItem(1)),result=SourceItemRules.copy(event.getCurrentItem());
        if(!policy.enabled() || session==null || SourceItemRules.empty(result)
                || (policy.ignoreCustomItems() && (SourceItemRules.custom(left) || SourceItemRules.custom(right) || SourceItemRules.custom(result))))return;
        int levels=EnchantingSourceRules.removedLevels(SourceEnchantments.read(left),SourceEnchantments.read(right),SourceEnchantments.read(result),policy.blockedGrindstoneEnchants(),policy.maximumLevelsPerAction());
        if(levels<=0)return;int beforeReceipt=SourceItemRules.count(player,result);
        rewards.deferOnce(event,()->{
            if(event.isCancelled() || !rewards.valid(session) || !settings.get().enabled()
                    || (!SourceItemRules.empty(left) && SourceItemRules.same(left,inventory.getItem(0)))
                    || (!SourceItemRules.empty(right) && SourceItemRules.same(right,inventory.getItem(1)))
                    || SourceItemRules.count(player,result)<=beforeReceipt)return;
            rewards.award(session,"grindstone",policy.xp("grindstone")*levels,policy.actionCooldownTicks(),policy.maximumXpPerMinute());
        });
    }
}
