package net.liplugins.liskills.internal.listener;

import net.liplugins.liskills.lib.scheduler.ServerThreads;
import net.liplugins.liskills.lib.scheduler.TaskScheduler;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.manager.ProfileManager;
import net.liplugins.liskills.internal.manager.SkillManager;
import net.liplugins.liskills.internal.manager.source.AgilityProgress;
import net.liplugins.liskills.internal.storage.PlayerProfile;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Statistic;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.*;
import org.bukkit.plugin.java.JavaPlugin;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** 只采集真实Bukkit移动统计并转交计量器；输入活动与状态切换由标准玩家事件确认。 */
public final class AgilityExperienceListener implements Listener {
    private static final int MAX_PLAYERS=2048;
    private final ConfigManager config;
    private final ProfileManager profiles;
    private final SkillManager skills;
    private final Map<UUID,Tracked> tracked=new java.util.concurrent.ConcurrentHashMap<>();
    private final java.util.Set<UUID> sampling=java.util.concurrent.ConcurrentHashMap.newKeySet();
    private final TaskScheduler scheduler;
    private long revision=-1;
    private int ticks;

    public AgilityExperienceListener(JavaPlugin plugin,ConfigManager config,ProfileManager profiles,SkillManager skills) {
        this.config=config;this.profiles=profiles;this.skills=skills;
        scheduler=new TaskScheduler(plugin);scheduler.globalTimer(this::tick,1,1);
    }
    private void tick() {
        if(revision!=config.revision()) { tracked.clear(); revision=config.revision(); ticks=0; }
        if(++ticks<config.sources().agility().sampleTicks())return;
        ticks=0;
        if(!config.sources().agility().enabled()) { tracked.clear(); return; }
        for(Player player:Bukkit.getOnlinePlayers())if(sampling.add(player.getUniqueId())) {
            UUID playerId=player.getUniqueId();
            long expectedRevision=config.revision();
            scheduler.entityNow(player,()->{try{if(expectedRevision==config.revision())sample(player);}finally{sampling.remove(playerId);}},
                    ()->{sampling.remove(playerId);tracked.remove(playerId);});
        }
        tracked.keySet().removeIf(id->Bukkit.getPlayer(id)==null);
    }
    private void sample(Player player) {
        if(!ServerThreads.owns(player))return;
        UUID id=player.getUniqueId(); PlayerProfile profile=profiles.get(id);
        var routing=config.sourceRouting();
        if(profile==null || !skills.eligible(player) || (!eligible(player,routing.movementSkill()) && !eligible(player,routing.jumpSkill()))
                || player.isDead() || player.isInsideVehicle() || player.isFlying() || player.isGliding() || player.isSleeping()) { tracked.remove(id);return; }
        var snapshot=snapshot(player); Tracked entry=tracked.get(id);
        if(entry==null || entry.profile!=profile || entry.revision!=config.revision() || !entry.world.equals(player.getWorld().getUID())) {
            if(tracked.size()<MAX_PLAYERS)tracked.put(id,new Tracked(profile,player.getWorld().getUID(),new AgilityProgress(snapshot),config.revision()));
            return;
        }
        long capturedRevision=config.revision();
        for(var source:entry.progress.sample(snapshot,config.sources().agility(),eligible(player,routing.movementSkill()),eligible(player,routing.jumpSkill())).entrySet()) {
            // 公开经验事件可能触发重载/离线；任何后续来源都必须仍属于同一个角色配置。
            if(capturedRevision!=config.revision() || profiles.get(id)!=profile || !player.isOnline() || player.isDead())break;
            String skill=routing.movementSourceSkill(source.getKey());
            if(eligible(player,skill))skills.award(player,skill,source.getValue());
        }
    }
    private boolean eligible(Player player,String id) {
        var skill=config.skill(id);
        return skill!=null && skill.enabled() && player.hasPermission("liskills.skill."+id);
    }
    private AgilityProgress.Snapshot snapshot(Player player) {
        Location location=player.getLocation();
        return new AgilityProgress.Snapshot(location.getX(),location.getY(),location.getZ(),player.getStatistic(Statistic.WALK_ONE_CM),
                player.getStatistic(Statistic.SPRINT_ONE_CM),player.getStatistic(Statistic.SWIM_ONE_CM),player.getStatistic(Statistic.JUMP),System.currentTimeMillis());
    }
    private void active(Player player) { Tracked entry=tracked.get(player.getUniqueId());if(entry!=null)entry.progress.activity(System.currentTimeMillis()); }
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true) public void move(PlayerMoveEvent event) {
        Location to=event.getTo();if(to==null || event instanceof PlayerTeleportEvent)return;
        if(Math.abs(to.getYaw()-event.getFrom().getYaw())>=1 || Math.abs(to.getPitch()-event.getFrom().getPitch())>=1)active(event.getPlayer());
    }
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true) public void interact(PlayerInteractEvent event) { active(event.getPlayer()); }
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true) public void animate(PlayerAnimationEvent event) { active(event.getPlayer()); }
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true) public void sprint(PlayerToggleSprintEvent event) { active(event.getPlayer()); }
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true) public void sneak(PlayerToggleSneakEvent event) { active(event.getPlayer()); }
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true) public void held(PlayerItemHeldEvent event) { active(event.getPlayer()); }
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true) public void swap(PlayerSwapHandItemsEvent event) { active(event.getPlayer()); }
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true) public void teleport(PlayerTeleportEvent event) { tracked.remove(event.getPlayer().getUniqueId()); }
    @EventHandler public void world(PlayerChangedWorldEvent event) { tracked.remove(event.getPlayer().getUniqueId()); }
    @EventHandler public void quit(PlayerQuitEvent event) { tracked.remove(event.getPlayer().getUniqueId()); }
    private record Tracked(PlayerProfile profile,UUID world,AgilityProgress progress,long revision) { }
}
