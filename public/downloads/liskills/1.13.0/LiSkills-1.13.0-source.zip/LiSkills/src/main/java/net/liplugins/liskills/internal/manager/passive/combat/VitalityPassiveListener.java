package net.liplugins.liskills.internal.manager.passive.combat;

import net.liplugins.liskills.internal.hook.LiRealEnchantHook;
import net.liplugins.liskills.internal.manager.PassiveAbilityManager;
import org.bukkit.Bukkit;
import net.liplugins.liskills.lib.scheduler.ServerThreads;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Phantom;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityRegainHealthEvent;

/** 黄金治疗、黄金之心和击杀吸血，恢复量通过标准回血事件接受其他插件的取消。 */
final class VitalityPassiveListener implements Listener {
    private final PassiveAbilityManager passives;
    private final LiRealEnchantHook enchantments;
    VitalityPassiveListener(PassiveAbilityManager passives,LiRealEnchantHook enchantments){this.passives=passives;this.enchantments=enchantments;}
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)
    public void onRegeneration(EntityRegainHealthEvent event) {
        if(!(event.getEntity() instanceof Player player) || event.getRegainReason()!=EntityRegainHealthEvent.RegainReason.MAGIC_REGEN
                || !Double.isFinite(event.getAmount()) || event.getAmount()<=0) return;
        double value=passives.value(player,"golden_heal");
        if(value>0) event.setAmount(Math.min(1024,event.getAmount()*(1+Math.min(1000,value)/100)));
    }
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)
    public void onAbsorption(EntityDamageEvent event) {
        if(!(event.getEntity() instanceof Player player) || player.getAbsorptionAmount()<=0 || !Double.isFinite(event.getDamage())
                || event.getDamage()<=0 || SecondaryDamageContext.active() || (enchantments!=null && enchantments.isSecondaryDamage())) return;
        event.setDamage(PassiveCombatMath.reduce(event.getDamage(),PassiveCombatMath.percent(passives.value(player,"golden_heart"))));
    }
    @EventHandler(priority=EventPriority.MONITOR)
    public void onKill(EntityDeathEvent event) {
        if(!(event.getEntity() instanceof Monster || event.getEntity() instanceof Phantom || event.getEntity() instanceof Player)) return;
        Player player=event.getEntity().getKiller();
        if(player==null || !ServerThreads.owns(player) || player.equals(event.getEntity()) || player.isDead() || !player.isOnline()) return;
        double value=passives.value(player,"life_steal");
        AttributeInstance targetHealth=event.getEntity().getAttribute(Attribute.MAX_HEALTH),health=player.getAttribute(Attribute.MAX_HEALTH);
        if(value<=0 || targetHealth==null || health==null || player.getHealth()>=health.getValue()) return;
        double amount=Math.min(health.getValue()-player.getHealth(),targetHealth.getValue()*Math.min(value,100)/100);
        EntityRegainHealthEvent regain=new EntityRegainHealthEvent(player,amount,EntityRegainHealthEvent.RegainReason.CUSTOM);
        Bukkit.getPluginManager().callEvent(regain);
        if(regain.isCancelled() || !Double.isFinite(regain.getAmount()) || regain.getAmount()<=0 || player.isDead()) return;
        player.setHealth(Math.min(health.getValue(),player.getHealth()+regain.getAmount()));
    }
}
