package net.liplugins.liskills.internal.manager.passive.combat;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.manager.ProfileManager;
import net.liplugins.liskills.internal.manager.SkillManager;
import org.bukkit.block.Block;
import net.liplugins.liskills.lib.scheduler.ServerThreads;
import org.bukkit.block.BrewingStand;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.BrewerInventory;
import org.bukkit.inventory.ItemStack;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.function.BooleanSupplier;

/** 只有玩家真实改变酿造输入后认领；开菜单、漏斗搬运和取消点击不产生酿造者。 */
final class BrewingOwnership implements Listener,AutoCloseable {
    private final ConfigManager config;
    private final ProfileManager profiles;
    private final SkillManager skills;
    private final DeferredPassiveEffects effects;
    private final Map<Position,Owner> owners=new java.util.concurrent.ConcurrentHashMap<>();
    BrewingOwnership(ConfigManager config,ProfileManager profiles,SkillManager skills,DeferredPassiveEffects effects) {
        this.config=config;this.profiles=profiles;this.skills=skills;this.effects=effects;
    }
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void onClick(InventoryClickEvent event) {
        if(!(event.getWhoClicked() instanceof Player player) || !(event.getView().getTopInventory() instanceof BrewerInventory inventory)) return;
        if(!(event.getRawSlot()>=0 && event.getRawSlot()<4) && !event.isShiftClick()) return;
        claim(player,inventory,event::isCancelled);
    }
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void onDrag(InventoryDragEvent event) {
        if(!(event.getWhoClicked() instanceof Player player) || !(event.getView().getTopInventory() instanceof BrewerInventory inventory)
                || event.getRawSlots().stream().noneMatch(slot->slot>=0 && slot<4)) return;
        claim(player,inventory,event::isCancelled);
    }
    private void claim(Player player,BrewerInventory inventory,BooleanSupplier cancelled) {
        BrewingStand stand=inventory.getHolder();
        if(!config.progressionEnabled() || !skills.eligible(player) || !player.hasPermission("liskills.skill.alchemy") || stand==null) return;
        ItemStack[] before=inputs(inventory);
        PassiveSession session=PassiveSession.capture(player,profiles,config);
        Block block=stand.getBlock();
        effects.submit(player.getUniqueId(),()->{
            if(cancelled.getAsBoolean() || !session.valid(profiles,config) || !ServerThreads.owns(block) || !block.getWorld().equals(player.getWorld())
                    || !block.getWorld().isChunkLoaded(block.getX()>>4,block.getZ()>>4)
                    || block.getType()!=org.bukkit.Material.BREWING_STAND || !inserted(before,inputs(inventory))) return;
            if(owners.size()>=4096) owners.entrySet().removeIf(entry->System.currentTimeMillis()-entry.getValue().created>600_000);
            Position key=Position.of(block);
            if(owners.size()<4096 || owners.containsKey(key)) owners.put(key,new Owner(session,System.currentTimeMillis()));
        });
    }
    PassiveSession owner(Block block) {
        Position position=Position.of(block);
        Owner owner=owners.get(position);
        if(owner==null) return null;
        if(System.currentTimeMillis()-owner.created>600_000 || !owner.session.valid(profiles,config)) {owners.remove(position,owner);return null;}
        return owner.session;
    }
    // 坐标不是酿造台身份。破坏、重放和爆炸后清除归属，不能把上一个容器的经验借给新容器。
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void onBreak(BlockBreakEvent event){owners.remove(Position.of(event.getBlock()));}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void onPlace(BlockPlaceEvent event){owners.remove(Position.of(event.getBlockPlaced()));}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void onExplosion(BlockExplodeEvent event){event.blockList().forEach(block->owners.remove(Position.of(block)));}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void onEntityExplosion(EntityExplodeEvent event){event.blockList().forEach(block->owners.remove(Position.of(block)));}
    @EventHandler(priority=EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent event){owners.entrySet().removeIf(entry->entry.getValue().session.player().getUniqueId().equals(event.getPlayer().getUniqueId()));}
    private static ItemStack[] inputs(BrewerInventory inventory) {
        ItemStack[] result=new ItemStack[4];
        for(int i=0;i<result.length;i++) {ItemStack item=inventory.getItem(i);result[i]=item==null?null:item.clone();}
        return result;
    }
    private static boolean inserted(ItemStack[] before,ItemStack[] after) {
        for(int i=0;i<after.length;i++) {
            ItemStack current=after[i],old=before[i];
            if(current!=null && !current.getType().isAir() && (old==null || !current.isSimilar(old) || current.getAmount()>old.getAmount())) return true;
        }
        return false;
    }
    @Override public void close(){owners.clear();}
    private record Position(UUID world,int x,int y,int z){static Position of(Block block){return new Position(block.getWorld().getUID(),block.getX(),block.getY(),block.getZ());}}
    private record Owner(PassiveSession session,long created){ }
}
