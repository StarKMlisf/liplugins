package net.liplugins.liskills.internal.manager.passive.combat;

import net.liplugins.liskills.internal.manager.PassiveAbilityManager;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityRegainHealthEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;

/** 耐力的抗饥饿/低血恢复和治疗的瞬时药水增益；原有黄金治疗仍只由原监听器处理。 */
final class RestorationPassiveListener implements Listener {
    private final PassiveAbilityManager passives;
    RestorationPassiveListener(PassiveAbilityManager passives) { this.passives = passives; }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onHunger(FoodLevelChangeEvent event) {
        if (event.getEntity() instanceof Player player && event.getFoodLevel() < player.getFoodLevel()
                && passives.roll(player, "anti_hunger")) event.setFoodLevel(player.getFoodLevel());
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onHealing(EntityRegainHealthEvent event) {
        if (!(event.getEntity() instanceof Player player) || !Double.isFinite(event.getAmount()) || event.getAmount() <= 0) return;
        double percent = 0;
        if (event.getRegainReason() == EntityRegainHealthEvent.RegainReason.MAGIC) {
            percent = passives.value(player, "life_essence");
        } else if (event.getRegainReason() == EntityRegainHealthEvent.RegainReason.SATIATED) {
            var health = player.getAttribute(Attribute.MAX_HEALTH);
            if (health != null && player.getHealth() < health.getValue() / 2) percent = passives.value(player, "recovery");
        }
        if (percent > 0) event.setAmount(Math.min(1024, event.getAmount() * (1 + Math.min(1000, percent) / 100)));
    }
}
