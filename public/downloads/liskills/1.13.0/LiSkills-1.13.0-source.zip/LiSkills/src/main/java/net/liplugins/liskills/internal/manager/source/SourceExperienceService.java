package net.liplugins.liskills.internal.manager.source;

import net.liplugins.liskills.lib.scheduler.ServerThreads;
import net.liplugins.liskills.lib.scheduler.TaskScheduler;
import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.manager.ProfileManager;
import net.liplugins.liskills.internal.manager.SkillManager;
import net.liplugins.liskills.internal.storage.PlayerProfile;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryEvent;
import org.bukkit.plugin.java.JavaPlugin;
import java.util.*;

/** 来源事务的次tick调度、会话守卫与奖励限额；不推断任何具体玩法是否成功。 */
final class SourceExperienceService implements AutoCloseable {
    private final ConfigManager config;private final ProfileManager profiles;private final SkillManager skills;
    private final JavaPlugin plugin;private final TaskScheduler scheduler;
    private final java.util.concurrent.atomic.AtomicInteger pending=new java.util.concurrent.atomic.AtomicInteger();
    private final SourceContainerChanges receipts=new SourceContainerChanges();
    private final Map<Key,SourceRewardWindow> limits=new java.util.concurrent.ConcurrentHashMap<>();
    SourceExperienceService(JavaPlugin plugin,ConfigManager config,ProfileManager profiles,SkillManager skills) {
        this.plugin=plugin;this.config=config;this.profiles=profiles;this.skills=skills;this.scheduler=new TaskScheduler(plugin);
    }
    Session capture(Player player,String skill) {
        var definition=config.skill(skill);var profile=profiles.get(player.getUniqueId());
        if(!ServerThreads.owns(player) || profile==null || definition==null || !definition.enabled() || !skills.eligible(player)
                || player.getGameMode()==GameMode.CREATIVE || player.getGameMode()==GameMode.SPECTATOR
                || !player.hasPermission("liskills.skill."+skill))return null;
        return new Session(player,profile,config.revision(),player.getWorld().getUID(),skill);
    }
    long revision(){return config.revision();}
    boolean valid(Session session) {
        return session!=null && ServerThreads.owns(session.player) && session.player.isOnline() && !session.player.isDead() && session.revision==config.revision()
                && session.world.equals(session.player.getWorld().getUID()) && profiles.get(session.player.getUniqueId())==session.profile
                && capture(session.player,session.skill)!=null;
    }
    boolean defer(Entity owner,Runnable action) {
        return defer(owner,action,()->{});
    }
    boolean defer(Entity owner,Runnable action,Runnable retired) {
        if(!reserve())return false;
        scheduler.entity(owner,()->{try{if(plugin.isEnabled())action.run();}finally{pending.decrementAndGet();}},
                ()->{try{retired.run();}finally{pending.decrementAndGet();}});
        return true;
    }
    boolean defer(Block owner,Runnable action) { return defer(owner.getLocation(),action); }
    boolean defer(Location owner,Runnable action) {
        if(!reserve())return false;
        scheduler.region(owner,()->{try{if(plugin.isEnabled())action.run();}finally{pending.decrementAndGet();}});
        return true;
    }
    private boolean reserve() {
        if(!plugin.isEnabled())return false;
        if(pending.incrementAndGet()<=4096)return true;
        pending.decrementAndGet();return false;
    }
    /** 同一结果容器在结算前只接受一张收货凭据，重复事件不能共用同一次库存变化。 */
    boolean deferOnce(InventoryEvent event,Runnable action) {
        var receipt=receipts.begin(event);if(receipt==null)return false;
        if(defer(event.getView().getPlayer(),()->{try{if(receipts.valid(receipt))action.run();}finally{receipts.finish(receipt);}},()->receipts.finish(receipt)))return true;
        receipts.finish(receipt);return false;
    }
    Listener receiptListener(){return receipts;}
    boolean award(Session session,String source,double amount,int cooldownTicks,double maximum) {
        if(!valid(session) || !Double.isFinite(amount) || amount<=0)return false;
        long now=System.currentTimeMillis();Key key=new Key(session.player.getUniqueId(),session.skill);
        if(limits.size()>=8192)limits.entrySet().removeIf(entry->now-entry.getValue().lastActivity()>120_000);
        if(limits.size()>=8192 && !limits.containsKey(key))return false;
        SourceRewardWindow window=limits.computeIfAbsent(key,ignored->new SourceRewardWindow());
        double accepted=window.available(source,amount,maximum,now);
        if(accepted<=0 || !skills.award(session.player,session.skill,accepted))return false;
        window.commit(source,accepted,cooldownTicks,now);return true;
    }
    @Override public void close(){scheduler.cancelAll();limits.clear();receipts.close();}
    record Session(Player player,PlayerProfile profile,long revision,UUID world,String skill) { }
    private record Key(UUID player,String skill) { }
}
