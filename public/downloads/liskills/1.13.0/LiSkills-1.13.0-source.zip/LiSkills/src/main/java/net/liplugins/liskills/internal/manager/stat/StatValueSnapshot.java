package net.liplugins.liskills.internal.manager.stat;

import net.liplugins.liskills.internal.config.ItemModifier;
import java.util.AbstractMap;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/** 对外仍是九属性Map，额外携带同一次计算的物品trait；不向Map塞入伪属性键。 */
public final class StatValueSnapshot extends AbstractMap<String, Double> {
    private final Map<String, Double> values;
    private final Map<String, ItemModifier> itemTraits;
    public StatValueSnapshot(Map<String, Double> values, Map<String, ItemModifier> itemTraits) {
        this.values = Collections.unmodifiableMap(new LinkedHashMap<>(values));
        this.itemTraits = Map.copyOf(itemTraits);
    }
    public Map<String, ItemModifier> itemTraits() { return itemTraits; }
    @Override public Set<Entry<String, Double>> entrySet() { return values.entrySet(); }
    @Override public Double get(Object key) { return values.get(key); }
}
