package net.liplugins.liskills.internal.manager;

import net.liplugins.liskills.internal.config.ActiveSkill;
import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.storage.PlayerProfile;
import net.liplugins.liskills.internal.util.ToolIdentity;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;
import net.liplugins.liskills.lib.scheduler.TaskHandle;
import net.liplugins.liskills.lib.scheduler.TaskScheduler;
import net.liplugins.liskills.lib.scheduler.ServerThreads;
import java.util.*;

/** 共用主动窗口的身份、期限及失效检查；不处理伤害、鱼钩或扣费。 */
public final class SkillAbilityWindows implements AutoCloseable {
    private final ConfigManager config;
    private final ProfileManager profiles;
    private final SkillManager skills;
    private final Map<Key,Window> windows=new java.util.concurrent.ConcurrentHashMap<>();
    private final net.liplugins.liskills.lib.scheduler.PlayerTasks cleanup;
    private final TaskScheduler scheduler;
    private final java.util.concurrent.atomic.AtomicLong sequence=new java.util.concurrent.atomic.AtomicLong();
    public SkillAbilityWindows(JavaPlugin plugin,ConfigManager config,ProfileManager profiles,SkillManager skills) {
        this.config=config;this.profiles=profiles;this.skills=skills;
        scheduler=new TaskScheduler(plugin);
        cleanup=new net.liplugins.liskills.lib.scheduler.PlayerTasks(plugin,player->windows.entrySet().removeIf(entry ->
                entry.getKey().player().equals(player.getUniqueId()) && !valid(player,entry.getKey().skill(),entry.getValue())),20,20);
    }
    public boolean open(Player player,String id,String type,ActiveSkill active,Set<Material> allowedMainHand) {
        if(!ServerThreads.owns(player) || active(player,id))return false;
        var definition=config.skill(id);var profile=profiles.get(player.getUniqueId());
        if(definition==null || profile==null || !ActiveSkillProgression.resolve(config,definition,profile).equals(active) || !type.equals(active.type())
                || !allowedMainHand.contains(player.getInventory().getItemInMainHand().getType()))return false;
        Window window=new Window(player.getWorld().getUID(),profile,config.revision(),sequence.incrementAndGet(),
                System.currentTimeMillis()+active.durationSeconds()*1000L,type,
                player.getInventory().getHeldItemSlot(),ToolIdentity.snapshot(player.getInventory().getItemInMainHand()));
        if(!valid(player,id,window))return false;
        windows.put(new Key(player.getUniqueId(),id),window);return true;
    }
    public boolean active(Player player,String id){return current(player,id)!=null;}
    public boolean active(Player player,String id,String type){Window window=current(player,id);return window!=null&&window.type().equals(type);}
    public long token(Player player,String id){Window window=current(player,id);return window==null?0:window.token();}
    public long remainingMillis(Player player,String id){Window window=current(player,id);return window==null?0:Math.max(0,window.expires()-System.currentTimeMillis());}
    private Window current(Player player,String id) {
        if(!ServerThreads.owns(player))return null;
        Key key=new Key(player.getUniqueId(),id);Window window=windows.get(key);
        if(window!=null && !valid(player,id,window)){windows.remove(key);return null;}
        return window;
    }
    private boolean valid(Player player,String id,Window window) {
        var definition=config.skill(id);
        return player.isOnline() && !player.isDead() && player.isValid() && skills.eligible(player)
                && player.hasPermission("liskills.skill."+id) && config.revision()==window.revision()
                && player.getWorld().getUID().equals(window.world()) && profiles.get(player.getUniqueId())==window.profile()
                && definition!=null && definition.enabled() && definition.active().enabled()
                && definition.active().type().equals(window.type()) && System.currentTimeMillis()<window.expires()
                && window.profile().progress(id).level()>=definition.active().unlockLevel()
                && player.getInventory().getHeldItemSlot()==window.slot()
                && window.tool().isSimilar(ToolIdentity.snapshot(player.getInventory().getItemInMainHand()));
    }
    public void remove(Player player,String id){windows.remove(new Key(player.getUniqueId(),id));}
    public void removeAll(Player player){windows.keySet().removeIf(key->key.player().equals(player.getUniqueId()));}
    @Override public void close(){cleanup.close();scheduler.cancelAll();windows.clear();}
    private record Key(UUID player,String skill) { }
    private record Window(UUID world,PlayerProfile profile,long revision,long token,long expires,String type,int slot,ItemStack tool) { }
}
