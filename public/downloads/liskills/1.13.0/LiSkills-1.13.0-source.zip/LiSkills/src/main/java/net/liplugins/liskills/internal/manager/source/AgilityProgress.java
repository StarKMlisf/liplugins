package net.liplugins.liskills.internal.manager.source;

import net.liplugins.liskills.internal.config.AgilitySourceSettings;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

/** 单个玩家的可信移动计量；纯数值规则，不读取Bukkit玩家，也不直接发经验。 */
public final class AgilityProgress {
    private static final int MAX_CELLS=512;
    private final Map<Cell,Long> recent=new HashMap<>();
    private final Map<Cell,Visit> credited=new HashMap<>();
    private Snapshot previous;
    private long lastActivity;
    private double walk,sprint,swim;
    private int jumps;

    public AgilityProgress(Snapshot initial) { previous=initial; lastActivity=initial.time(); }
    public void activity(long now) { lastActivity=Math.max(lastActivity,now); }

    public Map<String,Double> sample(Snapshot current,AgilitySourceSettings settings) {
        return sample(current,settings,true,true);
    }
    public Map<String,Double> sample(Snapshot current,AgilitySourceSettings settings,boolean movementEligible,boolean jumpingEligible) {
        Snapshot before=previous; previous=current;
        // 两个技能可独立授权：权限撤销时丢弃该分支未满门槛的旧进度，保留另一分支。
        if(!movementEligible) { walk=0;sprint=0;swim=0; }
        if(!jumpingEligible)jumps=0;
        recent.values().removeIf(time->current.time()-time>settings.recentSeconds()*1000L);
        credited.values().removeIf(visit->current.time()-visit.time>=settings.repeatSeconds()*1000L);
        long elapsed=current.time()-before.time();
        long walking=(long)current.walk()-before.walk(),sprinting=(long)current.sprint()-before.sprint(),swimming=(long)current.swim()-before.swim();
        long jumping=(long)current.jumps()-before.jumps();
        double horizontal=Math.hypot(current.x()-before.x(),current.z()-before.z());
        double physical=Math.hypot(horizontal,current.y()-before.y());
        double meters=(walking+sprinting+swimming)/100.0;
        // 先检查位置和统计的共同证据。管理员改统计、计数回滚、传送、骑乘推送都不能积攒奖励。
        if(!settings.enabled() || elapsed<=0 || elapsed>Math.max(2000L,settings.sampleTicks()*200L)
                || current.time()-lastActivity>settings.activitySeconds()*1000L || walking<0 || sprinting<0 || swimming<0 || jumping<0
                || !Double.isFinite(physical) || physical>settings.maximumMeters()+1e-7 || meters>settings.maximumMeters()+1e-7
                || jumping>settings.maximumJumps() || meters>physical*1.5+.35) return reject();
        if(horizontal<.05 || meters<=0) return Map.of();
        Cell start=cell(before,settings.cellSize()),end=cell(current,settings.cellSize());
        if(recent.size()>=MAX_CELLS || credited.size()>=MAX_CELLS) return reject();
        recent.put(start,current.time()); recent.put(end,current.time());
        if(recent.size()<settings.minimumCells())return Map.of();
        Visit visit=credited.computeIfAbsent(end,ignored->new Visit(current.time()));
        // 同一空间格在冷却内最多认可一次对角线长度；格内抖动与绕圈不会无限累计距离。
        double allowed=Math.max(0,settings.cellSize()*Math.sqrt(2)-visit.meters);
        if(allowed<=1e-7)return Map.of();
        double ratio=Math.min(1,allowed/meters);
        visit.meters+=meters*ratio;
        if(movementEligible) { walk+=walking/100.0*ratio; sprint+=sprinting/100.0*ratio; swim+=swimming/100.0*ratio; }
        if(jumpingEligible && ratio>=1-1e-7 && horizontal>=.2)jumps+=(int)jumping;
        Map<String,Double> earned=new LinkedHashMap<>();
        if(walk+1e-7>=settings.thresholdMeters()) { put(earned,"walk",walk*settings.experience().get("walk")); walk=0; }
        if(sprint+1e-7>=settings.thresholdMeters()) { put(earned,"sprint",sprint*settings.experience().get("sprint")); sprint=0; }
        if(swim+1e-7>=settings.thresholdMeters()) { put(earned,"swim",swim*settings.experience().get("swim")); swim=0; }
        if(jumps>=settings.jumpsPerAward()) { put(earned,"jump",(jumps/settings.jumpsPerAward())*settings.experience().get("jump")); jumps%=settings.jumpsPerAward(); }
        return Map.copyOf(earned);
    }
    private Map<String,Double> reject() { walk=0;sprint=0;swim=0;jumps=0;return Map.of(); }
    private static void put(Map<String,Double> values,String key,double value) { if(value>0 && Double.isFinite(value))values.put(key,value); }
    private static Cell cell(Snapshot snapshot,int size) { return new Cell((int)Math.floor(snapshot.x()/size),(int)Math.floor(snapshot.z()/size)); }
    public record Snapshot(double x,double y,double z,int walk,int sprint,int swim,int jumps,long time) { }
    private record Cell(int x,int z) { }
    private static final class Visit { final long time; double meters; Visit(long time) { this.time=time; } }
}
