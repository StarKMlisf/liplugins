package net.liplugins.liskills.lib;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.security.DigestInputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;
import java.util.function.Consumer;

/** 下载器只接收内置库描述；摘要校验通过前绝不覆盖最终缓存文件。 */
public final class LibraryDownloader {
    private static final long MAX_BYTES = 16L * 1024 * 1024;
    private final Path directory;
    private final Consumer<String> downloadNotice;
    private final Consumer<String> invalidCacheNotice;

    public LibraryDownloader(Path directory, Consumer<String> downloadNotice, Consumer<String> invalidCacheNotice) {
        this.directory = directory;
        this.downloadNotice = downloadNotice;
        this.invalidCacheNotice = invalidCacheNotice;
    }

    public Path ensure(RuntimeLibrary library) throws IOException {
        Files.createDirectories(directory);
        Path target = directory.resolve(library.fileName());
        if (Files.isRegularFile(target) && matches(target, library.sha256())) {
            return target;
        }
        if (Files.exists(target)) {
            invalidCacheNotice.accept(library.fileName());
        }
        downloadNotice.accept(library.fileName());
        Path temporary = Files.createTempFile(directory, library.fileName(), ".part");
        try {
            download(library, temporary);
            if (!matches(temporary, library.sha256())) {
                throw new IOException("SHA-256 mismatch: " + library.fileName());
            }
            try {
                Files.move(temporary, target, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
            } catch (AtomicMoveNotSupportedException ignored) {
                Files.move(temporary, target, StandardCopyOption.REPLACE_EXISTING);
            }
            return target;
        } finally {
            Files.deleteIfExists(temporary);
        }
    }

    private void download(RuntimeLibrary library, Path target) throws IOException {
        HttpURLConnection connection = (HttpURLConnection) library.uri().toURL().openConnection();
        connection.setConnectTimeout(10_000);
        connection.setReadTimeout(15_000);
        connection.setInstanceFollowRedirects(false);
        connection.setRequestProperty("User-Agent", "LiSkills dependency loader");
        try {
            int status = connection.getResponseCode();
            if (status != HttpURLConnection.HTTP_OK) {
                throw new IOException("HTTP " + status + ": " + library.fileName());
            }
            if (connection.getContentLengthLong() > MAX_BYTES) {
                throw new IOException("Dependency exceeds size limit: " + library.fileName());
            }
            try (InputStream input = connection.getInputStream(); OutputStream output = Files.newOutputStream(target)) {
                byte[] buffer = new byte[8192];
                long count = 0;
                int read;
                while ((read = input.read(buffer)) >= 0) {
                    count += read;
                    if (count > MAX_BYTES) {
                        throw new IOException("Dependency exceeds size limit: " + library.fileName());
                    }
                    output.write(buffer, 0, read);
                }
            }
        } finally {
            connection.disconnect();
        }
    }

    private boolean matches(Path path, String expected) throws IOException {
        if (Files.size(path) > MAX_BYTES) {
            return false;
        }
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            try (InputStream stream = new DigestInputStream(Files.newInputStream(path), digest)) {
                stream.transferTo(OutputStream.nullOutputStream());
            }
            return HexFormat.of().formatHex(digest.digest()).equals(expected);
        } catch (NoSuchAlgorithmException impossible) {
            throw new IOException(impossible);
        }
    }
}
