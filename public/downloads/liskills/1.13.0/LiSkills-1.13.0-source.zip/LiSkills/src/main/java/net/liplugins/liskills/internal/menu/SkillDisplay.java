package net.liplugins.liskills.internal.menu;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.config.SkillDefinition;
import net.liplugins.liskills.internal.storage.PlayerProfile;
import net.liplugins.liskills.internal.storage.SkillProgress;
import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.ChatColor;

import java.util.HashMap;
import java.util.Map;

/** 把技能档案转为菜单、聊天和占位符共用的展示数值。 */
public final class SkillDisplay {
    private SkillDisplay() { }

    public static double totalExperience(SkillDefinition skill, SkillProgress progress) {
        double total = progress.xp();
        for (int level = 1; level < progress.level(); level++) {
            total += skill.requiredXp(level);
        }
        return total;
    }

    public static int totalLevel(ConfigManager config, PlayerProfile profile) {
        return config.skills().values().stream().filter(SkillDefinition::enabled)
                .mapToInt(skill -> profile.progress(skill.id()).level()).sum();
    }

    public static Map<String, Object> values(SkillDefinition skill, SkillProgress progress, TextService text) {
        Map<String, Object> values = new HashMap<>();
        values.put("skill", text.plain(skill.name()));
        values.put("skill_id", skill.id());
        values.put("description", text.plain(skill.description()));
        values.put("level", progress.level());
        values.put("max", skill.maxLevel());
        values.put("xp", text.format(progress.xp()));
        values.put("required", text.format(progress.level() >= skill.maxLevel() ? 0 : skill.requiredXp(progress.level())));
        values.put("total_xp", text.format(totalExperience(skill, progress)));
        values.put("ability", skill.active().enabled() ? text.plain(skill.active().name())
                : ChatColor.stripColor(text.text("menu.no-ability")));
        return values;
    }
}
