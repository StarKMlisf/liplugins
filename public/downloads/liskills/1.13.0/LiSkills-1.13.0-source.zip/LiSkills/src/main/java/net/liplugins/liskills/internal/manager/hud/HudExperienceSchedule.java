package net.liplugins.liskills.internal.manager.hud;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** 合并同 tick 的经验变更，由各玩家实体定时器独立领取变更和到期状态。 */
final class HudExperienceSchedule {
    private final Set<UUID> dirty = new HashSet<>();
    private final Map<UUID, Long> deadlines = new HashMap<>();

    synchronized void changed(UUID uuid, long deadline) {
        dirty.add(uuid);
        deadlines.put(uuid, deadline);
    }

    /** 实体定时器只领取该玩家的变更；慢区域不会消费或丢失其他玩家的待显示经验。 */
    synchronized boolean drain(UUID uuid, long now) {
        boolean changed = dirty.remove(uuid);
        Long deadline = deadlines.get(uuid);
        if (deadline != null && deadline <= now) {
            deadlines.remove(uuid);
            return true;
        }
        return changed;
    }

    synchronized void remove(UUID uuid) {
        dirty.remove(uuid);
        deadlines.remove(uuid);
    }

    synchronized void clear() { dirty.clear(); deadlines.clear(); }
}
