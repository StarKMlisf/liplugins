package net.liplugins.liskills.internal.config;

import org.bukkit.configuration.ConfigurationSection;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.ArrayList;

/** 独立解析属性配置；完整校验成功后才由 ConfigManager 发布新快照。 */
public record StatsSettings(int rewardStartLevel, Map<String, StatDefinition> definitions,
                            Map<String, List<StatGrowth>> growth, Map<String, StatTraitSettings> traits,
                            double damageReductionBase, double anvilDiscountBase,
                            double maximumHealthBonus, double maximumSpeedBonus) {
    public static final List<String> IDS = List.of("strength", "health", "regeneration", "luck", "wisdom",
            "toughness", "crit_chance", "crit_damage", "speed");
    private static final Set<String> SKILLS = Set.of("farming", "foraging", "mining", "fishing", "excavation",
            "archery", "defense", "fighting", "agility", "alchemy", "enchanting", "endurance", "healing", "forging", "sorcery");
    public static final List<String> TRAITS = List.of("attack-damage", "hp", "saturation-regen", "hunger-regen",
            "mana-regen", "gathering-luck", "experience-bonus", "anvil-discount", "max-mana",
            "damage-reduction", "crit-chance", "crit-damage", "movement-speed", "luck", "double-drop",
            "farming-luck", "foraging-luck", "mining-luck", "fishing-luck", "excavation-luck");
    public static final Set<String> GATHERING_TRAITS = Set.of("farming-luck", "foraging-luck", "mining-luck", "fishing-luck", "excavation-luck");

    public StatsSettings {
        definitions = Collections.unmodifiableMap(new LinkedHashMap<>(definitions));
        Map<String, List<StatGrowth>> copied = new LinkedHashMap<>();
        growth.forEach((key, value) -> copied.put(key, List.copyOf(value)));
        growth = Collections.unmodifiableMap(copied);
        traits = Collections.unmodifiableMap(new LinkedHashMap<>(traits));
    }

    public static StatsSettings parse(ConfigurationSection root) {
        return parse(root,SKILLS);
    }
    public static StatsSettings parse(ConfigurationSection root,Set<String> skills) {
        if (root == null) throw invalid("stats.yml", "配置节");
        int start = integer(root, "reward-start-level", 1, 1000);
        ConfigurationSection attributes = section(root, "stats");
        rejectUnknown(attributes, Set.copyOf(IDS), "stats");
        Map<String, StatDefinition> definitions = new LinkedHashMap<>();
        for (String id : IDS) {
            ConfigurationSection stat = section(attributes, id);
            Object name = stat.get("name");
            if (!(name instanceof String text) || text.isBlank()) throw invalid("stats." + id + ".name", "非空中文显示文本");
            double maximum = number(stat, "maximum", 0, 1_000_000);
            double base = number(stat, "base", 0, maximum);
            definitions.put(id, new StatDefinition(id, (String) name, bool(stat, "enabled"), base, maximum));
        }
        ConfigurationSection rewards = section(root, "growth");
        rejectUnknown(rewards, skills, "growth");
        Map<String, List<StatGrowth>> growth = new LinkedHashMap<>();
        for (String skill : rewards.getKeys(false)) {
            ConfigurationSection entries = section(rewards, skill);
            rejectUnknown(entries, Set.copyOf(IDS), "growth." + skill);
            List<StatGrowth> rules = new ArrayList<>();
            for (String stat : entries.getKeys(false)) {
                ConfigurationSection rule = section(entries, stat);
                rules.add(new StatGrowth(stat, number(rule, "value", 0, 1000), integer(rule, "interval", 1, 1000)));
            }
            growth.put(skill, rules);
        }
        ConfigurationSection effects = section(root, "traits");
        rejectUnknown(effects, Set.copyOf(TRAITS), "traits");
        Map<String, StatTraitSettings> traits = new LinkedHashMap<>();
        for (String id : TRAITS) {
            // 新增trait未补写到旧文件时保留兼容行为；已有13项仍然严格校验。
            if (!effects.contains(id) && (GATHERING_TRAITS.contains(id) || id.equals("luck") || id.equals("double-drop"))) {
                traits.put(id, new StatTraitSettings(true, 0));
                continue;
            }
            ConfigurationSection trait = section(effects, id);
            traits.put(id, new StatTraitSettings(bool(trait, "enabled"), number(trait, "modifier", 0, 1000)));
        }
        return new StatsSettings(start, definitions, growth, traits,
                number(root, "damage-reduction-base", 1, 2), number(root, "anvil-discount-base", 1, 2),
                number(root, "maximum-health-bonus", 0, 1000), number(root, "maximum-speed-bonus", 0, 900));
    }

    public StatTraitSettings trait(String id) { return traits.get(id); }
    public List<StatGrowth> growthFor(String skill) { return growth.getOrDefault(skill, List.of()); }

    private static void rejectUnknown(ConfigurationSection section, Set<String> allowed, String path) {
        for (String key : section.getKeys(false)) if (!allowed.contains(key)) throw invalid(path + "." + key, "内置标识符");
    }
    private static ConfigurationSection section(ConfigurationSection root, String path) {
        ConfigurationSection result = root.getConfigurationSection(path);
        if (result == null) throw invalid(path, "配置节");
        return result;
    }
    private static boolean bool(ConfigurationSection root, String path) {
        Object value = root.get(path);
        if (!(value instanceof Boolean result)) throw invalid(path, "true 或 false");
        return result;
    }
    private static int integer(ConfigurationSection root, String path, int minimum, int maximum) {
        double value = number(root, path, minimum, maximum);
        if (value != Math.rint(value)) throw invalid(path, "整数 " + minimum + "～" + maximum);
        return (int) value;
    }
    private static double number(ConfigurationSection root, String path, double minimum, double maximum) {
        Object value = root.get(path);
        if (!(value instanceof Number number) || !Double.isFinite(number.doubleValue())
                || number.doubleValue() < minimum || number.doubleValue() > maximum)
            throw invalid(path, "有限数字 " + minimum + "～" + maximum);
        return number.doubleValue();
    }
    private static IllegalArgumentException invalid(String path, String expected) {
        return new IllegalArgumentException("stats.yml:" + path + " 必须是" + expected);
    }
}
