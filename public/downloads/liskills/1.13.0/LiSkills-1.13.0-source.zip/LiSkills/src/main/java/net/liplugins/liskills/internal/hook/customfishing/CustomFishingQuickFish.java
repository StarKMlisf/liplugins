package net.liplugins.liskills.internal.hook.customfishing;

import net.liplugins.liskills.lib.scheduler.ServerThreads;
import net.liplugins.liskills.lib.scheduler.TaskScheduler;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.manager.SkillAbilityWindows;
import net.liplugins.liskills.lib.customfishing.CustomFishingAccess;
import org.bukkit.entity.FishHook;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.inventory.EquipmentSlot;

import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.UUID;

/** 通过公开 FISHING 效果入口加速，完全不访问或调整第三方内部鱼钩计时器。 */
final class CustomFishingQuickFish {
    private static final int MAX_CASTS = 512, MAX_EFFECTS_PER_CAST = 16;
    private final ConfigManager config;
    private final SkillAbilityWindows windows;
    private final CustomFishingAccess access;
    private final Map<UUID, Cast> casts = new java.util.concurrent.ConcurrentHashMap<>();
    private final java.util.Set<UUID> checking = java.util.concurrent.ConcurrentHashMap.newKeySet();
    private final TaskScheduler scheduler;
    private final java.util.function.Consumer<Throwable> failure;
    private final CustomFishingClaims<UUID> observedHooks = new CustomFishingClaims<>(2048, 300_000L);

    CustomFishingQuickFish(ConfigManager config, SkillAbilityWindows windows, CustomFishingAccess access,
                           TaskScheduler scheduler, java.util.function.Consumer<Throwable> failure) {
        this.config = config; this.windows = windows; this.access = access;
        this.scheduler = scheduler; this.failure = failure;
    }
    void cast(Event event) throws ReflectiveOperationException {
        PlayerFishEvent source = access.rodSource(event);
        if (!ServerThreads.owns(source.getPlayer()) || !ServerThreads.owns(source.getHook())) return;
        if (source.getState() != PlayerFishEvent.State.FISHING
                || !observedHooks.claim(source.getHook().getUniqueId(), System.currentTimeMillis())) return;
        Player player = source.getPlayer();
        Cast previous = casts.remove(player.getUniqueId());
        if (previous != null) restore(previous);
        long token = windows.token(player, "fishing");
        if (source.getHand() != EquipmentSlot.HAND || token == 0 || casts.size() >= MAX_CASTS) return;
        casts.put(player.getUniqueId(), new Cast(event, source, token));
    }
    void effect(CustomFishingAccess.EffectView view) throws ReflectiveOperationException {
        Cast cast = casts.get(view.player().getUniqueId());
        if (cast == null || !cast.source.getHook().getUniqueId().equals(view.hook().getUniqueId())
                || cast.source.getPlayer() != view.player()) return;
        if (view.stage().equals("CAST")) { cast.confirmed = true; return; }
        if (!view.stage().equals("FISHING") || !cast.confirmed || !valid(cast)
                || cast.effects.containsKey(view.effect()) || cast.effects.size() >= MAX_EFFECTS_PER_CAST) return;
        double original = access.multiplier(view.effect());
        double adjusted = CustomFishingEffectRules.adjusted(original, config.quickFish().waitMultiplier());
        if (!Double.isFinite(adjusted) || adjusted >= original) return;
        access.multiplier(view.effect(), adjusted);
        cast.effects.put(view.effect(), new EffectLease(original, adjusted));
    }
    private boolean valid(Cast cast) {
        Player player = cast.source.getPlayer();
        FishHook hook = cast.source.getHook();
        return ServerThreads.owns(player) && ServerThreads.owns(hook) && config.customFishing().quickFish() && !((Cancellable) cast.event).isCancelled()
                && !cast.source.isCancelled() && windows.token(player, "fishing") == cast.token
                && player.isOnline() && player.isValid() && hook.isValid()
                && hook.getWorld().equals(player.getWorld())
                && hook.getShooter() instanceof Player shooter && shooter.getUniqueId().equals(player.getUniqueId());
    }
    void tick() throws ReflectiveOperationException {
        observedHooks.clean(System.currentTimeMillis());
        for (var entry : Map.copyOf(casts).entrySet()) {
            if (!checking.add(entry.getKey())) continue;
            scheduler.entityNow(entry.getValue().source.getPlayer(), () -> {
                try {
                    if (casts.get(entry.getKey()) != entry.getValue() || valid(entry.getValue())) return;
                    casts.remove(entry.getKey(), entry.getValue());
                    restore(entry.getValue());
                } catch (ReflectiveOperationException | RuntimeException | LinkageError error) { failure.accept(error); }
                finally { checking.remove(entry.getKey()); }
            }, () -> { checking.remove(entry.getKey()); casts.remove(entry.getKey(), entry.getValue()); });
        }
    }
    private void restore(Cast cast) throws ReflectiveOperationException {
        for (var entry : cast.effects.entrySet()) {
            EffectLease lease = entry.getValue();
            // 只撤回仍等于我方写入值的倍率，保留第三方稍后做出的修改。
            if (Double.compare(access.multiplier(entry.getKey()), lease.applied()) == 0)
                access.multiplier(entry.getKey(), lease.original());
        }
        cast.effects.clear();
    }
    void clear() {
        var previous = java.util.List.copyOf(casts.values());
        casts.clear();
        checking.clear();
        for (Cast cast : previous) {
            scheduler.entityNow(cast.source.getPlayer(), () -> {
                try { restore(cast); } catch (ReflectiveOperationException | RuntimeException | LinkageError ignored) { }
            });
        }
        observedHooks.clear();
    }
    private static final class Cast {
        private final Event event;
        private final PlayerFishEvent source;
        private final long token;
        private final Map<Object, EffectLease> effects = new IdentityHashMap<>();
        private boolean confirmed;
        private Cast(Event event, PlayerFishEvent source, long token) { this.event = event; this.source = source; this.token = token; }
    }
    private record EffectLease(double original, double applied) { }
}
