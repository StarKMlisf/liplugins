package net.liplugins.liskills.internal.config;

/** 护盾按抵消的基础伤害收取魔力；最多比例必须小于1，避免无限免伤。 */
public record ManaShieldSettings(double manaPerDamage,double maximumAbsorptionRatio) { }
