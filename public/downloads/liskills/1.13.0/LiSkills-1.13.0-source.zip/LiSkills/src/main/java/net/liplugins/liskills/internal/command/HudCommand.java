package net.liplugins.liskills.internal.command;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.manager.hud.HudManager;
import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Locale;

/** 只修改调用玩家的 HUD 偏好，不修改全服配置或其他玩家。 */
final class HudCommand implements Subcommand {
    private final ConfigManager config;
    private final SenderChecks checks;
    private final TextService text;
    private final HudManager hud;

    HudCommand(ConfigManager config,SenderChecks checks,TextService text,HudManager hud) {
        this.config=config;this.checks=checks;this.text=text;this.hud=hud;
    }

    public String name(){return "hud";}
    public String permission(){return "liskills.hud";}

    public void execute(CommandSender sender,String[] arguments) {
        if(!checks.permission(sender,"liskills.use"))return;
        Player player=checks.player(sender);
        if(player==null)return;
        String action=arguments.length==0?"toggle":arguments[0].toLowerCase(Locale.ROOT);
        if(arguments.length>1 || !HudCommandSuggestions.ACTIONS.contains(action)) {
            checks.usage(sender,"hud.usage");return;
        }
        if(!config.hud().enabled()) {text.send(sender,"hud.server-disabled");return;}
        switch(action) {
            case "on" -> hud.setEnabled(player,true);
            case "off" -> hud.setEnabled(player,false);
            case "toggle" -> hud.toggle(player);
            default -> { }
        }
        String message=action.equals("status")?(hud.enabled(player)?"hud.status-on":"hud.status-off")
                :(hud.enabled(player)?"hud.enabled":"hud.disabled");
        text.send(sender,message);
    }
}
