package net.liplugins.liskills.internal.manager.hud;

import org.bukkit.NamespacedKey;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

/** 只保存个人 HUD 开关；随玩家原生档案持久化，不改变技能存储格式。 */
final class HudPreferenceStore {
    private final NamespacedKey key;

    HudPreferenceStore(NamespacedKey key) { this.key = key; }

    boolean enabled(PersistentDataContainer data, boolean defaultEnabled) {
        // 旧档和管理员编辑造成的错误类型只影响此键，不能阻断整次 HUD 刷新。
        if (!data.has(key, PersistentDataType.BYTE)) {
            if (data.has(key)) data.remove(key);
            return defaultEnabled;
        }
        Byte value = data.get(key, PersistentDataType.BYTE);
        if (value != null && (value == 0 || value == 1)) return value == 1;
        data.remove(key);
        return defaultEnabled;
    }

    void setEnabled(PersistentDataContainer data, boolean enabled) {
        data.set(key, PersistentDataType.BYTE, enabled ? (byte) 1 : (byte) 0);
    }
}
