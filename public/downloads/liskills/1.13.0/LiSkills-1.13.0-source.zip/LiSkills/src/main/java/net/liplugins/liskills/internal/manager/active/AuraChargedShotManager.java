package net.liplugins.liskills.internal.manager.active;

import net.liplugins.liskills.internal.config.ActiveSkill;
import net.liplugins.liskills.internal.config.AuraChargedShotSettings;
import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.hook.LiRealEnchantHook;
import net.liplugins.liskills.internal.manager.AbilityManager;
import net.liplugins.liskills.internal.manager.ActiveAbilityHandler;
import net.liplugins.liskills.internal.manager.ActiveSkillProgression;
import net.liplugins.liskills.internal.manager.ManaManager;
import net.liplugins.liskills.internal.manager.ProfileManager;
import net.liplugins.liskills.internal.manager.SkillManager;
import net.liplugins.liskills.internal.manager.source.SorceryManaExperienceSource;
import net.liplugins.liskills.internal.manager.passive.combat.SecondaryDamageContext;
import net.liplugins.liskills.internal.storage.PlayerProfile;
import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.AbstractArrow;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Player;
import org.bukkit.entity.SpectralArrow;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityShootBowEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.plugin.java.JavaPlugin;
import net.liplugins.liskills.lib.scheduler.TaskHandle;
import net.liplugins.liskills.lib.scheduler.TaskScheduler;
import net.liplugins.liskills.lib.scheduler.ServerThreads;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.function.Supplier;

/** AURA_CHARGED_SHOT逐箭模式：左键开关，每箭按力度预留魔力，最终射击取消则退款。 */
public final class AuraChargedShotManager implements ActiveAbilityHandler,Listener,AutoCloseable {
    private final ConfigManager config;
    private final ProfileManager profiles;
    private final SkillManager skills;
    private final LiRealEnchantHook enchantments;
    private final TextService text;
    private final Supplier<AuraChargedShotSettings> settings;
    private final Map<UUID,Toggle> toggles=new java.util.concurrent.ConcurrentHashMap<>();
    private final Map<UUID,Shot> shots=new java.util.concurrent.ConcurrentHashMap<>(),pendingLaunch=new java.util.concurrent.ConcurrentHashMap<>();
    private final Map<UUID,PlayerInteractEvent> gestures=new java.util.concurrent.ConcurrentHashMap<>();
    private final TaskScheduler scheduler;
    private final net.liplugins.liskills.internal.manager.EntityWorkQueue work = new net.liplugins.liskills.internal.manager.EntityWorkQueue();
    private final TaskHandle ticker;
    private volatile AbilityManager abilities;
    public AuraChargedShotManager(JavaPlugin plugin,ConfigManager config,ProfileManager profiles,SkillManager skills,
                                  LiRealEnchantHook enchantments,TextService text,Supplier<AuraChargedShotSettings> settings) {
        this.config=config;this.profiles=profiles;this.skills=skills;this.enchantments=enchantments;this.text=text;this.settings=settings;
        ticker=(scheduler = new TaskScheduler(plugin)).globalTimer(this::tick,1,1);
    }
    public void bind(AbilityManager abilities){this.abilities=abilities;}
    @Override public boolean consumesActivationMana(){return false;}
    @Override public boolean startsActivationCooldown(){return false;}
    @Override public boolean usesStandardActivationMessage(){return false;}
    @Override public boolean activate(Player player,ActiveSkill active) {
        if(!ServerThreads.owns(player))return false;
        if(player.getInventory().getItemInMainHand().getType()!=Material.BOW){text.send(player,"ability.charged-shot-tool");return false;}
        if(!config.mana().enabled()){text.send(player,"ability.aura-charged-mana-disabled");return false;}
        if(settings.get().alwaysEnabled()){text.send(player,"ability.aura-charged-always-enabled");return false;}
        long now=System.currentTimeMillis();Toggle old=toggles.get(player.getUniqueId());
        if(old!=null && !eligible(player,old.profile,old.revision,old.world))old=null;
        if(old!=null && old.revision==config.revision() && old.changedAt+2000>now){text.send(player,"ability.aura-charged-toggle-wait");return false;}
        if(toggles.size()>=2048 && old==null)return false;
        boolean enabled=old==null || old.revision!=config.revision() || !old.enabled;
        toggles.put(player.getUniqueId(),new Toggle(enabled,now,config.revision(),player.getWorld().getUID(),profiles.get(player.getUniqueId())));
        text.send(player,enabled?"ability.aura-charged-enabled":"ability.aura-charged-disabled");return true;
    }
    @Override public long remainingMillis(Player player){return 0;}
    private boolean eligible(Player player,PlayerProfile profile,long revision,UUID world) {
        var skill=config.skill("archery");
        return profile!=null && ServerThreads.owns(player) && player.isOnline() && player.isValid() && !player.isDead() && skills.eligible(player)
                && player.hasPermission("liskills.use") && player.hasPermission("liskills.skill.archery")
                && config.revision()==revision && player.getWorld().getUID().equals(world) && profiles.get(player.getUniqueId())==profile
                && skill!=null && skill.enabled() && skill.active().enabled() && skill.active().type().equals("AURA_CHARGED_SHOT")
                && ActiveSkillProgression.rank(config,skill,profile)>0;
    }
    private boolean enabled(Player player) {
        PlayerProfile profile=profiles.get(player.getUniqueId());
        if(profile==null || !eligible(player,profile,config.revision(),player.getWorld().getUID()))return false;
        Toggle toggle=toggles.get(player.getUniqueId());
        return settings.get().alwaysEnabled() || toggle!=null && toggle.enabled
                && eligible(player,toggle.profile,toggle.revision,toggle.world);
    }
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)
    public void onShoot(EntityShootBowEvent event) {
        if(!config.mana().enabled() || !(event.getEntity() instanceof Player player) || !ServerThreads.owns(player) || !ServerThreads.owns(event.getProjectile()) || !enabled(player)
                || event.getHand()!=EquipmentSlot.HAND || event.getBow()==null || event.getBow().getType()!=Material.BOW
                || !(event.getProjectile() instanceof Arrow || event.getProjectile() instanceof SpectralArrow)
                || SecondaryDamageContext.active() || (enchantments!=null && enchantments.isSecondaryDamage()))return;
        var policy=settings.get();
        if(!Float.isFinite(event.getForce()) || event.getForce()<policy.minimumForce() || shots.size()>=policy.maxProjectiles()
                || pendingLaunch.size()>=policy.maxProjectiles() || shots.containsKey(event.getProjectile().getUniqueId())
                || pendingLaunch.containsKey(event.getProjectile().getUniqueId()))return;
        AbstractArrow arrow=(AbstractArrow)event.getProjectile();
        if(!(arrow.getShooter() instanceof Player shooter) || !shooter.getUniqueId().equals(player.getUniqueId()))return;
        PlayerProfile profile=profiles.get(player.getUniqueId());int rank=ActiveSkillProgression.rank(config,config.skill("archery"),profile);
        var calculation=AuraChargedShotMath.calculate(policy.manaCost(rank),event.getForce(),ManaManager.available(profile,config),
                policy.damagePercentPerMana(rank),policy.maximumBonusPercent());
        if(calculation.mana()<=0)return;
        var reservation=new AbilityManager.ManaReservation(calculation.mana(),()->ManaManager.available(profile,config),
                ()->ManaManager.maximum(profile,config),profile::mana,()->ManaManager.spend(profile,config,calculation.mana()));
        Shot shot=new Shot(event,arrow,player.getUniqueId(),player.getWorld().getUID(),profile,config.revision(),
                System.currentTimeMillis()+policy.projectileLifetimeSeconds()*1000L,calculation.mana(),calculation.multiplier(),
                policy.maximumBoostedHits(),reservation,policy.showShotMessage(),abilities==null?null:abilities.captureManaExperience(player,calculation.mana()));
        shots.put(arrow.getUniqueId(),shot);pendingLaunch.put(arrow.getUniqueId(),shot);
    }
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)
    public void onDamage(EntityDamageByEntityEvent event) {
        if(!ServerThreads.owns(event.getEntity()) || event.getCause()!=EntityDamageEvent.DamageCause.PROJECTILE || !(event.getDamager() instanceof AbstractArrow arrow) || !ServerThreads.owns(arrow)
                || SecondaryDamageContext.active() || (enchantments!=null && enchantments.isSecondaryDamage()))return;
        Shot shot=shots.get(arrow.getUniqueId());Player owner=shot==null?null:Bukkit.getPlayer(shot.owner);
        if(shot==null || owner==null || !valid(owner,shot) || shot.pendingHit!=null
                || !event.getEntity().getWorld().getUID().equals(shot.world) || (shot.collision!=null && shot.collision.isCancelled())
                || !Double.isFinite(event.getDamage()) || event.getDamage()<=0 || !Double.isFinite(event.getFinalDamage()) || event.getFinalDamage()<=0)return;
        event.setDamage(Math.min(1_000_000,event.getDamage()*shot.multiplier));shot.pendingHit=event;
    }
    private boolean valid(Player owner,Shot shot) {
        return ServerThreads.owns(shot.arrow) && System.currentTimeMillis()<shot.expires
                && (ServerThreads.owns(owner) ? eligible(owner,shot.profile,shot.revision,shot.world)
                : config.revision()==shot.revision && profiles.get(shot.owner)==shot.profile && config.skill("archery")!=null && config.skill("archery").enabled())
                && shot.launchResolved && shot.launchAccepted
                && shot.arrow.getShooter() instanceof Player shooter && shooter.getUniqueId().equals(shot.owner) && shot.remainingHits>0;
    }
    @EventHandler(priority=EventPriority.MONITOR)
    public void onHit(ProjectileHitEvent event) {
        Shot shot=shots.get(event.getEntity().getUniqueId());if(shot==null)return;shot.collision=event;
        if(event.getHitBlock()!=null && !event.isCancelled())shots.remove(event.getEntity().getUniqueId());
    }
    @EventHandler(priority=EventPriority.MONITOR)
    public void onInteract(PlayerInteractEvent event) {
        var skill=config.skill("archery");
        if(!ServerThreads.owns(event.getPlayer()) || abilities==null || skill==null || !skill.active().type().equals("AURA_CHARGED_SHOT") || settings.get().alwaysEnabled()
                || event.getHand()!=EquipmentSlot.HAND || event.getPlayer().getInventory().getItemInMainHand().getType()!=Material.BOW
                || (event.getAction()!=Action.LEFT_CLICK_AIR && event.getAction()!=Action.LEFT_CLICK_BLOCK) || gestures.size()>=2048)return;
        gestures.put(event.getPlayer().getUniqueId(),event);
    }
    private void finishLaunch(Shot shot) {
        boolean successful=!shot.launch.isCancelled() && shot.launch.getProjectile().getUniqueId().equals(shot.arrow.getUniqueId());
        // 发射事件只由射手区域结算，将最终结果发布给箭矢所在区域，不跨线程读取活跃发射事件。
        shot.launchAccepted=successful;shot.launchResolved=true;
        if(successful)shot.reservation.commit();else shots.remove(shot.arrow.getUniqueId(),shot);
        shot.reservation.close();
        Player player=Bukkit.getPlayer(shot.owner);
        if(successful && abilities!=null && player!=null && ServerThreads.owns(player))abilities.completeManaExperience(shot.experience);
        if(successful && shot.showMessage && player!=null && ServerThreads.owns(player))text.send(player,"ability.aura-charged-shot",Map.of("mana",text.format(shot.mana),"percent",text.format((shot.multiplier-1)*100)));
    }
    public void settleFor(UUID player) {
        for(var entry:Map.copyOf(pendingLaunch).entrySet())if(entry.getValue().owner.equals(player)){
            pendingLaunch.remove(entry.getKey());finishLaunch(entry.getValue());
        }
    }
    private void tick() {
        settleLaunches();
        shots.forEach((id,shot)->{
            EntityDamageByEntityEvent hit=shot.pendingHit;
            if(hit!=null)work.dispatch(scheduler,hit,hit.getEntity(),()->{
                synchronized(shot){if(shot.pendingHit!=hit)return;if(!hit.isCancelled() && Double.isFinite(hit.getFinalDamage()) && hit.getFinalDamage()>0)shot.remainingHits--;shot.pendingHit=null;}
            },()->shots.remove(id,shot));
            Player player=Bukkit.getPlayer(shot.owner);
            if(player==null){shots.remove(id,shot);return;}
            work.dispatch(scheduler,shot,shot.arrow,()->{if((shot.launchResolved && !valid(player,shot)) || !shot.arrow.isValid())shots.remove(id,shot);},()->shots.remove(id,shot));
        });
        toggles.forEach((id,toggle)->{Player player=Bukkit.getPlayer(id);if(player==null)toggles.remove(id,toggle);else work.dispatch(scheduler,toggle,player,()->{if(!eligible(player,toggle.profile,toggle.revision,toggle.world))toggles.remove(id,toggle);},()->toggles.remove(id,toggle));});
        for(var entry:Map.copyOf(gestures).entrySet()) {
            PlayerInteractEvent event=entry.getValue();
            work.dispatch(scheduler,event,event.getPlayer(),()->{
                if(!gestures.remove(entry.getKey(),event) || event.useItemInHand()==Event.Result.DENY || (event.getClickedBlock()!=null && event.useInteractedBlock()==Event.Result.DENY))return;
                if(abilities!=null)abilities.activate(event.getPlayer(),"archery");
            },()->gestures.remove(entry.getKey(),event));
        }
    }
    @EventHandler(priority=EventPriority.LOWEST)
    public void onQuit(PlayerQuitEvent event){UUID player=event.getPlayer().getUniqueId();settleFor(player);toggles.remove(player);gestures.remove(player);shots.values().removeIf(shot->shot.owner.equals(player));}
    private void settleLaunches() {
        // 完成经验事件可能重入施法/离线，先移除旧事务，不清掉回调新建的下一笔箭矢。
        for(var entry:Map.copyOf(pendingLaunch).entrySet()){
            Player player=Bukkit.getPlayer(entry.getValue().owner);
            if(player!=null)work.dispatch(scheduler,entry.getValue().reservation,player,()->{if(pendingLaunch.remove(entry.getKey(),entry.getValue()))finishLaunch(entry.getValue());},()->{
                if(pendingLaunch.remove(entry.getKey(),entry.getValue()))entry.getValue().reservation.close();
            });
            else if(pendingLaunch.remove(entry.getKey(),entry.getValue()))entry.getValue().reservation.close();
        }
    }
    @Override public void close(){
        ticker.cancel();scheduler.cancelAll();
        for(Shot shot:pendingLaunch.values()){
            Player player=Bukkit.getPlayer(shot.owner);
            if(player!=null && ServerThreads.owns(player))finishLaunch(shot);else shot.reservation.close();
        }
        pendingLaunch.clear();shots.clear();toggles.clear();gestures.clear();abilities=null;
    }
    private record Toggle(boolean enabled,long changedAt,long revision,UUID world,PlayerProfile profile) { }
    private static final class Shot {
        private final EntityShootBowEvent launch;private final AbstractArrow arrow;private final UUID owner,world;private final PlayerProfile profile;
        private final long revision,expires;private final double mana,multiplier;private final AbilityManager.ManaReservation reservation;private final boolean showMessage;
        private final SorceryManaExperienceSource.Receipt experience;
        private volatile int remainingHits;private volatile EntityDamageByEntityEvent pendingHit;private volatile ProjectileHitEvent collision;
        private boolean launchAccepted;private volatile boolean launchResolved;
        private Shot(EntityShootBowEvent launch,AbstractArrow arrow,UUID owner,UUID world,PlayerProfile profile,long revision,long expires,
                     double mana,double multiplier,int hits,AbilityManager.ManaReservation reservation,boolean showMessage,SorceryManaExperienceSource.Receipt experience) {
            this.launch=launch;this.arrow=arrow;this.owner=owner;this.world=world;this.profile=profile;this.revision=revision;this.expires=expires;
            this.mana=mana;this.multiplier=multiplier;this.remainingHits=hits;this.reservation=reservation;this.showMessage=showMessage;
            this.experience=experience;
        }
    }
}
