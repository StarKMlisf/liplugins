package net.liplugins.liskills.internal.manager.stat;

import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import net.liplugins.liskills.lib.scheduler.TaskHandle;
import net.liplugins.liskills.lib.scheduler.TaskScheduler;
import net.liplugins.liskills.lib.scheduler.ServerThreads;

import java.util.Map;

/** 仅维护本插件的生命/移动属性修饰符，保留服务器及其他插件的基值和修饰符。 */
final class StatAttributeManager implements AutoCloseable {
    private final JavaPlugin plugin;
    private final StatManager stats;
    private final NamespacedKey healthKey;
    private final NamespacedKey speedKey;
    private final NamespacedKey luckKey;
    private net.liplugins.liskills.lib.scheduler.PlayerTasks task;

    StatAttributeManager(JavaPlugin plugin, StatManager stats) {
        this.plugin = plugin;
        this.stats = stats;
        healthKey = new NamespacedKey(plugin, "stat_health");
        speedKey = new NamespacedKey(plugin, "stat_speed");
        luckKey = new NamespacedKey(plugin, "stat_luck");
    }

    void start() {
        if (task == null) task = new net.liplugins.liskills.lib.scheduler.PlayerTasks(plugin, stats::refresh, 1, 20);
    }

    void refresh(Player player) {
        Map<String, Double> values = stats.values(player);
        if (!stats.active(player)) { clear(player); return; }
        StatAttributeModifiers.update(player.getAttribute(Attribute.MAX_HEALTH), healthKey, stats.trait(values, "hp"));
        StatAttributeModifiers.update(player.getAttribute(Attribute.MOVEMENT_SPEED), speedKey, stats.trait(values, "movement-speed") / 1000.0);
        StatAttributeModifiers.update(player.getAttribute(Attribute.LUCK), luckKey, stats.trait(values, "luck"));
        clampHealth(player);
    }

    void clear(Player player) {
        StatAttributeModifiers.update(player.getAttribute(Attribute.MAX_HEALTH), healthKey, 0);
        StatAttributeModifiers.update(player.getAttribute(Attribute.MOVEMENT_SPEED), speedKey, 0);
        StatAttributeModifiers.update(player.getAttribute(Attribute.LUCK), luckKey, 0);
        clampHealth(player);
    }

    private void clampHealth(Player player) {
        AttributeInstance health = player.getAttribute(Attribute.MAX_HEALTH);
        if (health != null && !player.isDead() && player.getHealth() > health.getValue()) player.setHealth(health.getValue());
    }

    public void close() {
        if (task != null) { task.close(); task = null; }
        Throwable failure = null;
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (!ServerThreads.owns(player)) continue;
            try {
                stats.clear(player);
                // Bukkit 的普通修饰符会随玩家数据保存。停用时立刻写回清理结果，避免依赖下一次自动存档。
                // 只保存当前在线玩家；异常关服后尚未重新上线的旧存档不能靠卸载后的插件自动修复。
                player.saveData();
            } catch (RuntimeException | LinkageError error) {
                // 个别玩家清理或存档失败不能阻止其余玩家恢复，最后交由入口输出统一中文故障提示。
                if (failure == null) failure = error;
                else if (failure != error) failure.addSuppressed(error);
            }
        }
        if (failure instanceof RuntimeException error) throw error;
        if (failure instanceof LinkageError error) throw error;
    }
}
