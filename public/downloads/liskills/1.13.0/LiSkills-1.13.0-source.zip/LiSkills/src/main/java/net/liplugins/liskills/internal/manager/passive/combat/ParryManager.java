package net.liplugins.liskills.internal.manager.passive.combat;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.manager.PassiveAbilityManager;
import net.liplugins.liskills.internal.manager.ProfileManager;
import net.liplugins.liskills.internal.util.TextService;
import net.liplugins.liskills.internal.util.ToolIdentity;
import org.bukkit.Sound;
import net.liplugins.liskills.lib.scheduler.ServerThreads;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.Vector;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** 持剑左键形成短暂朝向窗口；只恢复成功招架这次事件的击退。 */
final class ParryManager implements Listener, AutoCloseable {
    private final ConfigManager config;
    private final ProfileManager profiles;
    private final PassiveAbilityManager passives;
    private final DeferredPassiveEffects effects;
    private final TextService text;
    private final Map<UUID, Window> windows=new java.util.concurrent.ConcurrentHashMap<>();
    ParryManager(ConfigManager config,ProfileManager profiles,PassiveAbilityManager passives,DeferredPassiveEffects effects,TextService text) {
        this.config=config;this.profiles=profiles;this.passives=passives;this.effects=effects;this.text=text;
    }
    @EventHandler(priority=EventPriority.MONITOR)
    public void onSwing(PlayerInteractEvent event) {
        if(event.getHand()!=EquipmentSlot.HAND || (event.getAction()!=Action.LEFT_CLICK_AIR && event.getAction()!=Action.LEFT_CLICK_BLOCK)) return;
        Player player=event.getPlayer();
        if(!player.getInventory().getItemInMainHand().getType().name().endsWith("_SWORD") || passives.value(player,"parry")<=0) return;
        // 左键空气本身可能被Bukkit标为cancelled；明确DENY物品使用时仍不准备。
        if(event.useItemInHand()==org.bukkit.event.Event.Result.DENY) return;
        Window current=windows.get(player.getUniqueId());
        if(current!=null && current.expires>System.nanoTime()) return;
        if(windows.size()>=2048) windows.entrySet().removeIf(entry->entry.getValue().expires<System.nanoTime());
        if(windows.size()>=2048) return;
        long duration=(long)Math.clamp(passives.option("parry","time_ms",250),50,2000);
        windows.put(player.getUniqueId(),new Window(PassiveSession.capture(player,profiles,config),
                player.getLocation().getDirection(),ToolIdentity.snapshot(player.getInventory().getItemInMainHand()),
                player.getInventory().getHeldItemSlot(),System.nanoTime()+duration*1_000_000));
    }
    double reduction(Player player,Entity attacker,EntityDamageByEntityEvent event) {
        if(!ServerThreads.owns(player) || !ServerThreads.owns(attacker))return 0;
        Window window=windows.get(player.getUniqueId());
        double value=passives.value(player,"parry");
        if(window==null || value<=0 || window.expires<System.nanoTime() || !window.session.valid(profiles,config)
                || window.slot!=player.getInventory().getHeldItemSlot()
                || !window.tool.equals(ToolIdentity.snapshot(player.getInventory().getItemInMainHand()))) return 0;
        Vector toward=attacker.getLocation().toVector().subtract(player.getLocation().toVector());
        if(toward.lengthSquared()<1e-8 || toward.normalize().dot(window.facing)<0.7) return 0;
        Vector before=player.getVelocity().clone();
        effects.submit(player.getUniqueId(),()->{
            if(event.isCancelled() || !(event.getFinalDamage()>0) || !window.session.valid(profiles,config) || passives.value(player,"parry")<=0) return;
            player.setVelocity(before);
            text.send(player,"passive.parry");
            if(passives.flag("parry","enable_sound",true)) player.playSound(player.getLocation(),Sound.ITEM_TRIDENT_RETURN,1,1.4f);
        });
        return PassiveCombatMath.percent(value);
    }
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void onHeld(PlayerItemHeldEvent event){windows.remove(event.getPlayer().getUniqueId());}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void onSwap(PlayerSwapHandItemsEvent event){windows.remove(event.getPlayer().getUniqueId());}
    @EventHandler(priority=EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent event){windows.remove(event.getPlayer().getUniqueId());}
    @EventHandler(priority=EventPriority.MONITOR)
    public void onWorld(PlayerChangedWorldEvent event){windows.remove(event.getPlayer().getUniqueId());}
    @EventHandler(priority=EventPriority.MONITOR)
    public void onDeath(PlayerDeathEvent event){windows.remove(event.getEntity().getUniqueId());}
    @Override public void close(){windows.clear();}
    private record Window(PassiveSession session,Vector facing,ItemStack tool,int slot,long expires) { }
}
