package net.liplugins.liskills.internal.config;

import org.bukkit.configuration.ConfigurationSection;

/** 新模块共用的严格配置读取；错误数值不会退回默认值掩盖配置问题。 */
public final class ConfigValues {
    private ConfigValues() { }
    public static ConfigurationSection section(ConfigurationSection root,String key) {
        ConfigurationSection value=root.getConfigurationSection(key);
        if(value==null)throw invalid(key,"配置节");return value;
    }
    public static boolean bool(ConfigurationSection root,String key) {
        if(!(root.get(key) instanceof Boolean value))throw invalid(key,"true/false");return value;
    }
    public static String text(ConfigurationSection root,String key) {
        if(!(root.get(key) instanceof String value)||value.isBlank())throw invalid(key,"非空文本");return value;
    }
    public static double number(ConfigurationSection root,String key,double min,double max) {
        if(!(root.get(key) instanceof Number value)||!Double.isFinite(value.doubleValue())||value.doubleValue()<min||value.doubleValue()>max)
            throw invalid(key,min+"至"+max+"的有限数值");return value.doubleValue();
    }
    public static int integer(ConfigurationSection root,String key,int min,int max) {
        double value=number(root,key,min,max);if(value!=Math.rint(value))throw invalid(key,"整数");return (int)value;
    }
    public static IllegalArgumentException invalid(String key,String expected) {
        return new IllegalArgumentException(key+"：应为"+expected);
    }
}
