package net.liplugins.liskills.internal.config;

/** 范围挖掘搜索与分帧预算；由配置层校验后发布。 */
public record TerraformSettings(int maxBlocks, int maxScans, int blocksPerTick, int radius) { }
