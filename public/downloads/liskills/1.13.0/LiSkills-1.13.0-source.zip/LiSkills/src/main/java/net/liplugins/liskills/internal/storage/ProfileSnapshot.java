package net.liplugins.liskills.internal.storage;

import java.util.Map;
import java.util.UUID;

public record ProfileSnapshot(UUID uuid,String name,Map<String,SkillProgress> skills,Map<String,Long> cooldowns,double mana) {
    public ProfileSnapshot {
        skills=Map.copyOf(skills); cooldowns=Map.copyOf(cooldowns);
        if(!Double.isFinite(mana) || (mana<0 && mana!=-1)) throw new IllegalArgumentException("mana");
    }
    public ProfileSnapshot(UUID uuid,String name,Map<String,SkillProgress> skills,Map<String,Long> cooldowns) {
        this(uuid,name,skills,cooldowns,-1);
    }
}
