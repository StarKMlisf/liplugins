package net.liplugins.liskills.internal.config;

import java.util.Map;

/** level变量表示将要到达的等级，与AuraSkills的xp_requirements表达式一致。 */
public record XpCurve(XpExpression expression,double base,double multiplier,Map<Integer,Double> levels) {
    public XpCurve { levels=Map.copyOf(levels); }
    public double required(int currentLevel){int target=currentLevel+1;Double explicit=levels.get(target);return explicit==null?expression.evaluate(target,base,multiplier):explicit;}
}
