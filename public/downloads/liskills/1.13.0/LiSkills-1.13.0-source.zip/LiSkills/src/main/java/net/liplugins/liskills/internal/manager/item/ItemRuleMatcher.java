package net.liplugins.liskills.internal.manager.item;

import net.liplugins.liskills.internal.config.ItemRule;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import java.util.function.Function;

/** 只读匹配材质和公开PDC，不读取Lore，不认领或重写其他插件的标签。 */
public final class ItemRuleMatcher {
    private ItemRuleMatcher() { }

    public static boolean matches(ItemRule rule, ItemStack item) {
        if (item == null || item.getAmount() <= 0) return false;
        return matches(rule, item.getType(), key -> {
            if (!item.hasItemMeta()) return null;
            var meta = item.getItemMeta();
            NamespacedKey namespacedKey = NamespacedKey.fromString(key);
            if (meta == null || namespacedKey == null) return null;
            var data = meta.getPersistentDataContainer();
            // 同名但不同类型的PDC不是匹配项；不能直接get后让类型错误中断玩家事件。
            return data.has(namespacedKey, PersistentDataType.STRING) ? data.get(namespacedKey, PersistentDataType.STRING) : null;
        });
    }

    public static boolean matches(ItemRule rule, Material material, Function<String, String> stringPdc) {
        return rule.enabled() && material != null && material != Material.AIR && material != Material.CAVE_AIR && material != Material.VOID_AIR
                && (rule.materials().isEmpty() || rule.materials().contains(material))
                && (rule.pdcKey().isEmpty() || rule.pdcValue().equals(stringPdc.apply(rule.pdcKey())));
    }
}
