package net.liplugins.liskills.internal.config;

import org.bukkit.configuration.ConfigurationSection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** 炼金自然来源、实际取药凭据与用药频率限制；不读取旧event-xp。 */
public record AlchemySourceSettings(boolean enabled,boolean ignoreCustomItems,double experienceMultiplier,double maximumXpPerMinute,
                                    int maximumTrackedStands,int claimLifetimeSeconds,int maximumBrewingSteps,
                                    int consumeCooldownTicks,int splashCooldownTicks,int maximumProjectiles,int projectileLifetimeSeconds,
                                    boolean requireSplashTarget,Map<String,Double> experience) {
    public static final List<String> SOURCES=List.of("brew.awkward","brew.regular","brew.extended","brew.upgraded","brew.splash","brew.lingering",
            "drink.regular","drink.extended","drink.upgraded","drink.golden-apple","drink.enchanted-golden-apple",
            "splash.regular","splash.extended","splash.upgraded","lingering.regular","lingering.extended","lingering.upgraded");
    public AlchemySourceSettings { experience=Map.copyOf(experience); }
    public double xp(String source){return experience.getOrDefault(source,0.0)*experienceMultiplier;}
    public static AlchemySourceSettings parse(ConfigurationSection section) {
        if(section==null)throw ConfigValues.invalid("alchemy","炼金来源配置节");
        Map<String,Double> values=new LinkedHashMap<>();
        for(String source:SOURCES)values.put(source,ConfigValues.number(section,"experience."+source,0,1e9));
        return new AlchemySourceSettings(ConfigValues.bool(section,"enabled"),ConfigValues.bool(section,"ignore-custom-items"),
                ConfigValues.number(section,"experience-multiplier",0,100),ConfigValues.number(section,"maximum-xp-per-minute",1,1e9),
                ConfigValues.integer(section,"maximum-tracked-stands",1,16384),ConfigValues.integer(section,"claim-lifetime-seconds",30,3600),
                ConfigValues.integer(section,"maximum-brewing-steps",1,5),ConfigValues.integer(section,"consume-cooldown-ticks",0,1200),
                ConfigValues.integer(section,"splash-cooldown-ticks",0,1200),ConfigValues.integer(section,"maximum-projectiles",1,8192),
                ConfigValues.integer(section,"projectile-lifetime-seconds",1,120),ConfigValues.bool(section,"require-splash-target"),values);
    }
}
