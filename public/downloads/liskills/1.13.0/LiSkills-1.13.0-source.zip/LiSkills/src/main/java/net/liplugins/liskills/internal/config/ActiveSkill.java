package net.liplugins.liskills.internal.config;

public record ActiveSkill(boolean enabled, String name, String effect, int amplifier,
                          int durationSeconds, int cooldownSeconds, int unlockLevel, double manaCost, String type) {
    public ActiveSkill(boolean enabled,String name,String effect,int amplifier,int durationSeconds,int cooldownSeconds,int unlockLevel,double manaCost) {
        this(enabled,name,effect,amplifier,durationSeconds,cooldownSeconds,unlockLevel,manaCost,"POTION");
    }
    public ActiveSkill(boolean enabled,String name,String effect,int amplifier,int durationSeconds,int cooldownSeconds,int unlockLevel) {
        this(enabled,name,effect,amplifier,durationSeconds,cooldownSeconds,unlockLevel,20,"POTION");
    }
}
