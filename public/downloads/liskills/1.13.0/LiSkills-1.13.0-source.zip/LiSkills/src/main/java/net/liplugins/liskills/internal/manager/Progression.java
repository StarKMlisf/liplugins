package net.liplugins.liskills.internal.manager;

import net.liplugins.liskills.internal.config.SkillDefinition;
import net.liplugins.liskills.internal.storage.SkillProgress;

/** 纯数值结算，可独立回归验证；每次最多迭代配置允许的 1000 级。 */
public final class Progression {
    private Progression() { }
    /** 计算本次实际记入的经验，跨级和达到上限时不显示被丢弃的溢出经验。 */
    public static double gained(SkillDefinition skill,SkillProgress before,SkillProgress after,double requested) {
        double gained=after.xp()-before.xp();
        for(int level=before.level();level<after.level();level++)gained+=skill.requiredXp(level);
        return Math.max(0,Math.min(requested,gained));
    }
    public static SkillProgress add(SkillDefinition skill,SkillProgress current,double amount) {
        if(!Double.isFinite(amount) || amount<0)throw new IllegalArgumentException("amount");
        double xp=current.xp()+amount;
        if(!Double.isFinite(xp))throw new IllegalArgumentException("xp overflow");
        int level=current.level();
        // 降低配置上限不能删除玩家已有等级和经验；超出上限时冻结继续成长。
        if(level>=skill.maxLevel())return current;
        while(level<skill.maxLevel() && xp>=skill.requiredXp(level)){
            xp-=skill.requiredXp(level);level++;
        }
        return new SkillProgress(level,level>=skill.maxLevel()?0:xp);
    }
}
