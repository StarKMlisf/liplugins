package net.liplugins.liskills.internal.storage;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** SQL载荷与YAML格式一致；每次保存带版本和幂等令牌，禁止UPSERT覆盖别人的进度。 */
public final class SqlProfileStore implements ProfileRepository {
    private final SqlSession session;
    private final String table;
    private final boolean readOnly;
    private final boolean tablePresent;
    private final Map<UUID,Long> revisions=new HashMap<>();
    private final Map<UUID,SqlWriteVersion> uncertain=new HashMap<>();
    private record Row(String payload,long revision,String token){ }
    public SqlProfileStore(SqlSession session,String prefix,boolean mysql)throws Exception{this(session,prefix,mysql,false);}
    public SqlProfileStore(SqlSession session,String prefix,boolean mysql,boolean readOnly)throws Exception{this(session,prefix,mysql,readOnly,false);}
    public SqlProfileStore(SqlSession session,String prefix,boolean mysql,boolean readOnly,boolean allowMissingTable)throws Exception{
        if(!prefix.matches("[a-z][a-z0-9_]{0,31}"))throw new IllegalArgumentException("table-prefix");
        if(allowMissingTable&&!readOnly)throw new IllegalArgumentException("missing-table-preview-requires-read-only");
        this.session=session;this.readOnly=readOnly;table=prefix+"profiles";
        String columns="uuid VARCHAR(36) PRIMARY KEY, payload "+(mysql?"LONGTEXT":"TEXT")+" NOT NULL, revision BIGINT NOT NULL, write_token VARCHAR(36) NOT NULL";
        if(!readOnly)try(var statement=session.prepare("CREATE TABLE IF NOT EXISTS "+table+" ("+columns+")"+(mysql?" ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin":""))){statement.executeUpdate();}
        boolean present=true;
        // SQLite已有数据库但目标表不存在时查询schema，不通过宽泛SQLException判定空表。
        if(allowMissingTable&&!mysql)try(var statement=session.prepare("SELECT name FROM sqlite_schema WHERE name=? COLLATE NOCASE AND type IN ('table','view')")){
            statement.setString(1,table);try(var result=statement.executeQuery()){present=result.next();}
        }
        // 验证已有表结构；MySQL只接受明确的1146/42S02缺表错误，权限/断线/缺列不能假装空目标。
        if(present)try(var statement=session.prepare("SELECT uuid,payload,revision,write_token FROM "+table+" WHERE 1=0")){statement.executeQuery().close();}
        catch(SQLException error){if(allowMissingTable&&mysql&&error.getErrorCode()==1146&&"42S02".equals(error.getSQLState())&&mysqlTargetMissing())present=false;else throw error;}
        tablePresent=present;
    }
    private boolean mysqlTargetMissing()throws SQLException{
        // 错误也可能来自同名视图缺少底层表；只有目标对象自身不存在才允许空预检。
        try(var statement=session.prepare("SELECT table_name FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?")){
            statement.setString(1,table);try(var result=statement.executeQuery()){return !result.next();}
        }
    }
    public ProfileSnapshot load(UUID uuid,String name)throws Exception{
        if(uncertain.containsKey(uuid))resolve(uuid);
        Row row=row(uuid);
        if(row==null){if(name==null)throw new IOException("Missing enumerated SQL profile: "+uuid);revisions.put(uuid,0L);return new ProfileSnapshot(uuid,name,Map.of(),Map.of());}
        ProfileSnapshot snapshot=ProfileYamlCodec.decode(uuid,name,row.payload());revisions.put(uuid,row.revision());return snapshot;
    }
    public List<ProfileSnapshot> loadAll()throws Exception{
        if(!tablePresent)return List.of();
        List<ProfileSnapshot> profiles=new ArrayList<>();
        try(var statement=session.prepare("SELECT uuid,payload,revision,write_token FROM "+table+" ORDER BY uuid")){try(var result=statement.executeQuery()){
            while(result.next()){
                UUID uuid=UUID.fromString(result.getString(1));validateRevision(result.getLong(3));
                profiles.add(ProfileYamlCodec.decode(uuid,null,result.getString(2)));
                if(profiles.size()>1_000_000)throw new IOException("SQL profile count exceeds safe export limit");
            }
        }}catch(SQLException error){session.invalidate();throw error;}
        return List.copyOf(profiles);
    }
    public void save(ProfileSnapshot snapshot)throws Exception{
        if(readOnly)throw new IOException("read-only-profile-repository");
        UUID uuid=snapshot.uuid();String payload=ProfileYamlCodec.encode(snapshot);
        if(!revisions.containsKey(uuid))throw new StorageConflictException("SQL profile was not loaded before save: "+uuid);
        resolve(uuid);
        SqlWriteVersion write=new SqlWriteVersion(revisions.get(uuid),UUID.randomUUID().toString());uncertain.put(uuid,write);
        try{
            int changed;
            if(write.expected()==0){
                try(var statement=session.prepare("INSERT INTO "+table+" (uuid,payload,revision,write_token) VALUES (?,?,?,?)")){
                    statement.setString(1,uuid.toString());statement.setString(2,payload);statement.setLong(3,write.next());statement.setString(4,write.token());changed=statement.executeUpdate();
                }
            }else{
                try(var statement=session.prepare("UPDATE "+table+" SET payload=?,revision=?,write_token=? WHERE uuid=? AND revision=?")){
                    statement.setString(1,payload);statement.setLong(2,write.next());statement.setString(3,write.token());statement.setString(4,uuid.toString());statement.setLong(5,write.expected());changed=statement.executeUpdate();
                }
            }
            if(changed!=1)throw new StorageConflictException("SQL revision changed externally: "+uuid);
            revisions.put(uuid,write.next());uncertain.remove(uuid);
        }catch(SQLException error){session.invalidate();throw error;}
    }
    @Override public boolean insertIfAbsent(ProfileSnapshot snapshot)throws Exception{
        if(readOnly)throw new IOException("read-only-profile-repository");
        UUID uuid=snapshot.uuid();resolve(uuid);Row existing=row(uuid);
        if(existing!=null){
            if(ProfileYamlCodec.decode(uuid,null,existing.payload()).equals(snapshot))return false;
            throw new StorageConflictException("migration-target-conflict: "+uuid);
        }
        // 强制期望不存在，后续INSERT由主键约束处理竞争；绝不能把新出现的行当成UPDATE。
        revisions.put(uuid,0L);save(snapshot);return true;
    }
    private void resolve(UUID uuid)throws Exception{
        SqlWriteVersion write=uncertain.get(uuid);if(write==null)return;
        Row row=row(uuid);long actual=row==null?0:row.revision();
        if(row!=null&&write.committed(actual,row.token()))revisions.put(uuid,actual);
        else if(!write.untouched(actual))throw new StorageConflictException("SQL uncertain write conflicts with stored version: "+uuid);
        uncertain.remove(uuid);
    }
    private Row row(UUID uuid)throws Exception{
        try(var statement=session.prepare("SELECT payload,revision,write_token FROM "+table+" WHERE uuid=?")){
            statement.setString(1,uuid.toString());try(var result=statement.executeQuery()){
                if(!result.next())return null;long revision=result.getLong(2);validateRevision(revision);return new Row(result.getString(1),revision,result.getString(3));
            }
        }catch(SQLException error){session.invalidate();throw error;}
    }
    private static void validateRevision(long revision)throws IOException{if(revision<=0||revision==Long.MAX_VALUE)throw new IOException("Invalid SQL profile revision");}
    @Override public void close()throws Exception{session.close();}
}
