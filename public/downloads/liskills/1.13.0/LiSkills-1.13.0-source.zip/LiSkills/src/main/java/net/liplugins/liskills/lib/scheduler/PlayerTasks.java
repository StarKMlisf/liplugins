package net.liplugins.liskills.lib.scheduler;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.server.PluginDisableEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;

/** 每玩家一个随实体迁移的周期任务；不会在全局任务里读取玩家属性或跨区执行玩法。 */
public final class PlayerTasks implements Listener, AutoCloseable {
    private final JavaPlugin plugin;
    private final TaskScheduler scheduler;
    private final Consumer<Player> action;
    private final long delay, period;
    private final ConcurrentMap<UUID, Session> sessions = new ConcurrentHashMap<>();
    private final AtomicBoolean closed = new AtomicBoolean();

    public PlayerTasks(JavaPlugin plugin, Consumer<Player> action, long delay, long period) {
        this(plugin, new TaskScheduler(plugin), action, delay, period);
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
        Bukkit.getOnlinePlayers().forEach(this::start);
    }
    PlayerTasks(TaskScheduler scheduler, Consumer<Player> action, long delay, long period) {
        this(null, scheduler, action, delay, period);
    }
    private PlayerTasks(JavaPlugin plugin, TaskScheduler scheduler, Consumer<Player> action, long delay, long period) {
        if (delay < 0 || period < 1) throw new IllegalArgumentException("invalid player task interval");
        this.plugin = plugin;
        this.scheduler = Objects.requireNonNull(scheduler);
        this.action = Objects.requireNonNull(action);
        this.delay = delay;
        this.period = period;
    }

    public void start(Player player) {
        Objects.requireNonNull(player);
        if (closed.get()) return;
        UUID uuid = player.getUniqueId();
        Session session = new Session(player);
        while (true) {
            Session previous = sessions.putIfAbsent(uuid, session);
            if (previous == null) break;
            if (previous.player == player) return;
            if (sessions.replace(uuid, previous, session)) { previous.close(); break; }
        }
        if (closed.get()) { sessions.remove(uuid, session); session.close(); return; }
        try {
            session.bind(scheduler.entityTimer(player, () -> {
                if (closed.get() || sessions.get(uuid) != session || !player.isOnline()) {
                    sessions.remove(uuid, session); session.close(); return;
                }
                try { action.accept(player); }
                catch (RuntimeException | Error error) { sessions.remove(uuid, session); session.close(); throw error; }
            }, delay, period, () -> { sessions.remove(uuid, session); session.close(); }));
        } catch (RuntimeException | Error error) {
            sessions.remove(uuid, session); session.close(); throw error;
        }
    }

    /** 仅结束同一Player对象的会话，旧退服事件不会取消同UUID的新连接。 */
    public void stop(Player player) {
        UUID uuid = Objects.requireNonNull(player).getUniqueId();
        Session session = sessions.get(uuid);
        if (session != null && session.player == player && sessions.remove(uuid, session)) session.close();
    }

    /** 重载等入口请求现有会话下一tick刷新；不从调用线程读取玩家世界状态。 */
    public void refreshAll() {
        if (closed.get()) return;
        sessions.forEach((uuid, session) -> scheduler.entity(session.player, () -> {
            if (!closed.get() && sessions.get(uuid) == session && session.player.isOnline()) action.accept(session.player);
        }, () -> { if (sessions.remove(uuid, session)) session.close(); }));
    }

    @EventHandler(priority = EventPriority.MONITOR) public void onJoin(PlayerJoinEvent event) { start(event.getPlayer()); }
    @EventHandler(priority = EventPriority.MONITOR) public void onQuit(PlayerQuitEvent event) { stop(event.getPlayer()); }
    @EventHandler(priority = EventPriority.MONITOR) public void onDisable(PluginDisableEvent event) { if (event.getPlugin() == plugin) close(); }
    @Override public void close() {
        if (!closed.compareAndSet(false, true)) return;
        HandlerList.unregisterAll(this);
        try { scheduler.cancelAll(); }
        finally { sessions.values().forEach(Session::close); sessions.clear(); }
    }

    /** 退休或close可能先于底层调度返回，晚绑定句柄仍需立即取消。 */
    private static final class Session {
        private final Player player;
        private TaskHandle task;
        private boolean closed;
        private Session(Player player) { this.player = player; }
        void bind(TaskHandle handle) {
            boolean cancel;
            synchronized (this) { cancel = closed; if (!cancel) task = handle; }
            if (cancel) handle.cancel();
        }
        void close() {
            TaskHandle handle;
            synchronized (this) { closed = true; handle = task; task = null; }
            if (handle != null) handle.cancel();
        }
    }
}
