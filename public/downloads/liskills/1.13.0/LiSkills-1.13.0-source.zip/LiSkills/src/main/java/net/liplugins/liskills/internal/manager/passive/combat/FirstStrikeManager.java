package net.liplugins.liskills.internal.manager.passive.combat;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.manager.PassiveAbilityManager;
import net.liplugins.liskills.internal.manager.ProfileManager;
import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** 先出之刃以个人冷却存档；同tick重入不能重复申请，最终取消则释放申请。 */
final class FirstStrikeManager {
    private static final String COOLDOWN = "passive:first_strike";
    private final ConfigManager config;
    private final ProfileManager profiles;
    private final PassiveAbilityManager passives;
    private final DeferredPassiveEffects effects;
    private final TextService text;
    private final Map<UUID, EntityDamageByEntityEvent> pending = new java.util.concurrent.ConcurrentHashMap<>();
    FirstStrikeManager(ConfigManager config, ProfileManager profiles, PassiveAbilityManager passives,
                       DeferredPassiveEffects effects, TextService text) {
        this.config=config; this.profiles=profiles; this.passives=passives; this.effects=effects; this.text=text;
    }
    double reserve(Player player, EntityDamageByEntityEvent event) {
        double value=passives.value(player,"first_strike");
        PassiveSession session=PassiveSession.capture(player,profiles,config);
        if(value<=0 || !session.valid(profiles,config) || pending.containsKey(player.getUniqueId())
                || session.profile().cooldown(COOLDOWN)>System.currentTimeMillis()) return 0;
        pending.put(player.getUniqueId(),event);
        boolean submitted=effects.submit(player.getUniqueId(),()->{
            if(!pending.remove(player.getUniqueId(),event)) return;
            if(!session.valid(profiles,config) || passives.value(player,"first_strike")<=0 || event.isCancelled() || !(event.getFinalDamage()>0)
                    || !Double.isFinite(event.getFinalDamage())) return;
            long ticks=(long)Math.clamp(passives.option("first_strike","cooldown_ticks",6000),1,72_000);
            session.profile().cooldown(COOLDOWN,System.currentTimeMillis()+ticks*50);
            if(passives.flag("first_strike","enable_message",true)) text.send(player,"passive.first-strike");
        });
        if(!submitted) { pending.remove(player.getUniqueId(),event); return 0; }
        return value;
    }
}
