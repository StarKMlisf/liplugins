package net.liplugins.liskills.internal.config;

/** 一个属性的展示名、开关和取值边界；不含玩家状态。 */
public record StatDefinition(String id, String name, boolean enabled, double base, double maximum) { }
