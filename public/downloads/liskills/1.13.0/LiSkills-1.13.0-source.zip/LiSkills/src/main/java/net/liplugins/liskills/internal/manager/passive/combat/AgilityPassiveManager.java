package net.liplugins.liskills.internal.manager.passive.combat;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.hook.LiRealEnchantHook;
import net.liplugins.liskills.internal.manager.PassiveAbilityManager;
import net.liplugins.liskills.internal.manager.ProfileManager;
import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Player;
import org.bukkit.entity.LivingEntity;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityRegainHealthEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;
import net.liplugins.liskills.lib.scheduler.TaskHandle;
import net.liplugins.liskills.lib.scheduler.TaskScheduler;
import net.liplugins.liskills.lib.scheduler.ServerThreads;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** 轻盈降落、残血飞奔及PvP饥饿偷取；不干涉原版飞行或客户端。 */
final class AgilityPassiveManager implements Listener,AutoCloseable {
    private final ConfigManager config;
    private final ProfileManager profiles;
    private final PassiveAbilityManager passives;
    private final DeferredPassiveEffects effects;
    private final LiRealEnchantHook enchantments;
    private final NamespacedKey fleetingKey;
    private final Map<UUID,Player> boosted=new java.util.concurrent.ConcurrentHashMap<>();
    private final TaskScheduler scheduler;
    private final net.liplugins.liskills.lib.scheduler.PlayerTasks task;
    AgilityPassiveManager(JavaPlugin plugin,ConfigManager config,ProfileManager profiles,PassiveAbilityManager passives,
                          DeferredPassiveEffects effects,LiRealEnchantHook enchantments) {
        this.config=config;this.profiles=profiles;this.passives=passives;this.effects=effects;this.enchantments=enchantments;
        fleetingKey=new NamespacedKey(plugin,"passive_fleeting");
        scheduler = new TaskScheduler(plugin);
        task=new net.liplugins.liskills.lib.scheduler.PlayerTasks(plugin,this::refresh,1,20);
        Bukkit.getOnlinePlayers().forEach(player->scheduler.entityNow(player,()->TemporaryMovementModifiers.remove(player,fleetingKey)));
    }
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)
    public void onDamage(EntityDamageEvent event) {
        if(!(event.getEntity() instanceof Player player) || !(event.getFinalDamage()>0)
                || SecondaryDamageContext.active() || (enchantments!=null && enchantments.isSecondaryDamage())) return;
        if(event.getCause()==EntityDamageEvent.DamageCause.FALL) {
            thunderFall(player,event);
            event.setDamage(PassiveCombatMath.reduce(event.getDamage(),PassiveCombatMath.percent(passives.value(player,"light_fall"))));
        }
        if(passives.value(player,"fleeting")>0) effects.submit(player.getUniqueId(),()->{if(!event.isCancelled())refresh(player);});
    }
    private void thunderFall(Player player,EntityDamageEvent event) {
        if(!player.isSneaking() || !passives.roll(player,"thunder_fall"))return;
        double damage=Math.min(1024,event.getDamage()*Math.min(1000,passives.secondary(player,"thunder_fall"))/100);
        if(!Double.isFinite(damage) || damage<=0)return;
        PassiveSession session=PassiveSession.capture(player,profiles,config);
        double radius=Math.clamp(passives.option("thunder_fall","radius",3),1,8);
        int limit=(int)Math.clamp(passives.option("thunder_fall","maximum_targets",16),1,32);
        var origin=player.getLocation().clone();
        effects.submit(player.getUniqueId(),()->{
            if(event.isCancelled() || !(event.getFinalDamage()>0) || !session.valid(profiles,config)
                    || !passives.enabled(player,"thunder_fall") || !OwnedCombatArea.owns(origin,radius))return;
            int count=0;
            for(var entity:origin.getWorld().getNearbyEntities(origin,radius,radius,radius)) {
                if(!(entity instanceof LivingEntity target) || !ServerThreads.owns(target) || target.equals(player) || target.isDead() || !target.isValid()
                        || target.isInvulnerable() || target.getLocation().distanceSquared(origin)>radius*radius)continue;
                if(count++>=limit)break;
                // 每个目标仍经过标准Bukkit伤害事件；上下文阻止触发同次武器被动及二次经验。
                SecondaryDamageContext.run(player,()->target.damage(damage,player));
            }
        });
    }
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void onHeal(EntityRegainHealthEvent event) {
        if(event.getEntity() instanceof Player player && boosted.containsKey(player.getUniqueId())) effects.submit(player.getUniqueId(),()->{if(!event.isCancelled())refresh(player);});
    }
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void onMelee(EntityDamageByEntityEvent event) {
        if(SecondaryDamageContext.active() || (enchantments!=null && enchantments.isSecondaryDamage())
                || !(event.getDamager() instanceof Player player) || !(event.getEntity() instanceof Player victim)
                || !ServerThreads.owns(player) || !ServerThreads.owns(victim) || player.equals(victim) || (event.getCause()!=EntityDamageEvent.DamageCause.ENTITY_ATTACK
                && event.getCause()!=EntityDamageEvent.DamageCause.ENTITY_SWEEP_ATTACK) || !passives.roll(player,"meal_steal")) return;
        PassiveSession session=PassiveSession.capture(player,profiles,config);
        effects.submit(player.getUniqueId(),()->{
            if(event.isCancelled() || !(event.getFinalDamage()>0) || !session.valid(profiles,config) || passives.value(player,"meal_steal")<=0
                    || !ServerThreads.owns(victim) || !victim.isOnline() || victim.isDead() || !victim.getWorld().equals(player.getWorld()) || victim.getFoodLevel()<=0) return;
            victim.setFoodLevel(victim.getFoodLevel()-1);
            if(player.getFoodLevel()<20) player.setFoodLevel(player.getFoodLevel()+1);
            else player.setSaturation(Math.min(20,player.getSaturation()+1));
        });
    }
    private void refresh(Player player) {
        AttributeInstance health=player.getAttribute(Attribute.MAX_HEALTH);
        double value=passives.value(player,"fleeting");
        double threshold=Math.clamp(passives.option("fleeting","health_percent_required",20),1,100)/100;
        if(!config.progressionEnabled() || !player.isOnline() || player.isDead() || profiles.get(player.getUniqueId())==null
                || health==null || value<=0 || player.getHealth()>=health.getValue()*threshold) {
            TemporaryMovementModifiers.remove(player,fleetingKey);boosted.remove(player.getUniqueId());return;
        }
        TemporaryMovementModifiers.apply(player,fleetingKey,Math.clamp(value/100,0,3));
        boosted.put(player.getUniqueId(),player);
    }
    @EventHandler(priority=EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent event){remove(event.getPlayer());}
    @EventHandler(priority=EventPriority.MONITOR)
    public void onDeath(PlayerDeathEvent event){remove(event.getEntity());}
    private void remove(Player player){TemporaryMovementModifiers.remove(player,fleetingKey);boosted.remove(player.getUniqueId());}
    @Override public void close(){task.close();scheduler.cancelAll();boosted.values().forEach(player->TemporaryMovementModifiers.remove(player,fleetingKey));boosted.clear();}
}
