package net.liplugins.liskills.internal.manager.reward;

import net.liplugins.liskills.api.SkillLevelUpEvent;
import net.liplugins.liskills.internal.config.RewardsSettings;
import net.liplugins.liskills.internal.hook.VaultEconomyBridge;
import net.liplugins.liskills.internal.manager.ledger.*;
import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.inventory.ItemStack;
import java.io.IOException;
import java.util.*;
import java.util.function.Supplier;

/** 只处理升级奖励；领取高水位先持久化，再提交物品/经济/控制台命令，避免降级刷奖励。 */
public final class LevelRewardManager implements Listener {
    private final Supplier<RewardsSettings> settings;private final VaultEconomyBridge economy;private final TextService text;
    private final PlayerRewardLedger ledger;private final LedgerFailureReporter failures;
    private final RewardCommandDispatcher commands;
    public LevelRewardManager(Supplier<RewardsSettings> settings,VaultEconomyBridge economy,TextService text,
                              PlayerRewardLedger ledger,LedgerFailureReporter failures,RewardCommandDispatcher commands){
        this.settings=settings;this.economy=economy;this.text=text;this.ledger=ledger;this.failures=failures;this.commands=commands;
    }
    @EventHandler(priority=EventPriority.MONITOR)
    public void levelUp(SkillLevelUpEvent event){
        var rules=settings.get();if(!rules.enabled()||(!event.isNatural()&&!rules.adminExperience()))return;
        Player player=event.getPlayer();if(!player.isOnline())return;
        List<PlayerRewardLedger.RewardRequest> requests=new ArrayList<>();Map<String,RewardsSettings.Rule> matching=new LinkedHashMap<>();
        for(var rule:rules.rules()){
            if(!rule.skill().equals("all")&&!rule.skill().equals(event.getSkill()))continue;
            String key=LedgerState.rewardKey(rule.id(),event.getSkill());matching.put(key,rule);
            requests.add(new PlayerRewardLedger.RewardRequest(key,event.getOldLevel(),event.getNewLevel(),rule.start(),rule.interval(),rule.end()));
        }
        if(requests.isEmpty())return;
        PlayerRewardLedger.RewardReservation reserved;
        try{
            long day=Math.floorDiv(System.currentTimeMillis(),86_400_000L);
            reserved=ledger.reserveRewards(player.getUniqueId(),requests,rules.maximumPerEvent(),()->LegacyLedgerData.read(player,day));
            LegacyLedgerData.mirrorRewards(player,reserved.state(),matching.keySet());
        }catch(IOException error){failures.failed(player,error);return;}
        // 所有高水位已经持久化；PDC回滚或playerdata禁存不会让同一等级重新进入这里。
        for(var award:reserved.awards()){var rule=matching.get(award.key());boolean success=economy.deposit(player,rule.money());
            if(rule.material()!=Material.AIR){var item=new ItemStack(rule.material(),rule.amount());player.getInventory().addItem(item).values().forEach(left->player.getWorld().dropItemNaturally(player.getLocation(),left));}
            List<String> rendered=rule.commands().stream().map(command->command.replace("{player}",player.getName()).replace("{uuid}",player.getUniqueId().toString()).replace("{skill}",event.getSkill()).replace("{level}",String.valueOf(award.level()))).toList();
            boolean paid=success;
            commands.dispatch(rendered,completed->text.send(player,paid&&completed?"extended.reward-received":"extended.reward-partial",Map.of("id",rule.id(),"level",award.level())));
        }
    }
}
