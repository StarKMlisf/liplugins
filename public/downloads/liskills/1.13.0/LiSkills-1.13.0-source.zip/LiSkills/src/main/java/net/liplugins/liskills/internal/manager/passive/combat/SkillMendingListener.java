package net.liplugins.liskills.internal.manager.passive.combat;

import net.liplugins.liskills.api.SkillExperienceGainEvent;
import net.liplugins.liskills.internal.manager.PassiveAbilityManager;
import net.liplugins.liskills.internal.manager.source.SourceItemRules;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/** 经验修补只监听已入账的自然技能经验；随机修复一个当前装备槽，不扫描背包或消耗原版经验。 */
final class SkillMendingListener implements Listener {
    private final PassiveAbilityManager passives;
    SkillMendingListener(PassiveAbilityManager passives) { this.passives = passives; }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onExperience(SkillExperienceGainEvent event) {
        var player = event.getPlayer();
        if (!passives.roll(player, "skill_mender")) return;
        int amount = ForgingRepairMath.mendingAmount(event.getAmount(), (int) passives.option("skill_mender", "maximum_repair", 200));
        if (amount <= 0) return;
        var inventory = player.getInventory();
        List<Integer> candidates = new ArrayList<>();
        // 36-39为四件护甲、40为副手；主手只选择当前快捷栏槽。
        for (int slot : new int[]{inventory.getHeldItemSlot(), 36, 37, 38, 39, 40}) {
            ItemStack item = inventory.getItem(slot);
            if (!SourceItemRules.empty(item) && item.containsEnchantment(Enchantment.MENDING)
                    && item.getItemMeta() instanceof Damageable damageable && damageable.hasDamage()
                    && !(passives.flag("skill_mender", "ignore_custom_items", true) && SourceItemRules.custom(item))) candidates.add(slot);
        }
        if (candidates.isEmpty()) return;
        int slot = candidates.get(ThreadLocalRandom.current().nextInt(candidates.size()));
        ItemStack item = inventory.getItem(slot).clone();
        Damageable meta = (Damageable) item.getItemMeta();
        meta.setDamage(Math.max(0, meta.getDamage() - amount)); item.setItemMeta(meta); inventory.setItem(slot, item);
    }
}
