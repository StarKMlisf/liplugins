package net.liplugins.liskills.internal.manager;

import net.liplugins.liskills.api.SkillLevelUpEvent;
import net.liplugins.liskills.api.SkillExperienceGainEvent;
import net.liplugins.liskills.api.SkillExperiencePreGainEvent;
import net.liplugins.liskills.internal.config.*;
import net.liplugins.liskills.internal.storage.*;
import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.Bukkit;
import net.liplugins.liskills.lib.scheduler.ServerThreads;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import java.util.Map;

public final class SkillManager {
    private final ConfigManager config;
    private final ProfileManager profiles;
    private final TextService text;
    private final java.util.Set<String> awarding=java.util.concurrent.ConcurrentHashMap.newKeySet();
    private volatile java.util.function.ToDoubleBiFunction<Player,String> equipmentMultiplier=(player,skill)->1.0;
    public SkillManager(ConfigManager config,ProfileManager profiles,TextService text){this.config=config;this.profiles=profiles;this.text=text;}
    public ConfigManager config(){return config;}
    public void equipmentMultiplier(java.util.function.ToDoubleBiFunction<Player,String> provider){equipmentMultiplier=java.util.Objects.requireNonNull(provider);}
    public boolean eligible(Player player){
        Settings settings=config.settings();
        return ServerThreads.owns(player) && player.hasPermission("liskills.use") && !settings.disabledWorlds().contains(player.getWorld().getName())
                && (!settings.survivalOnly() || player.getGameMode()==GameMode.SURVIVAL || player.getGameMode()==GameMode.ADVENTURE);
    }
    public boolean award(Player player,String id,double amount){
        if(!ServerThreads.owns(player) || !eligible(player) || !player.hasPermission("liskills.skill."+id))return false;
        double multiplier=equipmentMultiplier.applyAsDouble(player,id);
        if(!Double.isFinite(multiplier)||multiplier<0||multiplier>10)return false;
        double scaled=amount*config.settings().xpMultiplier()*PassiveExperience.multiplier(config,profiles.get(player.getUniqueId()),id)*multiplier;
        if(!Double.isFinite(amount) || amount<0)return false;
        if(!validAmount(scaled))return false;
        String key=player.getUniqueId()+":"+id;
        if(!awarding.add(key))return false;
        try{
            SkillExperiencePreGainEvent event=new SkillExperiencePreGainEvent(player,id,scaled);
            Bukkit.getPluginManager().callEvent(event);
            return !event.isCancelled() && applyExperience(player,id,event.getAmount(),true);
        }finally{awarding.remove(key);}
    }
    public boolean addExperience(Player player,String id,double amount){
        return applyExperience(player,id,amount,false);
    }
    private boolean applyExperience(Player player,String id,double amount,boolean natural){
        if(!ServerThreads.owns(player))return false;
        SkillDefinition skill=config.skill(id);PlayerProfile profile=profiles.get(player.getUniqueId());
        if(skill==null || !skill.enabled() || profile==null || !validAmount(amount))return false;
        SkillProgress old=profile.progress(id), next;
        try{next=Progression.add(skill,old,amount);}catch(IllegalArgumentException ex){return false;}
        profile.progress(id,next);
        if(next.level()>old.level()){
            text.send(player,"progress.level-up",Map.of("skill",text.plain(skill.name()),"level",next.level(),"previous",old.level()));
            Bukkit.getPluginManager().callEvent(new SkillLevelUpEvent(player,id,old.level(),next.level(),natural));
        }
        double gained=natural?Progression.gained(skill,old,next,amount):0;
        if(gained>0)Bukkit.getPluginManager().callEvent(new SkillExperienceGainEvent(player,id,gained));
        return true;
    }
    /** set 设置本级经验；不执行升级，避免把经验总量与本级余额混淆。 */
    public boolean setExperience(Player player,String id,double amount){
        if(!ServerThreads.owns(player))return false;
        SkillDefinition skill=config.skill(id);PlayerProfile profile=profiles.get(player.getUniqueId());
        if(skill==null || !skill.enabled() || profile==null || !validAmount(amount))return false;
        int level=profile.progress(id).level();
        if((level>=skill.maxLevel() && amount!=0) || amount>=skill.requiredXp(level))return false;
        profile.progress(id,new SkillProgress(level,amount));return true;
    }
    public boolean setLevel(Player player,String id,int level){
        if(!ServerThreads.owns(player))return false;
        SkillDefinition skill=config.skill(id);PlayerProfile profile=profiles.get(player.getUniqueId());
        if(skill==null || !skill.enabled() || profile==null || level<1 || level>skill.maxLevel())return false;
        profile.progress(id,new SkillProgress(level,0));return true;
    }
    private boolean validAmount(double amount){return Double.isFinite(amount) && amount>=0 && amount<=config.settings().maxAward();}
    public SkillProgress progress(java.util.UUID uuid,String id){PlayerProfile profile=profiles.get(uuid);return profile==null?null:profile.progress(id);}
}
