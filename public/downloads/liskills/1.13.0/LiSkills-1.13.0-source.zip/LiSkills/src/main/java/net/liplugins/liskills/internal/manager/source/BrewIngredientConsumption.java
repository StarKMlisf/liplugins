package net.liplugins.liskills.internal.manager.source;

/** 完成酿造必须观察到原料减少；同tick自动补回导致无法证明时只跳过经验，不干预酿造。 */
final class BrewIngredientConsumption {
    private BrewIngredientConsumption() { }
    static boolean consumed(int before,int remaining,boolean sameIngredient) {
        return before>0 && (!sameIngredient || remaining<before);
    }
}
