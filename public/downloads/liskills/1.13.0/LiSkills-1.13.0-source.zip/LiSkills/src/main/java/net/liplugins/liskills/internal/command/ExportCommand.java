package net.liplugins.liskills.internal.command;

import net.liplugins.liskills.internal.manager.storage.ProfileExportManager;
import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;
import java.util.Map;

/** 导出指令异步写入，反馈切回Bukkit主线程；不接收任意文件路径。 */
final class ExportCommand implements Subcommand {
    private final JavaPlugin plugin;private final ProfileExportManager exports;private final SenderChecks checks;private final TextService text;
    ExportCommand(JavaPlugin plugin,ProfileExportManager exports,SenderChecks checks,TextService text){this.plugin=plugin;this.exports=exports;this.checks=checks;this.text=text;}
    public String name(){return "export";}public String permission(){return "liskills.admin";}
    public void execute(CommandSender sender,String[] args){
        if(args.length!=0){checks.usage(sender,"extended.usage-export");return;}text.send(sender,"extended.export-started");
        exports.export().whenComplete((result,error)->{if(plugin.isEnabled()){
            if(error==null)text.send(sender,"extended.export-complete",Map.of("path",result.directory().toString(),"count",result.profiles()));
            else text.send(sender,"extended.export-failed");
        }});
    }
}
