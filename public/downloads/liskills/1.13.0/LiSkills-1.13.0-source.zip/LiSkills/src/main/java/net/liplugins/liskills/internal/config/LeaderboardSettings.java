package net.liplugins.liskills.internal.config;
import org.bukkit.configuration.ConfigurationSection;

/** 排行榜刷新与显示预算；离线数据只在存储线程读取。 */
public record LeaderboardSettings(boolean enabled,int refreshSeconds,int pageSize,int maximumEntries) {
    public static LeaderboardSettings parse(ConfigurationSection root){return new LeaderboardSettings(ConfigValues.bool(root,"enabled"),ConfigValues.integer(root,"refresh-seconds",30,3600),ConfigValues.integer(root,"page-size",1,20),ConfigValues.integer(root,"maximum-entries",10,10000));}
}
