package net.liplugins.liskills.internal.manager.passive.combat;

import net.liplugins.liskills.api.SkillExperienceGainEvent;
import net.liplugins.liskills.internal.manager.PassiveAbilityManager;
import org.bukkit.NamespacedKey;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/** 只监听自然技能经验已入账通知；管理员经验操作不会触发，余量随玩家原生PDC保存。 */
final class ExperienceConversionListener implements Listener {
    private final PassiveAbilityManager passives;
    private final NamespacedKey remainderKey;
    private final Set<UUID> awarding=java.util.concurrent.ConcurrentHashMap.newKeySet();
    ExperienceConversionListener(JavaPlugin plugin,PassiveAbilityManager passives){this.passives=passives;remainderKey=new NamespacedKey(plugin,"xp_convert_remainder");}
    @EventHandler(priority=EventPriority.MONITOR)
    public void onExperience(SkillExperienceGainEvent event) {
        var player=event.getPlayer();
        if(awarding.contains(player.getUniqueId()) || passives.level(player,"xp_convert")<=0) return;
        double threshold=passives.value(player,"xp_convert");
        if(threshold<.01) return;
        var data=player.getPersistentDataContainer();
        XpConversion.Result result=XpConversion.convert(data.getOrDefault(remainderKey,PersistentDataType.DOUBLE,0.0),event.getAmount(),threshold);
        data.set(remainderKey,PersistentDataType.DOUBLE,result.remainder());
        if(result.experience()<=0) return;
        awarding.add(player.getUniqueId());
        try{player.giveExp(result.experience());}
        finally{awarding.remove(player.getUniqueId());}
    }
}
