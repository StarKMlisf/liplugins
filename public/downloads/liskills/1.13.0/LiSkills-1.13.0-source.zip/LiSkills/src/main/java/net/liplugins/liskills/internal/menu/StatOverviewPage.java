package net.liplugins.liskills.internal.menu;

import net.liplugins.liskills.internal.config.*;
import net.liplugins.liskills.internal.manager.stat.StatManager;
import net.liplugins.liskills.internal.storage.PlayerProfile;
import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.inventory.Inventory;
import java.util.Map;

/** 展示九项成长属性；动态装备/药水修正来自与魔力一致的属性快照。 */
final class StatOverviewPage {
    private static final Material[] ICONS={Material.IRON_SWORD,Material.APPLE,Material.GHAST_TEAR,Material.EMERALD,
            Material.ENCHANTED_BOOK,Material.IRON_CHESTPLATE,Material.BOW,Material.DIAMOND_SWORD,Material.FEATHER};
    private final ConfigManager config;
    private final TextService text;
    private final MenuItems items;
    StatOverviewPage(ConfigManager config,TextService text){this.config=config;this.text=text;this.items=new MenuItems(text);}
    Inventory create(PlayerProfile profile) {
        RpgMenuLayout layout=RpgMenuLayout.parse(config.menu(),"stats",9);
        SkillMenuHolder holder=new SkillMenuHolder(profile.uuid(),SkillMenuHolder.Screen.STATS,null,0,config.revision(),
                Map.of(layout.back(),new MenuAction(MenuAction.Type.BACK,null,0)),-1);
        Inventory inventory=Bukkit.createInventory(holder,layout.size(),text.text("rpg.stats-title",Map.of("player",profile.name())));
        holder.inventory(inventory);
        if(config.menu().getBoolean("fill"))for(int i=0;i<layout.size();i++)inventory.setItem(i,items.item(new MenuMaterials(config).get("filler-material",Material.GRAY_STAINED_GLASS_PANE),"menu.filler-name",null,Map.of()));
        inventory.setItem(layout.back(),items.item(Material.ARROW,"menu.details.back-name","menu.details.back-lore",Map.of()));
        refresh(inventory,holder,profile);return inventory;
    }
    void refresh(Inventory inventory,SkillMenuHolder holder,PlayerProfile profile) {
        RpgMenuLayout layout=RpgMenuLayout.parse(config.menu(),"stats",9);
        Map<String,Double> values=StatManager.snapshotValues(profile,config);
        for(int index=0;index<StatsSettings.IDS.size();index++) {
            String id=StatsSettings.IDS.get(index);StatDefinition stat=config.stats().definitions().get(id);
            Map<String,Object> replacements=Map.of("name",text.plain(stat.name()),"value",text.format(values.getOrDefault(id,0d)),"id",id);
            var item=items.item(ICONS[index],"rpg.stat-name","rpg.stat-lore",replacements);
            RpgMenuItems.append(item,text.lines("rpg.stat-guide."+id,replacements));
            inventory.setItem(layout.slots().get(index),item);
        }
        inventory.setItem(layout.summary(),items.item(Material.PLAYER_HEAD,"rpg.stats-summary-name","rpg.stats-summary-lore",Map.of("player",profile.name(),
                "state",text.plain(text.text(config.progressionEnabled()?"rpg.unlocked":"rpg.disabled")))));
    }
}
