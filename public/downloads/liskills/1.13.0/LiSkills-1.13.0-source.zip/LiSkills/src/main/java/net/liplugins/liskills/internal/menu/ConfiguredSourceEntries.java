package net.liplugins.liskills.internal.menu;

import net.liplugins.liskills.internal.config.*;
import net.liplugins.liskills.internal.manager.source.FishingSourceRules;
import org.bukkit.Material;
import java.util.*;

/** 纯配置来源目录，只描述实际业务入口消费的配置，不读取玩家或服务器注册表。 */
final class ConfiguredSourceEntries {
    private static final Set<Material> COLUMNS=Set.of(Material.BAMBOO,Material.SUGAR_CANE,Material.CACTUS,Material.KELP,Material.KELP_PLANT);
    private ConfiguredSourceEntries() { }
    static List<SourceSpec> materials(SkillDefinition skill,NaturalSourcesSettings settings) {
        if(!skill.enabled())return List.of();
        List<SourceSpec> result=new ArrayList<>();
        skill.blocks().entrySet().stream().filter(entry->entry.getValue()>0).sorted(Map.Entry.comparingByKey()).forEach(entry->{
            Material material=entry.getKey();boolean fishing=skill.id().equals("fishing");
            String unit=fishing?"catch":"block",condition=fishing?"fish-material":"block";
            Map<String,Object> values=Map.of();
            if(!fishing && COLUMNS.contains(material) && settings.verticalPlantsEnabled()) {
                condition="column";values=Map.of("maximum_blocks",material==Material.SUGAR_CANE?Math.min(3,settings.maximumPlantBlocks()):settings.maximumPlantBlocks());
            } else if(!fishing && material==Material.SWEET_BERRY_BUSH && settings.berryStateMultiplier()) { unit="berry-stage";condition="berry"; }
            else if(!fishing && material==Material.SEA_PICKLE && settings.pickleStateMultiplier()) { unit="pickle";condition="pickle"; }
            else if(skill.id().equals("farming"))condition="farming";
            result.add(new SourceSpec(material.name(),"materials",material.name(),fishing?"item":"block",entry.getValue(),material,unit,condition,values));
        });
        return List.copyOf(result);
    }
    static List<SourceSpec> legacyEvents(SkillDefinition skill,int damageCooldown) {
        if(!skill.enabled() || skill.eventXp()<=0)return List.of();
        String type=switch(skill.id()) { case "fishing"->"fishing.other";case "agility"->"agility.fall";case "defense"->"defense.hit";default->null; };
        if(type==null)return List.of();
        return List.of(new SourceSpec(type,"events",skill.id(),"event",skill.eventXp(),Material.EXPERIENCE_BOTTLE,"event",skill.id().equals("fishing")?"fish-fallback":"damage",Map.of("cooldown",damageCooldown)));
    }
    static List<SourceSpec> agility(AgilitySourceSettings settings) {
        if(!settings.enabled())return List.of();List<SourceSpec> result=new ArrayList<>();
        for(String id:List.of("walk","sprint","swim","jump")) {
            double xp=settings.experience().getOrDefault(id,0.0);if(xp<=0)continue;
            result.add(source("agility."+id,"statistic",xp,switch(id){case "swim"->Material.WATER_BUCKET;case "jump"->Material.FEATHER;default->Material.LEATHER_BOOTS;},
                    id.equals("jump")?"jumps":"meter","movement",Map.of("jumps",settings.jumpsPerAward(),"threshold",settings.thresholdMeters(),"activity",settings.activitySeconds(),"cells",settings.minimumCells(),"repeat",settings.repeatSeconds())));
        }
        return List.copyOf(result);
    }
    static List<SourceSpec> fishing(SkillDefinition skill,NaturalSourcesSettings settings) {
        if(!skill.enabled() || !settings.fishingCategoriesEnabled())return List.of();List<SourceSpec> result=new ArrayList<>();
        for(String category:List.of("treasure","junk")) {
            boolean reachable=Arrays.stream(Material.values()).anyMatch(material->!skill.blocks().containsKey(material)
                    && (category.equals(FishingSourceRules.category(material,false)) || category.equals(FishingSourceRules.category(material,true))));
            double xp=settings.fishingXp(category);
            if(reachable && xp>0)result.add(source("fishing."+category,"category",xp,category.equals("treasure")?Material.NAME_TAG:Material.BOWL,"catch","fish-category",Map.of()));
        }
        return List.copyOf(result);
    }
    static List<SourceSpec> loot(SkillDefinition skill,NaturalSourcesSettings natural,LootSettings loot,Map<String,PassiveDefinition> passives,boolean progression) {
        if(!progression || !skill.enabled() || !Set.of("fishing","excavation").contains(skill.id()))return List.of();
        List<SourceSpec> result=new ArrayList<>();
        for(var pool:loot.pools(skill.id())) {
            String ability=skill.id().equals("fishing")?(pool.id().equals("rare")?"treasure_hunter":"epic_catch"):(pool.id().equals("rare")?"metal_detector":"lucky_spades");
            var passive=passives.get(ability);
            if(!pool.enabled() || pool.entries().isEmpty() || passive==null || !passive.enabled() || passive.unlockLevel()>skill.maxLevel())continue;
            Map<String,Object> values=Map.of("ability",passive.name(),"unlock",passive.unlockLevel());
            String condition=pool.requireOpenWater()?"loot-open-water":"loot";
            if(skill.id().equals("fishing") && natural.fishingCategoriesEnabled() && natural.fishingXp(pool.id())>0)
                result.add(source("fishing."+pool.id(),"loot",natural.fishingXp(pool.id()),pool.id().equals("epic")?Material.NETHER_STAR:Material.DIAMOND,"catch",condition,values));
            int index=0;
            for(var entry:pool.entries()) {
                index++;if(entry.experience()<=0)continue;
                Map<String,Object> entryValues=new LinkedHashMap<>(values);entryValues.put("item",entry.material().name());entryValues.put("pool",pool.id());
                entryValues.put("amount_min",entry.minimumAmount());entryValues.put("amount_max",entry.maximumAmount());
                result.add(new SourceSpec("loot."+pool.id()+"."+index,"","loot.extra","loot",entry.experience(),entry.material(),"treasure-entry","loot-extra",entryValues));
            }
        }
        return List.copyOf(result);
    }
    static List<SourceSpec> alchemy(AlchemySourceSettings settings) {
        if(!settings.enabled())return List.of();List<SourceSpec> result=new ArrayList<>();
        for(String key:AlchemySourceSettings.SOURCES) {
            double xp=settings.xp(key);if(xp<=0)continue;String group=key.substring(0,key.indexOf('.'));
            Material icon=switch(group){case "brew"->Material.BREWING_STAND;case "splash"->Material.SPLASH_POTION;case "lingering"->Material.LINGERING_POTION;default->key.endsWith("enchanted-golden-apple")?Material.ENCHANTED_GOLDEN_APPLE:key.endsWith("golden-apple")?Material.GOLDEN_APPLE:Material.POTION;};
            result.add(source("alchemy."+key,"alchemy",xp,icon,group.equals("brew")?"brew-step":group.equals("lingering")?"cloud":"use","alchemy-"+group,
                    Map.of("maximum_steps",settings.maximumBrewingSteps(),"cooldown",(group.equals("drink")?settings.consumeCooldownTicks():settings.splashCooldownTicks())/20.0,"maximum",settings.maximumXpPerMinute(),"source_multiplier",settings.experienceMultiplier())));
        }
        return List.copyOf(result);
    }
    static List<SourceSpec> enchanting(EnchantingSourceSettings settings) {
        if(!settings.enabled())return List.of();List<SourceSpec> result=new ArrayList<>();
        for(String key:EnchantingSourceSettings.SOURCES) {
            double xp=settings.xp(key);if(xp<=0)continue;String group=key.contains(".")?key.substring(0,key.indexOf('.')):key;
            result.add(source("enchanting."+key,"enchanting",xp,group.equals("table")?Material.ENCHANTING_TABLE:group.equals("anvil")?Material.ANVIL:Material.GRINDSTONE,
                    group.equals("table")?"enchant-level":group.equals("anvil")?"paid-level":"removed-level","enchanting-"+group,
                    Map.of("maximum_levels",settings.maximumLevelsPerAction(),"cooldown",settings.actionCooldownTicks()/20.0,"maximum",settings.maximumXpPerMinute(),"source_multiplier",settings.experienceMultiplier())));
        }
        return List.copyOf(result);
    }
    /** 同一来源只展示在实际接收经验的职业中，管理员切换归属后即时反映。 */
    static List<SourceSpec> routed(String skill, SourceSkillRoutingSettings routing, AgilitySourceSettings movement,
                                   AlchemySourceSettings potions, EnchantingSourceSettings crafting) {
        List<SourceSpec> result = new ArrayList<>();
        agility(movement).stream().filter(entry -> skill.equals(entry.id().equals("agility.jump")
                ? routing.jumpSkill() : routing.movementSkill())).forEach(result::add);
        alchemy(potions).stream().filter(entry -> skill.equals(entry.id().startsWith("alchemy.brew.") ? "alchemy"
                : entry.id().startsWith("alchemy.drink.") ? routing.consumptionSkill() : routing.potionThrowSkill())).forEach(result::add);
        enchanting(crafting).stream().filter(entry -> skill.equals(entry.id().startsWith("enchanting.table") ? "enchanting"
                : entry.id().startsWith("enchanting.anvil") ? routing.anvilSkill() : routing.grindstoneSkill())).forEach(result::add);
        return List.copyOf(result);
    }
    static List<SourceSpec> sorcery(SorcerySourceSettings settings) {
        if (!settings.enabled() || settings.manaXpPerPoint() <= 0 || settings.maximumXpPerMinute() <= 0) return List.of();
        return List.of(source("sorcery.mana-ability-use", "event", settings.manaXpPerPoint(), Material.LIGHT_BLUE_DYE,
                "mana", "mana-use", Map.of("maximum", settings.maximumXpPerMinute())));
    }
    private static SourceSpec source(String id,String kind,double xp,Material icon,String unit,String condition,Map<String,Object> values) {
        return new SourceSpec(id,"",id,kind,xp,icon,unit,condition,values);
    }
}
