package net.liplugins.liskills.internal.manager.ledger;

import net.liplugins.liskills.internal.storage.StorageFileLock;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.*;
import java.util.UUID;

/** 只负责账本文件读写：临时文件force后原子替换；不支持原子移动的文件系统拒绝付款。 */
final class LedgerFileStore implements AutoCloseable {
    private final Path directory;private StorageFileLock lock;private boolean closed;
    LedgerFileStore(Path directory){this.directory=directory.toAbsolutePath().normalize();}
    Path path(UUID uuid){return directory.resolve(uuid+".ledger");}
    private Path temporary(UUID uuid){return directory.resolve(uuid+".ledger.tmp");}
    private void open()throws IOException {
        if(closed)throw new IOException("ledger-closed");
        if(lock==null){
            if(Files.isSymbolicLink(directory))throw new IOException("ledger-directory-is-symbolic-link");
            lock=StorageFileLock.acquire(directory.resolve(".ledger.lock"));
        }
    }
    LedgerState read(UUID uuid)throws IOException {
        open();
        // 任何中断临时文件都需管理员核对；不能把半次写入当新玩家重新种入PDC。
        if(Files.exists(temporary(uuid),LinkOption.NOFOLLOW_LINKS))throw new IOException("ledger-interrupted-write");
        Path file=path(uuid);
        if(Files.notExists(file,LinkOption.NOFOLLOW_LINKS))return null;
        if(!Files.isRegularFile(file,LinkOption.NOFOLLOW_LINKS) || Files.size(file)>LedgerCodec.MAX_BYTES)throw new IOException("invalid-ledger-file");
        try(var in=Files.newInputStream(file)){
            byte[] bytes=in.readNBytes(LedgerCodec.MAX_BYTES+1);return LedgerCodec.decode(uuid,bytes);
        }
    }
    void write(UUID uuid,LedgerState state)throws IOException {
        open();Path target=path(uuid),temp=temporary(uuid);
        if(Files.exists(target,LinkOption.NOFOLLOW_LINKS) && !Files.isRegularFile(target,LinkOption.NOFOLLOW_LINKS))throw new IOException("invalid-ledger-target");
        byte[] encoded=LedgerCodec.encode(uuid,state);
        // CREATE_NEW防止覆盖遗留临时记录。失败时保留现场，不删除或回退到非原子写入。
        try(var channel=FileChannel.open(temp,StandardOpenOption.CREATE_NEW,StandardOpenOption.WRITE)) {
            ByteBuffer buffer=ByteBuffer.wrap(encoded);while(buffer.hasRemaining())channel.write(buffer);channel.force(true);
        }
        Files.move(temp,target,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);
    }
    @Override public void close()throws IOException{closed=true;if(lock!=null){lock.close();lock=null;}}
}
