package net.liplugins.liskills.internal.manager.source;

import net.liplugins.liskills.internal.config.AlchemySourceSettings;
import net.liplugins.liskills.internal.config.SourceSkillRoutingSettings;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import java.util.function.Supplier;

/** 饮用药水和食用两种金苹果：完成消耗、最终未取消才奖励，重复注入同次消费不结算。 */
final class AlchemyConsumeSourceListener implements Listener {
    private final SourceExperienceService rewards;private final Supplier<AlchemySourceSettings> settings;
    private final Supplier<SourceSkillRoutingSettings> routing;
    private final Set<UUID> pending=java.util.concurrent.ConcurrentHashMap.newKeySet();
    AlchemyConsumeSourceListener(SourceExperienceService rewards,Supplier<AlchemySourceSettings> settings,Supplier<SourceSkillRoutingSettings> routing){this.rewards=rewards;this.settings=settings;this.routing=routing;}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void onConsume(PlayerItemConsumeEvent event) {
        var policy=settings.get();var player=event.getPlayer();var session=rewards.capture(player,routing.get().consumptionSkill());
        ItemStack item=SourceItemRules.copy(event.getItem());
        if(!policy.enabled() || session==null || SourceItemRules.empty(item) || (policy.ignoreCustomItems() && SourceItemRules.custom(item)))return;
        String source=switch(item.getType()) {
            case GOLDEN_APPLE->"drink.golden-apple";case ENCHANTED_GOLDEN_APPLE->"drink.enchanted-golden-apple";
            case POTION->{String kind=SourceItemRules.potionKind(item);yield kind==null?null:"drink."+kind;}
            default->null;
        };
        ItemStack held=event.getHand()==EquipmentSlot.OFF_HAND?player.getInventory().getItemInOffHand():player.getInventory().getItemInMainHand();
        UUID playerId=player.getUniqueId();
        if(source==null || !held.isSimilar(item) || !pending.add(playerId))return;
        int before=SourceItemRules.count(player,item);
        if(!rewards.defer(player, ()->{
            pending.remove(playerId);
            if(event.isCancelled() || !rewards.valid(session) || !settings.get().enabled() || !event.getItem().isSimilar(item)
                    || SourceItemRules.count(player,item)>=before)return;
            rewards.award(session,"drink",policy.xp(source),policy.consumeCooldownTicks(),policy.maximumXpPerMinute());
        },()->pending.remove(playerId)))pending.remove(playerId);
    }
}
