package net.liplugins.liskills.internal.hook.customfishing;

/** 只缩短第三方已经计算好的正等待倍率；不改它的最短时间、加数或其他效果。 */
final class CustomFishingEffectRules {
    private CustomFishingEffectRules() { }
    static double adjusted(double existing, double skillMultiplier) {
        if (!Double.isFinite(existing) || existing < 0 || !Double.isFinite(skillMultiplier)
                || skillMultiplier <= 0 || skillMultiplier > 1) return existing;
        return existing * skillMultiplier;
    }
}
