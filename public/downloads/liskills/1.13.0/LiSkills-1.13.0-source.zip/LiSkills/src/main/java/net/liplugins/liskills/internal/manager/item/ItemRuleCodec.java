package net.liplugins.liskills.internal.manager.item;

import net.liplugins.liskills.internal.config.ItemRule;
import net.liplugins.liskills.internal.config.ItemSettings;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.configuration.file.YamlConfiguration;
import java.util.List;
import java.util.Set;

/** 只序列化本插件命名规则；沿用配置校验，标签中的数值不能绕过配置边界。 */
public final class ItemRuleCodec {
    public static final int MAXIMUM_RULES = 32;
    public static final int MAXIMUM_LENGTH = 65_536;

    public List<ItemRule> decode(String encoded) {
        if (encoded == null || encoded.length() > MAXIMUM_LENGTH) throw new IllegalArgumentException("item-data-size");
        YamlConfiguration yaml = new YamlConfiguration();
        try { yaml.loadFromString(encoded); }
        catch (InvalidConfigurationException error) { throw new IllegalArgumentException("item-data-yaml", error); }
        if (!yaml.getKeys(false).equals(Set.of("schema", "rules")) || !Integer.valueOf(1).equals(yaml.get("schema")))
            throw new IllegalArgumentException("item-data-schema");
        ConfigurationSection rules = yaml.getConfigurationSection("rules");
        if (rules == null || rules.getKeys(false).size() > MAXIMUM_RULES) throw new IllegalArgumentException("item-data-rules");
        for (String id : rules.getKeys(false)) {
            ConfigurationSection rule = rules.getConfigurationSection(id);
            if (rule == null || rule.contains("match")) throw new IllegalArgumentException("item-data-match");
            // PDC上的规则直接绑定此物品，不允许把配置匹配条件混入持久标签。
            rule.set("match.materials", List.of());
            rule.set("match.pdc-key", "liskills:item_rules");
            rule.set("match.pdc-value", "owned");
        }
        yaml.set("schema", null); yaml.set("enabled", true); yaml.set("message-cooldown-millis", 0);
        return ItemSettings.parse(yaml).rules();
    }

    public String encode(List<ItemRule> rules) {
        if (rules.size() > MAXIMUM_RULES || rules.stream().map(ItemRule::id).distinct().count() != rules.size())
            throw new IllegalArgumentException("item-data-rules");
        YamlConfiguration yaml = new YamlConfiguration();
        yaml.set("schema", 1);
        ConfigurationSection target = yaml.createSection("rules");
        for (ItemRule rule : rules) {
            ConfigurationSection entry = target.createSection(rule.id());
            entry.set("name", rule.name()); entry.set("enabled", rule.enabled());
            entry.set("slots", rule.slots().stream().map(Enum::name).sorted().toList());
            entry.set("uses", rule.uses().stream().map(Enum::name).sorted().toList());
            entry.createSection("attributes", rule.attributes()); entry.createSection("requirements", rule.requirements());
            entry.createSection("stat-multipliers", rule.statMultipliers());
            entry.createSection("stat-percent-additions", rule.statPercentAdditions());
            entry.createSection("skill-xp-multipliers", rule.skillXpMultipliers());
            ConfigurationSection traits = entry.createSection("traits");
            rule.traits().forEach((id, value) -> {
                ConfigurationSection modifier = traits.createSection(id);
                modifier.set("add", value.add()); modifier.set("multiply", value.multiply()); modifier.set("add-percent", value.addPercent());
            });
        }
        String encoded = yaml.saveToString();
        decode(encoded); // 同一条严格读取路径验证，避免管理API生成运行时无法读取的物品。
        return encoded;
    }
}
