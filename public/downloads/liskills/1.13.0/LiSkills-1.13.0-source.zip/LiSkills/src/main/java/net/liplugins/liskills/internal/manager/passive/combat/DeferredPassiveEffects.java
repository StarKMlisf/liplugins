package net.liplugins.liskills.internal.manager.passive.combat;

import net.liplugins.liskills.lib.scheduler.ServerThreads;
import net.liplugins.liskills.lib.scheduler.TaskScheduler;
import org.bukkit.Bukkit;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/** 有界副作用队列只在玩家的下一实体 tick 读取最终事件状态；退出前也能领取尚未执行的事务。 */
final class DeferredPassiveEffects implements Listener, AutoCloseable {
    private static final int LIMIT = 4096;
    private final Set<Entry> pending = ConcurrentHashMap.newKeySet();
    private final AtomicInteger inFlight = new AtomicInteger();
    private final TaskScheduler scheduler;
    private volatile boolean closed;

    DeferredPassiveEffects(JavaPlugin plugin) { scheduler = new TaskScheduler(plugin); }

    boolean submit(UUID owner, Runnable action) {
        if (closed) return false;
        if (inFlight.incrementAndGet() > LIMIT) { inFlight.decrementAndGet(); return false; }
        Entry entry = new Entry(owner, action);
        pending.add(entry);
        var player = Bukkit.getPlayer(owner);
        if (closed || player == null) { complete(entry, false); return false; }
        try {
            scheduler.entity(player, () -> complete(entry, !closed), () -> complete(entry, false));
            return true;
        } catch (RuntimeException | Error error) {
            complete(entry, false);
            throw error;
        }
    }

    private void complete(Entry entry, boolean execute) {
        // 退服、退休和正常实体回调竞争同一条记录，只有成功领取者可以结算一次。
        if (!pending.remove(entry)) return;
        try { if (execute) entry.action.run(); }
        finally { inFlight.decrementAndGet(); }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onQuit(PlayerQuitEvent event) {
        UUID owner = event.getPlayer().getUniqueId();
        pending.forEach(entry -> { if (entry.owner.equals(owner)) complete(entry, true); });
    }

    @Override public void close() {
        closed = true;
        try {
            pending.forEach(entry -> {
                var player = Bukkit.getPlayer(entry.owner);
                complete(entry, player != null && ServerThreads.owns(player));
            });
        } finally { scheduler.cancelAll(); }
    }

    /** 使用对象身份，两个相同回调仍是独立事件，不能因 record 值相等而合并。 */
    private static final class Entry {
        private final UUID owner;
        private final Runnable action;
        private Entry(UUID owner, Runnable action) { this.owner = owner; this.action = action; }
    }
}