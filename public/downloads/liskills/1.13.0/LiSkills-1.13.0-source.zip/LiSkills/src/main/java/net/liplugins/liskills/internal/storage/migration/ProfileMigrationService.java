package net.liplugins.liskills.internal.storage.migration;

import net.liplugins.liskills.internal.storage.ProfileRepository;
import net.liplugins.liskills.internal.storage.ProfileSnapshot;
import java.io.IOException;
import java.util.List;

/** 调用者须持有源/目标独占锁；全程串行，只调用源读取和目标不可覆盖插入。 */
public final class ProfileMigrationService {
    public record Result(int sourceProfiles,int copied,int skipped,int targetProfiles){ }
    public Result migrate(ProfileRepository source,ProfileRepository target)throws Exception{
        return migrate(source.loadAll(),target);
    }
    public Result migrate(List<ProfileSnapshot> source,ProfileRepository target)throws Exception{
        ProfileMigrationPlan plan=ProfileMigrationPlan.prepare(source,target.loadAll());
        int copied=0,skipped=plan.identical();
        for(var snapshot:plan.create()){
            if(target.insertIfAbsent(snapshot))copied++;else skipped++;
        }
        // 最后重新读取持久数据校验整个并集，额外原目标档案也不能被修改或遗漏。
        if(!ProfileMigrationPlan.index(target.loadAll()).equals(plan.expected()))throw new IOException("migration-final-verification-failed");
        return new Result(plan.sourceCount(),copied,skipped,plan.expected().size());
    }
}
