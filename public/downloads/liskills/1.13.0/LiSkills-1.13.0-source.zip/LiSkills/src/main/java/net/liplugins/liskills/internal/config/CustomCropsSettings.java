package net.liplugins.liskills.internal.config;

import java.util.Map;

/** 成熟自定义作物每次确认收获的基础经验，关闭奖励不关闭归属保护。 */
public record CustomCropsSettings(boolean enabled, double defaultXp, Map<String, Double> cropXp) {
    public CustomCropsSettings { cropXp = Map.copyOf(cropXp); }
    public double xp(String id) { return id == null || id.isBlank() ? 0 : cropXp.getOrDefault(id, defaultXp); }
}
