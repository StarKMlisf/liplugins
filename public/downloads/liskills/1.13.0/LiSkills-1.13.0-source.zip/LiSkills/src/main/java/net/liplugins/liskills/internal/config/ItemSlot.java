package net.liplugins.liskills.internal.config;

import org.bukkit.inventory.EquipmentSlot;

/** 玩家物品规则只使用六个标准装备位，不把普通背包格当作已装备。 */
public enum ItemSlot {
    MAIN_HAND(EquipmentSlot.HAND), OFF_HAND(EquipmentSlot.OFF_HAND),
    HEAD(EquipmentSlot.HEAD), CHEST(EquipmentSlot.CHEST), LEGS(EquipmentSlot.LEGS), FEET(EquipmentSlot.FEET);

    private final EquipmentSlot equipmentSlot;
    ItemSlot(EquipmentSlot equipmentSlot) { this.equipmentSlot = equipmentSlot; }
    public EquipmentSlot equipmentSlot() { return equipmentSlot; }
    public boolean armor() { return this != MAIN_HAND && this != OFF_HAND; }
    public static ItemSlot from(EquipmentSlot slot) {
        if (slot == null) return null;
        for (ItemSlot value : values()) if (value.equipmentSlot == slot) return value;
        return null;
    }
}
