package net.liplugins.liskills.lib.scheduler;

import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;

import java.lang.reflect.Method;
import java.util.Objects;

/** Folia瞬时成长不写入NBT；普通Bukkit保持原有持久修饰符及显式卸载清理流程。 */
public final class AttributeModifiers {
    private AttributeModifiers() { }
    private static final class Access {
        static final Method TRANSIENT = SchedulerReflection.optional(AttributeInstance.class, "addTransientModifier", AttributeModifier.class);
    }
    public static void add(AttributeInstance instance, AttributeModifier modifier) {
        add(instance, modifier, ServerThreads.folia(), Access.TRANSIENT);
    }
    static void add(AttributeInstance instance, AttributeModifier modifier, boolean folia, Method transientMethod) {
        Objects.requireNonNull(instance); Objects.requireNonNull(modifier);
        if (!folia) { instance.addModifier(modifier); return; }
        // 缺少不持久化API时必须拒绝，不可悄悄回落到关服后可能残留的普通修饰符。
        if (transientMethod == null) throw new IllegalStateException("当前Folia服务端缺少addTransientModifier，无法安全应用技能属性");
        SchedulerReflection.invoke(transientMethod, instance, modifier);
    }
    /** 供启动预检输出统一中文提示，不要求插件先改动任何玩家属性。 */
    public static boolean supported() { return !ServerThreads.folia() || Access.TRANSIENT != null; }
}
