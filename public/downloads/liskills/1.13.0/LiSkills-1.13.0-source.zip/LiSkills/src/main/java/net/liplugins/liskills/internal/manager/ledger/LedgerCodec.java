package net.liplugins.liskills.internal.manager.ledger;

import java.io.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.*;

/** 有版本与SHA-256完整性校验的有限二进制格式；不反序列化Java对象、不执行配置文本。 */
final class LedgerCodec {
    static final int MAX_BYTES=1_048_576;
    private static final int MAGIC=0x4c534c47,VERSION=1,DIGEST_BYTES=32;
    private LedgerCodec(){ }
    static byte[] encode(UUID uuid,LedgerState state)throws IOException {
        var bytes=new ByteArrayOutputStream();
        try(var data=new DataOutputStream(bytes)) {
            data.writeInt(MAGIC);data.writeInt(VERSION);data.writeLong(uuid.getMostSignificantBits());data.writeLong(uuid.getLeastSignificantBits());
            data.writeLong(state.incomeDay());data.writeDouble(state.income());data.writeInt(state.rewardHighWatermarks().size());
            for(var entry:state.rewardHighWatermarks().entrySet()){data.writeUTF(entry.getKey());data.writeInt(entry.getValue());}
        }
        byte[] payload=bytes.toByteArray();bytes.write(digest(payload));
        if(bytes.size()>MAX_BYTES)throw new IOException("ledger-too-large");return bytes.toByteArray();
    }
    static LedgerState decode(UUID expected,byte[] bytes)throws IOException {
        if(bytes.length<76 || bytes.length>MAX_BYTES)throw new IOException("invalid-ledger-length");
        byte[] payload=Arrays.copyOf(bytes,bytes.length-DIGEST_BYTES),checksum=Arrays.copyOfRange(bytes,bytes.length-DIGEST_BYTES,bytes.length);
        if(!MessageDigest.isEqual(digest(payload),checksum))throw new IOException("invalid-ledger-checksum");
        try(var data=new DataInputStream(new ByteArrayInputStream(payload))) {
            if(data.readInt()!=MAGIC || data.readInt()!=VERSION)throw new IOException("unsupported-ledger-format");
            UUID uuid=new UUID(data.readLong(),data.readLong());if(!uuid.equals(expected))throw new IOException("ledger-player-mismatch");
            long day=data.readLong();double income=data.readDouble();int size=data.readInt();
            if(size<0 || size>LedgerState.MAX_REWARDS)throw new IOException("invalid-ledger-reward-count");
            Map<String,Integer> rewards=new HashMap<>();
            for(int i=0;i<size;i++)if(rewards.put(data.readUTF(),data.readInt())!=null)throw new IOException("duplicate-ledger-reward");
            if(data.available()!=0)throw new IOException("unexpected-ledger-trailing-data");
            try{return new LedgerState(day,income,rewards);}catch(IllegalArgumentException error){throw new IOException("invalid-ledger-values",error);}
        }
    }
    private static byte[] digest(byte[] bytes){
        try{return MessageDigest.getInstance("SHA-256").digest(bytes);}catch(NoSuchAlgorithmException impossible){throw new IllegalStateException(impossible);}
    }
}
