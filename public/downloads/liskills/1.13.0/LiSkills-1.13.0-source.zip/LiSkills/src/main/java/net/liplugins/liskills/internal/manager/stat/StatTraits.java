package net.liplugins.liskills.internal.manager.stat;

import net.liplugins.liskills.internal.config.StatsSettings;
import net.liplugins.liskills.internal.config.StatTraitSettings;

import java.util.Map;

/** 属性到实际效果的纯函数，战斗、界面、魔力和监听器共享同一套公式。 */
public final class StatTraits {
    private StatTraits() { }

    public static double value(StatsSettings settings, Map<String, Double> values, String id) {
        StatTraitSettings trait = settings.trait(id);
        if (trait == null || !trait.enabled()) return 0;
        String stat = switch (id) {
            case "attack-damage" -> "strength";
            case "hp" -> "health";
            case "saturation-regen", "hunger-regen", "mana-regen" -> "regeneration";
            case "gathering-luck", "farming-luck", "foraging-luck", "mining-luck", "fishing-luck", "excavation-luck", "luck", "double-drop" -> "luck";
            case "experience-bonus", "anvil-discount", "max-mana" -> "wisdom";
            case "damage-reduction" -> "toughness";
            case "crit-chance" -> "crit_chance";
            case "crit-damage" -> "crit_damage";
            case "movement-speed" -> "speed";
            default -> null;
        };
        if (stat == null) return 0;
        double raw = values.getOrDefault(stat, 0.0) * trait.modifier();
        // 旧合并系数作为五项幸运的共同基底，随后再按每种独立物品trait运算。
        if (StatsSettings.GATHERING_TRAITS.contains(id)) raw += value(settings, values, "gathering-luck");
        if (values instanceof StatValueSnapshot snapshot) {
            var modifier = snapshot.itemTraits().get(id);
            if (modifier != null) raw = modifier.apply(raw);
        }
        if (!Double.isFinite(raw) || raw <= 0) return 0;
        return switch (id) {
            case "damage-reduction" -> reduction(raw, settings.damageReductionBase());
            case "anvil-discount" -> reduction(raw, settings.anvilDiscountBase());
            case "crit-chance", "double-drop" -> Math.min(100, raw);
            case "hp" -> Math.min(settings.maximumHealthBonus(), raw);
            case "movement-speed" -> Math.min(settings.maximumSpeedBonus(), raw);
            default -> raw;
        };
    }

    public static double reduction(double value, double base) {
        if (!Double.isFinite(value) || value <= 0 || !Double.isFinite(base) || base < 1) return 0;
        // expm1 在极小属性点时比 1 - pow(...) 保留更多有效位。
        return Math.max(0, Math.min(1, -Math.expm1(-value * Math.log(base))));
    }

    public static int experience(int original, double percent) {
        if (original <= 0 || !Double.isFinite(percent) || percent <= 0) return original;
        return (int) Math.min(Integer.MAX_VALUE, Math.floor(original * (1.0 + percent / 100.0)));
    }

    public static int anvilCost(int original, double discount) {
        if (original <= 0 || !Double.isFinite(discount) || discount <= 0) return original;
        return (int) Math.max(1, Math.round(original * (1.0 - Math.min(1, discount))));
    }
}
