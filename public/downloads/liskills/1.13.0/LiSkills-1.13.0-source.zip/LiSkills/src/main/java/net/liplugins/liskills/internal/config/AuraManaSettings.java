package net.liplugins.liskills.internal.config;

import org.bukkit.configuration.ConfigurationSection;

/** mana_abilities.yml 的独立数值策略；持续时间、冷却、基础耗魔继续复用技能主动配置。 */
public record AuraManaSettings(LightningBlade lightningBlade,SharpHook sharpHook,Absorption absorption,SpeedMine speedMine) {
    public static AuraManaSettings defaults() {
        return new AuraManaSettings(new LightningBlade(5,5,50),new SharpHook(.5,.5,5,33,false),
                new Absorption(2,20,false),new SpeedMine(3));
    }
    public static AuraManaSettings parse(ConfigurationSection root) {
        if(root==null)throw new IllegalArgumentException("mana_abilities.yml：缺少主动能力配置");
        return new AuraManaSettings(new LightningBlade(number(root,"lightning-blade.base-attack-speed-percent",0.1,100),
                number(root,"lightning-blade.attack-speed-per-level",0,100),number(root,"lightning-blade.maximum-attack-speed-percent",0.1,200)),
                new SharpHook(number(root,"sharp-hook.base-damage",0.1,20),number(root,"sharp-hook.damage-per-level",0,20),
                        number(root,"sharp-hook.maximum-damage",0.1,100),number(root,"sharp-hook.maximum-distance",1,64),bool(root,"sharp-hook.allow-pvp")),
                new Absorption(number(root,"absorption.mana-per-damage",0.1,100),number(root,"absorption.maximum-damage-per-hit",0.1,100),
                        bool(root,"absorption.allow-environmental-damage")),new SpeedMine(integer(root,"speed-mine.haste-level",1,10)));
    }
    private static double number(ConfigurationSection root,String key,double min,double max) {
        Object raw=root.get(key);
        if(!(raw instanceof Number value) || !Double.isFinite(value.doubleValue()) || value.doubleValue()<min || value.doubleValue()>max)
            throw new IllegalArgumentException("mana_abilities.yml."+key+"：应为 "+min+" 至 "+max+" 的有限数字");
        return value.doubleValue();
    }
    private static int integer(ConfigurationSection root,String key,int min,int max) {
        double value=number(root,key,min,max);
        if(value!=Math.rint(value))throw new IllegalArgumentException("mana_abilities.yml."+key+"：应为整数");
        return (int)value;
    }
    private static boolean bool(ConfigurationSection root,String key) {
        if(!(root.get(key) instanceof Boolean value))throw new IllegalArgumentException("mana_abilities.yml."+key+"：应为 true/false");
        return value;
    }
    public record LightningBlade(double baseAttackSpeedPercent,double attackSpeedPerLevel,double maximumAttackSpeedPercent) {
        public double percent(int rank){return rank<=0?0:Math.min(maximumAttackSpeedPercent,baseAttackSpeedPercent+(rank-1.0)*attackSpeedPerLevel);}
    }
    public record SharpHook(double baseDamage,double damagePerLevel,double maximumDamage,double maximumDistance,boolean allowPvp) {
        public double damage(int rank){return rank<=0?0:Math.min(maximumDamage,baseDamage+(rank-1.0)*damagePerLevel);}
    }
    public record Absorption(double manaPerDamage,double maximumDamagePerHit,boolean allowEnvironmentalDamage) { }
    public record SpeedMine(int hasteLevel) { }
}
