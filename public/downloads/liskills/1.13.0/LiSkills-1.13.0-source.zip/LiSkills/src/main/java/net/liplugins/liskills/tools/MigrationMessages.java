package net.liplugins.liskills.tools;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.Properties;

/** 独立命令行工具的中文消息，不依赖服务器、MiniMessage 或插件运行状态。 */
final class MigrationMessages {
    private final Properties messages = new Properties();

    MigrationMessages() {
        try (InputStream input = MigrationMessages.class.getResourceAsStream("/migration-messages.properties")) {
            if (input == null) throw new IllegalStateException("migration-messages.properties");
            messages.load(new InputStreamReader(input, StandardCharsets.UTF_8));
        } catch (IOException failure) {
            throw new IllegalStateException("migration-messages.properties", failure);
        }
    }

    String text(String key, Object... arguments) {
        return String.format(Locale.ROOT, messages.getProperty(key, key), arguments);
    }
}
