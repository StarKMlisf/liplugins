package net.liplugins.liskills.internal.listener.item;

import net.liplugins.liskills.internal.config.ItemSlot;
import net.liplugins.liskills.internal.config.ItemUse;
import net.liplugins.liskills.internal.hook.LiRealEnchantHook;
import net.liplugins.liskills.internal.manager.item.ItemEquipmentSlots;
import net.liplugins.liskills.internal.manager.item.ItemRequirementFeedback;
import net.liplugins.liskills.internal.manager.item.ItemRuleManager;
import org.bukkit.entity.Player;
import net.liplugins.liskills.lib.scheduler.ServerThreads;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityShootBowEvent;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

/** 尽早阻止受限制物品的原生使用；只取消本次动作，不扣物品、不改伤害或附魔。 */
public final class ItemRequirementListener implements Listener {
    private final ItemRuleManager rules;
    private final ItemRequirementFeedback feedback;
    private final LiRealEnchantHook enchantments;

    public ItemRequirementListener(ItemRuleManager rules, ItemRequirementFeedback feedback, LiRealEnchantHook enchantments) {
        this.rules = rules; this.feedback = feedback; this.enchantments = enchantments;
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        // LRE领地预检不是实际使用；真正的原始破坏在本监听器先检查，避免重复取消/提示预检。
        if (enchantments != null && enchantments.checkingSecondaryBreak()) return;
        check(event.getPlayer(), event.getPlayer().getInventory().getItemInMainHand(), ItemSlot.MAIN_HAND, ItemUse.BREAK, event);
    }
    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent event) {
        check(event.getPlayer(), event.getItemInHand(), hand(event.getHand()), ItemUse.PLACE, event);
    }
    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onAttack(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player player) || !ServerThreads.owns(player) || enchantments != null && enchantments.isSecondaryDamage()) return;
        check(player, player.getInventory().getItemInMainHand(), ItemSlot.MAIN_HAND, ItemUse.ATTACK, event);
    }
    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onShoot(EntityShootBowEvent event) {
        if (event.getEntity() instanceof Player player) check(player, event.getBow(), hand(event.getHand()), ItemUse.SHOOT, event);
    }
    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onConsume(PlayerItemConsumeEvent event) {
        check(event.getPlayer(), event.getItem(), hand(event.getHand()), ItemUse.CONSUME, event);
    }
    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onFish(PlayerFishEvent event) {
        if (event.getState() != PlayerFishEvent.State.FISHING) return;
        ItemSlot slot = hand(event.getHand());
        check(event.getPlayer(), event.getPlayer().getInventory().getItem(slot.equipmentSlot()), slot, ItemUse.FISH, event);
    }
    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onEntityInteract(PlayerInteractEntityEvent event) {
        ItemSlot slot = hand(event.getHand());
        check(event.getPlayer(), event.getPlayer().getInventory().getItem(slot.equipmentSlot()), slot, ItemUse.INTERACT, event);
    }
    @EventHandler(priority = EventPriority.LOWEST)
    public void onInteract(PlayerInteractEvent event) {
        if (!rules.active(event.getPlayer()) || event.getAction() == Action.PHYSICAL || event.useItemInHand() == Event.Result.DENY) return;
        if (event.getAction() == Action.RIGHT_CLICK_AIR || event.getAction() == Action.RIGHT_CLICK_BLOCK) {
            ItemSlot armor = ItemEquipmentSlots.armorSlot(event.getItem());
            if (armor != null && check(event.getPlayer(), event.getItem(), armor, ItemUse.EQUIP, event)) return;
        }
        check(event.getPlayer(), event.getItem(), hand(event.getHand()), ItemUse.INTERACT, event);
    }
    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent event) { feedback.clear(event.getPlayer().getUniqueId()); }

    private boolean check(Player player, ItemStack item, ItemSlot slot, ItemUse use, Cancellable event) {
        var failure = rules.denial(player, item, slot, use);
        if (failure.isEmpty()) return false;
        event.setCancelled(true);
        feedback.denied(player, failure.get());
        return true;
    }
    private static ItemSlot hand(EquipmentSlot slot) { return slot == EquipmentSlot.OFF_HAND ? ItemSlot.OFF_HAND : ItemSlot.MAIN_HAND; }
}
