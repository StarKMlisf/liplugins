package net.liplugins.liskills.lib.scheduler;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;

import java.lang.reflect.Method;

/** 只使用服务器公开的归属检查；全局线程或停服状态都不代表拥有某个玩家/区块。 */
public final class ServerThreads {
    private ServerThreads() { }

    private static final class Access {
        static final boolean FOLIA = detect();
        static final Method ENTITY = owner(Entity.class);
        static final Method LOCATION = owner(Location.class);
        static final Method BLOCK = owner(Block.class);
        static final Method GLOBAL = FOLIA ? SchedulerReflection.required(Bukkit.class, "isGlobalTickThread") : null;
        static final Method STOPPING = SchedulerReflection.optional(Bukkit.class, "isStopping");
        private static Method owner(Class<?> type) {
            return FOLIA ? SchedulerReflection.required(Bukkit.class, "isOwnedByCurrentRegion", type) : null;
        }
        private static boolean detect() {
            try {
                Class.forName("io.papermc.paper.threadedregions.RegionizedServer", false, Bukkit.class.getClassLoader());
                return true;
            } catch (ClassNotFoundException absent) { return false; }
        }
    }

    public static boolean folia() { return Access.FOLIA; }
    public static boolean owns(Entity entity) { return entity != null && owned(Access.ENTITY, entity); }
    public static boolean owns(Location location) { return location != null && location.getWorld() != null && owned(Access.LOCATION, location); }
    public static boolean owns(Block block) { return block != null && owned(Access.BLOCK, block); }
    private static boolean owned(Method method, Object target) {
        if (Bukkit.getServer() == null) return false;
        return folia() ? (boolean) SchedulerReflection.invoke(method, null, target) : Bukkit.isPrimaryThread();
    }
    public static boolean global() {
        if (Bukkit.getServer() == null) return false;
        return folia() ? (boolean) SchedulerReflection.invoke(Access.GLOBAL, null) : Bukkit.isPrimaryThread();
    }
    /** 仅供生命周期判断，不能将true当作跨区域访问许可。 */
    public static boolean stopping() {
        return Bukkit.getServer() != null && Access.STOPPING != null && (boolean) SchedulerReflection.invoke(Access.STOPPING, null);
    }
}
