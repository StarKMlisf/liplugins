package net.liplugins.liskills.internal.menu;

import net.liplugins.liskills.internal.config.*;
import net.liplugins.liskills.internal.storage.PlayerProfile;
import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.inventory.Inventory;
import java.util.*;

/** 每页五项能力；旧自定义归属保留导致超过五项时，摘要按钮循环翻页。 */
final class PassiveAbilityPage {
    private final ConfigManager config;
    private final TextService text;
    private final MenuItems items;
    private final SkillPresentation presentation;
    PassiveAbilityPage(ConfigManager config,TextService text,SkillPresentation presentation) {
        this.config=config;this.text=text;this.items=new MenuItems(text);this.presentation=presentation;
    }
    Inventory create(PlayerProfile profile,SkillDefinition skill) {
        return create(profile,skill,0);
    }
    Inventory create(PlayerProfile profile,SkillDefinition skill,int requestedPage) {
        RpgMenuLayout layout=RpgMenuLayout.parse(config.menu(),"passives",5);
        int count=(int)config.passives().values().stream().filter(p->p.skill().equals(skill.id())).count();
        int pages=Math.max(1,(count+4)/5),page=Math.clamp(requestedPage,0,pages-1);
        Map<Integer,MenuAction> actions=new LinkedHashMap<>();
        actions.put(layout.back(),new MenuAction(MenuAction.Type.DETAIL,skill.id(),0));
        actions.put(layout.active(),new MenuAction(MenuAction.Type.CAST,skill.id(),0));
        if(pages>1)actions.put(layout.summary(),new MenuAction(MenuAction.Type.PASSIVES,skill.id(),(page+1)%pages));
        SkillMenuHolder holder=new SkillMenuHolder(profile.uuid(),SkillMenuHolder.Screen.PASSIVES,skill.id(),page,config.revision(),actions,-1);
        Inventory inventory=Bukkit.createInventory(holder,layout.size(),text.text("rpg.passives-title",Map.of("skill",text.plain(skill.name()))));
        holder.inventory(inventory);
        if(config.menu().getBoolean("fill"))for(int i=0;i<layout.size();i++)inventory.setItem(i,items.item(new MenuMaterials(config).get("filler-material",Material.GRAY_STAINED_GLASS_PANE),"menu.filler-name",null,Map.of()));
        inventory.setItem(layout.back(),items.item(Material.ARROW,"rpg.back-detail-name","rpg.back-detail-lore",Map.of()));
        refresh(inventory,holder,profile);
        return inventory;
    }
    void refresh(Inventory inventory,SkillMenuHolder holder,PlayerProfile profile) {
        SkillDefinition skill=config.skill(holder.selectedSkill());
        if(skill==null)return;
        RpgMenuLayout layout=RpgMenuLayout.parse(config.menu(),"passives",5);
        int skillLevel=Math.min(skill.maxLevel(),profile.progress(skill.id()).level());
        var player=Bukkit.getPlayer(profile.uuid());
        boolean eligible=player!=null && !player.isDead() && player.hasPermission("liskills.use") && player.hasPermission("liskills.skill."+skill.id())
                && !config.settings().disabledWorlds().contains(player.getWorld().getName())
                && (!config.settings().survivalOnly() || player.getGameMode()==org.bukkit.GameMode.SURVIVAL || player.getGameMode()==org.bukkit.GameMode.ADVENTURE);
        List<PassiveDefinition> abilities=config.passives().values().stream().filter(p->p.skill().equals(skill.id())).toList();
        int start=holder.page()*layout.slots().size();
        for(int index=0;index<layout.slots().size() && start+index<abilities.size();index++) {
            PassiveDefinition ability=abilities.get(start+index);
            int rank=ability.level(skillLevel);
            boolean enabled=config.progressionEnabled() && ability.enabled() && skill.enabled();
            int next=ability.nextUnlock(skillLevel);
            Map<String,Object> values=new LinkedHashMap<>();
            values.put("name",text.plain(ability.name()));values.put("id",ability.id());values.put("level",rank);
            values.put("skill_level",skillLevel);values.put("unlock",ability.unlockLevel());values.put("interval",ability.levelInterval());
            values.put("value",text.format(ability.value(skillLevel)));values.put("secondary",text.format(ability.secondary(skillLevel)));
            values.put("reduction_percent",text.format(Math.clamp(ability.numberOption("speed_reduction",.2),0,.95)*100));
            values.put("food_saturation",text.format(ability.value(skillLevel)/10));
            values.put("next",next<=0 || next>skill.maxLevel()?text.plain(text.text("rpg.maximum")):next);
            values.put("state",text.plain(text.text(!enabled?"rpg.disabled":!eligible?"rpg.inactive":rank==0?"rpg.locked":"rpg.unlocked")));
            var item=items.item(!enabled || !eligible?Material.GRAY_DYE:rank>0?skill.icon():Material.IRON_BARS,
                    "rpg.passive-name","rpg.passive-lore",values);
            RpgMenuItems.append(item,List.of(text.render(ability.description(),values)));
            inventory.setItem(layout.slots().get(index),item);
        }
        Map<String,Object> values=presentation.values(skill,profile);
        var summary=items.item(skill.icon(),"rpg.summary-name","rpg.summary-lore",values);
        int pages=Math.max(1,(abilities.size()+4)/5);
        if(pages>1)RpgMenuItems.append(summary,List.of(text.text("rpg.passive-pages",Map.of("page",holder.page()+1,"pages",pages))));
        inventory.setItem(layout.summary(),summary);
        inventory.setItem(layout.active(),items.item(Material.BLAZE_POWDER,"rpg.active-name","rpg.active-lore",values));
    }
}
