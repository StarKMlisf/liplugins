package net.liplugins.liskills.internal.storage;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** YAML文件与SQL载荷使用同一格式/校验，不会因后端不同丢失冷却或魔力。 */
public final class ProfileYamlCodec {
    public static final int MAXIMUM_LENGTH=1_048_576;
    private ProfileYamlCodec(){ }
    public static ProfileSnapshot decode(UUID uuid,String name,String content)throws Exception{
        if(content==null||content.length()>MAXIMUM_LENGTH)throw new IOException("Invalid profile payload size");
        YamlConfiguration yaml=new YamlConfiguration();yaml.loadFromString(content);
        if(!uuid.toString().equals(yaml.getString("uuid")))throw new IOException("UUID mismatch: "+uuid);
        if(!(yaml.get("schema-version") instanceof Number schema)||schema.doubleValue()!=1.0)throw new IOException("Unsupported schema: "+uuid);
        Map<String,SkillProgress> skills=new HashMap<>();ConfigurationSection skillSection=yaml.getConfigurationSection("skills");
        if(skillSection==null)throw new IOException("Missing skills: "+uuid);
        if(skillSection.getKeys(false).size()>4096)throw new IOException("Too many skill entries");
        for(String id:skillSection.getKeys(false)){
            Object level=skillSection.get(id+".level"),xp=skillSection.get(id+".xp");
            if(!(level instanceof Number l)||!Double.isFinite(l.doubleValue())||l.doubleValue()<1||l.doubleValue()>1000||l.doubleValue()!=Math.rint(l.doubleValue())||!(xp instanceof Number x))throw new IOException("Invalid skill: "+id);
            skills.put(id,new SkillProgress(l.intValue(),x.doubleValue()));
        }
        Map<String,Long> cooldowns=new HashMap<>();ConfigurationSection cooldownSection=yaml.getConfigurationSection("cooldowns");
        if(cooldownSection!=null){
            if(cooldownSection.getKeys(false).size()>8192)throw new IOException("Too many cooldown entries");
            for(String id:cooldownSection.getKeys(false)){
                Object value=cooldownSection.get(id);
                if(!(value instanceof Number n)||!Double.isFinite(n.doubleValue())||n.doubleValue()<0||n.doubleValue()>=0x1p63||n.doubleValue()!=Math.rint(n.doubleValue()))throw new IOException("Invalid cooldown: "+id);
                cooldowns.put(id,n.longValue());
            }
        }
        double mana=-1;
        if(yaml.contains("mana")){if(!(yaml.get("mana") instanceof Number n)||!Double.isFinite(n.doubleValue())||n.doubleValue()<0)throw new IOException("Invalid mana");mana=n.doubleValue();}
        String resolvedName=name==null?yaml.getString("name",uuid.toString()):name;
        if(resolvedName==null||resolvedName.length()>64)throw new IOException("Invalid profile name");
        return new ProfileSnapshot(uuid,resolvedName,skills,cooldowns,mana);
    }
    public static String encode(ProfileSnapshot snapshot)throws IOException{
        YamlConfiguration yaml=new YamlConfiguration();yaml.set("schema-version",1);yaml.setComments("schema-version",List.of("数据结构版本；由插件管理，请勿修改。"));
        yaml.set("uuid",snapshot.uuid().toString());yaml.setComments("uuid",List.of("玩家唯一标识；必须与文件名一致。"));
        yaml.set("name",snapshot.name());yaml.setComments("name",List.of("最近一次在线名称；仅供辨识，身份以UUID为准。"));
        if(snapshot.mana()>=0){yaml.set("mana",snapshot.mana());yaml.setComments("mana",List.of("当前魔力；非负有限数字，离线期间不回复。"));}
        yaml.createSection("skills");yaml.setComments("skills",List.of("技能档案；请使用指令修改，不要在运行中编辑。"));
        snapshot.skills().forEach((id,value)->{yaml.set("skills."+id+".level",value.level());yaml.setComments("skills."+id+".level",List.of("当前等级；整数1至该技能最大等级。"));yaml.set("skills."+id+".xp",value.xp());yaml.setComments("skills."+id+".xp",List.of("本级经验；非负有限数字。"));});
        yaml.createSection("cooldowns");yaml.setComments("cooldowns",List.of("技能冷却到期时间；Unix毫秒整数，离线继续计时。"));
        snapshot.cooldowns().forEach((id,expiry)->{yaml.set("cooldowns."+id,expiry);yaml.setComments("cooldowns."+id,List.of("此技能可再次使用的时间；非负Unix毫秒整数。"));});
        String content=yaml.saveToString();
        try{decode(snapshot.uuid(),null,content);}catch(Exception error){throw new IOException("Invalid profile snapshot",error);}
        return content;
    }
}
