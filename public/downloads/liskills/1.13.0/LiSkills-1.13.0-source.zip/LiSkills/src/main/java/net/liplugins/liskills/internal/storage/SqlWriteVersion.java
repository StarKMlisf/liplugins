package net.liplugins.liskills.internal.storage;

/** 提交结果不明时，只接受自己的写入令牌或原版本；任何其他版本都不能当成成功。 */
public record SqlWriteVersion(long expected,String token) {
    public SqlWriteVersion {if(expected<0||expected>=Long.MAX_VALUE-1||token==null||token.isBlank())throw new IllegalArgumentException("invalid-write-version");}
    public long next(){return expected+1;}
    public boolean committed(long actual,String actualToken){return actual==next()&&token.equals(actualToken);}
    public boolean untouched(long actual){return actual==expected;}
}
