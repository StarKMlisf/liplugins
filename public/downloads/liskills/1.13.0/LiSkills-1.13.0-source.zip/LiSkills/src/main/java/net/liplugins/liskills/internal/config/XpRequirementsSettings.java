package net.liplugins.liskills.internal.config;

import org.bukkit.configuration.ConfigurationSection;
import java.util.*;

/** 独立经验曲线配置；未启用时继续使用每技能原有base-xp/growth-xp。 */
public record XpRequirementsSettings(boolean enabled,XpCurve defaults,Map<String,XpCurve> skills) {
    public XpRequirementsSettings { skills=Map.copyOf(skills); }
    public XpCurve curve(String id){return enabled?skills.getOrDefault(id,defaults):null;}
    public static XpRequirementsSettings parse(ConfigurationSection root,Set<String> ids){
        XpCurve defaults=curve(ConfigValues.section(root,"default"));Map<String,XpCurve> curves=new LinkedHashMap<>();
        ConfigurationSection section=ConfigValues.section(root,"skills");
        for(String id:section.getKeys(false)){if(!ids.contains(id))throw ConfigValues.invalid("xp_requirements.skills."+id,"已注册技能");curves.put(id,curve(ConfigValues.section(section,id)));}
        return new XpRequirementsSettings(ConfigValues.bool(root,"enabled"),defaults,curves);
    }
    private static XpCurve curve(ConfigurationSection c){
        Map<Integer,Double> levels=new HashMap<>();ConfigurationSection exact=ConfigValues.section(c,"levels");
        for(String key:exact.getKeys(false)){
            int target;try{target=Integer.parseInt(key);}catch(NumberFormatException e){throw ConfigValues.invalid("levels."+key,"目标等级2～1000");}
            if(target<2||target>1000)throw ConfigValues.invalid("levels."+key,"目标等级2～1000");levels.put(target,ConfigValues.number(exact,key,1,1e12));
        }
        XpCurve result=new XpCurve(XpExpression.compile(ConfigValues.text(c,"expression")),ConfigValues.number(c,"base",0,1e9),ConfigValues.number(c,"multiplier",0,1e9),levels);
        for(int level=1;level<1000;level++)result.required(level);return result;
    }
}
