package net.liplugins.liskills.internal.storage.migration;

import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/** 命令行仅接受配置文件路径，不把数据库密码写进进程参数。 */
public record MigrationArguments(Path source,Path sourceConfig,Path target,Path targetConfig,Path drivers,boolean apply) {
    private static final Set<String> OPTIONS=Set.of("--source","--source-config","--target","--target-config","--drivers");
    public static MigrationArguments parse(String[] args){
        Map<String,String> values=new HashMap<>();boolean apply=false;
        for(int index=0;index<args.length;index++){
            String key=args[index];
            if(key.equals("--apply")){if(apply)throw new IllegalArgumentException("migration-duplicate-apply");apply=true;continue;}
            if(!OPTIONS.contains(key)||index+1>=args.length||args[index+1].startsWith("--")||values.putIfAbsent(key,args[++index])!=null)
                throw new IllegalArgumentException("migration-invalid-arguments");
        }
        if(!values.keySet().equals(OPTIONS)||values.values().stream().anyMatch(String::isBlank))throw new IllegalArgumentException("migration-explicit-arguments-required");
        return new MigrationArguments(Path.of(values.get("--source")),Path.of(values.get("--source-config")),Path.of(values.get("--target")),Path.of(values.get("--target-config")),Path.of(values.get("--drivers")),apply);
    }
}
