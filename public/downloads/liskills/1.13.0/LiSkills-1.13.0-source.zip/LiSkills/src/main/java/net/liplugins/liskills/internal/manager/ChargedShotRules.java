package net.liplugins.liskills.internal.manager;

import org.bukkit.Material;
import org.bukkit.entity.EntityType;
import org.bukkit.inventory.EquipmentSlot;

import java.util.OptionalDouble;

/** 蓄力射击的纯输入规则；不读玩家、不操作事件或世界。 */
final class ChargedShotRules {
    private ChargedShotRules() { }

    static boolean qualifies(Material weapon, EquipmentSlot hand, EntityType projectile, float force, double minimumForce) {
        if (weapon != Material.BOW || hand != EquipmentSlot.HAND
                || projectile != EntityType.ARROW && projectile != EntityType.SPECTRAL_ARROW) return false;
        if (!Float.isFinite(force) || force < 0 || force > 1
                || !Double.isFinite(minimumForce) || minimumForce < 0.1 || minimumForce > 1) return false;
        // Bukkit 以 float 给出蓄力值；将配置转成同一精度，避免 0.9f 因舍入而小于配置 0.9。
        return force >= (float) minimumForce;
    }

    static OptionalDouble boostedDamage(double damage, double finalDamage, double multiplier) {
        if (!Double.isFinite(damage) || damage <= 0 || !Double.isFinite(finalDamage) || finalDamage <= 0
                || !Double.isFinite(multiplier) || multiplier < 1 || multiplier > 5) return OptionalDouble.empty();
        double boosted = damage * multiplier;
        return Double.isFinite(boosted) ? OptionalDouble.of(boosted) : OptionalDouble.empty();
    }
}
