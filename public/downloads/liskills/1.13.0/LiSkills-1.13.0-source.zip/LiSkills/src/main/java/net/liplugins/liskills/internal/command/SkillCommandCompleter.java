package net.liplugins.liskills.internal.command;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.config.SkillDefinition;
import org.bukkit.Bukkit;
import net.liplugins.liskills.lib.scheduler.ServerThreads;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.Collection;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** 补全仅提供调用者有权使用的指令与当前启用技能。 */
final class SkillCommandCompleter implements TabCompleter {
    private final ConfigManager config;
    private final Map<String, Subcommand> commands;
    private final ExtendedCommandSuggestions extended=new ExtendedCommandSuggestions();
    SkillCommandCompleter(ConfigManager config, Map<String, Subcommand> commands) {
        this.config = config; this.commands = Map.copyOf(commands);
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] arguments) {
        if(sender instanceof Player player && !ServerThreads.owns(player))return List.of();
        if (arguments.length == 0) return List.of();
        if (arguments.length == 1) {
            return matches(commands.values().stream().filter(sub -> sender.hasPermission(sub.permission())).map(Subcommand::name).toList(), arguments[0]);
        }
        String name = arguments[0].toLowerCase(Locale.ROOT);
        Subcommand subcommand = commands.get(name);
        if (subcommand == null || !sender.hasPermission(subcommand.permission())) return List.of();
        String current = arguments[arguments.length - 1];
        if(name.equals("hud"))return matches(HudCommandSuggestions.options(arguments),current);
        List<String> additions=extended.options(config,sender,arguments);
        if(additions!=null)return matches(additions,current);
        if ((name.equals("sources") || name.equals("cast") || name.equals("abilities")) && arguments.length == 2) {
            return matches(config.skills().values().stream().filter(SkillDefinition::enabled).map(SkillDefinition::id).toList(), current);
        }
        if ((name.equals("stats") || name.equals("mana") || name.equals("attributes")) && arguments.length == 2) {
            if (sender.hasPermission("liskills.stats.others")) return players(sender, current);
            return sender instanceof Player player ? matches(List.of(player.getName()), current) : List.of();
        }
        if (name.equals("xp") || name.equals("level")) {
            if (arguments.length == 2) return matches(name.equals("xp") ? List.of("add", "set") : List.of("set"), current);
            if (arguments.length == 3) return players(sender, current);
            if (arguments.length == 4) {
                return matches(config.skills().values().stream().filter(SkillDefinition::enabled).map(SkillDefinition::id).toList(), current);
            }
            if (arguments.length == 5) {
                if (name.equals("xp")) return matches(List.of("0", "10", "100", "1000"), current);
                SkillDefinition skill = config.skill(arguments[3].toLowerCase(Locale.ROOT));
                int maximum = skill == null ? 100 : skill.maxLevel();
                return matches(List.of("1", Integer.toString(Math.min(10, maximum)), Integer.toString(maximum)), current);
            }
        }
        return List.of();
    }

    private List<String> players(CommandSender sender, String input) {
        return matches(ExtendedCommandSuggestions.visiblePlayers(sender), input);
    }

    private List<String> matches(Collection<String> options, String input) {
        String lower = input.toLowerCase(Locale.ROOT);
        return options.stream().filter(option -> option.toLowerCase(Locale.ROOT).startsWith(lower)).distinct().sorted().toList();
    }
}
