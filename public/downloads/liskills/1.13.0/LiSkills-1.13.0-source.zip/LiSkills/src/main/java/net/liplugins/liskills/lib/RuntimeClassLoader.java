package net.liplugins.liskills.lib;

import java.net.URL;
import java.net.URLClassLoader;

/** 仅业务包优先从本插件加载，Bukkit、API 接口与服务器已有公共库始终交给父加载器。 */
public final class RuntimeClassLoader extends URLClassLoader {
    public RuntimeClassLoader(URL[] urls, ClassLoader parent) {
        super(urls, parent);
    }

    @Override
    protected Class<?> loadClass(String name, boolean resolve) throws ClassNotFoundException {
        synchronized (getClassLoadingLock(name)) {
            if (!name.startsWith("net.liplugins.liskills.internal.")) {
                return super.loadClass(name, resolve);
            }
            Class<?> loaded = findLoadedClass(name);
            if (loaded == null) {
                loaded = findClass(name);
            }
            if (resolve) {
                resolveClass(loaded);
            }
            return loaded;
        }
    }
}
