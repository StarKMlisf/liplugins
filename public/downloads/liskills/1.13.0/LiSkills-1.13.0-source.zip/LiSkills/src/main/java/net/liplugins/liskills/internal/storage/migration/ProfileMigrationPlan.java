package net.liplugins.liskills.internal.storage.migration;

import net.liplugins.liskills.internal.storage.ProfileSnapshot;
import net.liplugins.liskills.internal.storage.ProfileYamlCodec;
import net.liplugins.liskills.internal.storage.StorageConflictException;
import java.io.IOException;
import java.util.*;

/** 全量预检：发现任何重复UUID、无效档案或目标冲突时，尚未开始创建玩家档案。 */
public record ProfileMigrationPlan(List<ProfileSnapshot> create,Map<UUID,ProfileSnapshot> expected,int sourceCount,int identical) {
    public ProfileMigrationPlan{create=List.copyOf(create);expected=Map.copyOf(expected);}
    public record Preview(int sourceProfiles,int missing,int identical,int conflicts,int targetProfiles){ }
    public static Preview preview(List<ProfileSnapshot> source,List<ProfileSnapshot> target)throws IOException{
        Map<UUID,ProfileSnapshot> from=index(source),to=index(target);int missing=0,identical=0,conflicts=0;
        for(var snapshot:from.values()){
            ProfileSnapshot existing=to.get(snapshot.uuid());
            if(existing==null)missing++;else if(existing.equals(snapshot))identical++;else conflicts++;
        }
        return new Preview(from.size(),missing,identical,conflicts,to.size());
    }
    public static ProfileMigrationPlan prepare(List<ProfileSnapshot> source,List<ProfileSnapshot> target)throws IOException{
        Map<UUID,ProfileSnapshot> from=index(source),to=index(target);List<ProfileSnapshot> create=new ArrayList<>();int identical=0;
        for(var snapshot:from.values()){
            ProfileSnapshot existing=to.get(snapshot.uuid());
            if(existing==null)create.add(snapshot);
            else if(existing.equals(snapshot))identical++;
            else throw new StorageConflictException("migration-target-conflict: "+snapshot.uuid());
        }
        Map<UUID,ProfileSnapshot> expected=new LinkedHashMap<>(to);expected.putAll(from);
        return new ProfileMigrationPlan(create,expected,from.size(),identical);
    }
    static Map<UUID,ProfileSnapshot> index(List<ProfileSnapshot> snapshots)throws IOException{
        Map<UUID,ProfileSnapshot> all=new LinkedHashMap<>();
        for(var snapshot:snapshots){
            ProfileYamlCodec.encode(snapshot);
            if(all.putIfAbsent(snapshot.uuid(),snapshot)!=null)throw new IOException("migration-duplicate-uuid: "+snapshot.uuid());
        }
        return all;
    }
}
