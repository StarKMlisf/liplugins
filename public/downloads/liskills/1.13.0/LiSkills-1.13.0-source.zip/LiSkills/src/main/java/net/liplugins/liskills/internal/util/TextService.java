package net.liplugins.liskills.internal.util;

import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.liplugins.liskills.internal.config.ConfigManager;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import net.liplugins.liskills.lib.scheduler.ServerThreads;
import net.liplugins.liskills.lib.scheduler.TaskScheduler;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.*;

/** 所有展示先经 MiniMessage；变量按纯文本转义，玩家名无法注入颜色或点击标签。 */
public final class TextService {
    private final ConfigManager config;
    private final MiniMessage mini=MiniMessage.miniMessage();
    private final LegacyComponentSerializer legacy=LegacyComponentSerializer.builder().hexColors().useUnusualXRepeatedCharacterHexFormat().build();
    public TextService(ConfigManager config){this.config=config;}
    public String render(String value){return legacy.serialize(mini.deserialize(value==null?"":value));}
    public String render(String value,Map<String,?> replacements){return render(replace(value,replacements));}
    public String text(String key){return text(key,Map.of());}
    public String text(String key,Map<String,?> replacements){return render(replace(config.messages().getString(key,key),replacements));}
    public void send(CommandSender sender,String key){send(sender,key,Map.of());}
    public void send(CommandSender sender,String key,Map<String,?> replacements){
        if(config.messages().isList(key)) sendRendered(sender,lines(key,replacements));
        else {String value=text(key,replacements); if(!value.isBlank()) sendRendered(sender,List.of(value));}
    }
    /** 先固定本次文本快照，跨区域反馈只在收件玩家的实体线程发送。 */
    public void sendRendered(CommandSender sender,List<String> lines){
        List<String> snapshot=List.copyOf(lines);
        if(sender instanceof Player player && !ServerThreads.owns(player)) {
            new TaskScheduler(config.plugin()).entity(player,()->{if(player.isOnline())snapshot.forEach(player::sendMessage);});
        } else snapshot.forEach(sender::sendMessage);
    }
    public List<String> lines(String key,Map<String,?> replacements){return config.messages().getStringList(key).stream().map(line->render(replace(line,replacements))).toList();}
    public String format(double value){return new DecimalFormat("0.##",DecimalFormatSymbols.getInstance(Locale.ROOT)).format(value);}
    public String progress(double fraction,int width){
        int size=Math.clamp(width,1,40), complete=(int)Math.floor(Math.clamp(fraction,0,1)*size);
        return render("<green>"+"|".repeat(complete)+"<dark_gray>"+"|".repeat(size-complete));
    }
    public String plain(String value){return ChatColor.stripColor(value!=null && value.indexOf('\u00a7')>=0?value:render(value));}
    public String gradient(String value,String... colors){
        if(colors.length<2) throw new IllegalArgumentException("colors");
        for(String color:colors) if(!color.matches("#[0-9a-fA-F]{6}")) throw new IllegalArgumentException("color");
        return render("<gradient:"+String.join(":",colors)+">"+mini.escapeTags(value)+"</gradient>");
    }
    public String brandGradient(String value){return gradient(value,"#57d5ff","#ae8aff","#ffd381");}
    private String replace(String value,Map<String,?> replacements){
        String result=value;
        for(var entry:replacements.entrySet()) result=result.replace("{"+entry.getKey()+"}",mini.escapeTags(String.valueOf(entry.getValue())));
        return result;
    }
}
