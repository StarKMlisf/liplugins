package net.liplugins.liskills.internal.listener;

import net.liplugins.liskills.lib.scheduler.ServerThreads;
import net.liplugins.liskills.lib.scheduler.TaskScheduler;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.manager.ProfileManager;
import net.liplugins.liskills.internal.manager.SkillManager;
import net.liplugins.liskills.internal.manager.source.CombatKillSources;
import net.liplugins.liskills.internal.manager.passive.combat.SecondaryDamageContext;
import net.liplugins.liskills.internal.storage.PlayerProfile;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.Cancellable;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.plugin.IllegalPluginAccessException;
import org.bukkit.plugin.java.JavaPlugin;
import java.util.*;

/** 只结算玩家直接击杀或其投射物击杀，不按每次伤害重复奖励。 */
public final class CombatExperienceListener implements Listener {
    private static final int MAX_PENDING_ENTITIES=4096,MAX_DEATHS_PER_ENTITY=8;
    private final JavaPlugin plugin;
    private final ConfigManager config;
    private final ProfileManager profiles;
    private final SkillManager skills;
    private final MobOriginListener origins;
    private final Map<UUID,List<DeathAttempt>> pending=new java.util.concurrent.ConcurrentHashMap<>();
    private final TaskScheduler scheduler;

    public CombatExperienceListener(JavaPlugin plugin,ConfigManager config,ProfileManager profiles,SkillManager skills,MobOriginListener origins) {
        this.plugin=plugin;
        this.scheduler=new TaskScheduler(plugin);
        this.config = config;
        this.profiles=profiles;
        this.skills = skills;
        this.origins = origins;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onDeath(EntityDeathEvent event) {
        if (event.getEntity() instanceof Player || !ServerThreads.owns(event.getEntity()) || !plugin.isEnabled() || !zeroHealth(event)) return;
        Player killer;
        String id;
        EntityDamageEvent cause=event.getEntity().getLastDamageCause();
        // 流血上下文只在当前伤害栈存在，必须在此捕获；下一tick不再读取lastDamageCause或投射物射手。
        if(SecondaryDamageContext.active()) {
            killer=SecondaryDamageContext.attacker();
            id="fighting";
            if(killer==null)return;
        } else if (!(cause instanceof EntityDamageByEntityEvent damage)) return;
        else if (damage.getDamager() instanceof Player player) {
            killer = player;
            id = "fighting";
        } else if (damage.getDamager() instanceof Projectile projectile && ServerThreads.owns(projectile) && projectile.getShooter() instanceof Player player) {
            killer = player;
            id = "archery";
        } else return;
        if (config.settings().naturalMobsOnly() && !origins.natural(event.getEntity())) return;
        var rewards = CombatKillSources.select(config.skills().values(), id, event.getEntityType());
        if(rewards.isEmpty())return;
        UUID uuid=event.getEntity().getUniqueId();List<DeathAttempt> attempts=pending.get(uuid);
        if(attempts!=null && (attempts.size()>=MAX_DEATHS_PER_ENTITY || attempts.stream().anyMatch(attempt->attempt.event()==event)))return;
        if(attempts==null && pending.size()>=MAX_PENDING_ENTITIES)return;
        var profile=profiles.get(killer.getUniqueId());Map<String,Double> permitted=new LinkedHashMap<>();
        boolean local=ServerThreads.owns(killer);
        for(var reward:rewards.entrySet())if(!local || killer.hasPermission("liskills.skill."+reward.getKey()))permitted.put(reward.getKey(),reward.getValue());
        var attempt=new DeathAttempt(event,cause,killer,profile,local?killer.getWorld().getUID():event.getEntity().getWorld().getUID(),config.revision(),
                profile!=null && (!local || killer.isOnline() && skills.eligible(killer)),Collections.unmodifiableMap(permitted));
        if(attempts!=null){attempts.add(attempt);return;}
        List<DeathAttempt> group=new ArrayList<>();group.add(attempt);pending.put(uuid,group);
        // 每实体仅排一个任务。取消后同tick再次真的死亡保留独立快照，不让首次pending吞掉后续死亡。
        try{scheduler.region(event.getEntity().getLocation(),()->settle(uuid,group));}
        catch(IllegalPluginAccessException disabled){pending.remove(uuid,group);}
    }

    private void settle(UUID uuid,List<DeathAttempt> group) {
        if(!pending.remove(uuid,group) || !plugin.isEnabled())return;
        for(var attempt:group) {
            var event=attempt.event();
            // Paper死亡事件可取消，Spigot同名类不实现接口；只用Bukkit通用Cancellable且读取最终状态。
            if((Object)event instanceof Cancellable cancelled && cancelled.isCancelled())continue;
            if(attempt.cause()!=null && attempt.cause().isCancelled())continue;
            if(!ServerThreads.owns(event.getEntity()) || !event.getEntity().isDead() || !zeroHealth(event))continue;
            // 只有真实死亡才消费整组凭据；无权限死亡仍一次终结，恢复权限不能补领旧死亡。
            if(!origins.markRewarded(event.getEntity()))return;
            Player killer=attempt.killer();
            scheduler.entityNow(killer,()->{
                for(var reward:attempt.rewards().entrySet()) {
                    if(!valid(attempt))break;
                    skills.award(killer,reward.getKey(),reward.getValue());
                }
            });
            return;
        }
    }
    private boolean valid(DeathAttempt attempt){
        Player killer=attempt.killer();
        return ServerThreads.owns(killer) && attempt.eligible() && killer.isOnline() && plugin.getServer().getPlayer(killer.getUniqueId())==killer
                && profiles.get(killer.getUniqueId())==attempt.profile() && config.revision()==attempt.revision()
                && killer.getWorld().getUID().equals(attempt.world()) && skills.eligible(killer);
    }
    private static boolean zeroHealth(EntityDeathEvent event){double health=event.getEntity().getHealth();return Double.isFinite(health) && health<=0;}
    private record DeathAttempt(EntityDeathEvent event,EntityDamageEvent cause,Player killer,PlayerProfile profile,UUID world,
                                long revision,boolean eligible,Map<String,Double> rewards){ }
}
