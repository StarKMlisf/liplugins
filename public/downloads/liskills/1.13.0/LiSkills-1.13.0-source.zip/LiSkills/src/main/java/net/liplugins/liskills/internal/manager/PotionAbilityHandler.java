package net.liplugins.liskills.internal.manager;

import net.liplugins.liskills.internal.config.ActiveSkill;
import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/** 原生药水能力；不覆盖更强效果，外部插件拒绝时返回失败供统一事务退款。 */
public final class PotionAbilityHandler implements ActiveAbilityHandler {
    private final TextService text;
    public PotionAbilityHandler(TextService text) { this.text = text; }

    @Override public boolean activate(Player player, ActiveSkill active) {
        PotionEffectType type = PotionEffectType.getByName(active.effect());
        long ticks = active.durationSeconds() * 20L;
        if (type == null || ticks <= 0 || ticks > Integer.MAX_VALUE || active.amplifier() < 0 || active.amplifier() > 255) {
            text.send(player, "ability.invalid");
            return false;
        }
        PotionEffect existing = player.getPotionEffect(type);
        if (existing != null && (existing.getAmplifier() > active.amplifier()
                || existing.getAmplifier() == active.amplifier() && (existing.isInfinite() || existing.getDuration() >= ticks))) {
            text.send(player, "ability.stronger-effect");
            return false;
        }
        boolean accepted=player.addPotionEffect(new PotionEffect(type, (int) ticks, active.amplifier(), false, true, true));
        // Paper26.1.2 build74的Bukkit适配层会丢弃底层取消结果并返回true，必须同步回读实际效果。
        // 同步事件链结束前游戏tick不会扣时长；取消后保留的较弱或较短旧效果也不能视为成功。
        PotionEffect actual=player.getPotionEffect(type);
        if (!PotionApplicationRules.applied(accepted,active.amplifier(),(int)ticks,actual!=null,
                actual==null?-1:actual.getAmplifier(),actual==null?0:actual.getDuration(),actual!=null && actual.isInfinite())) {
            text.send(player, "ability.effect-blocked");
            return false;
        }
        return true;
    }
}
