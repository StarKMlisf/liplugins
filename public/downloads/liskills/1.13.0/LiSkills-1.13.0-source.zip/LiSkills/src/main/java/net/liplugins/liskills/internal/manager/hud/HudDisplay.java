package net.liplugins.liskills.internal.manager.hud;

import net.liplugins.liskills.internal.config.HudSettings;
import org.bukkit.Bukkit;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.Player;

import java.util.EnumMap;
import java.util.Map;

/** 仅拥有本插件为一位玩家创建的三条 BossBar，绝不触碰其他插件的显示。 */
final class HudDisplay implements AutoCloseable {
    enum Slot { HEALTH, MANA, SKILL }
    @FunctionalInterface interface BarFactory { BossBar create(String title, HudSettings.Bar settings); }

    private final Map<Slot, BossBar> bars = new EnumMap<>(Slot.class);
    private final BarFactory factory;
    private final HudExperience experience = new HudExperience();

    HudDisplay() { this((title, settings) -> Bukkit.createBossBar(title, settings.color(), settings.style())); }
    HudDisplay(BarFactory factory) { this.factory = factory; }
    HudExperience experience() { return experience; }

    void render(Slot slot, Player player, HudSettings.Bar settings, String title, double progress) {
        if (!settings.enabled()) { hide(slot); return; }
        BossBar bar = bars.get(slot);
        if (bar == null) {
            bar = factory.create(title, settings);
            bars.put(slot, bar);
            // 首次加入前先设置进度，避免客户端先收到瞬间满条。
            bar.setProgress(HudProgress.fraction(progress, 1));
            bar.addPlayer(player);
        }
        if (!bar.getTitle().equals(title)) bar.setTitle(title);
        if (bar.getColor() != settings.color()) bar.setColor(settings.color());
        if (bar.getStyle() != settings.style()) bar.setStyle(settings.style());
        double fraction = HudProgress.fraction(progress, 1);
        if (Double.compare(bar.getProgress(), fraction) != 0) bar.setProgress(fraction);
    }

    void hide(Slot slot) {
        BossBar bar = bars.remove(slot);
        if (bar != null) bar.removeAll();
    }

    @Override public void close() {
        bars.values().forEach(BossBar::removeAll);
        bars.clear();
    }
}
