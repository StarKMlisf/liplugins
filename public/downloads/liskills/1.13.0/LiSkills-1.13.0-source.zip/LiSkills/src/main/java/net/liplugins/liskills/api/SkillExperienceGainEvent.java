package net.liplugins.liskills.api;

import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import java.util.Objects;

/** 自然经验成功结算后发布的只读通知；不含管理员/API直接写入，amount为实际记入的经验。 */
public final class SkillExperienceGainEvent extends Event {
    private static final HandlerList HANDLERS=new HandlerList();
    private final Player player;
    private final String skill;
    private final double amount;
    public SkillExperienceGainEvent(Player player,String skill,double amount) {
        this.player=Objects.requireNonNull(player);this.skill=Objects.requireNonNull(skill);
        if(!Double.isFinite(amount) || amount<=0)throw new IllegalArgumentException("amount");
        this.amount=amount;
    }
    public Player getPlayer(){return player;}
    public String getSkill(){return skill;}
    public double getAmount(){return amount;}
    @Override public HandlerList getHandlers(){return HANDLERS;}
    public static HandlerList getHandlerList(){return HANDLERS;}
}
