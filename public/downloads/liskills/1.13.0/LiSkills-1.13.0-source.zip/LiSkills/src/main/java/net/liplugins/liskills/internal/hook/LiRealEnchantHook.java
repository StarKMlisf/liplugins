package net.liplugins.liskills.internal.hook;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.listener.BlockExperienceListener;
import net.liplugins.liskills.internal.manager.SkillManager;
import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.Bukkit;
import net.liplugins.liskills.lib.scheduler.ServerThreads;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventPriority;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import java.lang.reflect.Method;
import java.util.*;

/** 仅通过 LiRealEnchant 的公开 API/事件桥接；不访问实现私有字段，不改装备附魔。 */
public final class LiRealEnchantHook implements AutoCloseable {
    private final JavaPlugin plugin;
    private final ConfigManager config;
    private final TextService text;
    private final Listener listener=new Listener() { };
    private volatile Object api;
    private Plugin enchantPlugin;
    private Method level,checking,secondaryDamage;
    private boolean completionEvents;
    private boolean warned;
    private final Set<Event> handled=Collections.synchronizedSet(Collections.newSetFromMap(new WeakHashMap<>()));
    public LiRealEnchantHook(JavaPlugin plugin,ConfigManager config,TextService text){this.plugin=plugin;this.config=config;this.text=text;}
    public void register(BlockExperienceListener blocks,SkillManager skills) {
        enchantPlugin=Bukkit.getPluginManager().getPlugin("LiRealEnchant2");
        if(enchantPlugin==null || !enchantPlugin.isEnabled())return;
        try {
            ClassLoader loader=enchantPlugin.getClass().getClassLoader();
            Class<?> type=Class.forName("com.yunmengze.lirealenchant.api.LiRealEnchantApi",true,loader);
            api=Bukkit.getServicesManager().load(type);
            if(api==null || ((Number)type.getMethod("apiVersion").invoke(api)).intValue()!=1)throw new IllegalStateException("API v1 unavailable");
            level=type.getMethod("level",ItemStack.class,NamespacedKey.class);
            try{checking=type.getMethod("isCheckingSecondaryBreak");secondaryDamage=type.getMethod("isSecondaryDamage");}
            catch(NoSuchMethodException legacy){text.send(Bukkit.getConsoleSender(),"compatibility.lre-legacy");return;}
            registerEvent(loader,"LiSecondaryBlockBreakEvent",event->{
                if(!available() || !handled.add(event))return;
                Player player=(Player)get(event,"getPlayer");
                Location location=(Location)get(event,"getLocation");
                if(!ServerThreads.owns(player) || !ServerThreads.owns(location) || location.getWorld()==null || !location.getWorld().isChunkLoaded(location.getBlockX()>>4,location.getBlockZ()>>4))return;
                blocks.completed(player,location.getBlock(),(Material)get(event,"getMaterial"),(BlockData)get(event,"getBlockData"),active() && config.compatibility().secondaryBlockXp());
            });
            registerEvent(loader,"LiEnchantTableCompleteEvent",event->{
                if(!active() || !config.compatibility().bedrockEnchantingXp() || !handled.add(event))return;
                if(!"BEDROCK".equals(String.valueOf(get(event,"getSource"))))return;
                if(((Number)get(event,"getExperienceCost")).intValue()<=0 || ((Number)get(event,"getLapisCost")).intValue()<=0)return;
                Player player=(Player)get(event,"getPlayer");
                var definition=config.skill("enchanting");
                if(definition!=null)skills.award(player,"enchanting",definition.eventXp());
            });
            completionEvents=true;
            text.send(Bukkit.getConsoleSender(),"compatibility.lre-ready",Map.of("version",enchantPlugin.getDescription().getVersion()));
        }catch(Exception|LinkageError error){report(error);}
    }
    private Object get(Event event,String method)throws ReflectiveOperationException{return event.getClass().getMethod(method).invoke(event);}
    private void registerEvent(ClassLoader loader,String name,EventConsumer handler)throws ReflectiveOperationException {
        Class<? extends Event> event=Class.forName("com.yunmengze.lirealenchant.api.event."+name,true,loader).asSubclass(Event.class);
        Bukkit.getPluginManager().registerEvent(event,listener,EventPriority.MONITOR,(ignored,value)->{
            try{handler.accept(value);}catch(Exception|LinkageError error){report(error);}
        },plugin,true);
    }
    private boolean available(){return api!=null && enchantPlugin!=null && enchantPlugin.isEnabled();}
    public boolean active(){return config.compatibility().liRealEnchant() && available();}
    public boolean complete(){return active() && completionEvents;}
    public boolean checkingSecondaryBreak(){return context(checking);}
    public boolean isSecondaryDamage(){return net.liplugins.liskills.internal.manager.passive.combat.SecondaryDamageContext.active()
            || config.compatibility().skipSecondaryDamageBonus() && context(secondaryDamage);}
    private boolean context(Method method){
        // 即使管理员关闭额外奖励，也不能把附魔的领地预检误认为已经破坏成功。
        if(!available() || method==null)return false;
        try{return Boolean.TRUE.equals(method.invoke(api));}catch(Exception|LinkageError error){report(error);return true;}
    }
    public boolean ownsTreeBreaking(ItemStack tool){
        return owns(tool,List.of("lumberjack","veinminer","excavation","digging"));
    }
    public boolean ownsReplanting(ItemStack tool){
        return owns(tool,List.of("replenish","harvest","planter"));
    }
    private boolean owns(ItemStack tool,List<String> ids){
        // 关闭额外奖励不应让同一把工具同时启动两套连锁/补种任务。
        if(!available() || tool==null || tool.getType().isAir())return false;
        try {
            for(String id:ids) {
                if(((Number)level.invoke(api,tool,new NamespacedKey("yunmengze",id))).intValue()>0)return true;
            }
            return false;
        }catch(Exception|LinkageError error){report(error);return true;}
    }
    public String status(){
        String key=!config.compatibility().liRealEnchant()?"compatibility.disabled":complete()?"compatibility.full":active()?"compatibility.legacy":"compatibility.absent";
        return text.text("compatibility.lre-status",Map.of("state",text.plain(text.text(key))));
    }
    private synchronized void report(Throwable error){if(!warned){warned=true;text.send(Bukkit.getConsoleSender(),"compatibility.lre-failed",Map.of("error",error.getClass().getSimpleName()));}}
    public void close(){HandlerList.unregisterAll(listener);handled.clear();api=null;}
    @FunctionalInterface private interface EventConsumer{void accept(Event event)throws Exception;}
}
