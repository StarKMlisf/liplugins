package net.liplugins.liskills.internal.command;

import net.liplugins.liskills.internal.config.LeaderboardSettings;
import net.liplugins.liskills.internal.manager.leaderboard.LeaderboardManager;
import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.command.CommandSender;
import java.util.Map;
import java.util.function.Supplier;

/** 分页排行查询；不触发同步磁盘读写。 */
final class TopCommand implements Subcommand {
    private final LeaderboardManager boards;private final Supplier<LeaderboardSettings> settings;private final SenderChecks checks;private final TextService text;
    TopCommand(LeaderboardManager boards,Supplier<LeaderboardSettings> settings,SenderChecks checks,TextService text){this.boards=boards;this.settings=settings;this.checks=checks;this.text=text;}
    public String name(){return "top";}public String permission(){return "liskills.use";}
    public void execute(CommandSender sender,String[] args){
        if(args.length>2){checks.usage(sender,"extended.usage-top");return;}
        if(!settings.get().enabled()){text.send(sender,"extended.leaderboard-disabled");return;}
        String skill=args.length==0?"total":args[0].toLowerCase(java.util.Locale.ROOT);if(!skill.equals("total")&&checks.skill(sender,skill)==null)return;
        int page=1;try{if(args.length==2)page=Integer.parseInt(args[1]);}catch(NumberFormatException ignored){page=0;}
        if(page<1||page>10000){checks.usage(sender,"extended.usage-top");return;}
        if(!boards.ready()){boards.refresh();text.send(sender,"extended.leaderboard-loading");return;}
        var list=boards.entries(skill);int size=settings.get().pageSize(),pages=Math.max(1,(list.size()+size-1)/size);
        if(page>pages){checks.usage(sender,"extended.usage-top");return;}
        text.send(sender,"extended.leaderboard-title",Map.of("skill",skill,"page",page,"pages",pages));
        for(int i=(page-1)*size;i<Math.min(list.size(),page*size);i++){var row=list.get(i);text.send(sender,"extended.leaderboard-row",Map.of("rank",i+1,"player",row.name(),"level",row.level(),"xp",text.format(row.xp())));}
    }
}
