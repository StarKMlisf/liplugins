package net.liplugins.liskills.internal.manager.source;

import net.liplugins.liskills.internal.config.SkillDefinition;
import org.bukkit.entity.EntityType;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/** 只选择一次击杀配置的技能来源；玩家资格、来源证明和去重由统一监听器处理。 */
public final class CombatKillSources {
    private static final Set<String> COMBAT_SKILLS = Set.of("fighting", "archery");

    private CombatKillSources() { }

    public static Map<String, Double> select(Collection<SkillDefinition> definitions, String combatSkill, EntityType type) {
        if (!COMBAT_SKILLS.contains(combatSkill)) return Map.of();
        Map<String, Double> selected = new LinkedHashMap<>();
        for (SkillDefinition definition : definitions) {
            if (!definition.enabled() || COMBAT_SKILLS.contains(definition.id()) && !definition.id().equals(combatSkill)) continue;
            Double xp = definition.mobs().get(type);
            // 零值/无映射不是来源；其他显式配置mobs的技能不依赖默认战斗技能是否开启。
            if (xp != null && Double.isFinite(xp) && xp > 0) selected.put(definition.id(), xp);
        }
        return Collections.unmodifiableMap(selected);
    }
}
