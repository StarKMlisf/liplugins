package net.liplugins.liskills.internal.command;

import net.liplugins.liskills.internal.config.SkillDefinition;
import net.liplugins.liskills.internal.menu.SkillDetails;
import org.bukkit.command.CommandSender;

final class SourcesCommand implements Subcommand {
    private final SenderChecks checks;
    private final SkillDetails details;
    SourcesCommand(SenderChecks checks, SkillDetails details) { this.checks = checks; this.details = details; }
    public String name() { return "sources"; }
    public String permission() { return "liskills.use"; }
    public void execute(CommandSender sender, String[] arguments) {
        if (arguments.length != 1) { checks.usage(sender, "command.usage-sources"); return; }
        SkillDefinition skill = checks.skill(sender, arguments[0]);
        if (skill != null) details.send(sender, skill);
    }
}
