package net.liplugins.liskills.internal.manager.ledger;

import java.io.IOException;
import java.nio.file.Path;
import java.util.*;

/** 收入额度和等级奖励的提交边界；只有完整持久化返回成功后，调用方才能产生外部副作用。 */
public final class PlayerRewardLedger implements AutoCloseable {
    @FunctionalInterface public interface LegacySeed { LedgerState read()throws IOException; }
    public record IncomeReservation(double amount,LedgerState state){ }
    public record RewardRequest(String key,int oldLevel,int newLevel,int start,int interval,int end) {
        public RewardRequest {
            if(!LedgerState.validRewardKey(key) || oldLevel<1 || newLevel<oldLevel || newLevel>1000 || start<2 || interval<1 || interval>1000 || end<start || end>1000)
                throw new IllegalArgumentException("invalid-ledger-reward-request");
        }
    }
    public record ClaimedReward(String key,int level){ }
    public record RewardReservation(List<ClaimedReward> awards,LedgerState state){public RewardReservation{awards=List.copyOf(awards);}}
    private final LedgerFileStore files;
    public PlayerRewardLedger(Path directory){files=new LedgerFileStore(Objects.requireNonNull(directory));}
    /** 只读已提交快照；尚未建立账本时为null，损坏时抛IOException而不是返回空数据。 */
    public synchronized LedgerState snapshot(UUID uuid)throws IOException{return files.read(Objects.requireNonNull(uuid));}
    public Path path(UUID uuid){return files.path(Objects.requireNonNull(uuid));}
    public synchronized IncomeReservation reserveIncome(UUID uuid,long day,double requested,double maximum,LegacySeed seed)throws IOException {
        if(day<0 || !Double.isFinite(requested) || requested<0 || !Double.isFinite(maximum) || maximum<0 || maximum>1_000_000)
            throw new IllegalArgumentException("invalid-ledger-income-request");
        LedgerState previous=files.read(Objects.requireNonNull(uuid));LedgerState state=previous==null?seed(seed):previous;
        if(day<state.incomeDay()){if(previous==null)files.write(uuid,state);return new IncomeReservation(0,state);}
        double earned=day==state.incomeDay()?state.income():0;
        double amount=Math.min(requested,Math.max(0,maximum-earned));
        double total=amount>0?Math.min(maximum,earned+amount):earned;
        // 小于double精度的额度不能“已付款但累计没有增长”；返回真正可记账的差额。
        amount=Math.max(0,total-earned);
        LedgerState next=new LedgerState(day,total,state.rewardHighWatermarks());
        if(previous==null || !next.equals(previous))files.write(uuid,next);
        return new IncomeReservation(amount,next);
    }
    public synchronized RewardReservation reserveRewards(UUID uuid,List<RewardRequest> requests,int maximum,LegacySeed seed)throws IOException {
        if(requests.size()>128 || maximum<1 || maximum>128)throw new IllegalArgumentException("invalid-ledger-reward-budget");
        Set<String> seen=new HashSet<>();for(var request:requests)if(!seen.add(request.key()))throw new IllegalArgumentException("duplicate-ledger-reward-request");
        LedgerState previous=files.read(Objects.requireNonNull(uuid));LedgerState state=previous==null?seed(seed):previous;
        Map<String,Integer> highs=new TreeMap<>(state.rewardHighWatermarks());List<ClaimedReward> awards=new ArrayList<>();
        for(var request:requests) {
            int prior=highs.getOrDefault(request.key(),1),high=prior;
            for(int level=Math.max(prior+1,Math.max(request.oldLevel()+1,request.start()));level<=Math.min(request.newLevel(),request.end());level++) {
                if((level-request.start())%request.interval()!=0)continue;
                high=level;if(awards.size()<maximum)awards.add(new ClaimedReward(request.key(),level));
            }
            if(high>prior)highs.put(request.key(),high);
        }
        if(highs.size()>LedgerState.MAX_REWARDS)throw new IOException("ledger-reward-key-limit");
        LedgerState next=new LedgerState(state.incomeDay(),state.income(),highs);
        // 超过单次发放预算的等级也先标记；后续降级不能补领被安全预算截断的奖励。
        if(previous==null || !next.equals(previous))files.write(uuid,next);
        return new RewardReservation(awards,next);
    }
    private static LedgerState seed(LegacySeed seed)throws IOException {
        try{return Objects.requireNonNull(seed.read());}catch(IllegalArgumentException|NullPointerException error){throw new IOException("invalid-legacy-ledger",error);}
    }
    @Override public synchronized void close()throws IOException{files.close();}
}
