package net.liplugins.liskills.internal.listener;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.config.SkillDefinition;
import net.liplugins.liskills.internal.manager.ProfileManager;
import net.liplugins.liskills.internal.manager.SkillManager;
import net.liplugins.liskills.internal.storage.PlayerProfile;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import net.liplugins.liskills.lib.scheduler.ServerThreads;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;

/** 防御与摔落训练按玩家、技能独立节流；冷却随资料保存，重连不会立即重置。 */
public final class DamageExperienceListener implements Listener {
    private final ConfigManager config;
    private final ProfileManager profiles;
    private final SkillManager skills;
    private final MobOriginListener origins;

    public DamageExperienceListener(ConfigManager config, ProfileManager profiles, SkillManager skills, MobOriginListener origins) {
        this.config = config;
        this.profiles = profiles;
        this.skills = skills;
        this.origins = origins;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player player) || !skills.eligible(player)) return;
        if (!Double.isFinite(event.getFinalDamage()) || event.getFinalDamage() <= 0) return;
        String id;
        if (event.getCause() == EntityDamageEvent.DamageCause.FALL) {
            id = "agility";
        } else if (event instanceof EntityDamageByEntityEvent attack && validAttacker(attack)) {
            id = "defense";
        } else return; // 火焰、仙人掌、窒息和玩家互殴不提供防御经验。

        PlayerProfile profile = profiles.get(player.getUniqueId());
        SkillDefinition definition = config.skill(id);
        if (profile == null || definition == null || !definition.enabled()) return;
        long now = System.currentTimeMillis();
        String cooldownKey = "_xp_" + id;
        if (profile.cooldown(cooldownKey) > now) return;
        if (skills.award(player, id, definition.eventXp())) {
            profile.cooldown(cooldownKey, now + Math.max(1, config.settings().damageCooldownSeconds()) * 1000L);
        }
    }

    private boolean validAttacker(EntityDamageByEntityEvent event) {
        LivingEntity attacker;
        if (event.getDamager() instanceof LivingEntity living) attacker = living;
        else if (event.getDamager() instanceof Projectile projectile && ServerThreads.owns(projectile) && projectile.getShooter() instanceof LivingEntity living) attacker = living;
        else return false;
        return ServerThreads.owns(attacker) && !(attacker instanceof Player) && (!config.settings().naturalMobsOnly() || origins.natural(attacker));
    }
}
