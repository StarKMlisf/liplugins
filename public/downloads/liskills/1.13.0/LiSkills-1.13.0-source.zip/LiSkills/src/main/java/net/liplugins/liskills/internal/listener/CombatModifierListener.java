package net.liplugins.liskills.internal.listener;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.config.SkillDefinition;
import net.liplugins.liskills.internal.manager.SkillManager;
import net.liplugins.liskills.internal.hook.LiRealEnchantHook;
import net.liplugins.liskills.internal.storage.SkillProgress;
import org.bukkit.entity.Player;
import net.liplugins.liskills.lib.scheduler.ServerThreads;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

/** 被动战斗加成只调整本次事件，不写永久属性，不遗留退出或重载后的属性修改。 */
public final class CombatModifierListener implements Listener {
    private final ConfigManager config;
    private final SkillManager skills;
    private final LiRealEnchantHook enchantments;

    public CombatModifierListener(ConfigManager config, SkillManager skills) {
        this(config,skills,null);
    }
    public CombatModifierListener(ConfigManager config,SkillManager skills,LiRealEnchantHook enchantments) {
        this.config = config;
        this.skills = skills;
        this.enchantments=enchantments;
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent event) {
        if(config.progressionEnabled())return;
        if(enchantments!=null && enchantments.isSecondaryDamage())return;
        double damage = event.getDamage();
        if (!Double.isFinite(damage) || damage <= 0) return;
        if (event.getDamager() instanceof Player player) {
            damage *= 1.0 + bonus(player, "fighting", config.settings().fightingBonusPerLevel(), config.settings().maxDamageBonus());
        } else if (event.getDamager() instanceof Projectile projectile && ServerThreads.owns(projectile) && projectile.getShooter() instanceof Player player) {
            damage *= 1.0 + bonus(player, "archery", config.settings().archeryBonusPerLevel(), config.settings().maxDamageBonus());
        }
        if (event.getEntity() instanceof Player player) {
            damage *= 1.0 - bonus(player, "defense", config.settings().defenseReductionPerLevel(), config.settings().maxDamageReduction());
        }
        if (Double.isFinite(damage) && damage >= 0) event.setDamage(damage);
    }

    private double bonus(Player player, String id, double perLevel, double cap) {
        if (!skills.eligible(player) || !player.hasPermission("liskills.use") || !player.hasPermission("liskills.skill." + id)) return 0;
        SkillDefinition definition = config.skill(id);
        if (definition == null || !definition.enabled()) return 0;
        SkillProgress progress = skills.progress(player.getUniqueId(), id);
        if (progress == null) return 0;
        return Math.min(Math.max(0, cap), Math.max(0, progress.level() - 1) * Math.max(0, perLevel));
    }
}
