package net.liplugins.liskills.internal.manager.leaderboard;

import net.liplugins.liskills.internal.config.SkillDefinition;
import net.liplugins.liskills.internal.storage.*;
import java.util.*;

/** 根据不可变玩家快照计算排行；无Bukkit调用，可在存储线程执行。 */
public final class LeaderboardCalculator {
    private LeaderboardCalculator(){ }
    public record Entry(UUID uuid,String name,int level,double xp) { }
    public static Map<String,List<Entry>> calculate(Collection<ProfileSnapshot> profiles,Map<String,SkillDefinition> skills,int maximum){
        Map<String,List<Entry>> rows=new LinkedHashMap<>();rows.put("total",new ArrayList<>());
        skills.values().stream().filter(SkillDefinition::enabled).forEach(skill->rows.put(skill.id(),new ArrayList<>()));
        Set<UUID> seen=new HashSet<>();
        for(ProfileSnapshot profile:profiles){if(!seen.add(profile.uuid()))continue;int total=0;double xp=0;
            for(String id:rows.keySet()){if(id.equals("total"))continue;var skill=skills.get(id);var progress=profile.skills().getOrDefault(id,new SkillProgress(1,0));
                int level=Math.min(skill.maxLevel(),progress.level());rows.get(id).add(new Entry(profile.uuid(),profile.name(),level,progress.xp()));total+=level;xp+=progress.xp();}
            rows.get("total").add(new Entry(profile.uuid(),profile.name(),total,xp));
        }
        Comparator<Entry> order=Comparator.comparingInt(Entry::level).reversed().thenComparing(Comparator.comparingDouble(Entry::xp).reversed()).thenComparing(Entry::name,String.CASE_INSENSITIVE_ORDER).thenComparing(Entry::uuid);
        Map<String,List<Entry>> result=new LinkedHashMap<>();rows.forEach((id,list)->result.put(id,list.stream().sorted(order).limit(maximum).toList()));return Collections.unmodifiableMap(result);
    }
}
