package net.liplugins.liskills.internal.config;

import org.bukkit.configuration.ConfigurationSection;
import java.util.Map;

/** 敏捷自然来源与防挂机边界，距离单位米，时间单位秒。 */
public record AgilitySourceSettings(boolean enabled, int sampleTicks, int activitySeconds, double thresholdMeters,
                                    double maximumMeters, int maximumJumps, int minimumCells, int cellSize,
                                    int recentSeconds, int repeatSeconds, int jumpsPerAward, Map<String,Double> experience) {
    public AgilitySourceSettings { experience = Map.copyOf(experience); }
    static AgilitySourceSettings parse(ConfigurationSection section) {
        return new AgilitySourceSettings(NaturalSourcesSettings.bool(section,"enabled"),
                NaturalSourcesSettings.integer(section,"sample-ticks",10,200), NaturalSourcesSettings.integer(section,"activity-timeout-seconds",5,300),
                NaturalSourcesSettings.number(section,"distance-threshold",1,100), NaturalSourcesSettings.number(section,"maximum-meters-per-sample",.1,100),
                NaturalSourcesSettings.integer(section,"maximum-jumps-per-sample",1,20), NaturalSourcesSettings.integer(section,"minimum-unique-cells",2,20),
                NaturalSourcesSettings.integer(section,"cell-size",2,32), NaturalSourcesSettings.integer(section,"recent-cell-seconds",10,600),
                NaturalSourcesSettings.integer(section,"repeat-cell-seconds",10,1800), NaturalSourcesSettings.integer(section,"jumps-per-award",10,1000),
                Map.of("walk",NaturalSourcesSettings.number(section,"sources.walk",0,1000),"sprint",NaturalSourcesSettings.number(section,"sources.sprint",0,1000),
                        "swim",NaturalSourcesSettings.number(section,"sources.swim",0,1000),"jump",NaturalSourcesSettings.number(section,"sources.jump",0,1000)));
    }
}
