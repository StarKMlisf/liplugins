package net.liplugins.liskills.internal.command;

import net.liplugins.liskills.internal.manager.stat.PlayerModifierManager;
import net.liplugins.liskills.internal.manager.stat.StatManager;
import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.command.CommandSender;
import java.util.Map;

/** 属性修饰符管理；数值修改不修改技能等级，也不冒用附魔的PDC。 */
final class ModifierCommand implements Subcommand {
    private final SenderChecks checks;private final TextService text;private final PlayerModifierManager modifiers;private final StatManager stats;
    ModifierCommand(SenderChecks checks,TextService text,PlayerModifierManager modifiers,StatManager stats){this.checks=checks;this.text=text;this.modifiers=modifiers;this.stats=stats;}
    public String name(){return "modifier";}public String permission(){return "liskills.admin";}
    public void execute(CommandSender sender,String[] args){
        if(args.length<2){checks.usage(sender,"extended.usage-modifier");return;}
        var player=checks.online(sender,args[1]);if(player==null)return;
        checks.onPlayer(player, () -> {
        if(checks.profile(sender,player)==null)return;
        if(args[0].equals("list")&&args.length==2){text.send(sender,"extended.modifier-title",Map.of("player",player.getName()));modifiers.entries(player).forEach((id,value)->text.send(sender,"extended.modifier-row",Map.of("id",id,"stat",value.stat(),"amount",text.format(value.amount()))));return;}
        boolean changed=false;
        if(args[0].equals("remove")&&args.length==3)changed=modifiers.remove(player,args[2]);
        else if(args[0].equals("set")&&args.length==5){try{changed=modifiers.set(player,args[2],args[3],Double.parseDouble(args[4]));}catch(NumberFormatException ignored){ }}
        if(!changed){checks.usage(sender,"extended.usage-modifier");return;}
        player.saveData();if(stats!=null)stats.refreshAll();text.send(sender,"extended.modifier-saved",Map.of("player",player.getName()));
        });
    }
}
