package net.liplugins.liskills.internal.manager.item;

import net.liplugins.liskills.internal.config.ItemModifierOperation;
import net.liplugins.liskills.internal.config.ItemRule;
import net.liplugins.liskills.internal.config.ItemSlot;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** 只读AuraSkills2.3.12公开Bukkit PDC格式；不调用其API，不猜测旧版私有NBT。 */
public final class AuraItemReader {
    public record Preview(boolean recognized, boolean complete, List<ItemRule> rules, List<String> problems) {
        public Preview { rules = List.copyOf(rules); problems = List.copyOf(problems); }
    }
    public Preview preview(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return new Preview(false, true, List.of(), List.of());
        return preview(item.getItemMeta().getPersistentDataContainer(), ItemEquipmentSlots.armorSlot(item));
    }
    /** 可供管理面板预览；问题字符串是稳定原因码，面向玩家的文本由消息层翻译。 */
    public Preview preview(PersistentDataContainer root, ItemSlot armorSlot) {
        List<ItemRule> rules = new ArrayList<>(); List<String> problems = new ArrayList<>(); boolean recognized = false;
        for (String scope : List.of("item", "armor")) {
            Set<ItemSlot> slots = scope.equals("item") ? Set.of(ItemSlot.MAIN_HAND, ItemSlot.OFF_HAND)
                    : armorSlot == null ? Set.of() : Set.of(armorSlot);
            for (String kind : List.of("modifiers", "trait_modifiers", "multipliers", "requirements")) {
                NamespacedKey key = key(scope + "_" + kind);
                if (!root.has(key)) continue;
                recognized = true;
                try {
                    if (slots.isEmpty()) throw new IllegalArgumentException("unknown-armor-slot");
                    String name = "aura_" + scope + "_" + kind;
                    if (kind.equals("modifiers") || kind.equals("trait_modifiers"))
                        modifiers(root, key, name, slots, kind.equals("trait_modifiers"), rules);
                    else maps(root, key, name, slots, kind.equals("requirements"), rules);
                } catch (IllegalArgumentException error) { problems.add(scope + "_" + kind + ":" + error.getMessage()); }
            }
        }
        try { if (!rules.isEmpty()) new ItemRuleCodec().encode(rules); }
        catch (IllegalArgumentException error) { problems.add("unsupported-value-or-id:" + error.getMessage()); }
        return new Preview(recognized, problems.isEmpty(), rules, problems);
    }
    /** 显式迁移到新副本；任何未知字段/运算/超界数值都拒绝整件，原Aura和其他PDC保持原样。 */
    public ItemStack migrate(ItemStack original, ItemMetadataService metadata) {
        Preview preview = preview(original);
        if (!preview.recognized() || !preview.complete() || preview.rules().isEmpty())
            throw new IllegalArgumentException("aura-item-migration-incomplete");
        return metadata.appendRules(original, preview.rules());
    }

    @SuppressWarnings("deprecation")
    private void modifiers(PersistentDataContainer root, NamespacedKey key, String name, Set<ItemSlot> slots,
                           boolean trait, List<ItemRule> rules) {
        List<PersistentDataContainer> entries;
        if (root.has(key, PersistentDataType.LIST.dataContainers())) entries = root.get(key, PersistentDataType.LIST.dataContainers());
        else if (root.has(key, PersistentDataType.TAG_CONTAINER_ARRAY)) entries = Arrays.asList(root.get(key, PersistentDataType.TAG_CONTAINER_ARRAY));
        else if (root.has(key, PersistentDataType.TAG_CONTAINER)) {
            PersistentDataContainer legacy = root.get(key, PersistentDataType.TAG_CONTAINER);
            if (legacy.getKeys().size() > 32) throw new IllegalArgumentException("too-many-modifiers");
            int index = 0;
            for (NamespacedKey entry : legacy.getKeys().stream().sorted(java.util.Comparator.comparing(NamespacedKey::toString)).toList()) {
                own(entry); String id = id(entry.getKey(), trait);
                double value = required(legacy, entry, PersistentDataType.DOUBLE);
                ItemRule rule = ItemRuleEditor.named(name + "_" + index++, slots);
                rules.add(trait ? ItemRuleEditor.trait(rule, id, ItemModifierOperation.ADD, value)
                        : ItemRuleEditor.stat(rule, id, ItemModifierOperation.ADD, value));
            }
            return;
        } else throw new IllegalArgumentException("wrong-container-type");
        if (entries == null || entries.size() > 32) throw new IllegalArgumentException("too-many-modifiers");
        int index = 0;
        for (PersistentDataContainer entry : entries) {
            Set<NamespacedKey> allowed = Set.of(key(trait ? "trait" : "stat"), key("value"), key("operation"));
            if (!allowed.containsAll(entry.getKeys())) throw new IllegalArgumentException("unknown-modifier-fields");
            String id = id(required(entry, key(trait ? "trait" : "stat"), PersistentDataType.STRING), trait);
            double value = required(entry, key("value"), PersistentDataType.DOUBLE);
            String operation = entry.has(key("operation")) ? required(entry, key("operation"), PersistentDataType.STRING) : "add";
            ItemModifierOperation type;
            try { type = ItemModifierOperation.valueOf(operation.toUpperCase(Locale.ROOT)); }
            catch (IllegalArgumentException error) { throw new IllegalArgumentException("unknown-operation"); }
            ItemRule rule = ItemRuleEditor.named(name + "_" + index++, slots);
            rules.add(trait ? ItemRuleEditor.trait(rule, id, type, value) : ItemRuleEditor.stat(rule, id, type, value));
        }
    }
    private void maps(PersistentDataContainer root, NamespacedKey key, String name, Set<ItemSlot> slots,
                      boolean requirement, List<ItemRule> rules) {
        PersistentDataContainer values = required(root, key, PersistentDataType.TAG_CONTAINER);
        if (values.getKeys().size() > 256) throw new IllegalArgumentException("too-many-skills");
        ItemRule rule = ItemRuleEditor.named(name, slots);
        for (NamespacedKey entry : values.getKeys().stream().sorted(java.util.Comparator.comparing(NamespacedKey::toString)).toList()) {
            own(entry); String id = !requirement && entry.getKey().equals("global") ? "all" : id(entry.getKey(), false);
            if (requirement) rule = ItemRuleEditor.requirement(rule, id, required(values, entry, PersistentDataType.INTEGER));
            else rule = ItemRuleEditor.experience(rule, id, required(values, entry, PersistentDataType.DOUBLE));
        }
        if (!values.isEmpty()) rules.add(rule);
    }
    private static String id(String value, boolean trait) {
        String id = value.startsWith("auraskills/") ? value.substring("auraskills/".length()) : value;
        if (!id.matches("[a-z][a-z0-9_]{0,47}")) throw new IllegalArgumentException("unknown-id-namespace");
        return trait ? id.replace('_', '-') : id;
    }
    private static void own(NamespacedKey key) {
        if (!key.getNamespace().equals("auraskills")) throw new IllegalArgumentException("foreign-field");
    }
    private static NamespacedKey key(String value) { return new NamespacedKey("auraskills", value); }
    private static <P,C> C required(PersistentDataContainer data, NamespacedKey key, PersistentDataType<P,C> type) {
        if (!data.has(key, type)) throw new IllegalArgumentException("missing-or-wrong-type:" + key.getKey());
        C result = data.get(key, type);
        if (result == null) throw new IllegalArgumentException("missing-value:" + key.getKey());
        return result;
    }
}
