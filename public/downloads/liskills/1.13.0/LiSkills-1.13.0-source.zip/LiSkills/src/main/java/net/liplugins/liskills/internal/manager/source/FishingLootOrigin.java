package net.liplugins.liskills.internal.manager.source;

import org.bukkit.NamespacedKey;
import org.bukkit.entity.Item;
import org.bukkit.persistence.PersistentDataType;
import java.util.UUID;

/** 仅在同一个钓获实体上传递本插件池来源，绑定鱼钩身份，不把标签写入可再次使用的物品。 */
public final class FishingLootOrigin {
    private static final NamespacedKey KEY=new NamespacedKey("liskills","fishing_pool_origin");
    private FishingLootOrigin() { }
    public static void mark(Item item,UUID hook,String pool) {
        if(pool.equals("rare") || pool.equals("epic"))item.getPersistentDataContainer().set(KEY,PersistentDataType.STRING,hook+":"+pool);
    }
    public static String consume(Item item,UUID hook) {
        String value=item.getPersistentDataContainer().has(KEY,PersistentDataType.STRING)?item.getPersistentDataContainer().get(KEY,PersistentDataType.STRING):null;
        item.getPersistentDataContainer().remove(KEY);
        if(value==null)return null;
        if(value.equals(hook+":rare"))return "rare";
        if(value.equals(hook+":epic"))return "epic";
        return null;
    }
}
