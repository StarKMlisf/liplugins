package net.liplugins.liskills.internal.listener;

import net.liplugins.liskills.internal.manager.ProfileManager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import java.util.UUID;
import java.util.function.Consumer;

public final class ProfileListener implements Listener {
    private final ProfileManager profiles;
    private final Consumer<UUID> beforeQuit;
    public ProfileListener(ProfileManager profiles){this(profiles,ignored->{});}
    public ProfileListener(ProfileManager profiles,Consumer<UUID> beforeQuit){this.profiles=profiles;this.beforeQuit=beforeQuit;}
    @EventHandler public void onJoin(PlayerJoinEvent event){profiles.join(event.getPlayer());}
    @EventHandler public void onQuit(PlayerQuitEvent event){
        UUID uuid=event.getPlayer().getUniqueId();
        beforeQuit.accept(uuid);profiles.quit(uuid);
    }
}
