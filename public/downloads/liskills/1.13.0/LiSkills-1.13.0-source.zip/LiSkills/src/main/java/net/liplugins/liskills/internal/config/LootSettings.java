package net.liplugins.liskills.internal.config;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.potion.PotionType;
import java.util.*;
import java.util.function.BiPredicate;

/** 独立校验四个原版宝藏池；任何错误交由 ConfigManager 保留上一完整快照。 */
public record LootSettings(Map<String, List<LootPoolSettings>> tables) {
    private static final Set<Material> DIRTS = Set.of(Material.DIRT, Material.GRASS_BLOCK, Material.MYCELIUM,
            Material.COARSE_DIRT, Material.PODZOL, Material.ROOTED_DIRT);

    public LootSettings {
        Map<String, List<LootPoolSettings>> copy = new LinkedHashMap<>();
        tables.forEach((key, value) -> copy.put(key, List.copyOf(value)));
        tables = Collections.unmodifiableMap(copy);
    }
    public List<LootPoolSettings> pools(String skill) { return tables.getOrDefault(skill, List.of()); }

    public static LootSettings parse(ConfigurationSection root) {
        // 运行时必须向真实 Bukkit 注册表确认物品/方块身份；纯语法测试使用独立材料策略。
        return parse(root, (material, block) -> !material.isAir() && (block ? material.isBlock() : material.isItem()));
    }
    static LootSettings parse(ConfigurationSection root, BiPredicate<Material, Boolean> materialType) {
        if (root == null || integer(root.get("config-version"), "config-version", 1, 1) != 1)
            throw bad("config-version", "1");
        ConfigurationSection tables = root.getConfigurationSection("tables");
        if (tables == null) throw bad("tables", "fishing 和 excavation 配置节");
        if (!Set.of("fishing", "excavation").containsAll(tables.getKeys(false))) throw bad("tables", "仅 fishing、excavation");
        Map<String, List<LootPoolSettings>> parsed = new LinkedHashMap<>();
        for (String skill : List.of("fishing", "excavation")) {
            ConfigurationSection table = tables.getConfigurationSection(skill);
            if (table == null || !Set.of("rare", "epic").containsAll(table.getKeys(false))) throw bad(skill, "rare、epic 配置节");
            List<LootPoolSettings> pools = new ArrayList<>();
            for (String id : List.of("rare", "epic")) {
                String path = "tables." + skill + "." + id;
                ConfigurationSection pool = table.getConfigurationSection(id);
                if (pool == null) throw bad(path, "配置节");
                List<?> raw = pool.getList("entries");
                if (raw == null || raw.size() > 256) throw bad(path + ".entries", "最多256项的物品列表，可为空");
                List<LootEntrySettings> entries = new ArrayList<>();
                for (int i = 0; i < raw.size(); i++) {
                    String at = path + ".entries[" + i + "]";
                    if (!(raw.get(i) instanceof Map<?, ?> entry)) throw bad(at, "物品配置映射");
                    Material material = material(entry.get("material"), at + ".material", false, materialType);
                    double weight = number(entry.get("weight"), at + ".weight", 0.000001, 1_000_000);
                    int[] amount = amount(entry.get("amount"), at + ".amount");
                    double xp = entry.containsKey("xp") ? number(entry.get("xp"), at + ".xp", 0, 1e9) : 0;
                    Set<Material> sources = new LinkedHashSet<>();
                    if (entry.containsKey("sources")) {
                        if (!(entry.get("sources") instanceof List<?> values) || values.size() > 256) throw bad(at + ".sources", "原版方块或dirts列表");
                        for (Object source : values) {
                            if ("dirts".equalsIgnoreCase(String.valueOf(source))) sources.addAll(DIRTS);
                            else sources.add(material(source, at + ".sources", true, materialType));
                        }
                    }
                    PotionType potion = null;
                    if (entry.containsKey("potion")) {
                        try { potion = PotionType.valueOf(String.valueOf(entry.get("potion")).toUpperCase(Locale.ROOT)); }
                        catch (IllegalArgumentException error) { throw bad(at + ".potion", "Bukkit PotionType 药水名"); }
                        if (material != Material.TIPPED_ARROW) throw bad(at + ".potion", "仅可用于TIPPED_ARROW");
                    }
                    entries.add(new LootEntrySettings(material, weight, amount[0], amount[1], xp, sources, potion));
                }
                pools.add(new LootPoolSettings(id, bool(pool.get("enabled"), path + ".enabled"),
                        number(pool.get("base-chance"), path + ".base-chance", 0, 100),
                        number(pool.get("chance-per-luck"), path + ".chance-per-luck", 0, 100),
                        integer(pool.get("priority"), path + ".priority", 0, 100),
                        bool(pool.get("require-open-water"), path + ".require-open-water"), entries));
            }
            pools.sort(Comparator.comparingInt(LootPoolSettings::priority).reversed());
            parsed.put(skill, pools);
        }
        return new LootSettings(parsed);
    }
    private static int[] amount(Object value, String path) {
        if (value instanceof Number) {
            int n = integer(value, path, 1, 64); return new int[] {n, n};
        }
        if (value instanceof String range && range.matches("[0-9]+-[0-9]+")) {
            try {
                String[] parts = range.split("-");
                int min = Integer.parseInt(parts[0]), max = Integer.parseInt(parts[1]);
                if (min >= 1 && min <= max && max <= 64) return new int[] {min, max};
            } catch (NumberFormatException ignored) { }
        }
        throw bad(path, "1..64整数或递增的min-max范围");
    }
    private static Material material(Object raw, String path, boolean block, BiPredicate<Material, Boolean> materialType) {
        Material material = raw instanceof String name ? Material.matchMaterial(name) : null;
        if (material == null || !materialType.test(material, block))
            throw bad(path, block ? "原版方块材料" : "原版物品材料");
        return material;
    }
    private static boolean bool(Object raw, String path) {
        if (!(raw instanceof Boolean value)) throw bad(path, "true或false"); return value;
    }
    private static int integer(Object raw, String path, int min, int max) {
        double value = number(raw, path, min, max);
        if (value != Math.rint(value)) throw bad(path, min + ".." + max + "整数"); return (int) value;
    }
    private static double number(Object raw, String path, double min, double max) {
        if (!(raw instanceof Number number) || !Double.isFinite(number.doubleValue()) || number.doubleValue() < min || number.doubleValue() > max)
            throw bad(path, min + ".." + max + "有限数值");
        return number.doubleValue();
    }
    private static IllegalArgumentException bad(String path, String expected) {
        return new IllegalArgumentException("loot.yml:" + path + " 必须为" + expected);
    }
}
