package net.liplugins.liskills.internal.manager;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.config.PassiveDefinition;
import org.bukkit.entity.Player;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/** 统一能力访问和资格判断；行为由不同业务监听器实现。 */
public final class PassiveAbilityManager {
    private final ConfigManager config;
    private final ProfileManager profiles;
    private final SkillManager skills;
    public PassiveAbilityManager(ConfigManager config,ProfileManager profiles,SkillManager skills) {
        this.config=config;this.profiles=profiles;this.skills=skills;
    }
    public PassiveDefinition definition(String id) { return config.passives().get(id); }
    private int skillLevel(Player player,PassiveDefinition definition) {
        if(!config.progressionEnabled() || player==null || !player.isOnline() || player.isDead() || definition==null
                || !definition.enabled() || !skills.eligible(player) || !player.hasPermission("liskills.skill."+definition.skill()))return 0;
        var profile=profiles.get(player.getUniqueId()); var skill=config.skill(definition.skill());
        return profile==null || skill==null || !skill.enabled()?0:Math.min(profile.progress(skill.id()).level(),skill.maxLevel());
    }
    public int level(Player player,String id) { var d=definition(id);return d==null?0:d.level(skillLevel(player,d)); }
    public boolean enabled(Player player,String id) { return level(player,id)>0; }
    public double value(Player player,String id) { var d=definition(id);return d==null?0:d.value(skillLevel(player,d)); }
    public double secondary(Player player,String id) { var d=definition(id);return d==null?0:d.secondary(skillLevel(player,d)); }
    public double option(String id,String key,double fallback) { var d=definition(id);return d==null?fallback:d.numberOption(key,fallback); }
    public boolean flag(String id,String key,boolean fallback) { var d=definition(id);return d==null?fallback:d.booleanOption(key,fallback); }
    public List<String> strings(String id,String key) { var d=definition(id);return d==null?List.of():d.stringListOption(key); }
    public boolean roll(Player player,String id) { return ThreadLocalRandom.current().nextDouble(100)<Math.clamp(value(player,id),0,100); }
}
