package net.liplugins.liskills.internal.manager.passive.gathering;

import net.liplugins.liskills.lib.scheduler.TaskScheduler;
import org.bukkit.entity.Entity;
import org.bukkit.event.Event;
import org.bukkit.plugin.java.JavaPlugin;
import java.util.*;

/** 有界次 tick 事务；实际玩家回调始终在所属实体区域执行。 */
final class GatheringTasks implements AutoCloseable {
    private static final int MAX_PENDING = 4096;
    private final java.util.concurrent.atomic.AtomicInteger pending = new java.util.concurrent.atomic.AtomicInteger();
    private final Map<Event, Long> seen = new IdentityHashMap<>();
    private final Map<UUID, Long> sources = new HashMap<>();
    private TaskScheduler scheduler;
    private long tick;
    void start(JavaPlugin plugin) { scheduler = new TaskScheduler(plugin); scheduler.globalTimer(this::tick, 1, 1); }
    synchronized boolean claim(Event event) {
        if (seen.containsKey(event) || seen.size() >= MAX_PENDING * 2) return false;
        seen.put(event, tick + 4); return true;
    }
    boolean defer(Entity owner, Runnable action) {
        return defer(owner, action, () -> { });
    }
    boolean defer(Entity owner, Runnable action, Runnable retired) {
        if (pending.incrementAndGet() > MAX_PENDING) { pending.decrementAndGet(); return false; }
        scheduler.entity(owner, () -> { try { action.run(); } finally { pending.decrementAndGet(); } },
                () -> { try { retired.run(); } finally { pending.decrementAndGet(); } });
        return true;
    }
    synchronized boolean claimSource(UUID identity) {
        if (sources.containsKey(identity) || sources.size() >= MAX_PENDING * 2) return false;
        sources.put(identity, tick + 40); return true;
    }
    private synchronized void tick() {
        tick++;
        seen.values().removeIf(expiry -> expiry <= tick);
        sources.values().removeIf(expiry -> expiry <= tick);
    }
    @Override public synchronized void close() {
        if (scheduler != null) scheduler.cancelAll();
        seen.clear(); sources.clear();
    }
}
