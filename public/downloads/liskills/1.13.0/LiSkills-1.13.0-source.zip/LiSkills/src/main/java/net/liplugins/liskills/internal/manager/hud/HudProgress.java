package net.liplugins.liskills.internal.manager.hud;

/** 外部属性数值只用于展示；非法值不传给 BossBar，也不写回玩家生命或魔力。 */
final class HudProgress {
    private HudProgress() { }

    static double value(double value) { return Double.isFinite(value) && value > 0 ? value : 0; }

    static double fraction(double current, double maximum) {
        if (!Double.isFinite(maximum) || maximum <= 0) return 0;
        return Math.clamp(value(current) / maximum, 0, 1);
    }
}
