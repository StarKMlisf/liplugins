package net.liplugins.liskills.internal.manager.passive.gathering;

import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import java.util.Set;

/** 植物学家在最终成功消费后一tick追加饱和，不提前覆盖原版食物补充。 */
final class PlantFoodListener implements Listener {
    private static final Set<Material> FOODS = Set.of(Material.BREAD, Material.APPLE, Material.GOLDEN_APPLE,
            Material.POTATO, Material.BAKED_POTATO, Material.CARROT, Material.GOLDEN_CARROT, Material.MELON_SLICE,
            Material.PUMPKIN_PIE, Material.BEETROOT, Material.BEETROOT_SOUP, Material.MUSHROOM_STEW, Material.POISONOUS_POTATO);
    private final GatheringContext context;
    PlantFoodListener(GatheringContext context) { this.context = context; }
    @EventHandler(priority = EventPriority.MONITOR)
    public void consume(PlayerItemConsumeEvent event) {
        if (!FOODS.contains(event.getItem().getType()) || !context.tasks().claim(event)) return;
        var actor = context.capture(event.getPlayer(), "farming");
        if (actor == null || context.passives().value(actor.player(), "geneticist") <= 0) return;
        context.tasks().defer(actor.player(), () -> {
            if (event.isCancelled() || !context.valid(actor) || !FOODS.contains(event.getItem().getType())) return;
            double value = context.passives().value(actor.player(), "geneticist");
            actor.player().setSaturation(GatheringRules.saturation(actor.player().getSaturation(), actor.player().getFoodLevel(), value));
        });
    }
}
