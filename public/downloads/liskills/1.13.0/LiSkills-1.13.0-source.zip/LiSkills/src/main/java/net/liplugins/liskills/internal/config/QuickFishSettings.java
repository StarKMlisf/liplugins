package net.liplugins.liskills.internal.config;

/** 快速咬钩仅缩放后续原生等待区间，不改钓获概率、宝藏或经验。 */
public record QuickFishSettings(double waitMultiplier, int minimumWaitTicks) { }
