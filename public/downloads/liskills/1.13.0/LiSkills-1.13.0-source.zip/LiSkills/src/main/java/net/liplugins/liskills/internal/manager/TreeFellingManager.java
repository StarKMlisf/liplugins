package net.liplugins.liskills.internal.manager;

import net.liplugins.liskills.lib.scheduler.ServerThreads;
import net.liplugins.liskills.lib.scheduler.TaskScheduler;

import net.liplugins.liskills.internal.config.ActiveSkill;
import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.config.SkillDefinition;
import net.liplugins.liskills.internal.hook.LiRealEnchantHook;
import net.liplugins.liskills.internal.listener.PlacedBlockTracker;
import net.liplugins.liskills.internal.storage.PlayerProfile;
import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** 管理砍树生效窗口与公平轮转的有限工作队列，不直接发放经验或物品。 */
public final class TreeFellingManager implements Listener, AutoCloseable {
    private final ConfigManager config;
    private final ProfileManager profiles;
    private final SkillManager skills;
    private final LiRealEnchantHook lre;
    private final TextService text;
    private final PlacedBlockTracker placed;
    private final TreePlanner planner;
    private final java.util.function.Predicate<Block> customBlock;
    private final Map<UUID, Window> windows = new java.util.concurrent.ConcurrentHashMap<>();
    private final Map<UUID, Job> jobs = new java.util.concurrent.ConcurrentHashMap<>();
    private final java.util.concurrent.ConcurrentLinkedDeque<UUID> order = new java.util.concurrent.ConcurrentLinkedDeque<>();
    private final Set<UUID> breaking = java.util.concurrent.ConcurrentHashMap.newKeySet();
    private final TaskScheduler scheduler;
    private volatile boolean closed;

    public TreeFellingManager(JavaPlugin plugin, ConfigManager config, ProfileManager profiles, SkillManager skills,
                              LiRealEnchantHook lre, TextService text) {
        this(plugin, config, profiles, skills, lre, text, new PlacedBlockTracker(plugin));
    }

    public TreeFellingManager(JavaPlugin plugin, ConfigManager config, ProfileManager profiles, SkillManager skills,
                              LiRealEnchantHook lre, TextService text, PlacedBlockTracker placed) {
        this(plugin, config, profiles, skills, lre, text, placed, block -> false);
    }

    public TreeFellingManager(JavaPlugin plugin, ConfigManager config, ProfileManager profiles, SkillManager skills,
                              LiRealEnchantHook lre, TextService text, PlacedBlockTracker placed,
                              java.util.function.Predicate<Block> customBlock) {
        this.config = config;
        this.profiles = profiles;
        this.skills = skills;
        this.lre = lre;
        this.text = text;
        this.placed = placed;
        this.planner = new TreePlanner(placed);
        this.customBlock = customBlock;
        scheduler = new TaskScheduler(plugin);
        scheduler.globalTimer(this::tick, 1L, 1L);
    }

    public boolean activate(Player player, ActiveSkill active) {
        if (closed || !ServerThreads.owns(player) || !allowed(player)) return false;
        if (!isAxe(player.getInventory().getItemInMainHand())) {
            text.send(player, "ability.tree-tool");
            return false;
        }
        if (lre.ownsTreeBreaking(player.getInventory().getItemInMainHand())) {
            text.send(player, "ability.tree-lre-owned");
            return false;
        }
        Window existing = windows.get(player.getUniqueId());
        if (existing != null && existing.expires > System.currentTimeMillis()) {
            text.send(player, "ability.tree-already-active");
            return false;
        }
        windows.put(player.getUniqueId(), new Window(player.getWorld().getUID(), System.currentTimeMillis() + active.durationSeconds() * 1000L, config.revision()));
        return true;
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        if (closed || !ServerThreads.owns(player) || !ServerThreads.owns(event.getBlock())) return;
        UUID uuid = player.getUniqueId();
        // LRE 保护检查还没有实际破坏；自己的二次破坏也不得再开启一棵树的任务。
        if (breaking.contains(uuid) || lre.checkingSecondaryBreak() || jobs.containsKey(uuid)) return;
        Window window = windows.get(uuid);
        if (!validWindow(player, window) || lre.ownsTreeBreaking(player.getInventory().getItemInMainHand())) return;
        if (!isAxe(player.getInventory().getItemInMainHand())) return;
        Block origin = event.getBlock();
        if (customBlock.test(origin)) return;
        String family = TreePlanner.family(origin.getType());
        if (family == null || placed.contains(origin)) return;
        List<TreeTraversal.Position> positions = planner.plan(origin, config.treeFelling());
        if (positions.size() < 2) return;
        Job job = new Job(event, family, placed.stamp(origin), positions.subList(1, positions.size()),
                toolIdentity(player.getInventory().getItemInMainHand()), player.getInventory().getHeldItemSlot());
        jobs.put(uuid, job);
        order.addLast(uuid);
    }

    private void tick() {
        long now = System.currentTimeMillis();
        windows.entrySet().removeIf(entry -> entry.getValue().expires <= now || entry.getValue().revision != config.revision());
        int budget = config.treeFelling().blocksPerTick();
        int participants = Math.min(budget, order.size());
        int remaining = budget;
        // 全局只分配有限预算；玩家工具、方块和事件只能交给该玩家所属区域访问。
        for (int attempts = 0; attempts < participants && !order.isEmpty(); attempts++) {
            UUID uuid = order.pollFirst();
            if (uuid == null) break;
            Job job = jobs.get(uuid);
            Player player = Bukkit.getPlayer(uuid);
            if (job == null) continue;
            if (player == null) { stop(uuid); continue; }
            int allowance = Math.max(1, remaining / (participants - attempts));
            remaining -= allowance;
            scheduler.entityNow(player, () -> {
                for (int count = 0; count < allowance && jobs.get(uuid) == job; count++) process(player, uuid, job);
                if (!closed && jobs.get(uuid) == job) order.addLast(uuid);
            }, () -> stop(uuid));
        }
    }

    private void process(Player player, UUID uuid, Job job) {
            if (closed || jobs.get(uuid) != job || !ServerThreads.owns(player)) return;
            if (!validWindow(player, windows.get(uuid)) || !sameTool(player, job)
                    || lre.ownsTreeBreaking(player.getInventory().getItemInMainHand())) {
                jobs.remove(uuid);
                return;
            }
            if (!job.started) {
                job.started = true;
                // 允许后续优先级取消原事件；原始方块未真正改变时，不触发额外破坏。
                if (!ServerThreads.owns(job.trigger.getBlock()) || !placed.unchanged(job.trigger.getBlock(), job.stamp) || !originalSucceeded(job.trigger)) {
                    jobs.remove(uuid);
                    return;
                }
            }
            TreeTraversal.Position position = job.positions.pollFirst();
            if (position == null) { jobs.remove(uuid); return; }
            World world = player.getWorld();
            Block block = TreePlanner.loadedBlock(world, position);
            // 自定义作物/盆栽可能使用原版木头作为模型，禁止连锁工具代替其专属收获流程。
            if (block == null || customBlock.test(block)) { jobs.remove(uuid); return; }
            if (block != null && job.family.equals(TreePlanner.family(block.getType())) && !placed.contains(block)) {
                breaking.add(uuid);
                try {
                    // Bukkit 完整玩家破坏链路负责领地检查、工具耐久、掉落及统一经验事件。
                    if (!player.breakBlock(block)) {
                        // 保护拒绝后停止这棵树，不能沿预先排队的节点继续穿过被拒绝的树干。
                        jobs.remove(uuid);
                        return;
                    }
                } catch (RuntimeException failure) {
                    jobs.remove(uuid);
                    text.send(player, "ability.tree-failed");
                    return;
                } finally {
                    breaking.remove(uuid);
                }
            }
            if (jobs.get(uuid) != job) return;
            if (job.positions.isEmpty()) jobs.remove(uuid);
    }

    private boolean allowed(Player player) {
        SkillDefinition definition = config.skill("foraging");
        PlayerProfile profile = profiles.get(player.getUniqueId());
        return !player.isDead() && skills.eligible(player) && player.hasPermission("liskills.skill.foraging")
                && profile != null && definition != null && definition.enabled()
                && definition.active().enabled() && definition.active().type().equals("TREECAPITATOR")
                && profile.progress("foraging").level() >= definition.active().unlockLevel();
    }

    private boolean validWindow(Player player, Window window) {
        return window != null && window.expires > System.currentTimeMillis() && window.revision == config.revision()
                && window.world.equals(player.getWorld().getUID()) && allowed(player);
    }

    private boolean sameTool(Player player, Job job) {
        return player.getInventory().getHeldItemSlot() == job.slot && isAxe(player.getInventory().getItemInMainHand())
                && job.tool.isSimilar(toolIdentity(player.getInventory().getItemInMainHand()));
    }

    private ItemStack toolIdentity(ItemStack tool) {
        ItemStack copy = tool.clone();
        ItemMeta meta = copy.getItemMeta();
        if (meta instanceof Damageable damage) { damage.setDamage(0); copy.setItemMeta(meta); }
        return copy;
    }

    private static boolean isAxe(ItemStack tool) { return tool.getType().name().endsWith("_AXE"); }

    static boolean originalSucceeded(BlockBreakEvent event) {
        // 材料变成石头或另一种木头不等于真正破坏；只接受原位置已清空的保守条件。
        Material material = event.getBlock().getType();
        return !event.isCancelled() && (material == Material.AIR || material == Material.CAVE_AIR || material == Material.VOID_AIR);
    }

    @EventHandler public void onQuit(PlayerQuitEvent event) { stop(event.getPlayer().getUniqueId()); }
    @EventHandler public void onDeath(PlayerDeathEvent event) { stop(event.getEntity().getUniqueId()); }
    @EventHandler public void onWorldChange(PlayerChangedWorldEvent event) { stop(event.getPlayer().getUniqueId()); }

    private void stop(UUID uuid) { windows.remove(uuid); jobs.remove(uuid); order.remove(uuid); }

    @Override public void close() { closed = true; scheduler.cancelAll(); windows.clear(); jobs.clear(); order.clear(); breaking.clear(); }

    private record Window(UUID world, long expires, long revision) { }
    private static final class Job {
        private final BlockBreakEvent trigger;
        private final String family;
        private final long stamp;
        private final ArrayDeque<TreeTraversal.Position> positions;
        private final ItemStack tool;
        private final int slot;
        private boolean started;
        private Job(BlockBreakEvent trigger, String family, long stamp, List<TreeTraversal.Position> positions, ItemStack tool, int slot) {
            this.trigger = trigger; this.family = family; this.stamp = stamp;
            this.positions = new ArrayDeque<>(positions); this.tool = tool; this.slot = slot;
        }
    }
}
