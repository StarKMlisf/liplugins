package net.liplugins.liskills.internal.config;

import java.util.Set;

public record Settings(double xpMultiplier, int autosaveSeconds, boolean survivalOnly,
                       Set<String> disabledWorlds, boolean preventPlacedBlocks, boolean naturalMobsOnly,
                       int damageCooldownSeconds, double maxAward, double fightingBonusPerLevel,
                       double archeryBonusPerLevel, double defenseReductionPerLevel,
                       double maxDamageBonus, double maxDamageReduction) {
    public Settings { disabledWorlds = Set.copyOf(disabledWorlds); }
}
