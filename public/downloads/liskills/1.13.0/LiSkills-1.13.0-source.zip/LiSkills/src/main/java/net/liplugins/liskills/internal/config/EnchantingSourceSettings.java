package net.liplugins.liskills.internal.config;

import org.bukkit.configuration.ConfigurationSection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** 附魔台、铁砧和砂轮只按真实完成交易结算，来源金额独立于旧固定经验。 */
public record EnchantingSourceSettings(boolean enabled,boolean ignoreCustomItems,double experienceMultiplier,double maximumXpPerMinute,
                                       int actionCooldownTicks,int maximumLevelsPerAction,Set<String> blockedGrindstoneEnchants,
                                       Map<String,Double> experience) {
    public static final List<String> SOURCES=List.of("table.weapon","table.armor","table.tool","table.book",
            "anvil.weapon","anvil.armor","anvil.tool","anvil.book","grindstone");
    public EnchantingSourceSettings { experience=Map.copyOf(experience);blockedGrindstoneEnchants=Set.copyOf(blockedGrindstoneEnchants); }
    public double xp(String source){return experience.getOrDefault(source,0.0)*experienceMultiplier;}
    public static EnchantingSourceSettings parse(ConfigurationSection section) {
        if(section==null)throw ConfigValues.invalid("enchanting","附魔来源配置节");
        Map<String,Double> values=new LinkedHashMap<>();
        for(String source:SOURCES)values.put(source,ConfigValues.number(section,"experience."+source,0,1e9));
        Object raw=section.get("blocked-grindstone-enchants");
        if(!(raw instanceof List<?> list) || list.stream().anyMatch(v->!(v instanceof String s) || !s.matches("(?:[a-z0-9_.-]+:)?[a-z0-9_/.-]+")))
            throw ConfigValues.invalid("blocked-grindstone-enchants","附魔标识符列表");
        return new EnchantingSourceSettings(ConfigValues.bool(section,"enabled"),ConfigValues.bool(section,"ignore-custom-items"),
                ConfigValues.number(section,"experience-multiplier",0,100),ConfigValues.number(section,"maximum-xp-per-minute",1,1e9),
                ConfigValues.integer(section,"action-cooldown-ticks",0,1200),ConfigValues.integer(section,"maximum-levels-per-action",1,1000),
                Set.copyOf(section.getStringList("blocked-grindstone-enchants")),values);
    }
}
