package net.liplugins.liskills.internal.manager.source;

import java.util.List;

/** 延后倒塌的原捕获植物列：只接受从根连续移除，不把后续新内容纳入事务。 */
public final class PlantColumnProgress {
    private final int size;
    private int attempts,removed;
    public PlantColumnProgress(int size) { if(size<2 || size>256)throw new IllegalArgumentException("column size");this.size=size; }
    public Decision observe(List<State> states) {
        attempts++;
        if(states.size()!=size || states.getFirst()!=State.REMOVED || states.contains(State.INVALID))return new Decision(true,0);
        int prefix=0;
        while(prefix<size && states.get(prefix)==State.REMOVED)prefix++;
        // 已消失的位置重新出现，或上段先于仍存活的下段消失，都不能当作原根引起的倒塌。
        if(prefix<removed || states.subList(prefix,size).contains(State.REMOVED))return new Decision(true,0);
        removed=prefix;
        return new Decision(prefix==size || attempts>=size+2,prefix);
    }
    public enum State { ORIGINAL,REMOVED,INVALID }
    public record Decision(boolean finished,int confirmedParts) { }
}
