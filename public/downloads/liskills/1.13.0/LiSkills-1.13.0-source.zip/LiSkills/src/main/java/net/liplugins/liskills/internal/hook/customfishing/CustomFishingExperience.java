package net.liplugins.liskills.internal.hook.customfishing;

import net.liplugins.liskills.lib.scheduler.ServerThreads;
import net.liplugins.liskills.lib.scheduler.TaskScheduler;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.manager.ProfileManager;
import net.liplugins.liskills.internal.manager.SkillManager;
import net.liplugins.liskills.internal.storage.PlayerProfile;
import net.liplugins.liskills.lib.customfishing.CustomFishingAccess;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** 成功结算独立排队，下一 tick 读取最终取消状态；一钩只结算一次、不乘多掉落数量。 */
final class CustomFishingExperience {
    private static final int MAX_PENDING = 1024;
    private final ConfigManager config;
    private final SkillManager skills;
    private final ProfileManager profiles;
    private final CustomFishingAccess access;
    private final Map<UUID, Pending> pending = new java.util.concurrent.ConcurrentHashMap<>();
    private final TaskScheduler scheduler;
    private final java.util.function.Consumer<Throwable> failure;
    private volatile long generation;
    private final CustomFishingClaims<UUID> settled = new CustomFishingClaims<>(4096, 300_000L);
    private final Set<Event> seenEvents = java.util.Collections.synchronizedSet(java.util.Collections.newSetFromMap(new java.util.WeakHashMap<>()));

    CustomFishingExperience(ConfigManager config, SkillManager skills, ProfileManager profiles, CustomFishingAccess access,
                            TaskScheduler scheduler, java.util.function.Consumer<Throwable> failure) {
        this.config = config; this.skills = skills; this.profiles = profiles; this.access = access;
        this.scheduler = scheduler; this.failure = failure;
    }
    void observe(Event event, CustomFishingAccess.ResultView view) {
        // 保留弱引用身份记录：已取消事件后来被重复派发，也不能冒充另一笔成功结果。
        if (seenEvents.contains(event) || seenEvents.size() >= 4096 || !seenEvents.add(event)
                || !view.success() || view.hook() == null || !config.customFishing().enabled()) return;
        Player player = view.player();
        if (!ServerThreads.owns(player)) return;
        UUID hook = view.hook().getUniqueId();
        PlayerProfile profile = profiles.get(player.getUniqueId());
        if (profile == null || !player.isOnline() || pending.containsKey(hook)
                || settled.contains(hook, System.currentTimeMillis()) || pending.size() >= MAX_PENDING) return;
        pending.put(hook, new Pending(event, player, profile, player.getWorld().getUID(), config.revision()));
    }
    void tick() throws ReflectiveOperationException {
        // 先移出队列，奖励前又先占用成功记录，阻止经验监听器同步重入。
        long now = System.currentTimeMillis();
        settled.clean(now);
        for (var entry : pending.entrySet()) {
            Pending item = entry.getValue();
            if (!pending.remove(entry.getKey(), item)) continue;
            long expectedGeneration = generation;
            scheduler.entityNow(item.player(), () -> {
                if (expectedGeneration != generation) return;
                try { settle(entry.getKey(), item); }
                catch (ReflectiveOperationException | RuntimeException | LinkageError error) { failure.accept(error); }
            });
        }
    }
    private void settle(UUID hook, Pending item) throws ReflectiveOperationException {
            long now=System.currentTimeMillis();
            Player player = item.player();
            if (((Cancellable) item.event()).isCancelled() || !config.customFishing().enabled()
                    || config.revision() != item.revision() || !player.isOnline() || !player.isValid()
                    || !player.getWorld().getUID().equals(item.world()) || profiles.get(player.getUniqueId()) != item.profile()) return;
            var result = access.result(item.event());
            if (!result.success() || result.amount() <= 0 || result.lootId() == null || result.lootId().isBlank()
                    || result.hook() == null || !hook.equals(result.hook().getUniqueId())
                    || result.player() != player || !settled.claim(hook, now)) return;
            skills.award(player, "fishing", config.customFishing().xp(result.lootId()));
    }
    void clear() { generation++; pending.clear(); settled.clear(); seenEvents.clear(); }
    private record Pending(Event event, Player player, PlayerProfile profile, UUID world, long revision) { }
}
