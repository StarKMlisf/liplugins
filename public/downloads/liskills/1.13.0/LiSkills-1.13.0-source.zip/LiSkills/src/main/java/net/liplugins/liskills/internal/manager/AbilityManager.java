package net.liplugins.liskills.internal.manager;

import net.liplugins.liskills.internal.config.ActiveSkill;
import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.config.SkillDefinition;
import net.liplugins.liskills.internal.manager.source.SorceryManaExperienceSource;
import net.liplugins.liskills.internal.storage.PlayerProfile;
import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.Bukkit;
import net.liplugins.liskills.lib.scheduler.ServerThreads;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Map;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import java.util.function.DoubleConsumer;
import java.util.function.DoubleSupplier;

/** 配置化主动能力执行器；冷却直接保存到玩家资料，不依赖内存倒计时任务。 */
public final class AbilityManager {
    private final ConfigManager config;
    private final ProfileManager profiles;
    private final SkillManager skills;
    private final TextService text;
    private final Map<String, ActiveAbilityHandler> handlers;
    private final SorceryManaExperienceSource sorcery;
    private final Set<UUID> activating = java.util.concurrent.ConcurrentHashMap.newKeySet();

    public AbilityManager(JavaPlugin plugin, ConfigManager config, ProfileManager profiles, SkillManager skills, TextService text) {
        this(plugin, config, profiles, skills, text, Map.of("POTION", new PotionAbilityHandler(text)));
    }

    public AbilityManager(JavaPlugin plugin, ConfigManager config, ProfileManager profiles, SkillManager skills, TextService text, TreeFellingManager treeFelling) {
        this(plugin,config,profiles,skills,text,treeFelling==null
                ? Map.of("POTION",new PotionAbilityHandler(text))
                : Map.of("POTION",new PotionAbilityHandler(text),"TREECAPITATOR",treeFelling::activate));
    }

    public AbilityManager(JavaPlugin plugin, ConfigManager config, ProfileManager profiles, SkillManager skills,
                          TextService text, Map<String, ActiveAbilityHandler> handlers) {
        this.config = config;
        this.profiles = profiles;
        this.skills = skills;
        this.text = text;
        this.handlers = Map.copyOf(handlers);
        this.sorcery = new SorceryManaExperienceSource(plugin,config,profiles,skills);
    }

    public boolean activate(Player player, String id) {
        return activate(player,id,true);
    }

    /** 自动准备的吸收窗口可能退激活费，调用方必须在最终确认后提交独立经验凭据。 */
    public boolean activateWithoutManaExperience(Player player,String id) {
        return activate(player,id,false);
    }

    private boolean activate(Player player,String id,boolean grantManaExperience) {
        if (!ServerThreads.owns(player)) return false;
        // 药水事件等外部回调不得在本次消费完成前重入另一次激活。
        if (!activating.add(player.getUniqueId())) {
            text.send(player, "ability.busy");
            return false;
        }
        try {
            return activateOnce(player, id,grantManaExperience);
        } finally {
            activating.remove(player.getUniqueId());
        }
    }

    private boolean activateOnce(Player player, String id,boolean grantManaExperience) {
        SkillDefinition definition = config.skill(id);
        if (definition == null || !definition.enabled() || definition.active() == null || !definition.active().enabled()) {
            text.send(player, "ability.unavailable");
            return false;
        }
        if (!player.hasPermission("liskills.use") || !player.hasPermission("liskills.skill." + id)) {
            text.send(player, "ability.no-permission");
            return false;
        }
        if (player.isDead() || !skills.eligible(player)) {
            text.send(player, "ability.blocked");
            return false;
        }
        PlayerProfile profile = profiles.get(player.getUniqueId());
        if (profile == null) {
            text.send(player, "ability.loading");
            return false;
        }
        ActiveSkill active = ActiveSkillProgression.resolve(config,definition,profile);
        ActiveAbilityHandler handler=handlers.get(active.type());
        if(handler==null){text.send(player,"ability.unavailable");return false;}
        if (profile.progress(id).level() < active.unlockLevel()) {
            text.send(player, "ability.locked", Map.of("level", active.unlockLevel()));
            return false;
        }
        long now = System.currentTimeMillis();
        long remaining = profile.cooldown(id) - now;
        if (handler.startsActivationCooldown() && remaining > 0) {
            text.send(player, "ability.cooldown", Map.of("seconds", (remaining + 999L) / 1000L));
            return false;
        }
        if(handler.consumesActivationMana() && !ManaManager.canAfford(profile,config,active.manaCost())) {
            text.send(player,"ability.not-enough-mana",Map.of("current",text.format(ManaManager.available(profile,config)),"cost",text.format(active.manaCost())));
            return false;
        }
        if (active.durationSeconds() <= 0 || active.cooldownSeconds() < 0) {
            text.send(player, "ability.invalid");
            return false;
        }
        // 在可能触发外部回调的效果执行前预留魔力，防止回调先花掉余额而获得免费效果。
        // 失败只退回本次预留额，不恢复旧快照，保留回调中发生的其他合法魔力变化。
        double reserved = config.mana().enabled() && handler.consumesActivationMana() ? active.manaCost() : 0;
        var experience=grantManaExperience?sorcery.capture(player,reserved):null;
        try (ManaReservation reservation = new ManaReservation(reserved,
                () -> ManaManager.available(profile, config), () -> ManaManager.maximum(profile, config), profile::mana,
                () -> {if(handler.consumesActivationMana())ManaManager.spend(profile, config, active.manaCost());})) {
            if (!handler.activate(player, active)) return false;
            reservation.commit();
            if(handler.startsActivationCooldown())profile.cooldown(id, now + active.cooldownSeconds() * 1000L);
            if(handler.usesStandardActivationMessage())text.send(player, "ability.activated", Map.of("ability", text.plain(active.name()), "seconds", active.durationSeconds()));
            sorcery.complete(experience);
            return true;
        }
    }

    public SorceryManaExperienceSource.Receipt captureManaExperience(Player player,double consumedMana) {
        return sorcery.capture(player,consumedMana);
    }
    public void completeManaExperience(SorceryManaExperienceSource.Receipt receipt) { sorcery.complete(receipt); }

    public long remainingMillis(Player player,String id) {
        if(!ServerThreads.owns(player))return 0;
        var definition=config.skill(id);
        if(definition==null)return 0;
        var handler=handlers.get(definition.active().type());
        return handler==null?0:handler.remainingMillis(player);
    }

    public void close() {
        activating.clear();
        sorcery.close();
        // Bukkit 管理药水生命周期；注入的 TreeFellingManager 由运行时统一关闭。
    }

    /** 一次性的预留凭据；失败退款读取当前余额/上限，兼容效果回调中重载魔力配置。 */
    public static final class ManaReservation implements AutoCloseable {
        private final double reserved;
        private final DoubleSupplier available;
        private final DoubleSupplier maximum;
        private final DoubleConsumer write;
        private boolean committed;
        private boolean closed;

        public ManaReservation(double reserved, DoubleSupplier available, DoubleSupplier maximum, DoubleConsumer write, Runnable reserve) {
            this.reserved = reserved;
            this.available = available;
            this.maximum = maximum;
            this.write = write;
            reserve.run();
        }

        public void commit() { committed = true; }

        @Override public void close() {
            if (closed) return;
            closed = true;
            if (!committed && reserved > 0) write.accept(Math.min(maximum.getAsDouble(), available.getAsDouble() + reserved));
        }
    }
}
