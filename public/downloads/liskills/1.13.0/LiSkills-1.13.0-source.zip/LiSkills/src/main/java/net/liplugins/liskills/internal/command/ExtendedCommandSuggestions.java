package net.liplugins.liskills.internal.command;

import net.liplugins.liskills.internal.config.*;
import net.liplugins.liskills.internal.manager.item.ItemMetadataService;
import org.bukkit.Bukkit;
import net.liplugins.liskills.lib.scheduler.ServerThreads;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import java.util.*;

/** 扩展指令的只读补全；玩家列表仍尊重隐身可见性，规则来自手持物品公开标签。 */
final class ExtendedCommandSuggestions {
    private final ItemMetadataService metadata=new ItemMetadataService();
    List<String> options(ConfigManager config,CommandSender sender,String[] args){
        String name=args[0].toLowerCase(Locale.ROOT);int length=args.length;
        List<String> skills=config.skills().values().stream().filter(SkillDefinition::enabled).map(SkillDefinition::id).sorted().toList();
        if(name.equals("top")||name.equals("rank")){
            if(length==2){var result=new ArrayList<>(skills);result.add("total");return result;}
            return name.equals("top")&&length==3?List.of("1","2","3"):List.of();
        }
        if(name.equals("jobs")){
            if(length==2)return List.of("list","join","leave");
            if(length!=3)return List.of();
            if(args[1].equalsIgnoreCase("leave")&&sender instanceof Player player)return new net.liplugins.liskills.internal.manager.jobs.JobSelectionStore().read(player).skills().stream().sorted().toList();
            return args[1].equalsIgnoreCase("join")?skills:List.of();
        }
        if(name.equals("modifier")){
            if(length==2)return List.of("list","set","remove");if(length==3)return visiblePlayers(sender);
            if(length==4){
                if(args[1].equalsIgnoreCase("remove")){var player=Bukkit.getPlayerExact(args[2]);return player!=null&&ServerThreads.owns(player)&&(!(sender instanceof Player viewer)||viewer.canSee(player))?new net.liplugins.liskills.internal.manager.stat.PlayerModifierManager().entries(player).keySet().stream().sorted().toList():List.of();}
                return args[1].equalsIgnoreCase("set")?List.of("quest_reward","rank_bonus"):List.of();
            }
            if(!args[1].equalsIgnoreCase("set"))return List.of();if(length==5)return StatsSettings.IDS;
            return length==6?List.of("0","1","5","-1"):List.of();
        }
        if(!name.equals("item"))return null;
        if(length==2)return List.of("inspect","identify","stat","trait","xp","require","remove","clear","legacy-preview","legacy-migrate");
        String operation=args[1];
        if(length==3){
            if(operation.equals("identify"))return List.of("mining_pickaxe","wisdom_helmet");
            if(!Set.of("stat","trait","xp","require","remove").contains(operation))return List.of();
            var ids=new ArrayList<String>();if(sender instanceof Player player)metadata.read(player.getInventory().getItemInMainHand()).rules().forEach(rule->ids.add(rule.id()));
            if(!operation.equals("remove"))ids.add("custom_bonus");return ids;
        }
        if(length==4)return switch(operation){case "stat"->StatsSettings.IDS;case "trait"->StatsSettings.TRAITS;
            case "require"->skills;case "xp"->{var ids=new ArrayList<>(skills);ids.add("all");yield ids;}default->List.of();};
        if(operation.equals("stat")||operation.equals("trait")){
            if(length==5)return List.of("ADD","MULTIPLY","ADD_PERCENT");if(length==6)return List.of("1","2","5","10","-1");
            if(length==7)return Arrays.stream(ItemSlot.values()).map(Enum::name).toList();
        }else if(operation.equals("xp")||operation.equals("require")){
            if(length==5)return List.of("1","5","10","25");if(length==6)return Arrays.stream(ItemSlot.values()).map(Enum::name).toList();
        }
        return List.of();
    }
    static List<String> visiblePlayers(CommandSender sender){return Bukkit.getOnlinePlayers().stream().filter(player->!(sender instanceof Player viewer)||viewer.canSee(player)).map(Player::getName).toList();}
}
