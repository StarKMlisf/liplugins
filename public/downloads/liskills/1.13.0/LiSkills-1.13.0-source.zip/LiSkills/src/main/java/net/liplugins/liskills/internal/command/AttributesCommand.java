package net.liplugins.liskills.internal.command;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.config.StatsSettings;
import net.liplugins.liskills.internal.manager.ManaManager;
import net.liplugins.liskills.internal.manager.stat.StatManager;
import net.liplugins.liskills.internal.manager.stat.StatTraits;
import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.LinkedHashMap;
import java.util.Map;

/** 九属性查询与效果说明；沿用统一的在线玩家/他人查询权限检查。 */
final class AttributesCommand implements Subcommand {
    private final ConfigManager config;
    private final SenderChecks checks;
    private final TextService text;
    private final StatManager stats;

    AttributesCommand(ConfigManager config, SenderChecks checks, TextService text, StatManager stats) {
        this.config = config; this.checks = checks; this.text = text; this.stats = stats;
    }

    public String name() { return "attributes"; }
    public String permission() { return "liskills.use"; }
    public void execute(CommandSender sender, String[] arguments) {
        if (arguments.length > 1) { checks.usage(sender, "rpg-commands.usage-attributes"); return; }
        Player player = arguments.length == 0 ? checks.player(sender) : checks.online(sender, arguments[0]);
        if (player == null || (!player.equals(sender) && !checks.permission(sender, "liskills.stats.others"))) return;
        checks.onPlayer(player, () -> {
        var profile = checks.profile(sender, player);
        if (profile == null) return;
        if (!config.progressionEnabled()) { text.send(sender, "rpg-commands.disabled"); return; }
        Map<String, Double> attributes = stats == null ? StatManager.snapshotValues(profile, config) : stats.values(player);
        Map<String, Object> replacements = new LinkedHashMap<>();
        for (String trait : StatsSettings.TRAITS) {
            double amount = StatTraits.value(config.stats(), attributes, trait);
            if (trait.equals("anvil-discount") || trait.equals("damage-reduction")) amount *= 100;
            replacements.put(trait.replace('-', '_'), text.format(amount));
        }
        replacements.put("mana_total", text.format(ManaManager.maximum(profile, config)));
        replacements.put("mana_regen_total", text.format(ManaManager.regeneration(profile, config)));
        replacements.put("player", player.getName());
        text.send(sender, "rpg-commands.attributes-title", replacements);
        for (String id : StatsSettings.IDS) {
            var definition = config.stats().definitions().get(id);
            replacements.put("name", text.plain(definition.name()));
            replacements.put("value", text.format(attributes.getOrDefault(id, 0.0)));
            replacements.put("effect", text.plain(text.text("rpg-commands.effects." + id, replacements)));
            text.send(sender, "rpg-commands.attribute-line", replacements);
        }
        text.send(sender, "rpg-commands.attributes-footer");
        });
    }
}
