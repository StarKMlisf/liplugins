package net.liplugins.liskills.internal.manager.passive.combat;

import org.bukkit.entity.Player;

/** 仅在同步流血结算栈内存在，其他技能监听可避让二次伤害，击杀监听可读取归属。 */
public final class SecondaryDamageContext {
    private static final ThreadLocal<Player> SOURCE = new ThreadLocal<>();
    private SecondaryDamageContext() { }
    public static boolean active() { return SOURCE.get() != null; }
    public static Player attacker() { return SOURCE.get(); }
    public static void run(Player source, Runnable action) {
        Player previous = SOURCE.get();
        SOURCE.set(source);
        try { action.run(); }
        finally { if (previous == null) SOURCE.remove(); else SOURCE.set(previous); }
    }
}
