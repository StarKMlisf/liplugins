package net.liplugins.liskills.internal.menu;

import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.Material;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Map;

/** 菜单物品只从消息配置获取名称和说明。 */
final class MenuItems {
    private final TextService text;
    MenuItems(TextService text) { this.text = text; }

    ItemStack item(Material material, String name, String lore, Map<String, ?> values) {
        ItemStack stack = new ItemStack(material == null || !material.isItem() || material.isAir() ? Material.PAPER : material);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(text.text(name, values));
            if (lore != null) meta.setLore(text.lines(lore, values));
            meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
            stack.setItemMeta(meta);
        }
        return stack;
    }
}
