package net.liplugins.liskills.internal.command;

import java.util.List;

/** HUD 子指令的补全与执行分离；只接收一个操作参数。 */
final class HudCommandSuggestions {
    static final List<String> ACTIONS=List.of("on","off","toggle","status");
    private HudCommandSuggestions(){ }
    static List<String> options(String[] arguments) {
        return arguments.length==2?ACTIONS:List.of();
    }
}
