package net.liplugins.liskills.internal.manager.storage;

import net.liplugins.liskills.internal.storage.ProfileSnapshot;
import net.liplugins.liskills.internal.storage.ProfileStore;
import java.nio.file.*;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.Supplier;

/** 只导出技能档案快照；固定目录、随机新目录，不覆盖任何历史导出或在线数据。 */
public final class ProfileExportManager implements AutoCloseable {
    private final Path directory;private final Supplier<CompletableFuture<List<ProfileSnapshot>>> source;
    private final ExecutorService io=Executors.newSingleThreadExecutor(r->{Thread thread=new Thread(r,"LiSkills-export");thread.setDaemon(true);return thread;});
    private final java.util.concurrent.atomic.AtomicBoolean running=new java.util.concurrent.atomic.AtomicBoolean();
    private volatile boolean closed;
    public record Result(Path directory,int profiles) { }
    public ProfileExportManager(Path directory,Supplier<CompletableFuture<List<ProfileSnapshot>>> source){this.directory=directory;this.source=source;}
    public CompletableFuture<Result> export(){
        if(closed||!running.compareAndSet(false,true))return CompletableFuture.failedFuture(new IllegalStateException("export busy"));
        try{return source.get().thenApplyAsync(this::write,io).whenComplete((result,error)->running.set(false));}
        catch(RuntimeException error){running.set(false);return CompletableFuture.failedFuture(error);}
    }
    private Result write(List<ProfileSnapshot> snapshots){
        try{
            Files.createDirectories(directory);Path target=directory.resolve("profiles-"+System.currentTimeMillis()+"-"+UUID.randomUUID());Files.createDirectory(target);
            Files.writeString(target.resolve("INCOMPLETE.txt"),"导出尚未完成，请勿恢复此目录。",StandardOpenOption.CREATE_NEW);
            ProfileStore store=new ProfileStore(target.resolve("players"));for(var snapshot:snapshots)store.save(snapshot);
            Files.writeString(target.resolve("COMPLETE.txt"),"生成时间："+Instant.now()+"\n技能档案数："+snapshots.size()+"\n包含等级、本级经验、魔力及主动冷却。\n不包含世界playerdata中的物品、职业、奖励领取标记和持久属性；完整备份必须另存世界playerdata。\n",StandardOpenOption.CREATE_NEW);
            Files.delete(target.resolve("INCOMPLETE.txt"));return new Result(target,snapshots.size());
        }catch(Exception error){throw new CompletionException(error);}
    }
    public void close(){closed=true;io.shutdown();try{io.awaitTermination(10,TimeUnit.SECONDS);}catch(InterruptedException error){Thread.currentThread().interrupt();}}
}
