package net.liplugins.liskills.internal.manager.source;

import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.Cancellable;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryEvent;
import org.bukkit.event.inventory.InventoryInteractEvent;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.inventory.InventoryView;
import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;

/** 将次tick收货证明绑定到原来的界面和输入操作，防止后续同款成品冒充上一次失败交易。 */
public final class SourceContainerChanges implements Listener,AutoCloseable {
    private final Map<InventoryView,Receipt> pending=java.util.Collections.synchronizedMap(new IdentityHashMap<>());
    public Receipt begin(InventoryEvent event) {
        Receipt previous=pending.get(event.getView());
        if(previous!=null) {
            if(previous.cause!=event) {
                if(previous.replacements.size()<32)previous.replacements.add(event);else previous.overflow=true;
            }
            return null;
        }
        if(pending.size()>=4096)return null;
        Receipt receipt=new Receipt(event);pending.put(event.getView(),receipt);return receipt;
    }
    public boolean valid(Receipt receipt) {
        return pending.get(receipt.view)==receipt && !receipt.overflow
                && receipt.view.getPlayer().getOpenInventory()==receipt.view
                && receipt.changes.stream().allMatch(InventoryInteractEvent::isCancelled)
                && receipt.replacements.stream().allMatch(event->event instanceof Cancellable cancelled && cancelled.isCancelled());
    }
    public void finish(Receipt receipt){pending.remove(receipt.view,receipt);}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void onClick(InventoryClickEvent event) {
        // 输入、结果以及从背包shift到容器均可能改变这张结果凭据；普通背包整理不干扰。
        if((event.getRawSlot()>=0 && event.getRawSlot()<=2) || event.isShiftClick() || event.getAction()==InventoryAction.COLLECT_TO_CURSOR)changed(event);
    }
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void onDrag(InventoryDragEvent event) {
        if(event.getRawSlots().stream().anyMatch(slot->slot>=0 && slot<=2))changed(event);
    }
    private void changed(InventoryInteractEvent event) {
        Receipt receipt=pending.get(event.getView());
        if(receipt==null || receipt.cause==event)return;
        // 保存事件引用，结算时才读取最终取消结果；被保护插件晚取消的输入操作不使旧凭据失效。
        if(receipt.changes.size()<32)receipt.changes.add(event);else receipt.overflow=true;
    }
    @Override public void close(){pending.clear();}
    public static final class Receipt {
        final InventoryEvent cause;final InventoryView view;final List<InventoryInteractEvent> changes=new ArrayList<>();
        final List<InventoryEvent> replacements=new ArrayList<>();boolean overflow;
        Receipt(InventoryEvent event){cause=event;view=event.getView();}
    }
}
