package net.liplugins.liskills.internal.manager;

import net.liplugins.liskills.internal.config.ActiveSkill;
import org.bukkit.entity.Player;

/** 单种主动能力的执行入口；魔力、冷却和统一权限由 AbilityManager 负责。 */
@FunctionalInterface
public interface ActiveAbilityHandler {
    boolean activate(Player player, ActiveSkill active);
    /** 只读当前窗口；默认效果由 Bukkit 管理，未提供查询时返回0。 */
    default long remainingMillis(Player player) { return 0; }
    /** 切换型能力自行在每次实际行动时结算；默认仍使用统一激活费用。 */
    default boolean consumesActivationMana(){return true;}
    default boolean startsActivationCooldown(){return true;}
    default boolean usesStandardActivationMessage(){return true;}
}
