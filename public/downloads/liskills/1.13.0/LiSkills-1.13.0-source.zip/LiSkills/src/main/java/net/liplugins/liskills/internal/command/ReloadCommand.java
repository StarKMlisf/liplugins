package net.liplugins.liskills.internal.command;

import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.command.CommandSender;

final class ReloadCommand implements Subcommand {
    private final Runnable reload;
    private final SenderChecks checks;
    private final TextService text;
    ReloadCommand(Runnable reload, SenderChecks checks, TextService text) {
        this.reload = reload; this.checks = checks; this.text = text;
    }
    public String name() { return "reload"; }
    public String permission() { return "liskills.admin"; }
    public void execute(CommandSender sender, String[] arguments) {
        if (arguments.length != 0) { checks.usage(sender, "command.usage-reload"); return; }
        checks.globally(() -> {
        try {
            reload.run();
            text.send(sender, "command.reload-success");
        } catch (RuntimeException ignored) {
            text.send(sender, "command.reload-failed");
        }
        });
    }
}
