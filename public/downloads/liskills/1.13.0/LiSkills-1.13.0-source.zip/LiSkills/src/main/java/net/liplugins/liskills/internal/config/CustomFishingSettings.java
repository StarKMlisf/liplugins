package net.liplugins.liskills.internal.config;

import java.util.Map;

/** 按成功渔获ID配置一次钓获的经验；不按掉落堆叠数量重复结算。 */
public record CustomFishingSettings(boolean enabled, double defaultXp, Map<String, Double> lootXp, boolean quickFish) {
    public CustomFishingSettings { lootXp = Map.copyOf(lootXp); }
    public double xp(String id) { return id == null || id.isBlank() ? 0 : lootXp.getOrDefault(id, defaultXp); }
}
