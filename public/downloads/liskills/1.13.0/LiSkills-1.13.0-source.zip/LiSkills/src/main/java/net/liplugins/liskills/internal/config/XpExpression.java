package net.liplugins.liskills.internal.config;

/** 只支持算术和三个数值变量的表达式，不执行脚本、反射或外部命令。 */
public final class XpExpression {
    private interface Node { double value(double level,double base,double multiplier); }
    private final Node node;
    private XpExpression(Node node){this.node=node;}
    public static XpExpression compile(String source) {
        if(source==null||source.length()>256)throw new IllegalArgumentException("经验表达式长度应为1～256");
        Parser parser=new Parser(source);Node node=parser.sum();parser.space();
        if(parser.position!=source.length())throw new IllegalArgumentException("经验表达式含不支持的字符");
        return new XpExpression(node);
    }
    public double evaluate(double level,double base,double multiplier) {
        double value=node.value(level,base,multiplier);
        if(!Double.isFinite(value)||value<=0||value>1e12)throw new IllegalArgumentException("经验需求必须大于0且不超过1000000000000");
        return value;
    }
    private static final class Parser {
        private final String source;private int position;private int depth;
        Parser(String source){this.source=source;}
        void space(){while(position<source.length()&&Character.isWhitespace(source.charAt(position)))position++;}
        boolean token(char c){space();if(position<source.length()&&source.charAt(position)==c){position++;return true;}return false;}
        Node sum(){Node left=product();for(;;){if(token('+')){Node a=left,b=product();left=(l,x,m)->a.value(l,x,m)+b.value(l,x,m);}else if(token('-')){Node a=left,b=product();left=(l,x,m)->a.value(l,x,m)-b.value(l,x,m);}else return left;}}
        Node product(){Node left=unary();for(;;){if(token('*')){Node a=left,b=unary();left=(l,x,m)->a.value(l,x,m)*b.value(l,x,m);}else if(token('/')){Node a=left,b=unary();left=(l,x,m)->a.value(l,x,m)/b.value(l,x,m);}else return left;}}
        Node unary(){if(token('+'))return unary();if(token('-')){Node a=unary();return(l,x,m)->-a.value(l,x,m);}return power();}
        Node power(){Node left=atom();if(token('^')){Node right=unary();return(l,x,m)->Math.pow(left.value(l,x,m),right.value(l,x,m));}return left;}
        Node atom(){
            space();if(++depth>32)throw new IllegalArgumentException("经验表达式嵌套过深");
            try{
                if(token('(')){Node n=sum();if(!token(')'))throw new IllegalArgumentException("经验表达式括号不配对");return n;}
                int start=position;
                while(position<source.length()&&Character.isLetter(source.charAt(position)))position++;
                if(position>start)return switch(source.substring(start,position)){
                    case "level"->(l,b,m)->l;case "base"->(l,b,m)->b;case "multiplier"->(l,b,m)->m;
                    default->throw new IllegalArgumentException("经验表达式只支持level/base/multiplier变量");};
                while(position<source.length()&&(Character.isDigit(source.charAt(position))||source.charAt(position)=='.'))position++;
                if(position==start)throw new IllegalArgumentException("经验表达式缺少数字");
                double value=Double.parseDouble(source.substring(start,position));
                if(!Double.isFinite(value))throw new IllegalArgumentException("经验表达式含非有限数字");return(l,b,m)->value;
            }finally{depth--;}
        }
    }
}
