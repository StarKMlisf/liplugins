package net.liplugins.liskills.internal.storage.migration;

import net.liplugins.liskills.internal.config.StorageSettings;
import net.liplugins.liskills.internal.storage.RecoverySnapshotStore;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/** 未解决的恢复/临时档案禁止作为迁移依据，避免复制较旧的数据库值掩盖新进度。 */
public final class MigrationDirectoryGuard {
    private MigrationDirectoryGuard(){ }
    public static void validate(Path data,StorageSettings settings)throws IOException{
        if(Files.exists(data.resolve("INCOMPLETE.txt")))throw new IOException("migration-incomplete-export");
        if(!new RecoverySnapshotStore(data.resolve("recovery")).previousSessionIds().isEmpty())throw new IOException("migration-unresolved-recovery");
        Path players=data.resolve("players");
        if(settings.type()==StorageSettings.Type.YAML&&Files.isDirectory(players))try(var paths=Files.list(players)){
            if(paths.anyMatch(path->path.getFileName().toString().matches("[0-9a-fA-F-]{36}\\.yml\\.tmp")))throw new IOException("migration-unresolved-yaml-temporary");
        }
    }
    /** 解析真实父路径后再判断，目录别名/链接也不能绕过源目录写入保护。 */
    public static Path canonical(Path path)throws IOException{
        Path absolute=path.toAbsolutePath().normalize();
        if(Files.exists(absolute))return absolute.toRealPath();
        Path parent=absolute.getParent();if(parent==null)throw new IOException("migration-path-missing");
        return canonical(parent).resolve(absolute.getFileName()).normalize();
    }
    public static void distinctPaths(Path source,Path target,Path drivers)throws IOException{
        Path from=canonical(source),to=canonical(target),cache=canonical(drivers);
        if(to.startsWith(from)||from.startsWith(to))throw new IOException("migration-source-target-overlap");
        if(cache.startsWith(from)||from.startsWith(cache))throw new IOException("migration-driver-cache-overlaps-source");
    }
}
