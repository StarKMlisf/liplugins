package net.liplugins.liskills.internal.listener;

import net.liplugins.liskills.lib.scheduler.ServerThreads;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.manager.ProfileManager;
import net.liplugins.liskills.internal.manager.SkillManager;
import net.liplugins.liskills.internal.manager.source.BlockHarvestSources;
import org.bukkit.Bukkit;
import org.bukkit.block.Block;
import org.bukkit.event.*;
import org.bukkit.event.player.PlayerHarvestBlockEvent;
import java.util.*;
import java.util.function.Predicate;

/** 成熟浆果实际采摘后结算；最终取消、状态回滚、重复事件及同tick替换均不能重复领经验。 */
public final class HarvestExperienceListener implements Listener {
    private final ConfigManager config;
    private final ProfileManager profiles;
    private final SkillManager skills;
    private final PlacedBlockTracker placed;
    private final Predicate<Block> custom;
    private final Set<PlayerHarvestBlockEvent> pending=Collections.synchronizedSet(Collections.newSetFromMap(new IdentityHashMap<>()));
    public HarvestExperienceListener(ConfigManager config,ProfileManager profiles,SkillManager skills,PlacedBlockTracker placed,Predicate<Block> custom) {
        this.config=config;this.profiles=profiles;this.skills=skills;this.placed=placed;this.custom=custom;
    }
    @EventHandler(priority=EventPriority.MONITOR)
    public void onHarvest(PlayerHarvestBlockEvent event) {
        if(!ServerThreads.owns(event.getPlayer()) || !ServerThreads.owns(event.getHarvestedBlock())
                || event.getItemsHarvested().isEmpty() || pending.size()>=4096 || !pending.add(event))return;
        Block block=event.getHarvestedBlock(); var material=block.getType(); var data=block.getBlockData().clone();
        var definition=config.skill("farming"); var player=event.getPlayer(); var profile=profiles.get(player.getUniqueId());
        if(custom.test(block) || profile==null || definition==null || !definition.enabled() || !HarvestMaturity.matureCrop(material,data)) { pending.remove(event);return; }
        Double base=definition.blocks().get(material); if(base==null) { pending.remove(event);return; }
        double xp=base*BlockHarvestSources.multiplier(material,data,config.sources()); long stamp=placed.stamp(block),revision=config.revision(); var world=player.getWorld().getUID();
        if(!placed.defer(player, ()->{
            pending.remove(event);
            if(event.isCancelled() || event.getItemsHarvested().isEmpty() || revision!=config.revision() || !placed.unchanged(block,stamp)
                    || block.getType()!=material || !HarvestMaturity.harvestedState(material,block.getBlockData()) || custom.test(block)
                    || !player.isOnline() || player.isDead() || !player.getWorld().getUID().equals(world) || profiles.get(player.getUniqueId())!=profile
                    || !skills.eligible(player) || !player.hasPermission("liskills.skill.farming") || !placed.claimExperience(block,stamp))return;
            skills.award(player,"farming",xp);
        },()->pending.remove(event)))pending.remove(event);
    }
}
