package net.liplugins.liskills.internal.config;

import org.bukkit.Material;
import org.bukkit.entity.EntityType;
import java.util.Map;

public record SkillDefinition(String id, String name, String description, Material icon, boolean enabled,
                              int maxLevel, double baseXp, double growthXp, Map<Material, Double> blocks,
                              Map<EntityType, Double> mobs, double eventXp, ActiveSkill active, XpCurve xpCurve) {
    public SkillDefinition(String id,String name,String description,Material icon,boolean enabled,int maxLevel,double baseXp,double growthXp,
                           Map<Material,Double> blocks,Map<EntityType,Double> mobs,double eventXp,ActiveSkill active){
        this(id,name,description,icon,enabled,maxLevel,baseXp,growthXp,blocks,mobs,eventXp,active,null);
    }
    public SkillDefinition {
        blocks = Map.copyOf(blocks);
        mobs = Map.copyOf(mobs);
    }

    // AuraSkills 默认曲线：下一等级 target 的需求为 100 * (target - 2)^2 + 100。
    public double requiredXp(int currentLevel) {
        if (currentLevel < 1) throw new IllegalArgumentException("level");
        if(xpCurve!=null)return xpCurve.required(currentLevel);
        return baseXp + growthXp * (currentLevel - 1.0) * (currentLevel - 1.0);
    }
}
