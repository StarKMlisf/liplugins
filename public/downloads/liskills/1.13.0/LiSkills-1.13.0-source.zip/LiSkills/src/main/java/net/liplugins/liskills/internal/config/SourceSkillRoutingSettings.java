package net.liplugins.liskills.internal.config;

import org.bukkit.configuration.ConfigurationSection;
import java.util.Set;

/** Legacy 分拆只改变经验归属，保留既有来源数值、交易核对和管理员选择。 */
public record SourceSkillRoutingSettings(String movementSkill,String jumpSkill,String consumptionSkill,
                                         String potionThrowSkill,String anvilSkill,String grindstoneSkill) {
    public static SourceSkillRoutingSettings defaults() {
        return new SourceSkillRoutingSettings("endurance","agility","healing","healing","forging","forging");
    }
    public String movementSourceSkill(String source) { return source.equals("jump")?jumpSkill:movementSkill; }
    public static SourceSkillRoutingSettings parse(ConfigurationSection section) {
        if(section==null)throw ConfigValues.invalid("legacy","Legacy经验归属配置节");
        return new SourceSkillRoutingSettings(skill(section,"movement-skill",Set.of("agility","endurance")),
                skill(section,"jump-skill",Set.of("agility","endurance")),
                skill(section,"consumption-skill",Set.of("alchemy","healing")),
                skill(section,"potion-throw-skill",Set.of("alchemy","healing")),
                skill(section,"anvil-skill",Set.of("enchanting","forging")),
                skill(section,"grindstone-skill",Set.of("enchanting","forging")));
    }
    private static String skill(ConfigurationSection section,String path,Set<String> allowed) {
        String value=ConfigValues.text(section,path);
        if(!allowed.contains(value))throw ConfigValues.invalid("legacy."+path,"以下技能之一："+String.join("、",allowed));
        return value;
    }
}
