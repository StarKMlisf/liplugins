package net.liplugins.liskills.internal.config;

import org.bukkit.configuration.ConfigurationSection;
import java.util.LinkedHashMap;
import java.util.Map;

/** 自定义内容ID按原样匹配；不把它当成Bukkit材料名，也不修改大小写。 */
final class CustomExperienceRates {
    private CustomExperienceRates() { }

    static Map<String, Double> parse(ConfigurationSection section, String path) {
        ConfigurationSection values = section.getConfigurationSection(path);
        if (values == null) throw new IllegalArgumentException(path + "：应为自定义ID到经验的映射，可用 {}");
        Map<String, Double> result = new LinkedHashMap<>();
        for (var entry : values.getValues(true).entrySet()) {
            if (entry.getValue() instanceof ConfigurationSection) continue;
            String id = entry.getKey();
            if (id.isBlank() || !id.equals(id.trim()) || id.length() > 256 || id.chars().anyMatch(Character::isISOControl))
                throw new IllegalArgumentException(path + "：ID须为1-256字符，不含首尾空白或控制字符");
            if (!(entry.getValue() instanceof Number number)) throw invalid(path + "." + id);
            double xp = number.doubleValue();
            if (!Double.isFinite(xp) || xp < 0 || xp > 1e9) throw invalid(path + "." + id);
            result.put(id, xp);
        }
        return Map.copyOf(result);
    }

    private static IllegalArgumentException invalid(String path) {
        return new IllegalArgumentException(path + "：经验应为0-1000000000的有限数字，0禁止此ID奖励");
    }
}
