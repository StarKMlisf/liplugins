package net.liplugins.liskills.internal.config;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import java.util.Map;

/** 第二轮原版主动模板迁移；只认完整未改动的第三版默认块，不重写管理员的主动配置。 */
final class AuraTemplateUpgrade {
    private AuraTemplateUpgrade() { }

    static boolean apply(YamlConfiguration file) {
        if(file.getConfigurationSection("skills")==null || !(file.get("config-version") instanceof Number revision)
                || Double.compare(revision.doubleValue(),3.0)!=0)return false;
        update(file,"mining","POTION","极速采掘","HASTE","SPEED_MINE","极速矿工",10,120,20);
        update(file,"fishing","QUICK_FISH","快速咬钩","LUCK","SHARP_HOOK","锐钩",1,2,5);
        update(file,"archery","CHARGED_SHOT","蓄力射击","SPEED","AURA_CHARGED_SHOT","逐箭蓄力",1,1,0);
        update(file,"defense","MANA_SHIELD","魔力护盾","RESISTANCE","ABSORPTION","吸收",2,120,10);
        update(file,"fighting","POTION","战斗专注","STRENGTH","LIGHTNING_BLADE","闪电之刃",5,120,20);
        // 即使全部是自定义配置也完成版本标记，避免以后恢复某一字段时意外再次迁移。
        file.set("config-version",4);
        return true;
    }

    private static void update(YamlConfiguration file,String id,String oldType,String oldName,String effect,
                               String type,String name,int duration,int cooldown,double mana) {
        String path="skills."+id;
        if(!Boolean.TRUE.equals(file.get(path+".enabled")))return;
        ConfigurationSection active=file.getConfigurationSection(path+".active");
        if(active==null)return;
        Map<String,Object> expected=Map.of("enabled",true,"type",oldType,"name",oldName,"effect",effect,
                "amplifier",0,"duration-seconds",10,"cooldown-seconds",60,"unlock-level",5,"mana-cost",20.0);
        if(!active.getKeys(false).equals(expected.keySet()))return;
        for(var entry:expected.entrySet()) {
            Object actual=active.get(entry.getKey()),value=entry.getValue();
            boolean same=actual instanceof Number a && value instanceof Number b
                    ?Double.compare(a.doubleValue(),b.doubleValue())==0:value.equals(actual);
            if(!same)return;
        }
        // 逐项set保留注释；其余技能内容、被动、经验源和解锁等级完全不动。
        active.set("type",type);active.set("name",name);
        active.set("duration-seconds",duration);active.set("cooldown-seconds",cooldown);active.set("mana-cost",mana);
    }
}
