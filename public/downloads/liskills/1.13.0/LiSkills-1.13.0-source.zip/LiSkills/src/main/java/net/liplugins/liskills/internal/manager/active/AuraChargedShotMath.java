package net.liplugins.liskills.internal.manager.active;

/** 逐箭付费只按真实预留魔力计算百分比；低余额按比例生效，不借用切换模式的激活费用。 */
public final class AuraChargedShotMath {
    private AuraChargedShotMath() { }
    public static Shot calculate(double fullCost,double force,double available,double percentPerMana,double maximumPercent) {
        if(!positive(fullCost) || !positive(force) || !positive(available) || !positive(percentPerMana) || !positive(maximumPercent))return new Shot(0,1);
        double spent=Math.min(available,fullCost*Math.min(1,force));
        double percent=Math.min(maximumPercent,spent*percentPerMana);
        return positive(spent) && positive(percent)?new Shot(spent,1+percent/100):new Shot(0,1);
    }
    private static boolean positive(double value){return Double.isFinite(value) && value>0;}
    public record Shot(double mana,double multiplier) { }
}
