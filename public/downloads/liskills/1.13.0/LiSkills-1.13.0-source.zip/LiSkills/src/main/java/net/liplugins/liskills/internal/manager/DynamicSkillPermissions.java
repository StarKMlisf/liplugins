package net.liplugins.liskills.internal.manager;

import net.liplugins.liskills.internal.config.ConfigManager;
import org.bukkit.Bukkit;
import org.bukkit.permissions.Permission;
import org.bukkit.permissions.PermissionDefault;
import java.util.*;

/** 自定义技能与内置技能采用相同的独立权限；只管理自己创建的Permission对象。 */
public final class DynamicSkillPermissions implements AutoCloseable {
    private final ConfigManager config;private final Map<String,Permission> owned=new HashMap<>();
    public DynamicSkillPermissions(ConfigManager config){this.config=config;}
    public void refresh(){
        var manager=Bukkit.getPluginManager();
        for(String id:config.skills().keySet()){
            String name="liskills.skill."+id;if(manager.getPermission(name)!=null)continue;
            Permission permission=new Permission(name,PermissionDefault.TRUE);manager.addPermission(permission);owned.put(name,permission);
        }
        owned.entrySet().removeIf(entry->{if(config.skill(entry.getKey().substring("liskills.skill.".length()))!=null)return false;if(manager.getPermission(entry.getKey())==entry.getValue())manager.removePermission(entry.getValue());return true;});
    }
    public void close(){var manager=Bukkit.getPluginManager();owned.forEach((name,permission)->{if(manager.getPermission(name)==permission)manager.removePermission(permission);});owned.clear();}
}
