package net.liplugins.liskills.internal.manager;

import net.liplugins.liskills.internal.config.StorageSettings;
import net.liplugins.liskills.internal.storage.*;
import net.liplugins.liskills.internal.util.TextService;
import net.liplugins.liskills.lib.scheduler.TaskScheduler;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import java.sql.SQLException;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

/** 单IO队列；失败不回退空档，SQL断线暂停使用，版本冲突保留恢复文件而不覆盖。 */
public final class ProfileManager implements AutoCloseable {
    private record PendingWrite(ProfileSnapshot snapshot,long sequence){ }
    private record Opened(ProfileRepository store,RecoverySnapshotStore recovery){ }
    private final JavaPlugin plugin;
    private final TextService text;
    private final StorageSettings storageSettings;
    private final ProfileRepository store;
    private final RecoverySnapshotStore recovery;
    private final Map<UUID,PlayerProfile> profiles=new ConcurrentHashMap<>();
    private final Map<UUID,Object> sessions=new ConcurrentHashMap<>();
    private final Map<UUID,PendingWrite> retry=new ConcurrentHashMap<>();
    private final Set<UUID> blocked=ConcurrentHashMap.newKeySet();
    private final AtomicLong sequence=new AtomicLong();
    private final ExecutorService io=Executors.newSingleThreadExecutor(r->{Thread thread=new Thread(r,"LiSkills-storage");thread.setDaemon(true);return thread;});
    private volatile boolean closing;
    private volatile boolean available=true;

    public ProfileManager(JavaPlugin plugin,TextService text){this(plugin,text,StorageSettings.defaults());}
    public ProfileManager(JavaPlugin plugin,TextService text,StorageSettings settings){
        this.plugin=plugin;this.text=text;storageSettings=settings;AtomicReference<ProfileRepository> opening=new AtomicReference<>();
        Future<Opened> future=io.submit(()->{
            ProfileRepository repository=ProfileStorageFactory.open(plugin.getDataFolder().toPath(),settings,
                    library->notice("storage.driver-downloading",Map.of("library",library)),library->notice("storage.driver-invalid",Map.of("library",library)));
            opening.set(repository);
            try{
                if(closing)throw new IllegalStateException("storage-startup-cancelled");
                return new Opened(repository,new RecoverySnapshotStore(plugin.getDataFolder().toPath().resolve("recovery")));
            }catch(Exception error){repository.close();throw error;}
        });
        try{
            Opened opened=future.get(90,TimeUnit.SECONDS);store=opened.store();recovery=opened.recovery();blocked.addAll(recovery.previousSessionIds());
            if(!blocked.isEmpty())notice("storage.recovery-pending",Map.of("count",blocked.size()));
        }catch(Exception failure){
            closing=true;
            ProfileRepository repository=opening.get();if(repository!=null)io.execute(()->{try{repository.close();}catch(Exception ignored){}});
            io.shutdown();if(failure instanceof InterruptedException)Thread.currentThread().interrupt();
            Throwable cause=failure instanceof ExecutionException&&failure.getCause()!=null?failure.getCause():failure;
            throw new IllegalStateException(text.plain(text.text("storage.initialization-failed",Map.of("error",safeMessage(cause)))),cause);
        }
    }
    public StorageSettings storageSettings(){return storageSettings;}
    public PlayerProfile get(UUID uuid){return closing||!available||blocked.contains(uuid)?null:profiles.get(uuid);}
    public Collection<PlayerProfile> loaded(){return List.copyOf(profiles.values());}
    /** 任一失败档案不能被静默漏掉；在线与尚未写入的同会话快照覆盖较旧持久数据。 */
    public CompletableFuture<List<ProfileSnapshot>> readAll(){
        if(closing)return CompletableFuture.failedFuture(new IllegalStateException("storage closing"));
        if(!blocked.isEmpty())return CompletableFuture.failedFuture(new IllegalStateException("unresolved recovery profiles"));
        List<ProfileSnapshot> online=loaded().stream().map(PlayerProfile::snapshot).toList();
        try{return CompletableFuture.supplyAsync(()->{
            try{
                if(!blocked.isEmpty())throw new IllegalStateException("unresolved recovery profiles");
                Map<UUID,ProfileSnapshot> all=new LinkedHashMap<>();store.loadAll().forEach(profile->all.put(profile.uuid(),profile));
                retry.values().forEach(write->all.put(write.snapshot().uuid(),write.snapshot()));online.forEach(profile->all.put(profile.uuid(),profile));
                return List.copyOf(all.values());
            }catch(Exception error){throw new CompletionException(error);}
        },io);}catch(RejectedExecutionException error){return CompletableFuture.failedFuture(error);}
    }
    public void join(Player player){
        if(closing)return;UUID uuid=player.getUniqueId();String name=player.getName();Object token=new Object();sessions.put(uuid,token);
        io.execute(()->{
            try{
                if(blocked.contains(uuid))throw new StorageConflictException("unresolved recovery profile: "+uuid);
                PendingWrite pending=retry.get(uuid);
                // 重连玩家先确认上一会话待写数据，不能直接把未经版本核对的RAM档案重新发布。
                if(pending!=null&&!persist(pending))throw new IllegalStateException("previous save is still pending");
                ProfileSnapshot snapshot=store.load(uuid,name);available=true;
                if(closing)return;
                new TaskScheduler(plugin).entity(player,()->{
                    if(!closing&&sessions.get(uuid)==token&&player.isOnline()&&!blocked.contains(uuid))
                        profiles.put(uuid,new PlayerProfile(new ProfileSnapshot(uuid,name,snapshot.skills(),snapshot.cooldowns(),snapshot.mana())));
                });
            }catch(Exception error){
                if(error instanceof SQLException)available=false;
                log("storage.load-failed",uuid,error);
                if(!closing)new TaskScheduler(plugin).entity(player,()->{if(sessions.get(uuid)==token&&player.isOnline())text.send(player,"storage.player-load-failed");});
            }
        });
    }
    public void quit(UUID uuid){sessions.remove(uuid);PlayerProfile profile=profiles.remove(uuid);if(profile!=null&&!closing)save(profile.snapshot());}
    public void saveAll(){if(closing)return;for(PlayerProfile profile:loaded())save(profile.snapshot());io.execute(this::retryFailed);}
    private void save(ProfileSnapshot snapshot){PendingWrite write=new PendingWrite(snapshot,sequence.incrementAndGet());io.execute(()->persist(write));}
    private boolean persist(PendingWrite write){
        ProfileSnapshot snapshot=write.snapshot();UUID uuid=snapshot.uuid();
        if(blocked.contains(uuid))return false;
        try{
            store.save(snapshot);recovery.acknowledge(snapshot,write.sequence());
            retry.computeIfPresent(uuid,(key,pending)->pending.sequence()<=write.sequence()?null:pending);
            if(!available){available=true;notice("storage.connection-restored",Map.of());}return true;
        }catch(Exception error){
            retry.compute(uuid,(key,pending)->pending==null||pending.sequence()<=write.sequence()?write:pending);
            if(error instanceof StorageConflictException)blocked.add(uuid);
            else if(storageSettings.type()!=StorageSettings.Type.YAML)available=false;
            try{recovery.preserve(snapshot,write.sequence());}catch(Exception journal){log("storage.recovery-write-failed",uuid,journal);}
            log(error instanceof StorageConflictException?"storage.version-conflict":"storage.save-failed",uuid,error);return false;
        }
    }
    private void retryFailed(){for(PendingWrite write:List.copyOf(retry.values()))if(!blocked.contains(write.snapshot().uuid()))persist(write);}
    private String safeMessage(Throwable error){String message=String.valueOf(error.getMessage());String password=storageSettings.mysql().password();return password.isEmpty()?message:message.replace(password,"<redacted>");}
    private void log(String key,UUID uuid,Exception error){plugin.getLogger().severe(text.plain(text.text(key,Map.of("player",uuid,"error",safeMessage(error)))));}
    private void notice(String key,Map<String,?> values){plugin.getLogger().info(text.plain(text.text(key,values)));}
    public void close(){
        if(closing)return;closing=true;sessions.clear();
        // 先把最新RAM快照落入恢复目录；即使驱动超时且JVM结束，也有人工恢复来源。
        List<PendingWrite> finalWrites=loaded().stream().map(profile->new PendingWrite(profile.snapshot(),sequence.incrementAndGet())).toList();
        for(PendingWrite write:retry.values())try{recovery.preserve(write.snapshot(),write.sequence());}catch(Exception error){log("storage.recovery-write-failed",write.snapshot().uuid(),error);}
        for(PendingWrite write:finalWrites){
            try{recovery.preserve(write.snapshot(),write.sequence());}catch(Exception error){log("storage.recovery-write-failed",write.snapshot().uuid(),error);}
            io.execute(()->persist(write));
        }
        profiles.clear();
        io.execute(()->{try{retryFailed();}finally{try{store.close();}catch(Exception error){notice("storage.close-failed",Map.of("error",safeMessage(error)));}}});
        io.shutdown();
        try{if(!io.awaitTermination(storageSettings.shutdownTimeoutSeconds(),TimeUnit.SECONDS))notice("storage.shutdown-timeout",Map.of("seconds",storageSettings.shutdownTimeoutSeconds()));}
        catch(InterruptedException error){Thread.currentThread().interrupt();}
    }
}
