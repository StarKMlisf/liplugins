package net.liplugins.liskills.internal.manager.leaderboard;

import net.liplugins.liskills.internal.config.*;
import net.liplugins.liskills.internal.storage.ProfileSnapshot;
import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;
import net.liplugins.liskills.lib.scheduler.TaskHandle;
import net.liplugins.liskills.lib.scheduler.TaskScheduler;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Supplier;

/** 缓存离线排行；指令与占位符只读不可变缓存，不阻塞主线程读取玩家文件。 */
public final class LeaderboardManager implements AutoCloseable {
    private final JavaPlugin plugin;private final ConfigManager config;private final Supplier<LeaderboardSettings> settings;
    private final Supplier<CompletableFuture<List<ProfileSnapshot>>> source;private final TextService text;
    private final AtomicBoolean loading=new AtomicBoolean();private volatile Map<String,List<LeaderboardCalculator.Entry>> rows=Map.of();
    private volatile boolean closed;private volatile long generation;private volatile long lastRefresh;private TaskHandle timer;
    public LeaderboardManager(JavaPlugin plugin,ConfigManager config,Supplier<LeaderboardSettings> settings,Supplier<CompletableFuture<List<ProfileSnapshot>>> source,TextService text){this.plugin=plugin;this.config=config;this.settings=settings;this.source=source;this.text=text;}
    public void register(){timer=new TaskScheduler(plugin).globalTimer(()->{if(System.currentTimeMillis()-lastRefresh>=settings.get().refreshSeconds()*1000L)refresh();},20,200);}
    public synchronized void refresh(){
        if(closed||!settings.get().enabled()||!loading.compareAndSet(false,true))return;
        var definitions=config.skills();int maximum=settings.get().maximumEntries();lastRefresh=System.currentTimeMillis();long requestGeneration=generation;
        try{source.get().thenApply(profiles->LeaderboardCalculator.calculate(profiles,definitions,maximum)).whenComplete((result,error)->{
            synchronized(this){
                if(!closed&&requestGeneration==generation){if(error==null)rows=result;else plugin.getLogger().warning(text.plain(text.text("extended.leaderboard-read-failed")));}
                loading.set(false);
            }
        });}catch(RuntimeException failure){loading.set(false);plugin.getLogger().warning(text.plain(text.text("extended.leaderboard-read-failed")));}
    }
    public boolean ready(){return !rows.isEmpty();}
    public boolean enabled(){return settings.get().enabled();}
    /** 重载清除旧定义缓存；完成较晚的旧读取不能覆盖新配置。 */
    public synchronized void reload(){generation++;rows=Map.of();lastRefresh=0;refresh();}
    public List<LeaderboardCalculator.Entry> entries(String skill){return settings.get().enabled()?rows.getOrDefault(skill,List.of()):List.of();}
    public int rank(UUID uuid,String skill){var list=entries(skill);for(int i=0;i<list.size();i++)if(list.get(i).uuid().equals(uuid))return i+1;return 0;}
    public synchronized void close(){closed=true;if(timer!=null)timer.cancel();rows=Map.of();}
}
