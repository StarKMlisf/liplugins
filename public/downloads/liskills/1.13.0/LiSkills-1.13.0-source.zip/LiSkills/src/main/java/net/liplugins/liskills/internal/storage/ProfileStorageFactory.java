package net.liplugins.liskills.internal.storage;

import net.liplugins.liskills.internal.config.StorageSettings;
import net.liplugins.liskills.lib.StorageDriverLoader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.nio.file.Files;
import java.io.IOException;
import java.security.MessageDigest;
import java.util.HexFormat;
import java.util.Locale;
import java.util.Properties;
import java.util.function.Consumer;

/** 初始化唯一后端；初始化失败由调用者终止技能系统，不创建空白替代存储。 */
public final class ProfileStorageFactory {
    private ProfileStorageFactory(){ }
    public static ProfileRepository open(Path data,StorageSettings settings,Consumer<String> downloading,Consumer<String> invalidCache)throws Exception{
        return open(data,settings,data.resolve("lib"),false,downloading,invalidCache);
    }
    /** 独立缓存用于离线工具；readOnly不初始化源表/数据库文件，驱动仅写入显式缓存。 */
    public static ProfileRepository open(Path data,StorageSettings settings,Path drivers,boolean readOnly,Consumer<String> downloading,Consumer<String> invalidCache)throws Exception{
        return open(data,settings,drivers,readOnly,false,downloading,invalidCache);
    }
    /** 目标预检：不存在的目录/数据库/表只表现为空视图，不初始化；真实读取错误仍须上抛。 */
    public static ProfileRepository preview(Path data,StorageSettings settings,Path drivers,Consumer<String> downloading,Consumer<String> invalidCache)throws Exception{
        return open(data,settings,drivers,true,true,downloading,invalidCache);
    }
    private static ProfileRepository open(Path data,StorageSettings settings,Path drivers,boolean readOnly,boolean preview,Consumer<String> downloading,Consumer<String> invalidCache)throws Exception{
        if(preview){
            if(Files.exists(data)&&!Files.isDirectory(data))throw new IOException("migration-target-is-not-directory");
            if(settings.type()==StorageSettings.Type.YAML&&Files.notExists(data.resolve("players")))return new ReadOnlyProfileRepository(new ProfileStore(data.resolve("players")));
            if(settings.type()==StorageSettings.Type.SQLITE&&Files.notExists(data.resolve(settings.sqlite().file()))){
                for(String suffix:new String[]{"-journal","-wal","-shm"})if(Files.exists(data.resolve(settings.sqlite().file()+suffix)))throw new IOException("migration-target-orphaned-sqlite-journal");
                return new EmptyProfileRepository();
            }
        }
        if(readOnly&&!preview){
            if(!Files.isDirectory(data))throw new IOException("migration-source-directory-missing");
            if(settings.type()==StorageSettings.Type.YAML&&!Files.isDirectory(data.resolve("players")))throw new IOException("migration-source-players-missing");
            if(settings.type()==StorageSettings.Type.SQLITE&&!Files.isRegularFile(data.resolve(settings.sqlite().file())))throw new IOException("migration-source-sqlite-missing");
        }
        if(readOnly&&settings.type()==StorageSettings.Type.SQLITE&&Files.exists(data.resolve(settings.sqlite().file()+"-journal")))throw new IOException("migration-source-sqlite-needs-recovery");
        if(settings.type()==StorageSettings.Type.YAML){
            StorageFileLock lock=StorageFileLock.acquire(data.resolve("players/.session.lock"));
            ProfileRepository repository=new LockedProfileRepository(new ProfileStore(data.resolve("players")),lock);
            return readOnly?new ReadOnlyProfileRepository(repository):repository;
        }
        boolean mysql=settings.type()==StorageSettings.Type.MYSQL;
        StorageFileLock fileLock=mysql?null:StorageFileLock.acquire(data.resolve(settings.sqlite().file()+".liskills.lock"));
        StorageDriverLoader driver=null;SqlSession session=null;
        try{
            driver=StorageDriverLoader.open(drivers,mysql,downloading,invalidCache);
            final StorageDriverLoader loadedDriver=driver;
            String url,sqliteFile,lockName=null,prefix;int queryTimeout;Properties properties=new Properties();
            if(mysql){
                var options=settings.mysql();String host=options.host().contains(":")?"["+options.host()+"]":options.host();
                url="jdbc:mysql://"+host+":"+options.port()+"/"+options.database();sqliteFile=null;prefix=options.tablePrefix();queryTimeout=options.queryTimeoutSeconds();
                properties.setProperty("user",options.username());properties.setProperty("password",options.password());properties.setProperty("sslMode",options.sslMode().name());
                properties.setProperty("allowPublicKeyRetrieval",Boolean.toString(options.allowPublicKeyRetrieval()));
                properties.setProperty("connectTimeout",Integer.toString(options.connectTimeoutMillis()));properties.setProperty("socketTimeout",Integer.toString(options.socketTimeoutMillis()));
                properties.setProperty("autoReconnect","false");properties.setProperty("allowLoadLocalInfile","false");properties.setProperty("allowUrlInLocalInfile","false");
                properties.setProperty("characterEncoding","UTF-8");properties.setProperty("connectionTimeZone","UTC");
                if(readOnly)properties.setProperty("readOnlyPropagatesToServer","true");
                String identity=options.database().toLowerCase(Locale.ROOT)+":"+prefix;
                lockName="liskills:"+HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(identity.getBytes(StandardCharsets.UTF_8))).substring(0,55);
            }else{
                Path database=data.resolve(settings.sqlite().file()).toAbsolutePath();
                // immutable避免只读WAL连接在源目录创建/改写共享内存文件；工具必须离线持有源生命周期锁。
                sqliteFile=readOnly?database.toUri().toASCIIString()+"?mode=ro&immutable=1":database.toString();url="jdbc:sqlite:"+sqliteFile;prefix="liskills_";queryTimeout=30;
                properties.setProperty("busy_timeout",Integer.toString(settings.sqlite().busyTimeoutMillis()));
                if(readOnly)properties.setProperty("open_mode","1");
                else{properties.setProperty("journal_mode","WAL");properties.setProperty("synchronous","FULL");}
            }
            session=new SqlSession(()->{
                var connection=loadedDriver.connect(url,sqliteFile,properties);
                if(readOnly&&mysql)try{connection.setReadOnly(true);}catch(java.sql.SQLException failure){try{connection.close();}catch(java.sql.SQLException close){failure.addSuppressed(close);}throw failure;}
                return connection;
            },driver,lockName,queryTimeout);
            ProfileRepository repository=new SqlProfileStore(session,prefix,mysql,readOnly,preview);
            if(fileLock!=null)repository=new LockedProfileRepository(repository,fileLock);
            return readOnly?new ReadOnlyProfileRepository(repository):repository;
        }catch(Exception|LinkageError failure){
            try{if(session!=null)session.close();else if(driver!=null)driver.close();}catch(Exception close){failure.addSuppressed(close);}
            if(fileLock!=null)try{fileLock.close();}catch(Exception close){failure.addSuppressed(close);}
            throw failure;
        }
    }
}
