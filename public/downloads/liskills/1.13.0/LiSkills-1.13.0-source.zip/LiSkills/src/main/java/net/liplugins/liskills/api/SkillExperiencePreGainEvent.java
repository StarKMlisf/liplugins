package net.liplugins.liskills.api;

import org.bukkit.entity.Player;
import org.bukkit.event.*;

/** 自然经验写入前的同步可取消事件；修改的是倍率结算后的最终技能经验，不影响管理员写入。 */
public final class SkillExperiencePreGainEvent extends Event implements Cancellable {
    private static final HandlerList HANDLERS=new HandlerList();
    private final Player player;private final String skill;private double amount;private boolean cancelled;
    public SkillExperiencePreGainEvent(Player player,String skill,double amount){this.player=player;this.skill=skill;setAmount(amount);}
    public Player getPlayer(){return player;}public String getSkill(){return skill;}public double getAmount(){return amount;}
    public void setAmount(double amount){if(!Double.isFinite(amount)||amount<0)throw new IllegalArgumentException("amount");this.amount=amount;}
    public boolean isCancelled(){return cancelled;}public void setCancelled(boolean value){cancelled=value;}
    public HandlerList getHandlers(){return HANDLERS;}public static HandlerList getHandlerList(){return HANDLERS;}
}
