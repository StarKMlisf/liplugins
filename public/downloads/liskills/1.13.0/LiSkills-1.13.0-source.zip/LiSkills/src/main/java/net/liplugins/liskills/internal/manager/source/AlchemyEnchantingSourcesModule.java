package net.liplugins.liskills.internal.manager.source;

import net.liplugins.liskills.internal.config.AlchemySourceSettings;
import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.config.EnchantingSourceSettings;
import net.liplugins.liskills.internal.manager.ProfileManager;
import net.liplugins.liskills.internal.manager.SkillManager;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.plugin.java.JavaPlugin;
import java.util.List;
import java.util.function.Supplier;

/** 仅装配炼金/附魔经验来源；不处理被动效果、主动能力或旧固定经验入口。 */
public final class AlchemyEnchantingSourcesModule implements AutoCloseable {
    private final JavaPlugin plugin;private final SourceExperienceService rewards;
    private final BrewingTakeoutSourceListener brewing;private final AlchemySplashSourceListener splash;
    private final List<Listener> listeners;private boolean registered;
    public AlchemyEnchantingSourcesModule(JavaPlugin plugin,ConfigManager config,ProfileManager profiles,SkillManager skills,
                                          Supplier<AlchemySourceSettings> alchemy,Supplier<EnchantingSourceSettings> enchanting) {
        this.plugin=plugin;rewards=new SourceExperienceService(plugin,config,profiles,skills);
        brewing=new BrewingTakeoutSourceListener(rewards,alchemy);splash=new AlchemySplashSourceListener(plugin,rewards,alchemy,config::sourceRouting);
        listeners=List.of(rewards.receiptListener(),brewing,splash,new AlchemyConsumeSourceListener(rewards,alchemy,config::sourceRouting),new EnchantingTableSourceListener(rewards,enchanting),
                new AnvilSourceListener(rewards,enchanting,config::sourceRouting),new GrindstoneSourceListener(rewards,enchanting,config::sourceRouting));
    }
    public void register(){if(registered)return;registered=true;listeners.forEach(listener->plugin.getServer().getPluginManager().registerEvents(listener,plugin));}
    @Override public void close(){listeners.forEach(HandlerList::unregisterAll);splash.close();brewing.close();rewards.close();}
}
