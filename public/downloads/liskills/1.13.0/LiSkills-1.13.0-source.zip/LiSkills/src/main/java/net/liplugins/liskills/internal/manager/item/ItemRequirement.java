package net.liplugins.liskills.internal.manager.item;

import java.util.Map;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.function.ToIntFunction;

/** 等级条件的纯计算结果；未知/停用技能、缺档和缺权限都不能意外通过要求。 */
public record ItemRequirement(String skill, int required, int current, Reason reason) {
    public enum Reason { LEVEL, PROFILE_LOADING, SKILL_UNAVAILABLE, PERMISSION, ITEM_DATA_INVALID }

    public static Optional<ItemRequirement> firstFailure(Map<String, Integer> requirements, boolean loaded,
                                                         ToIntFunction<String> level, Predicate<String> available,
                                                         Predicate<String> permitted) {
        for (var entry : requirements.entrySet()) {
            String skill = entry.getKey();
            int required = entry.getValue();
            if (!loaded) return Optional.of(new ItemRequirement(skill, required, 0, Reason.PROFILE_LOADING));
            if (!available.test(skill)) return Optional.of(new ItemRequirement(skill, required, 0, Reason.SKILL_UNAVAILABLE));
            int current = Math.max(0, level.applyAsInt(skill));
            if (!permitted.test(skill)) return Optional.of(new ItemRequirement(skill, required, current, Reason.PERMISSION));
            if (current < required) return Optional.of(new ItemRequirement(skill, required, current, Reason.LEVEL));
        }
        return Optional.empty();
    }
}
