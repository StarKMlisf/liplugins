package net.liplugins.liskills.internal.hook.customfishing;

import java.util.LinkedHashMap;
import java.util.Map;

/** 有界、定时失效的钩记录；避免第三方提前移除其钩映射后重复奖励。 */
final class CustomFishingClaims<K> {
    private final int capacity;
    private final long lifetime;
    private final Map<K, Long> entries = new LinkedHashMap<>();

    CustomFishingClaims(int capacity, long lifetime) {
        if (capacity < 1 || lifetime < 1) throw new IllegalArgumentException("Invalid claim limits");
        this.capacity = capacity;
        this.lifetime = lifetime;
    }
    synchronized boolean contains(K key, long now) {
        Long expires = entries.get(key);
        if (expires == null) return false;
        if (expires <= now) { entries.remove(key); return false; }
        return true;
    }
    synchronized boolean claim(K key, long now) {
        if (contains(key, now)) return false;
        remember(key, now);
        return true;
    }
    synchronized void remember(K key, long now) {
        entries.remove(key);
        while (entries.size() >= capacity) entries.remove(entries.keySet().iterator().next());
        entries.put(key, now + lifetime);
    }
    synchronized void clean(long now) { entries.values().removeIf(expires -> expires <= now); }
    synchronized void clear() { entries.clear(); }
    synchronized int size() { return entries.size(); }
}
