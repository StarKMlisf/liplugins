package net.liplugins.liskills.internal.config;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;

/** items.yml 的纯解析与完整校验；不会读写物品或自行发布配置。 */
public record ItemSettings(boolean enabled, int messageCooldownMillis, List<ItemRule> rules) {
    public ItemSettings { rules = List.copyOf(rules); }
    public static ItemSettings disabled() { return new ItemSettings(false, 2000, List.of()); }

    public static ItemSettings parse(ConfigurationSection root) {
        return parse(root, material -> !material.isAir() && material.isItem());
    }

    /** 材质存在性在真实Bukkit注册表确认；纯解析测试可传入独立材质判定，避免伪造服务器。 */
    static ItemSettings parse(ConfigurationSection root, Predicate<Material> isItem) {
        if (root == null) throw invalid("", "配置节");
        keys(root, Set.of("enabled", "message-cooldown-millis", "rules", "__liskills_backfill"), "");
        boolean enabled = bool(root, "enabled");
        int cooldown = integer(root, "message-cooldown-millis", 0, 60_000);
        ConfigurationSection rulesSection = section(root, "rules");
        if (rulesSection.getKeys(false).size() > 256) throw invalid("rules", "最多256条规则");
        List<ItemRule> rules = new ArrayList<>();
        for (String id : rulesSection.getKeys(false)) {
            if (!id.matches("[a-z][a-z0-9_-]{0,63}")) throw invalid("rules." + id, "小写规则标识，长度1至64");
            ConfigurationSection rule = section(rulesSection, id);
            String path = "rules." + id;
            keys(rule, Set.of("enabled", "name", "match", "slots", "attributes", "requirements", "uses", "traits",
                    "stat-multipliers", "stat-percent-additions", "skill-xp-multipliers"), path);
            boolean ruleEnabled = bool(rule, "enabled");
            String name = string(rule, "name");
            if (name.isBlank() || name.length() > 256) throw invalid(path + ".name", "1至256字符显示名称");
            ConfigurationSection match = section(rule, "match");
            keys(match, Set.of("materials", "pdc-key", "pdc-value"), path + ".match");
            Set<Material> materials = new LinkedHashSet<>();
            for (String entry : strings(match, "materials")) {
                Material material;
                try { material = Material.valueOf(entry.toUpperCase(Locale.ROOT)); }
                catch (IllegalArgumentException error) { throw invalid(path + ".match.materials", "有效Bukkit材质"); }
                if (!isItem.test(material)) throw invalid(path + ".match.materials", "非空气物品材质");
                materials.add(material);
            }
            if (materials.size() > 256) throw invalid(path + ".match.materials", "最多256种材质");
            String key = string(match, "pdc-key"), value = string(match, "pdc-value");
            if (!key.isEmpty() && (!key.matches("[a-z0-9._-]+:[a-z0-9/._-]+") || key.length() > 255))
                throw invalid(path + ".match.pdc-key", "完整小写命名空间键，例如 liskills:item_id");
            if (key.isEmpty() != value.isEmpty() || value.length() > 256)
                throw invalid(path + ".match.pdc-value", "与pdc-key同时留空，或填写1至256字符精确值");
            if (materials.isEmpty() && key.isEmpty()) throw invalid(path + ".match", "材质列表或PDC匹配条件");
            Set<ItemSlot> slots = enums(rule, "slots", ItemSlot.class);
            if (slots.isEmpty()) throw invalid(path + ".slots", "至少一个装备位");
            Set<ItemUse> uses = enums(rule, "uses", ItemUse.class);
            Map<String, Double> attributes = new LinkedHashMap<>();
            ConfigurationSection bonuses = section(rule, "attributes");
            for (String stat : bonuses.getKeys(false)) {
                if (!StatsSettings.IDS.contains(stat)) throw invalid(path + ".attributes." + stat, "九属性标识");
                attributes.put(stat, number(bonuses, stat, -100_000, 100_000));
            }
            Map<String, Integer> requirements = new LinkedHashMap<>();
            ConfigurationSection levels = section(rule, "requirements");
            for (String skill : levels.getKeys(false)) {
                // 自定义技能与内置技能使用同一语法；是否注册、启用和有权限在使用时确认。
                if (!skill.matches("[a-z][a-z0-9_]{0,47}")) throw invalid(path + ".requirements." + skill, "有效技能ID");
                requirements.put(skill, integer(levels, skill, 1, 1000));
            }
            if (requirements.size() > 256) throw invalid(path + ".requirements", "最多256项技能要求");
            Map<String, Double> multiply = numberMap(rule, "stat-multipliers", 0, 10, StatsSettings.IDS::contains);
            Map<String, Double> percent = numberMap(rule, "stat-percent-additions", -100, 1000, StatsSettings.IDS::contains);
            Map<String, Double> xp = numberMap(rule, "skill-xp-multipliers", -100, 1000,
                    skill -> skill.equals("all") || skill.matches("[a-z][a-z0-9_]{0,47}"));
            Map<String, ItemModifier> traits = traitMap(rule);
            if (attributes.isEmpty() && requirements.isEmpty() && multiply.isEmpty() && percent.isEmpty() && traits.isEmpty() && xp.isEmpty())
                throw invalid(path, "至少一个属性、效果、经验倍率或等级要求");
            rules.add(new ItemRule(id, name, ruleEnabled, materials, key, value, slots, attributes, requirements, uses, multiply, percent, traits, xp));
        }
        return new ItemSettings(enabled, cooldown, rules);
    }

    private static Map<String, Double> numberMap(ConfigurationSection root, String path, double minimum, double maximum,
                                                  Predicate<String> validId) {
        if (!root.contains(path)) return Map.of();
        ConfigurationSection section = section(root, path);
        if (section.getKeys(false).size() > 256) throw invalid(root.getCurrentPath() + "." + path, "最多256项");
        Map<String, Double> values = new LinkedHashMap<>();
        for (String id : section.getKeys(false)) {
            if (!validId.test(id)) throw invalid(root.getCurrentPath() + "." + path + "." + id, "有效标识");
            values.put(id, number(section, id, minimum, maximum));
        }
        return values;
    }
    private static Map<String, ItemModifier> traitMap(ConfigurationSection root) {
        if (!root.contains("traits")) return Map.of();
        ConfigurationSection traits = section(root, "traits");
        Map<String, ItemModifier> values = new LinkedHashMap<>();
        for (String id : traits.getKeys(false)) {
            if (!StatsSettings.TRAITS.contains(id)) throw invalid(traits.getCurrentPath() + "." + id, "效果trait标识");
            if (traits.get(id) instanceof Number) values.put(id, new ItemModifier(number(traits, id, -100_000, 100_000), 1, 0));
            else {
                ConfigurationSection modifier = section(traits, id);
                keys(modifier, Set.of("add", "multiply", "add-percent"), traits.getCurrentPath() + "." + id);
                if (modifier.getKeys(false).isEmpty()) throw invalid(modifier.getCurrentPath(), "至少一种运算");
                values.put(id, new ItemModifier(modifier.contains("add") ? number(modifier, "add", -100_000, 100_000) : 0,
                        modifier.contains("multiply") ? number(modifier, "multiply", 0, 10) : 1,
                        modifier.contains("add-percent") ? number(modifier, "add-percent", -100, 1000) : 0));
            }
        }
        return values;
    }

    private static <E extends Enum<E>> Set<E> enums(ConfigurationSection root, String path, Class<E> type) {
        Set<E> result = new LinkedHashSet<>();
        for (String value : strings(root, path)) {
            try { result.add(Enum.valueOf(type, value.toUpperCase(Locale.ROOT))); }
            catch (IllegalArgumentException error) { throw invalid(root.getCurrentPath() + "." + path, "有效的" + type.getSimpleName() + "标识"); }
        }
        return result;
    }
    private static List<String> strings(ConfigurationSection root, String path) {
        Object value = root.get(path);
        if (!(value instanceof List<?> list) || list.stream().anyMatch(entry -> !(entry instanceof String)))
            throw invalid(root.getCurrentPath() + "." + path, "文本列表");
        return list.stream().map(String.class::cast).toList();
    }
    private static String string(ConfigurationSection root, String path) {
        if (!(root.get(path) instanceof String result)) throw invalid(root.getCurrentPath() + "." + path, "文本");
        return result;
    }
    private static boolean bool(ConfigurationSection root, String path) {
        if (!(root.get(path) instanceof Boolean result)) throw invalid(root.getCurrentPath() + "." + path, "true或false");
        return result;
    }
    private static int integer(ConfigurationSection root, String path, int minimum, int maximum) {
        double value = number(root, path, minimum, maximum);
        if (value != Math.rint(value)) throw invalid(root.getCurrentPath() + "." + path, "整数");
        return (int) value;
    }
    private static double number(ConfigurationSection root, String path, double minimum, double maximum) {
        Object raw = root.get(path);
        if (!(raw instanceof Number number) || !Double.isFinite(number.doubleValue())
                || number.doubleValue() < minimum || number.doubleValue() > maximum)
            throw invalid(root.getCurrentPath() + "." + path, "有限数字" + minimum + "至" + maximum);
        return number.doubleValue();
    }
    private static ConfigurationSection section(ConfigurationSection root, String path) {
        ConfigurationSection section = root.getConfigurationSection(path);
        if (section == null) throw invalid(root.getCurrentPath() + "." + path, "配置节");
        return section;
    }
    private static void keys(ConfigurationSection section, Set<String> allowed, String path) {
        for (String key : section.getKeys(false)) if (!allowed.contains(key)) throw invalid(path + "." + key, "受支持的配置项");
    }
    private static IllegalArgumentException invalid(String path, String requirement) {
        return new IllegalArgumentException("items.yml:" + path + " 必须是" + requirement);
    }
}
