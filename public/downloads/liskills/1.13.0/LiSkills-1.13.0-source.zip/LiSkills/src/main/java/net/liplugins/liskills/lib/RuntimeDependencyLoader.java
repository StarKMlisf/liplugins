package net.liplugins.liskills.lib;

import org.bukkit.plugin.java.JavaPlugin;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** 在业务类验证之前确认文本库可用，需要时才创建可关闭的补充类加载器。 */
public final class RuntimeDependencyLoader {
    private final JavaPlugin plugin;
    private final BootstrapMessages messages;

    public RuntimeDependencyLoader(JavaPlugin plugin, BootstrapMessages messages) {
        this.plugin = plugin;
        this.messages = messages;
    }

    public RuntimeClassLoader prepare() throws IOException {
        ClassLoader parent = plugin.getClass().getClassLoader();
        if (available(parent)) {
            return null;
        }
        LibraryDownloader downloader = new LibraryDownloader(plugin.getDataFolder().toPath().resolve("lib"),
                name -> plugin.getLogger().info(messages.text("downloading", Map.of("library", name))),
                name -> plugin.getLogger().warning(messages.text("cache-invalid", Map.of("library", name))));
        List<URL> urls = new ArrayList<>();
        urls.add(plugin.getClass().getProtectionDomain().getCodeSource().getLocation());
        for (RuntimeLibrary library : RuntimeLibraryCatalog.libraries()) {
            urls.add(downloader.ensure(library).toUri().toURL());
        }
        RuntimeClassLoader loader = new RuntimeClassLoader(urls.toArray(URL[]::new), parent);
        if (!available(loader)) {
            loader.close();
            throw new IOException("Adventure MiniMessage / LegacyComponentSerializer initialization failed");
        }
        return loader;
    }

    private boolean available(ClassLoader loader) {
        try {
            Class<?> miniMessage = Class.forName("net.kyori.adventure.text.minimessage.MiniMessage", true, loader);
            Object parser = miniMessage.getMethod("miniMessage").invoke(null);
            Object component = miniMessage.getMethod("deserialize", Object.class).invoke(parser, "");
            Class<?> legacy = Class.forName("net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer", true, loader);
            Object serializer = legacy.getMethod("legacySection").invoke(null);
            Class<?> componentType = Class.forName("net.kyori.adventure.text.Component", true, loader);
            legacy.getMethod("serialize", componentType).invoke(serializer, component);
            return true;
        } catch (ReflectiveOperationException | LinkageError failure) {
            return false;
        }
    }
}
