package net.liplugins.liskills.internal.command;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.manager.ManaManager;
import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import java.util.Map;

final class ManaCommand implements Subcommand {
    private final ConfigManager config;
    private final SenderChecks checks;
    private final TextService text;
    ManaCommand(ConfigManager config,SenderChecks checks,TextService text){this.config=config;this.checks=checks;this.text=text;}
    public String name(){return "mana";}
    public String permission(){return "liskills.use";}
    public void execute(CommandSender sender,String[] args) {
        if(args.length>1){checks.usage(sender,"mana.usage");return;}
        Player player=args.length==0?checks.player(sender):checks.online(sender,args[0]);
        if(player==null || (!player.equals(sender) && !checks.permission(sender,"liskills.stats.others")))return;
        checks.onPlayer(player, () -> {
        var profile=checks.profile(sender,player);
        if(profile==null)return;
        if(!config.mana().enabled()){text.send(sender,"mana.disabled");return;}
        text.send(sender,"mana.status",Map.of("player",player.getName(),"mana",text.format(ManaManager.available(profile,config)),
                "maximum",text.format(ManaManager.maximum(profile,config)),"regen",text.format(ManaManager.regeneration(profile,config))));
        });
    }
}
