package net.liplugins.liskills.internal.listener.stat;

import net.liplugins.liskills.internal.manager.stat.StatManager;
import net.liplugins.liskills.internal.manager.stat.StatTraits;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerExpChangeEvent;

/** 智慧只增强当前原版经验事件，不再次生成经验球或技能经验事件。 */
public final class StatExperienceListener implements Listener {
    private final StatManager stats;
    public StatExperienceListener(StatManager stats) { this.stats = stats; }

    @EventHandler(priority = EventPriority.LOW)
    public void onExperience(PlayerExpChangeEvent event) {
        if (!stats.active(event.getPlayer()) || event.getAmount() <= 0) return;
        event.setAmount(StatTraits.experience(event.getAmount(), stats.trait(event.getPlayer(), "experience-bonus")));
    }
}
