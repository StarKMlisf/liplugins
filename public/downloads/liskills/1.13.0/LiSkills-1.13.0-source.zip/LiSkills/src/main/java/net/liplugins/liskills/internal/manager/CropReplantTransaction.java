package net.liplugins.liskills.internal.manager;

import net.liplugins.liskills.lib.scheduler.ServerThreads;

import net.liplugins.liskills.internal.listener.PlacedBlockTracker;
import org.bukkit.Bukkit;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.BlockState;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.Player;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

/** 补种事务：模拟标准放置检查，并在确认自己的种苗仍存在后才扣种子。 */
final class CropReplantTransaction {
    enum Result { PLANTED, NO_SEED, DENIED, CHANGED, FAILED }

    private final PlacedBlockTracker placed;
    private final Consumer<BlockPlaceEvent> dispatch;
    private final java.util.function.Predicate<Block> ownership;

    CropReplantTransaction(PlacedBlockTracker placed) {
        this(placed, event -> Bukkit.getPluginManager().callEvent(event), ServerThreads::owns);
    }

    CropReplantTransaction(PlacedBlockTracker placed, Consumer<BlockPlaceEvent> dispatch) {
        this(placed, dispatch, ServerThreads::owns);
    }
    CropReplantTransaction(PlacedBlockTracker placed, Consumer<BlockPlaceEvent> dispatch, java.util.function.Predicate<Block> ownership) {
        this.placed = placed;
        this.dispatch = dispatch;
        this.ownership = ownership;
    }

    Result place(Player player, Block block, BlockData harvested, boolean consumeSeed, BooleanSupplier stillAllowed) {
        if (!ownership.test(block) || !loaded(block) || !block.getType().isAir() || !stillAllowed.getAsBoolean()) return Result.CHANGED;
        Block soil = block.getRelative(BlockFace.DOWN);
        if (!ownership.test(soil) || !CropReplantRules.supports(harvested.getMaterial(), soil.getType())) return Result.CHANGED;
        var seed = CropReplantRules.seed(harvested.getMaterial());
        if (consumeSeed && !CropSeedPayment.available(player.getInventory(), seed)) return Result.NO_SEED;

        BlockState previous = block.getState();
        BlockData seedling = CropReplantRules.seedling(harvested);
        boolean wasMarked = placed.contains(block);
        try {
            // Bukkit 放置事件通常展示已经放入世界的新方块；替换前的 AIR 作为 replaced state 提交。
            block.setBlockData(seedling, false);
            BlockPlaceEvent event = new BlockPlaceEvent(block, previous, soil, new ItemStack(seed), player, true, EquipmentSlot.HAND);
            dispatch.accept(event);
            if (!same(block, seedling)) return Result.CHANGED;
            if (event.isCancelled() || !event.canBuild() || !stillAllowed.getAsBoolean()
                    || !CropReplantRules.supports(harvested.getMaterial(), soil.getType())) {
                rollback(block, previous, seedling, wasMarked);
                return Result.DENIED;
            }
            // 保护监听器可能动过库存。失败只撤销自己的种苗，不需要退款，也不会覆盖新库存。
            // 先完成可能失败的来源标记，再以单格库存写入作为最后提交动作。
            placed.mark(block);
            if (consumeSeed && !CropSeedPayment.consume(player.getInventory(), seed)) {
                rollback(block, previous, seedling, wasMarked);
                return Result.NO_SEED;
            }
            return Result.PLANTED;
        } catch (RuntimeException failure) {
            // 世界/PDC 写入本身失败时，尽力回滚；第二次故障不能让全服补种定时任务停止。
            try { rollback(block, previous, seedling, wasMarked); }
            catch (RuntimeException ignored) { }
            return Result.FAILED;
        }
    }

    private void rollback(Block block, BlockState previous, BlockData seedling, boolean wasMarked) {
        // 后续监听器若把这里换成了别的方块，则其结果和来源标记全部保留。
        if (!same(block, seedling)) return;
        if (previous.update(true, false)) {
            if (wasMarked) placed.mark(block);
            else placed.remove(block);
        }
    }

    static boolean loaded(Block block) { return block.getWorld().isChunkLoaded(block.getX() >> 4, block.getZ() >> 4); }
    private boolean same(Block block, BlockData expected) { return ownership.test(block) && loaded(block) && block.getBlockData().equals(expected); }
}
