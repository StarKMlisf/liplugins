package net.liplugins.liskills.lib;

import java.net.URI;

/** 固定版本和摘要的公共库描述，不接受服务器配置提供下载地址。 */
public record RuntimeLibrary(String group, String artifact, String version, String sha256) {
    public String fileName() {
        return artifact + "-" + version + ".jar";
    }

    public URI uri() {
        return URI.create("https://repo.maven.apache.org/maven2/" + group.replace('.', '/') + "/"
                + artifact + "/" + version + "/" + fileName());
    }
}
