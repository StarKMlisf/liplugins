package net.liplugins.liskills.internal.manager.passive.combat;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.hook.LiRealEnchantHook;
import net.liplugins.liskills.internal.manager.PassiveAbilityManager;
import net.liplugins.liskills.internal.manager.SkillManager;
import net.liplugins.liskills.internal.manager.stat.StatManager;
import org.bukkit.Material;
import net.liplugins.liskills.lib.scheduler.ServerThreads;
import org.bukkit.entity.AbstractArrow;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Trident;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import java.util.concurrent.ThreadLocalRandom;

/** 统一处理属性、武器大师、先手和实体防御，始终只改Bukkit原始伤害事件。 */
final class CombatPassiveManager implements Listener {
    private final ConfigManager config;
    private final SkillManager skills;
    private final PassiveAbilityManager passives;
    private final StatManager stats;
    private final LiRealEnchantHook enchantments;
    private final FirstStrikeManager firstStrike;
    private final ParryManager parry;
    private final BleedManager bleed;
    CombatPassiveManager(ConfigManager config,SkillManager skills,PassiveAbilityManager passives,StatManager stats,
                         LiRealEnchantHook enchantments,FirstStrikeManager firstStrike,ParryManager parry,BleedManager bleed) {
        this.config=config;this.skills=skills;this.passives=passives;this.stats=stats;this.enchantments=enchantments;
        this.firstStrike=firstStrike;this.parry=parry;this.bleed=bleed;
    }
    @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true)
    public void onDamage(EntityDamageByEntityEvent event) {
        if(!ServerThreads.owns(event.getEntity()) || !config.progressionEnabled() || SecondaryDamageContext.active() || (enchantments!=null && enchantments.isSecondaryDamage())) return;
        if(event.getCause()==EntityDamageEvent.DamageCause.THORNS || event.getCause()==EntityDamageEvent.DamageCause.CUSTOM) return;
        double damage=event.getDamage();
        if(!Double.isFinite(damage) || damage<=0 || !(event.getFinalDamage()>0)) return;
        Player attacker=attacker(event);
        if(event.getEntity() instanceof Player defender && passives.roll(defender,"immunity")) {
            event.setCancelled(true);return;
        }
        boolean sword=false;
        if(attacker!=null && skills.eligible(attacker)) {
            var attackStats=stats.values(attacker);
            String master=weaponMaster(event,attacker);
            sword="sword_master".equals(master);
            double weapon=master==null?0:passives.value(attacker,master);
            double first=sword?firstStrike.reserve(attacker,event):0;
            damage=PassiveCombatMath.attack(damage,stats.trait(attackStats,"attack-damage"),weapon,first);
            if(ThreadLocalRandom.current().nextDouble()<Math.clamp(stats.trait(attackStats,"crit-chance")/100,0,1)) {
                damage=PassiveCombatMath.attack(damage,stats.trait(attackStats,"crit-damage"),0,0);
            }
        }
        if(event.getEntity() instanceof Player defender && skills.eligible(defender)) {
            damage=PassiveCombatMath.reduce(damage,stats.trait(defender,"damage-reduction"));
            if(defender.isSneaking()) damage=PassiveCombatMath.reduce(damage,PassiveCombatMath.percent(passives.value(defender,"shielding")));
            if(event.getDamager() instanceof LivingEntity && !(event.getDamager() instanceof Player)) {
                damage=PassiveCombatMath.reduce(damage,PassiveCombatMath.percent(passives.value(defender,"mob_master")));
            }
            if(attacker!=null) damage=PassiveCombatMath.reduce(damage,parry.reduction(defender,event.getDamager(),event));
        }
        event.setDamage(damage);
        if(sword && attacker!=null && event.getEntity() instanceof LivingEntity target) bleed.afterHit(attacker,target,event);
    }
    private static Player attacker(EntityDamageByEntityEvent event) {
        if(!ServerThreads.owns(event.getDamager()))return null;
        if(event.getDamager() instanceof Player player && ServerThreads.owns(player)) return player;
        if(event.getDamager() instanceof AbstractArrow arrow && arrow.getShooter() instanceof Player player && ServerThreads.owns(player)) return player;
        if(event.getDamager() instanceof Trident trident && trident.getShooter() instanceof Player player && ServerThreads.owns(player)) return player;
        return null;
    }
    private static String weaponMaster(EntityDamageByEntityEvent event,Player player) {
        if(event.getDamager() instanceof AbstractArrow || event.getDamager() instanceof Trident) return "bow_master";
        if(event.getCause()!=EntityDamageEvent.DamageCause.ENTITY_ATTACK && event.getCause()!=EntityDamageEvent.DamageCause.ENTITY_SWEEP_ATTACK) return null;
        Material material=player.getInventory().getItemInMainHand().getType();
        String name=material.name();
        if(name.endsWith("_SWORD")) return "sword_master";
        if(name.endsWith("_PICKAXE")) return "pick_master";
        if(name.endsWith("_AXE")) return "axe_master";
        if(name.endsWith("_SHOVEL")) return "spade_master";
        if(name.endsWith("_HOE")) return "scythe_master";
        return null;
    }
}
