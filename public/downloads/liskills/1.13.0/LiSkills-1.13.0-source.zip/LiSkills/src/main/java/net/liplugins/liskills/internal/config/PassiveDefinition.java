package net.liplugins.liskills.internal.config;

import java.util.List;
import java.util.Map;

/** 被动能力的解锁、阶级和数值；技能等级与能力等级分开计算。 */
public record PassiveDefinition(String id, String skill, String name, String description, boolean enabled,
                                int unlockLevel, int levelInterval, int maxLevel, double baseValue, double perLevel,
                                double secondaryBase, double secondaryPerLevel, Map<String,Object> options) {
    public PassiveDefinition { options=Map.copyOf(options); }
    public int level(int skillLevel) {
        if (!enabled || skillLevel < unlockLevel) return 0;
        int rank=1+(skillLevel-unlockLevel)/levelInterval;
        return maxLevel == 0 ? rank : Math.min(rank,maxLevel);
    }
    public double value(int skillLevel) { return Math.min(Math.max(0,numberOption("maximum_value",1_000_000)),amount(level(skillLevel),baseValue,perLevel)); }
    public double secondary(int skillLevel) { return Math.min(Math.max(0,numberOption("maximum_secondary_value",1_000_000)),amount(level(skillLevel),secondaryBase,secondaryPerLevel)); }
    public int nextUnlock(int skillLevel) {
        int rank=level(skillLevel);
        if (!enabled || (maxLevel>0 && rank>=maxLevel)) return -1;
        return rank==0?unlockLevel:unlockLevel+rank*levelInterval;
    }
    public double numberOption(String key,double fallback) { return options.get(key) instanceof Number n?n.doubleValue():fallback; }
    public boolean booleanOption(String key,boolean fallback) { return options.get(key) instanceof Boolean b?b:fallback; }
    public List<String> stringListOption(String key) {
        Object value=options.get(key);
        return value instanceof List<?> list ? list.stream().map(String::valueOf).toList():List.of();
    }
    private static double amount(int rank,double base,double increment) {
        return rank<=0?0:Math.clamp(base+(rank-1.0)*increment,0,1_000_000);
    }
}
