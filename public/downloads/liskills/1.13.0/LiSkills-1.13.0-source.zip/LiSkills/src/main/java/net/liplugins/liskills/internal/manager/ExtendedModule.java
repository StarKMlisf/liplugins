package net.liplugins.liskills.internal.manager;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.hook.VaultEconomyBridge;
import net.liplugins.liskills.internal.manager.jobs.JobsManager;
import net.liplugins.liskills.internal.manager.ledger.PlayerRewardLedger;
import net.liplugins.liskills.internal.manager.ledger.LedgerFailureReporter;
import net.liplugins.liskills.internal.manager.leaderboard.LeaderboardManager;
import net.liplugins.liskills.internal.manager.reward.LevelRewardManager;
import net.liplugins.liskills.internal.manager.stat.PlayerModifierManager;
import net.liplugins.liskills.internal.manager.stat.StatManager;
import net.liplugins.liskills.internal.manager.storage.ProfileExportManager;
import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.event.HandlerList;
import org.bukkit.plugin.java.JavaPlugin;
import java.io.IOException;
import java.util.Map;

/** 职业、奖励、排行和管理扩展的生命周期装配；各项业务彼此独立。 */
public final class ExtendedModule implements AutoCloseable {
    private final JavaPlugin plugin;private final JobsManager jobs;private final LevelRewardManager rewards;
    private final LeaderboardManager boards;private final PlayerModifierManager modifiers;
    private final ProfileExportManager exports;private final PlayerRewardLedger ledger;private final TextService text;
    public ExtendedModule(JavaPlugin plugin,ConfigManager config,ProfileManager profiles,StatManager stats,TextService text){
        this.plugin=plugin;this.text=text;var economy=new VaultEconomyBridge();economy.connect();
        modifiers=new PlayerModifierManager();stats.bonusProvider(modifiers::values);
        ledger=new PlayerRewardLedger(plugin.getDataFolder().toPath().resolve("reward-ledger"));var failures=new LedgerFailureReporter(plugin.getLogger(),text);
        jobs=new JobsManager(config::jobs,config,economy,text,ledger,failures);rewards=new LevelRewardManager(config::rewards,economy,text,ledger,failures,new net.liplugins.liskills.internal.manager.reward.RewardCommandDispatcher(plugin));
        boards=new LeaderboardManager(plugin,config,config::leaderboards,profiles::readAll,text);
        exports=new ProfileExportManager(plugin.getDataFolder().toPath().resolve("exports"),profiles::readAll);
    }
    public void register(){plugin.getServer().getPluginManager().registerEvents(jobs,plugin);plugin.getServer().getPluginManager().registerEvents(rewards,plugin);boards.register();}
    public JobsManager jobs(){return jobs;}public LevelRewardManager rewards(){return rewards;}
    public LeaderboardManager boards(){return boards;}public PlayerModifierManager modifiers(){return modifiers;}
    public ProfileExportManager exports(){return exports;}
    public PlayerRewardLedger ledger(){return ledger;}
    public void close(){
        HandlerList.unregisterAll(jobs);HandlerList.unregisterAll(rewards);boards.close();exports.close();
        try{ledger.close();}catch(IOException error){plugin.getLogger().warning(text.plain(text.text("extended.ledger-close-failed",Map.of("error",String.valueOf(error.getMessage())))));}
    }
}
