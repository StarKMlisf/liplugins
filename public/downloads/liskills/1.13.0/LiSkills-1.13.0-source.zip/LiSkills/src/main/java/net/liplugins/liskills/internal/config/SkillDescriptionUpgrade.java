package net.liplugins.liskills.internal.config;

import org.bukkit.configuration.file.YamlConfiguration;
import java.util.Map;

/** 仅更新旧默认玩法说明；实际奖励规则由sources.yml负责，服主自定义文本和注释保留。 */
final class SkillDescriptionUpgrade {
    private static final Map<String,String> PREVIOUS = Map.of(
            "agility", "承受实际摔落伤害获得经验；伤害事件有间隔限制。",
            "alchemy", "喝下有效药水获得经验；水瓶与无效果基础药水不结算。",
            "enchanting", "完成一次附魔台附魔获得固定经验。");
    private SkillDescriptionUpgrade() { }
    static boolean apply(YamlConfiguration current, YamlConfiguration defaults) {
        boolean changed = false;
        for (var entry : PREVIOUS.entrySet()) {
            String path = "skills." + entry.getKey() + ".description";
            if (entry.getValue().equals(current.get(path)) && defaults.isString(path)) {
                current.set(path, defaults.getString(path)); changed = true;
            }
        }
        return changed;
    }
}
