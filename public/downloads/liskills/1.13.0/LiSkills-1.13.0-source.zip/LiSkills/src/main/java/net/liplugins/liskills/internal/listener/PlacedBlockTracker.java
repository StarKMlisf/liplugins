package net.liplugins.liskills.internal.listener;

import net.liplugins.liskills.lib.scheduler.ServerThreads;
import net.liplugins.liskills.lib.scheduler.TaskScheduler;
import org.bukkit.entity.Entity;

import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.BlockState;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.Directional;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.*;
import org.bukkit.event.entity.EntityChangeBlockEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.world.ChunkLoadEvent;
import org.bukkit.event.world.ChunkUnloadEvent;
import org.bukkit.event.world.StructureGrowEvent;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import java.util.*;
import java.util.function.BooleanSupplier;

/** 区块PDC保存人工来源；即时阻断、最终结果清理和位置世代共同防止取消/重放洗白。 */
public final class PlacedBlockTracker implements Listener {
    private static final int SECTION_WORDS = 64, MAX_PENDING = 8192;
    private final NamespacedKey key;
    private final Map<Integer, NamespacedKey> sectionKeys = new java.util.concurrent.ConcurrentHashMap<>();
    private final BlockOriginLedger<Position> ledger = new BlockOriginLedger<>(32768);
    private final List<Runnable> pending = new ArrayList<>();
    private final java.util.function.Predicate<Block> ownership;
    private final java.util.concurrent.atomic.AtomicInteger scheduled = new java.util.concurrent.atomic.AtomicInteger();
    private TaskScheduler scheduler;

    public PlacedBlockTracker(JavaPlugin plugin) {
        this(new NamespacedKey(plugin, "placed_blocks_v2"), ServerThreads::owns);
        scheduler = new TaskScheduler(plugin);
        scheduler.globalTimer(ledger::advance, 1, 1);
    }
    /** 无服务器测试可显式注入归属谓词；默认构造始终执行真实区域检查。 */
    PlacedBlockTracker(NamespacedKey key) { this(key, ServerThreads::owns); }
    PlacedBlockTracker(NamespacedKey key, java.util.function.Predicate<Block> ownership) { this.key = key; this.ownership = ownership; }

    public boolean contains(Block block) {
        if (!loaded(block)) return true;
        PersistentDataContainer data = block.getChunk().getPersistentDataContainer();
        NamespacedKey section = sectionKey(block);
        if (!data.has(section, PersistentDataType.LONG_ARRAY)) return data.has(section);
        long[] words = data.get(section, PersistentDataType.LONG_ARRAY);
        // 已存在但损坏/类型错误的数据不能静默洗成天然区域。
        if (words == null) return data.has(section);
        if (words.length != SECTION_WORDS) return true;
        int position = encode(block.getX(), block.getY(), block.getZ());
        return (words[position >>> 6] & bit(position)) != 0;
    }
    public void mark(Block block) { ledger.change(Position.of(block)); write(block, true); }
    public void remove(Block block) { ledger.change(Position.of(block)); write(block, false); }
    public long stamp(Block block) { return loaded(block) ? ledger.capture(Position.of(block)) : -1; }
    public boolean unchanged(Block block, long stamp) { return loaded(block) && ledger.unchanged(Position.of(block), stamp); }
    public boolean claimExperience(Block block, long stamp) { return loaded(block) && ledger.claim(Position.of(block), stamp, 1); }
    public boolean claimBonus(Block block, long stamp) { return loaded(block) && ledger.claim(Position.of(block), stamp, 2); }
    public void clearIfUnchanged(Block block, long stamp) { if (unchanged(block, stamp)) write(block, false); }
    boolean defer(Runnable action) {
        if (scheduler != null) return false;
        if (pending.size() >= MAX_PENDING) return false;
        pending.add(action); return true;
    }
    public boolean defer(Entity owner, Runnable action) {
        return defer(owner, action, () -> { });
    }
    public boolean defer(Entity owner, Runnable action, Runnable retired) {
        if (scheduler == null) return defer(action);
        if (scheduled.incrementAndGet() > MAX_PENDING) { scheduled.decrementAndGet(); return false; }
        scheduler.entity(owner, () -> { try { action.run(); } finally { scheduled.decrementAndGet(); } },
                () -> { try { retired.run(); } finally { scheduled.decrementAndGet(); } });
        return true;
    }
    public boolean defer(Block owner, Runnable action) {
        if (scheduler == null) return defer(action);
        if (scheduled.incrementAndGet() > MAX_PENDING) { scheduled.decrementAndGet(); return false; }
        scheduler.region(owner.getLocation(), () -> { try { action.run(); } finally { scheduled.decrementAndGet(); } });
        return true;
    }
    /** 单个共享调度器；先取快照，回调中新产生的事务留到下一tick。 */
    void settle() {
        ledger.advance();
        List<Runnable> ready = List.copyOf(pending); pending.clear();
        ready.forEach(Runnable::run);
    }
    private void write(Block block, boolean marked) {
        if (!loaded(block)) return;
        PersistentDataContainer data = block.getChunk().getPersistentDataContainer();
        NamespacedKey section = sectionKey(block);
        if (data.has(section) && !data.has(section, PersistentDataType.LONG_ARRAY)) return;
        long[] words = data.get(section, PersistentDataType.LONG_ARRAY);
        if (words == null) {
            if (data.has(section) || !marked) return;
            words = new long[SECTION_WORDS];
        }
        if (words.length != SECTION_WORDS) return;
        int position = encode(block.getX(), block.getY(), block.getZ()), word = position >>> 6;
        long flag = bit(position);
        if (marked) words[word] |= flag; else words[word] &= ~flag;
        for (long value : words) if (value != 0) { data.set(section, PersistentDataType.LONG_ARRAY, words); return; }
        data.remove(section);
    }
    private NamespacedKey sectionKey(Block block) {
        int sectionY = block.getY() >> 4;
        return sectionKeys.computeIfAbsent(sectionY, section -> new NamespacedKey(key.getNamespace(), key.getKey() + "_" + section));
    }
    private static long bit(int position) { return 1L << (position & 63); }
    static int encode(int x, int y, int z) { return (y & 15) << 8 | (x & 15) << 4 | z & 15; }
    private boolean loaded(Block block) { return ownership.test(block) && block.getWorld().isChunkLoaded(block.getX() >> 4, block.getZ() >> 4); }
    private static boolean same(Block block, BlockData before) { return block.getBlockData().matches(before); }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onPlace(BlockPlaceEvent event) {
        List<BlockState> states = event instanceof BlockMultiPlaceEvent multi ? multi.getReplacedBlockStates() : List.of(event.getBlockReplacedState());
        for (BlockState replaced : states) {
            Block block = replaced.getBlock(); boolean previous = contains(block); BlockData before = replaced.getBlockData().clone();
            mark(block); long stamp = stamp(block);
            defer(block, () -> {
                if ((event.isCancelled() || !event.canBuild()) && unchanged(block, stamp) && same(block, before)) write(block, previous);
            });
        }
    }
    @EventHandler(priority = EventPriority.LOWEST)
    public void onExtend(BlockPistonExtendEvent event) { move(event.getBlocks(), event.getDirection(), event::isCancelled); }
    @EventHandler(priority = EventPriority.LOWEST)
    public void onRetract(BlockPistonRetractEvent event) {
        BlockFace movement = event.getBlock().getBlockData() instanceof Directional facing ? facing.getFacing().getOppositeFace() : event.getDirection();
        move(event.getBlocks(), movement, event::isCancelled);
    }
    private void move(List<Block> sources, BlockFace direction, BooleanSupplier cancelled) {
        // 先快照所有源/目标，再一起标记；相邻推动与跨区块移动不能互相覆盖来源。
        Map<Position, Before> all = new LinkedHashMap<>(); Set<Position> targets = new HashSet<>();
        for (Block source : sources) {
            if (!loaded(source)) continue;
            Block target = source.getRelative(direction); targets.add(Position.of(target));
            for (Block block : List.of(source, target)) if (loaded(block)) all.computeIfAbsent(Position.of(block), ignored -> new Before(block, contains(block), block.getBlockData().clone()));
        }
        Map<Position, Long> stamps = new HashMap<>();
        all.forEach((position, before) -> { mark(before.block); stamps.put(position, stamp(before.block)); });
        all.forEach((position, before) -> defer(before.block, () -> {
            if (!unchanged(before.block, stamps.get(position))) return;
            if (cancelled.getAsBoolean()) { if (same(before.block, before.data)) write(before.block, before.marked); }
            else if (!targets.contains(position) && !same(before.block, before.data)) write(before.block, false);
        }));
    }
    @EventHandler(priority = EventPriority.LOWEST)
    public void onEntityChange(EntityChangeBlockEvent event) {
        Block block = event.getBlock(); Before before = new Before(block, contains(block), block.getBlockData().clone());
        Material target = event.getTo(); mark(block); long stamp = stamp(block);
        defer(block, () -> {
            if (!unchanged(block, stamp)) return;
            if (event.isCancelled()) { if (same(block, before.data)) write(block, before.marked); }
            else if (isAir(target) && isAir(block.getType())) write(block, false);
        });
    }
    @EventHandler(priority = EventPriority.LOWEST)
    public void onGrowth(BlockGrowEvent event) {
        BlockState grown = event.getNewState();
        if (HarvestMaturity.matureCrop(grown.getType(), grown.getBlockData())) {
            // 成熟只给farming例外，不抹掉人工来源；否则自定义WHEAT映射能借成长后清标记绕过防刷。
            ledger.change(Position.of(event.getBlock()));
        } else if (event.getBlock().getType() == Material.TORCHFLOWER_CROP && grown.getType() == Material.TORCHFLOWER)
            grown(event.getBlock(), grown, event::isCancelled);
    }
    @EventHandler(priority = EventPriority.LOWEST)
    public void onTreeGrowth(StructureGrowEvent event) {
        // 仅真正被生长替换的方块可解除旧种植标记；事件列出的既有原木不能因此洗白。
        event.getBlocks().forEach(state -> {
            Block block = state.getBlock();
            if (!loaded(block)) return;
            Material before = block.getType();
            // 生长只能解除树种/空位的旧标记，不能通过改变手放原木的轴向或树种洗白建筑材料。
            if (contains(block) && !isAir(before) && !treeSeed(before)) { ledger.change(Position.of(block)); return; }
            grown(block, state, () -> event.isCancelled() || !event.getBlocks().contains(state));
        });
    }
    private void grown(Block block, BlockState grown, BooleanSupplier cancelled) {
        BlockData before = block.getBlockData().clone(); ledger.change(Position.of(block)); long stamp = stamp(block);
        defer(block, () -> {
            if (!cancelled.getAsBoolean() && unchanged(block, stamp) && !same(block, before) && same(block, grown.getBlockData())) write(block, false);
        });
    }
    @EventHandler(priority = EventPriority.LOWEST)
    public void onBlockExplosion(BlockExplodeEvent event) {
        List.copyOf(event.blockList()).forEach(block -> destroyed(block, () -> event.isCancelled() || !event.blockList().contains(block)));
    }
    @EventHandler(priority = EventPriority.LOWEST)
    public void onEntityExplosion(EntityExplodeEvent event) {
        List.copyOf(event.blockList()).forEach(block -> destroyed(block, () -> event.isCancelled() || !event.blockList().contains(block)));
    }
    @EventHandler(priority = EventPriority.LOWEST)
    public void onBurn(BlockBurnEvent event) { destroyed(event.getBlock(), event::isCancelled); }
    @EventHandler(priority = EventPriority.LOWEST)
    public void onFade(BlockFadeEvent event) { destroyed(event.getBlock(), event::isCancelled); }
    private void destroyed(Block block, BooleanSupplier cancelled) {
        if (!loaded(block)) return;
        BlockData before = block.getBlockData().clone(); ledger.change(Position.of(block)); long stamp = stamp(block);
        defer(block, () -> { if (!cancelled.getAsBoolean() && unchanged(block, stamp) && !same(block, before)) write(block, false); });
    }
    @EventHandler public void onChunkUnload(ChunkUnloadEvent event) { invalidateChunk(event.getWorld().getUID(), event.getChunk().getX(), event.getChunk().getZ()); }
    @EventHandler public void onChunkLoad(ChunkLoadEvent event) { invalidateChunk(event.getWorld().getUID(), event.getChunk().getX(), event.getChunk().getZ()); }
    private void invalidateChunk(UUID world, int x, int z) { ledger.invalidate(position -> position.world.equals(world) && (position.x >> 4) == x && (position.z >> 4) == z); }
    private static boolean isAir(Material material) { return material == Material.AIR || material == Material.CAVE_AIR || material == Material.VOID_AIR; }
    private static boolean treeSeed(Material material) {
        return material.name().endsWith("_SAPLING") || material == Material.MANGROVE_PROPAGULE || material == Material.AZALEA
                || material == Material.FLOWERING_AZALEA || material == Material.BROWN_MUSHROOM || material == Material.RED_MUSHROOM
                || material == Material.CRIMSON_FUNGUS || material == Material.WARPED_FUNGUS;
    }
    private record Before(Block block, boolean marked, BlockData data) { }
    private record Position(UUID world, int x, int y, int z) {
        static Position of(Block block) { return new Position(block.getWorld().getUID(), block.getX(), block.getY(), block.getZ()); }
    }
}
