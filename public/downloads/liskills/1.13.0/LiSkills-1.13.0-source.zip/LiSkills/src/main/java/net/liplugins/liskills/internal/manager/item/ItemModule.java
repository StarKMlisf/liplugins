package net.liplugins.liskills.internal.manager.item;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.hook.LiRealEnchantHook;
import net.liplugins.liskills.internal.listener.item.ItemArmorRequirementListener;
import net.liplugins.liskills.internal.listener.item.ItemRequirementListener;
import net.liplugins.liskills.internal.manager.ProfileManager;
import net.liplugins.liskills.internal.manager.SkillManager;
import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.plugin.java.JavaPlugin;
import java.util.List;

/** 装配层只负责注册和关闭，物品匹配、属性计算与取消使用彼此独立。 */
public final class ItemModule implements AutoCloseable {
    private final JavaPlugin plugin;
    private final ItemRuleManager rules;
    private final ItemAttributeManager attributes;
    private final ItemMetadataService metadata;
    private final ItemRequirementFeedback feedback;
    private final List<Listener> listeners;
    private boolean registered;

    public ItemModule(JavaPlugin plugin, ConfigManager config, ProfileManager profiles, SkillManager skills,
                      LiRealEnchantHook enchantments, TextService text) {
        this.plugin = plugin;
        metadata = new ItemMetadataService();
        rules = new ItemRuleManager(config, profiles, skills, metadata);
        attributes = new ItemAttributeManager(rules);
        feedback = new ItemRequirementFeedback(config, text);
        listeners = List.of(new ItemRequirementListener(rules, feedback, enchantments), new ItemArmorRequirementListener(rules, feedback));
    }
    public ItemAttributeManager attributes() { return attributes; }
    public ItemRuleManager rules() { return rules; }
    public ItemMetadataService metadata() { return metadata; }
    public void register() {
        if (registered) return;
        registered = true;
        listeners.forEach(listener -> plugin.getServer().getPluginManager().registerEvents(listener, plugin));
    }
    @Override public void close() {
        listeners.forEach(HandlerList::unregisterAll);
        feedback.clear();
        registered = false;
    }
}
