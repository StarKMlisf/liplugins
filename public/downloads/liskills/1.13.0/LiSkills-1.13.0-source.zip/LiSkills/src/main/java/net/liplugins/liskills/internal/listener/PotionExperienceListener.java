package net.liplugins.liskills.internal.listener;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.config.SkillDefinition;
import net.liplugins.liskills.internal.manager.SkillManager;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.potion.PotionType;

/** 本版炼金来源是喝下有效药水；不做酿造台多人归属推断。 */
public final class PotionExperienceListener implements Listener {
    private final ConfigManager config;
    private final SkillManager skills;

    public PotionExperienceListener(ConfigManager config, SkillManager skills) {
        this.config = config;
        this.skills = skills;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDrink(PlayerItemConsumeEvent event) {
        if (event.getItem().getType() != Material.POTION || !(event.getItem().getItemMeta() instanceof PotionMeta meta)) return;
        PotionType type = meta.getBasePotionType();
        if (type == null || type == PotionType.WATER || type == PotionType.MUNDANE || type == PotionType.THICK || type == PotionType.AWKWARD) return;
        if (type.getPotionEffects().isEmpty() && meta.getCustomEffects().isEmpty()) return;
        SkillDefinition definition = config.skill("alchemy");
        if (definition == null || !definition.enabled()) return;
        skills.award(event.getPlayer(), "alchemy", definition.eventXp());
    }
}
