package net.liplugins.liskills.lib;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Properties;
import java.util.function.Consumer;

/** 独立固定版本驱动加载器；不向DriverManager注册，不把外部驱动打进插件Jar。 */
public final class StorageDriverLoader implements AutoCloseable {
    private final URLClassLoader loader;
    private final boolean mysql;
    private final Driver driver;
    private StorageDriverLoader(URLClassLoader loader,boolean mysql)throws ReflectiveOperationException{
        this.loader=loader;this.mysql=mysql;
        driver=mysql?(Driver)Class.forName("com.mysql.cj.jdbc.NonRegisteringDriver",true,loader).getConstructor().newInstance():null;
        if(!mysql)Class.forName("org.sqlite.jdbc4.JDBC4Connection",false,loader);
    }
    public static StorageDriverLoader open(Path directory,boolean mysql,Consumer<String> downloading,Consumer<String> invalidCache)throws IOException{
        LibraryDownloader downloader=new LibraryDownloader(directory,downloading,invalidCache);var urls=new ArrayList<URL>();
        for(RuntimeLibrary library:mysql?StorageDriverCatalog.mysql():StorageDriverCatalog.sqlite())urls.add(downloader.ensure(library).toUri().toURL());
        // 平台加载器仅共享JDK类，避免借用其他插件已加载的不同版本驱动。
        URLClassLoader loader=new URLClassLoader(urls.toArray(URL[]::new),ClassLoader.getPlatformClassLoader());
        try{return new StorageDriverLoader(loader,mysql);}catch(ReflectiveOperationException|LinkageError error){loader.close();throw new IOException("storage-driver-load-failed",error);}
    }
    public Connection connect(String url,String sqliteFile,Properties properties)throws SQLException{
        if(mysql){
            try{Connection connection=driver.connect(url,properties);if(connection==null)throw new SQLException("storage-driver-rejected-url");return connection;}
            catch(LinkageError error){throw new SQLException("mysql-driver-failed",error);}
        }
        try{return (Connection)Class.forName("org.sqlite.jdbc4.JDBC4Connection",true,loader).getConstructor(String.class,String.class,Properties.class).newInstance(url,sqliteFile,properties);}
        catch(InvocationTargetException error){if(error.getCause() instanceof SQLException sql)throw sql;throw new SQLException("sqlite-connection-failed",error.getCause());}
        catch(ReflectiveOperationException|LinkageError error){throw new SQLException("sqlite-driver-failed",error);}
    }
    @Override public void close()throws IOException{
        try{
            if(mysql)Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread",true,loader).getMethod("uncheckedShutdown").invoke(null);
        }catch(ReflectiveOperationException|LinkageError error){throw new IOException("mysql-driver-cleanup-failed",error);}
        finally{loader.close();}
    }
}
