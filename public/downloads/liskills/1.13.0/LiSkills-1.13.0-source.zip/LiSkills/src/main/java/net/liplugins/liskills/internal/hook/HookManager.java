package net.liplugins.liskills.internal.hook;

import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.manager.ProfileManager;
import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.plugin.java.JavaPlugin;

import java.lang.reflect.Method;
import java.util.Map;

/** 可选插件桥接的生命周期；缺少 PAPI 时不解析它的任何 API 类。 */
public final class HookManager implements AutoCloseable {
    private final JavaPlugin plugin;
    private final ConfigManager config;
    private final ProfileManager profiles;
    private final TextService text;
    private final VaultHook vault = new VaultHook();
    private Object expansion;
    private Method unregister;
    private boolean placeholderFailed;

    public HookManager(JavaPlugin plugin, ConfigManager config, ProfileManager profiles, TextService text) {
        this.plugin = plugin; this.config = config; this.profiles = profiles; this.text = text;
    }

    public void register() {
        if (expansion != null || !Bukkit.getPluginManager().isPluginEnabled("PlaceholderAPI")) return;
        try {
            Class<?> type = Class.forName("net.liplugins.liskills.internal.hook.LiSkillsExpansion", true, HookManager.class.getClassLoader());
            Object candidate = type.getConstructor(JavaPlugin.class, ConfigManager.class, ProfileManager.class)
                    .newInstance(plugin, config, profiles);
            boolean registered = Boolean.TRUE.equals(type.getMethod("register").invoke(candidate));
            if (!registered) { failure(); return; }
            expansion = candidate;
            unregister = type.getMethod("unregister");
            placeholderFailed = false;
        } catch (ReflectiveOperationException | LinkageError | RuntimeException ignored) {
            failure();
        }
    }

    private void failure() {
        placeholderFailed = true;
        text.send(Bukkit.getConsoleSender(), "hook.placeholderapi-failed");
    }

    public String status() {
        String vaultState = ChatColor.stripColor(text.text(vault.available() ? "hook.available" : "hook.unavailable"));
        String papiState = ChatColor.stripColor(text.text(expansion != null ? "hook.available" : placeholderFailed ? "hook.failed" : "hook.unavailable"));
        return text.text("hook.vault-status", Map.of("state", vaultState)) + "\n"
                + text.text("hook.placeholderapi-status", Map.of("state", papiState));
    }

    @Override
    public void close() {
        if (expansion == null) return;
        try {
            unregister.invoke(expansion);
        } catch (ReflectiveOperationException | RuntimeException | LinkageError ignored) {
            text.send(Bukkit.getConsoleSender(), "hook.placeholderapi-unregister-failed");
        } finally {
            expansion = null;
            unregister = null;
        }
    }
}
