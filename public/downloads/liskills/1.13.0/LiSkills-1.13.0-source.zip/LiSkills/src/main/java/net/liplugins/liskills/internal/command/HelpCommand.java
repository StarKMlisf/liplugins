package net.liplugins.liskills.internal.command;

import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.command.CommandSender;

import java.util.Map;

final class HelpCommand implements Subcommand {
    private final TextService text;
    private final boolean extended;
    private final boolean hud;
    HelpCommand(TextService text) { this(text,false); }
    HelpCommand(TextService text,boolean extended) { this(text,extended,false); }
    HelpCommand(TextService text,boolean extended,boolean hud) { this.text = text;this.extended=extended;this.hud=hud; }
    public String name() { return "help"; }
    public String permission() { return "liskills.use"; }
    public void execute(CommandSender sender, String[] arguments) {
        text.send(sender, "command.help-title");
        text.lines("command.help-player", Map.of()).forEach(sender::sendMessage);
        text.lines("rpg-commands.help-player", Map.of()).forEach(sender::sendMessage);
        if(hud && sender.hasPermission("liskills.hud"))text.send(sender,"hud.help");
        if(extended)text.lines("extended.help-player", Map.of()).forEach(sender::sendMessage);
        if (sender.hasPermission("liskills.admin")) {
            text.lines("command.help-admin", Map.of()).forEach(sender::sendMessage);
            if(extended)text.lines("extended.help-admin", Map.of()).forEach(sender::sendMessage);
        }
    }
}
