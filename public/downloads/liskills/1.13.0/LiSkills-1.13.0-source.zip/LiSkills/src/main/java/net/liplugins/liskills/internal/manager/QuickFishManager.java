package net.liplugins.liskills.internal.manager;

import net.liplugins.liskills.internal.config.ActiveSkill;
import net.liplugins.liskills.internal.config.ConfigManager;
import net.liplugins.liskills.internal.util.TextService;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.FishHook;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.plugin.java.JavaPlugin;
import net.liplugins.liskills.lib.scheduler.TaskHandle;
import net.liplugins.liskills.lib.scheduler.TaskScheduler;
import net.liplugins.liskills.lib.scheduler.ServerThreads;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** 快速咬钩只调整新抛钩的原生等待区间；不发放物品、经验或强制鱼咬钩。 */
public final class QuickFishManager implements ActiveAbilityHandler, Listener, AutoCloseable {
    private static final String SKILL = "fishing";
    private static final int MAX_TRACKED_CASTS = 512;
    private final ConfigManager config;
    private final SkillAbilityWindows windows;
    private final TextService text;
    private final java.util.function.Predicate<FishHook> customHook;
    private final Map<UUID, TrackedCast> tracked = new java.util.concurrent.ConcurrentHashMap<>();
    private final TaskScheduler scheduler;
    private final net.liplugins.liskills.lib.scheduler.PlayerTasks task;
    private volatile boolean closed;

    public QuickFishManager(JavaPlugin plugin, ConfigManager config, SkillAbilityWindows windows, TextService text) {
        this(plugin, config, windows, text, hook -> false);
    }

    public QuickFishManager(JavaPlugin plugin, ConfigManager config, SkillAbilityWindows windows, TextService text,
                            java.util.function.Predicate<FishHook> customHook) {
        this.config = config;
        this.windows = windows;
        this.text = text;
        this.customHook = customHook;
        scheduler = new TaskScheduler(plugin);
        task = new net.liplugins.liskills.lib.scheduler.PlayerTasks(plugin, this::tick, 1L, 1L);
    }

    @Override public boolean activate(Player player, ActiveSkill active) {
        if (closed || !ServerThreads.owns(player)) return false;
        if (player.getInventory().getItemInMainHand().getType() != Material.FISHING_ROD) {
            text.send(player, "ability.quick-fish-tool");
            return false;
        }
        if (!tracked.containsKey(player.getUniqueId()) && tracked.size() >= MAX_TRACKED_CASTS) {
            text.send(player, "ability.quick-fish-busy");
            return false;
        }
        return windows.open(player, SKILL, "QUICK_FISH", active, Set.of(Material.FISHING_ROD));
    }

    @Override public long remainingMillis(Player player) { return windows.remainingMillis(player, SKILL); }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onFish(PlayerFishEvent event) {
        if (closed || !ServerThreads.owns(event.getPlayer()) || !windows.active(event.getPlayer(),SKILL,"QUICK_FISH")) return;
        Player player = event.getPlayer();
        TrackedCast current = tracked.get(player.getUniqueId());
        if (event.getState() == PlayerFishEvent.State.FISHING) {
            long token = windows.token(player, SKILL);
            if (current == null) {
                if (token == 0 || event.getHand() != EquipmentSlot.HAND || tracked.size() >= MAX_TRACKED_CASTS) return;
                current = new TrackedCast();
                tracked.put(player.getUniqueId(), current);
            }
            // MONITOR 不改事件和实体；延至下一 tick 读取后续监听器的最终取消状态与参数。
            current.observation = new Observation(event, token);
        } else if (current != null && current.matches(event.getHook())) {
            current.observation = new Observation(event, windows.token(player, SKILL));
        }
    }

    private void tick(Player player) {
        if (closed) return;
        UUID uuid=player.getUniqueId();TrackedCast current=tracked.get(uuid);
        if(current!=null)tick(player,uuid,current);
    }
    private void tick(Player player,UUID uuid,TrackedCast current) {
            if(closed || tracked.get(uuid)!=current)return;
            Observation observation = current.observation;
            current.observation = null;
            try {
                long token = player == null ? 0 : windows.token(player, SKILL);
                if(current.lease!=null && !ServerThreads.owns(current.lease.hook())){
                    QuickFishHookLease lease=current.lease;current.lease=null;
                    scheduler.entityNow(lease.hook(),lease::restoreIfUnchanged);
                    tracked.remove(uuid,current);return;
                }
                if (current.lease != null && (token == 0 || current.lease.token() != token
                        || customHook.test(current.lease.hook())
                        || !QuickFishHookLease.usable(current.lease.hook(), uuid))) restore(current);
                if (observation != null) observe(player, uuid, token, current, observation);
                if (current.lease == null && current.observation == null) tracked.remove(uuid, current);
            } catch (RuntimeException failure) {
                try { restore(current); } catch (RuntimeException ignored) { }
                tracked.remove(uuid, current);
                if (player != null && player.isOnline()) text.send(player, "ability.quick-fish-failed");
            }
    }

    private void observe(Player player, UUID uuid, long token, TrackedCast current, Observation observation) {
        PlayerFishEvent event = observation.event;
        FishHook hook = event.getHook();
        if(!ServerThreads.owns(hook))return;
        if (event.getState() != PlayerFishEvent.State.FISHING) {
            if (current.lease != null && current.lease.matches(hook) && (event.isCancelled() || retracted(event.getState())))
                restore(current);
            return;
        }
        if (player == null || token == 0 || token != observation.token || !windows.active(player, SKILL)
                || customHook.test(hook)
                || event.isCancelled() || event.getHand() != EquipmentSlot.HAND
                || !QuickFishHookLease.usable(hook, uuid) || !hook.getWorld().equals(player.getWorld())) {
            restore(current);
            return;
        }
        // 重复发送同一个抛钩事件不能多次叠乘等待时间；后续插件改值也不再次夺回参数。
        if (current.lease != null && current.lease.matches(hook)) return;
        restore(current);
        current.lease = QuickFishHookLease.apply(hook, uuid, token, config.quickFish());
    }

    private static boolean retracted(PlayerFishEvent.State state) {
        return state == PlayerFishEvent.State.CAUGHT_FISH || state == PlayerFishEvent.State.CAUGHT_ENTITY
                || state == PlayerFishEvent.State.IN_GROUND || state == PlayerFishEvent.State.REEL_IN;
    }

    private void restore(TrackedCast current) {
        QuickFishHookLease lease = current.lease;
        current.lease = null;
        if (lease != null && ServerThreads.owns(lease.hook())) lease.restoreIfUnchanged();
    }

    @Override public void close() {
        closed = true;
        task.close();
        scheduler.cancelAll();
        for (TrackedCast current : tracked.values()) {
            try { restore(current); } catch (RuntimeException ignored) { }
        }
        tracked.clear();
    }

    private record Observation(PlayerFishEvent event, long token) { }
    private static final class TrackedCast {
        private QuickFishHookLease lease;
        private Observation observation;
        private boolean matches(FishHook hook) {
            return lease != null && lease.matches(hook)
                    || observation != null && observation.event.getHook().getUniqueId().equals(hook.getUniqueId());
        }
    }
}
