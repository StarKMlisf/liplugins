package net.liplugins.liskills.internal.manager.passive.combat;

/** 只计算有限非负伤害；减伤相乘、同组攻击加成相加，与AuraSkills默认模型一致。 */
public final class PassiveCombatMath {
    private PassiveCombatMath() { }
    public static double percent(double value) { return Double.isFinite(value) ? Math.clamp(value / 100, 0, 0.99) : 0; }
    public static double attack(double damage, double strengthPercent, double weaponPercent, double firstStrikePercent) {
        if (!Double.isFinite(damage) || damage <= 0) return 0;
        double bonus = positive(strengthPercent) + positive(weaponPercent) + positive(firstStrikePercent);
        return Math.min(1_000_000, damage * (1 + Math.min(10_000, bonus) / 100));
    }
    public static double reduce(double damage, double ratio) {
        return Math.max(0, damage * (1 - (Double.isFinite(ratio) ? Math.clamp(ratio, 0, 0.99) : 0)));
    }
    public static double positive(double value) { return Double.isFinite(value) ? Math.max(0, value) : 0; }
}
