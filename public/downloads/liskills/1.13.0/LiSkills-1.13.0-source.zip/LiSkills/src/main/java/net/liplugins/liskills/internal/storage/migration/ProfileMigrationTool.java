package net.liplugins.liskills.internal.storage.migration;

import net.liplugins.liskills.internal.config.StorageSettings;
import net.liplugins.liskills.internal.storage.ProfileStorageFactory;
import org.bukkit.configuration.file.YamlConfiguration;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** 可独立运行的离线入口；不启动插件、不切换配置、不导入recovery和世界PDC。 */
public final class ProfileMigrationTool {
    private ProfileMigrationTool(){ }
    public static void main(String[] args){System.exit(run(args,System.out,System.err));}
    public static int run(String[] args,PrintStream out,PrintStream err){
        StorageMigrationMessages messages;
        try{messages=new StorageMigrationMessages();}catch(Exception failure){err.println("storage-tool-messages-unavailable");return 2;}
        if(args.length==1&&args[0].equals("--help")){out.println(messages.text("usage",Map.of()));return 0;}
        List<String> secrets=new ArrayList<>();
        try{
            MigrationArguments arguments=MigrationArguments.parse(args);
            MigrationDirectoryGuard.distinctPaths(arguments.source(),arguments.target(),arguments.drivers());
            StorageSettings from=readSettings(arguments.sourceConfig());secrets.add(from.mysql().password());
            StorageSettings to=readSettings(arguments.targetConfig());secrets.add(to.mysql().password());
            MigrationDirectoryGuard.validate(arguments.source(),from);MigrationDirectoryGuard.validate(arguments.target(),to);
            var downloading=(java.util.function.Consumer<String>)library->out.println(messages.text("downloading",Map.of("library",library)));
            var invalid=(java.util.function.Consumer<String>)library->out.println(messages.text("invalid-cache",Map.of("library",library)));
            ProfileMigrationService.Result result=null;ProfileMigrationPlan.Preview preview=null;
            // 先锁定并完整读源；源损坏时甚至不会初始化目标库/目标锁文件。
            try(var source=ProfileStorageFactory.open(arguments.source(),from,arguments.drivers(),true,downloading,invalid)){
                var snapshots=source.loadAll();
                ProfileMigrationPlan.index(snapshots);
                if(arguments.apply()){
                    // 只有明确执行才初始化目标位置；预检缺失目标绝不创建目录或表。
                    Files.createDirectories(arguments.target());
                    try(var target=ProfileStorageFactory.open(arguments.target(),to,arguments.drivers(),false,downloading,invalid)){
                        MigrationDirectoryGuard.validate(arguments.source(),from);MigrationDirectoryGuard.validate(arguments.target(),to);
                        result=new ProfileMigrationService().migrate(snapshots,target);
                    }
                }else{
                    try(var target=ProfileStorageFactory.preview(arguments.target(),to,arguments.drivers(),downloading,invalid)){
                        MigrationDirectoryGuard.validate(arguments.source(),from);MigrationDirectoryGuard.validate(arguments.target(),to);
                        preview=ProfileMigrationPlan.preview(snapshots,target.loadAll());
                    }
                }
            }
            if(preview!=null){
                out.println(messages.text("preview",Map.of("source",preview.sourceProfiles(),"missing",preview.missing(),"identical",preview.identical(),"conflicts",preview.conflicts(),"target",preview.targetProfiles())));
                out.println(messages.text("preview-next-step",Map.of()));return preview.conflicts()>0?3:0;
            }
            out.println(messages.text("complete",Map.of("source",result.sourceProfiles(),"copied",result.copied(),"skipped",result.skipped(),"target",result.targetProfiles())));
            out.println(messages.text("next-step",Map.of()));return 0;
        }catch(Exception|LinkageError failure){
            String error=failure.getClass().getSimpleName()+": "+String.valueOf(failure.getMessage());
            for(String secret:secrets)if(!secret.isEmpty())error=error.replace(secret,"<redacted>");
            err.println(messages.text("failed",Map.of("error",error)));return 1;
        }
    }
    private static StorageSettings readSettings(Path path)throws Exception{
        if(!Files.isRegularFile(path)||Files.size(path)>262144)throw new IllegalArgumentException("migration-config-missing-or-too-large");
        YamlConfiguration yaml=new YamlConfiguration();
        // SnakeYAML语法异常可能包含原始password行，配置尚未解析成功时也不能把行内容输出。
        try(var reader=Files.newBufferedReader(path,StandardCharsets.UTF_8)){yaml.load(reader);}
        catch(Exception failure){throw new IllegalArgumentException("migration-config-invalid");}
        return StorageSettings.parse(yaml);
    }
}
