# LiSkills 1.13.0

面向 **Paper 26.1.2 / Java 25** 的中文技能插件，新增 **Folia 26.2 区域线程适配**。提供 **15职业技能、70被动、9属性、19种特性、8项工具与战斗主动、装备要求、职业、奖励、排行榜和可选数据库**，并保留自家附魔联动。业务仍以标准 Bukkit API 编译，Folia 调度和临时属性通过独立兼容层接入。

内置生命、魔力、近期技能经验 HUD，使用原生 BossBar，不需要资源包。`/lsk hud` 切换个人显示，偏好随玩家数据保存。普通 Paper 正常停服会清理自有属性并保存；Folia 使用不写入玩家存档的临时属性，并在正常退出时清理。两者都保留基础血量和其他插件加成；历史版本在崩溃前留下的离线数据仍需单独清理，见[HUD 与安全卸载](docs/HUD-AND-UNINSTALL.md)。

完整15职业继续保留耐力、治疗、锻造、法术；前14项各5被动，法术默认无被动/主动，通过幽匿方块与成功耗蓝升级。独立等级、菜单、权限、职业选择和迁移均支持完整集合。来源拆分不双发经验，见[完整职业说明](docs/LEGACY-PROFESSIONS.md)。

本次具体实测范围见[1.13.0 验证记录](docs/VERIFICATION-1.13.0.md)，旧版报告只作为历史证据。Folia 支持包含实体/区域调度和安全关闭，并非仅添加声明。Shiroha 26.2 以兼容同类公开调度 API 为适配目标；未拿到用户截图的同一构建 Jar，不能宣称该构建已经实测。跨区域玩法边界见[Folia 与 Shiroha 说明](docs/FOLIA-COMPATIBILITY.md)。未进行基岩专项适配。

## 安装与升级

1. 备份插件、技能档案及世界玩家数据（Paper26.1.2 为 `world/players/data/`，旧版本常为 `world/playerdata/`），停服后移走旧 LiSkills 和冲突的旧技能插件 Jar，保留数据目录。
2. 只安装`dist/LiSkills-1.13.0.jar`。已有LiRealEnchant dev201无需替换；不装附魔也能独立使用。
3. 用 Java 25 启动 Paper 26.1.2 或兼容的 Folia 26.2；`/lsk`打开，`/lsk help`看指令，`/lsk validate`校验，`/lsk reload`重载。
4. 安装包`defaults/`仅供对照，不要覆盖管理员现有配置。升级补缺失职业和注释；旧菜单只追加空闲格。仅完整未自定义的历史被动模板调整归属，自定义值/注释保留；超过5项的被动可点击摘要翻页。
5. 旧版技能档案迁移先预检再执行，见[等级迁移](docs/MIGRATION.md)；旧物品需单独执行预览/转换，见[装备规则](docs/AURA-ITEMS.md)。

首次启动产生16份完整中文配置，全部验证通过后才发布新快照：

| 文件 | 管理内容 |
| --- | --- |
| `config.yml` | 全局开关、生命/魔力/经验 HUD、经验倍率、采集队列、反馈及第三方桥接 |
| `skills.yml` | 15职业技能或自定义技能ID、材质/生物经验、等级、主动类型 |
| `abilities.yml` | 70被动的解锁、每阶数值和主动成长 |
| `stats.yml` | 九属性、19原版特性及旧版共用幸运兼容项 |
| `balance.yml` | 普通生存服数值倍率、属性/被动/主动上限 |
| `mana_abilities.yml` | 8项主动的专有行为和安全限制 |
| `sources.yml` | 采集状态、鱼获分类、移动、炼金及附魔交易来源 |
| `xp_requirements.yml` | 可选公式和逐等级经验覆盖，默认保留旧曲线 |
| `loot.yml` | 钓鱼/挖掘稀有与史诗宝藏池 |
| `items.yml` | 装备槽、属性/特性/经验加成与技能等级要求 |
| `rewards.yml` | 自定义升级物品、经济及控制台指令奖励 |
| `jobs.yml` | 可选职业选择、经验限制及Vault收入 |
| `leaderboards.yml` | 异步离线排行榜和分页 |
| `storage.yml` | YAML/SQLite/MySQL及连接、关闭超时 |
| `messages.yml` / `menu.yml` | MiniMessage文本、界面布局、音效和图标 |

公共依赖不打进Jar。优先复用服务器已有Adventure/MiniMessage，缺失时从固定地址下载并校验SHA-256；SQL驱动也按固定版本和哈希放在`plugins/LiSkills/lib/`。缺库/下载失败用中文提示安全停止，不擅自下载Vault、PAPI或商业插件。详见[依赖](docs/DEPENDENCIES.md)。

## 生存玩法与防刷

**矿物只在真实采集成功后发经验和额外掉落。** 玩家放置的矿石、人工搬运标记、取消的破坏、坐标替换和重复事件都不能领奖；天然精准采集默认也不追加原矿，避免回放。额外掉落读取真正产生的原版物品，不能凭一个破坏事件凭空造矿。

人工标记写入区块持久数据，重启/卸载仍保留。无法追溯安装插件之前已经存在的人工矿物，请先处理旧人工矿场。成熟种植作物及实际自然生长的树木有明确例外，允许正常农业；例外不能借自定义技能变成放置小麦刷经验。详情见[采集防刷](docs/ANTI-EXPLOIT.md)与[自然来源](docs/NATURAL-SOURCES.md)。

| 技能 | 主要自然经验来源 | 默认主动 |
| --- | --- | --- |
| 农耕 | 成熟作物、浆果、竖直植物、海泡菜 | 丰收补种 |
| 伐木 | 天然/实际长成树木、树叶和菌柄 | 连锁伐木 |
| 挖矿 | 天然石头和矿物 | 快速挖掘（急迫III） |
| 钓鱼 | 原版鱼/杂物/宝物、稀有/史诗分类 | 锐钩 |
| 挖掘 | 土沙等天然地形 | 地形开拓 |
| 箭术 | 有效玩家投射物击杀 | 逐箭蓄力射击 |
| 防御 | 有效生物伤害，受间隔限制 | 伤害吸收 |
| 战斗 | 有效玩家近战击杀 | 闪电之刃（攻速） |
| 敏捷 | 有效摔落与可信跳跃 | 保留额外跳跃药水主动 |
| 炼金 | 实际取出酿造药水 | 保留额外恢复药水主动 |
| 附魔 | 实际付费附魔台交易 | 保留额外夜视药水主动 |
| 耐力 | 可信步行、疾跑和游泳 | 无 |
| 治疗 | 有效饮用、金苹果和药水投掷 | 无 |
| 锻造 | 实际付费铁砧和砂轮收货 | 无 |
| 法术 | 自然幽匿方块和成功施法耗蓝 | 无 |

8项工具与战斗主动之外保留3个LiSkills药水主动及旧`CHARGED_SHOT/QUICK_FISH/MANA_SHIELD`类型供已有配置使用。锐钩需要真实挂钩目标；左键弓切换逐箭模式；默认左键盾准备、下一次有效受击激活伤害吸收。其他工具支持潜行右键或菜单/指令施放。完整区别见[主动能力](docs/aura-mana-module.md)。

普通生存默认开启`balance.yml`：常规主动最长20秒、冷却至少120秒、最高10阶；生命成长最多增加5颗心，暴击属性最多15点，常见采集幸运被动最多15。闪电之刃攻速最多50%，逐箭伤害增幅最多25%，锐钩最多5点基础伤害。外部附魔/装备的独立效果不被本插件强行抹除。精确计算、叠加和调整方法见[平衡与自定义](docs/BALANCE-AND-CONFIG.md)。

默认2至6级依次解锁五被动，每5技能级提升一阶。自然经验仅叠加一次全局/专精/装备倍率；管理员加经验不触发职业收入或自然经验反馈。经验BossBar批量合并，避免刷聊天。移动经验验证位移和Bukkit统计，拒绝传送、异常跳变和短时间小范围回放；不宣称能识别所有自动化。

## 装备、职业与奖励

装备规则支持主手、副手和四护甲槽，匹配材质与PDC身份，提供ADD/MULTIPLY/ADD_PERCENT属性/特性、全技能或指定技能经验及使用等级要求。堆叠64个不会把装备加成乘64；只写LiSkills自己的PDC，不覆盖LiRealEnchant附魔、其他插件Lore或原生装备修饰符。已穿戴的不合格装备取消LiSkills加成但不强制剥除。见[装备说明](docs/AURA-ITEMS.md)。

职业经济和物品奖励示例默认关闭，审核经济后再开启。奖励按规则ID+技能保存已处理等级，降级不能重刷；职业收入只使用实际新增自然经验，受持久每日限额限制。独立账本确认写入后才尝试发放，不依赖玩家存档的保存回执。Vault付款和控制台命令不能组成跨插件事务，失败不自动重发，需要管理员对账。

排行榜包含本服离线档案及在线最新快照，在后台读取排序，查询不阻塞读盘；`rank`为0表示未入缓存榜。收入/奖励权威记录在`reward-ledger/`，职业选择、HUD偏好和持久玩家加成在世界玩家数据中，都不在技能导出中。见[管理扩展](docs/EXTENSIONS.md)。

## 指令

| 指令 | 用途 |
| --- | --- |
| `/lsk` / `/lsk help` | 可配置总览和完整帮助 |
| `/lsk hud [on\|off\|toggle\|status]` | 切换或查询个人 HUD，无参数切换开关 |
| `/lsk stats [玩家]` / `/lsk attributes [玩家]` | 技能和九属性查询 |
| `/lsk abilities mining` / `/lsk sources mining` | 能力树与真实配置来源 |
| `/lsk cast mining` / `/lsk mana [玩家]` | 主动和魔力 |
| `/lsk jobs list` / `/lsk jobs join mining` / `/lsk jobs leave mining` | 选职管理 |
| `/lsk top total 1` / `/lsk rank mining` | 排行及个人名次 |
| `/lsk xp add 玩家 mining 100` / `/lsk xp set 玩家 mining 20` | 管理经验；set为本级经验 |
| `/lsk level set 玩家 mining 10` | 管理等级并清零本级经验 |
| `/lsk item inspect` / `/lsk item legacy-preview` | 检查手持物品/旧版公开标签 |
| `/lsk item stat bonus strength ADD 2 MAIN_HAND` | 手持物品增加命名规则 |
| `/lsk item require gate mining 20 MAIN_HAND` | 手持物品技能使用要求 |
| `/lsk modifier set 玩家 blessing health 2` | 命名的持久玩家属性加成 |
| `/lsk export` | 异步导出新目录，不覆盖旧导出 |
| `/lsk validate` / `/lsk reload` | 校验/安全重载；存储更改需重启 |

全部指令及参数带Tab补全。玩家默认`liskills.use`、`liskills.skill.*`与`liskills.hud`；管理员为`liskills.admin`，查询他人为`liskills.stats.others`。管理修改要求目标在线且档案加载成功。别名冲突请用完整`/liskills`。

## 联动

- **LiRealEnchant dev201**：使用公开预检/成功/二次伤害接口去重和避让；同一工具不启动两套连锁或补种，装备编辑保留自家附魔。[详细兼容](docs/COMPATIBILITY.md)
- **CustomCrops3.6.54**：成熟、产出与状态变化确认后发一次农耕经验；不再补种、加速或复制其产物。[作物说明](docs/customcrops-notes.md)
- **CustomFishing2.3.26**：最终成功结果发一次钓鱼经验，排除附带原版事件；不复制渔获，锐钩避让其受管鱼钩。[钓鱼说明](docs/customfishing-notes.md)
- 按ID经验映射仍在`config.yml -> compatibility.customcrops.crop-xp/customfishing.loot-xp`；默认XP设0可只允许显式ID。关闭经验桥接也保留必要归属避让。商业插件不随本包分发。
- **PlaceholderAPI/Vault** 可选；LiPet仅参考架构和中文界面，没有额外宣称宠物API互通。

## 数据与开发

默认YAML保留已有档案；SQLite/MySQL为可选后端，**不能只改类型就期待自动搬迁**。先停服备份，用离线工具预检/执行后再改`storage.yml`。同一存储只允许一个进程持锁，不提供多服同步。损坏/冲突/连接失败拒绝空档覆盖，关闭失败保留恢复快照。见[存储与迁移](docs/AURA-STORAGE.md)。

PAPI提供`%liskills_level_mining%`、`xp_mining`、`required_mining`、`total_xp_mining`、`total_level`、`mana`、`max_mana`、`stat_strength`、`ability_bountiful_harvest`及`ability_value_bountiful_harvest`等同前缀占位符。只读已加载快照，不为查询读盘。

其他插件通过Bukkit ServicesManager获取`LiSkillsApi`：技能/进度、自然经验、管理经验和等级、属性/特性、魔力、主动状态与施放。自然经验先发布可取消的`SkillExperiencePreGainEvent`，成功后再发布只读Gain事件；同技能重入不能重复入账。这是 LiSkills 自身 API，不提供其他技能插件的二进制 API 替代层；写入和施法须在目标玩家所属线程执行。

运行`./build.ps1`构建；依赖API归档于`lib/`，不打入成品。源码按主类、API、lib、配置、指令、监听器、管理器、存储、菜单、桥接、工具分层。最终测试与限制见[本次验证](docs/VERIFICATION-1.13.0.md)，未经真人视觉、全保护插件组合或长期多人压测验收。

保留原作者 Archyx 署名；完整来源、衍生关系和修改范围见修改说明。保留[GPL-3.0许可](LICENSE.md)与[修改说明](NOTICE.md)，完整源码随包提供。
