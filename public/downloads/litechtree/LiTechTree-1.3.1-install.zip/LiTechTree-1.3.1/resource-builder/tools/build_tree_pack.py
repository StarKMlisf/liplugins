#!/usr/bin/env python3
"""根据 tree.yml 生成 LiTechTree Dialog 字体资源包和独立布局预览。

构建依赖：Pillow、PyYAML。原版物品贴图来自本地合法安装的 Minecraft 客户端；
首次提取后缓存到 src/main/resources/tree-ui/icons，可在无客户端的构建机复用。
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import math
import os
from pathlib import Path
import re
import zipfile

from PIL import Image, ImageDraw, ImageEnhance
import yaml


ROOT = Path(__file__).resolve().parents[1]
UI_ROOT = ROOT / "src/main/resources/tree-ui"
STATES = ("ready", "locked", "done")
VALID_ID = re.compile(r"[a-z0-9_-]{1,64}\Z")


def write_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def find_client(argument: str | None) -> Path | None:
    if argument:
        client = Path(argument).expanduser().resolve()
        if not client.is_file():
            raise ValueError(f"客户端 Jar 不存在：{client}")
        return client
    candidate = Path(os.environ.get("APPDATA", Path.home())) / ".minecraft/versions/26.2/26.2.jar"
    return candidate if candidate.is_file() else None


def resource_path(kind: str, location: str, extension: str) -> str:
    namespace, value = location.split(":", 1) if ":" in location else ("minecraft", location)
    suffix = "" if value.endswith(f".{extension}") else f".{extension}"
    return f"assets/{namespace}/{kind}/{value}{suffix}"


class VanillaIcons:
    """缓存原版平面物品图标，或用原版模型与贴图绘制固定视角的小方块图标。"""

    def __init__(self, client: Path | None):
        self.client = client
        self.archive = zipfile.ZipFile(client) if client else None
        self.sources: dict[str, dict] = {}
        previous = UI_ROOT / "sources.json"
        if previous.is_file():
            self.sources = json.loads(previous.read_text(encoding="utf-8")).get("icons", {})

    def close(self) -> None:
        if self.archive:
            self.archive.close()

    def image(self, location: str) -> Image.Image:
        assert self.archive
        return Image.open(io.BytesIO(self.archive.read(resource_path("textures", location, "png")))).convert("RGBA")

    def model(self, location: str, seen: tuple[str, ...] = ()) -> dict:
        if location in seen:
            raise ValueError(f"原版模型继承循环：{location}")
        assert self.archive
        own = json.loads(self.archive.read(resource_path("models", location, "json")))
        parent = own.get("parent")
        base = self.model(parent, (*seen, location)) if parent else {}
        merged = {**base, **own}
        merged["textures"] = {**base.get("textures", {}), **own.get("textures", {})}
        return merged

    def get(self, material: str) -> Image.Image:
        name = material.lower()
        if not VALID_ID.fullmatch(name):
            raise ValueError(f"非法图标材质：{material}")
        cache = UI_ROOT / "icons" / f"{name}.png"
        if cache.is_file():
            return Image.open(cache).convert("RGBA")
        if not self.archive:
            raise ValueError(f"缺少 {material} 图标。请使用 --client 指定原版 26.2 客户端 Jar 后重建。")
        sprite = "compass_00" if name == "compass" else name
        texture = f"minecraft:item/{sprite}"
        if resource_path("textures", texture, "png") in self.archive.namelist():
            icon = self.image(texture)
            # 动态纹理仅取第一帧，不把纵向贴图条直接作为图标。
            if icon.height > icon.width:
                icon = icon.crop((0, 0, icon.width, icon.width))
            source = {"type": "vanilla_item_texture", "texture": texture}
        else:
            model_name = f"minecraft:block/{name}"
            try:
                icon = self.render_model(self.model(model_name))
                source = {"type": "vanilla_block_model_projection", "model": model_name,
                          "note": "使用原版模型与贴图绘制的固定视角预览，非游戏客户端截图。"}
            except (KeyError, ValueError) as error:
                raise ValueError(f"无法生成 {material} 图标，请在 {cache} 提供 RGBA PNG；原因：{error}") from error
        cache.parent.mkdir(parents=True, exist_ok=True)
        icon.save(cache)
        self.sources[name] = source
        return icon

    def render_model(self, model: dict) -> Image.Image:
        """绘制原版轴对齐方块元素；按像素深度遮挡，不伪装成客户端实拍。"""
        elements = model.get("elements", [])
        if not elements or any("rotation" in item for item in elements):
            raise ValueError("此构建器仅支持轴对齐方块元素")
        textures = model.get("textures", {})
        canvas = Image.new("RGBA", (20, 20))
        depth = [[-math.inf for _ in range(20)] for _ in range(20)]

        def project(point: tuple[float, float, float]) -> tuple[float, float, float]:
            x, y, z = point
            return ((x + z) * 0.58 + 0.72, (x - z) * 0.28 - y * 0.57 + 14.20,
                    x + y * 1.4 - z)

        def resolve(key: str) -> Image.Image:
            seen: set[str] = set()
            # 26.2 透明方块允许 {sprite, force_translucent} 形式的纹理引用。
            while True:
                if isinstance(key, dict):
                    key = key.get("sprite")
                if not isinstance(key, str):
                    raise ValueError("方块贴图引用缺少 sprite")
                if not key.startswith("#"):
                    break
                if key in seen:
                    raise ValueError("方块贴图引用循环")
                seen.add(key)
                key = textures[key[1:]]
            return self.image(key)

        def draw_triangle(points, uv, texture, brightness):
            a, b, c = points
            denominator = (b[1] - c[1]) * (a[0] - c[0]) + (c[0] - b[0]) * (a[1] - c[1])
            if abs(denominator) < 1e-6:
                return
            for py in range(max(0, math.floor(min(p[1] for p in points))), min(20, math.ceil(max(p[1] for p in points)))):
                for px in range(max(0, math.floor(min(p[0] for p in points))), min(20, math.ceil(max(p[0] for p in points)))):
                    x, y = px + 0.5, py + 0.5
                    wa = ((b[1] - c[1]) * (x - c[0]) + (c[0] - b[0]) * (y - c[1])) / denominator
                    wb = ((c[1] - a[1]) * (x - c[0]) + (a[0] - c[0]) * (y - c[1])) / denominator
                    wc = 1 - wa - wb
                    if min(wa, wb, wc) < -0.0001:
                        continue
                    z = wa * a[2] + wb * b[2] + wc * c[2]
                    if z <= depth[py][px]:
                        continue
                    u = wa * uv[0][0] + wb * uv[1][0] + wc * uv[2][0]
                    v = wa * uv[0][1] + wb * uv[1][1] + wc * uv[2][1]
                    rgba = texture.getpixel((min(texture.width - 1, max(0, int(u / 16 * texture.width))),
                                             min(texture.height - 1, max(0, int(v / 16 * texture.height)))))
                    if rgba[3]:
                        canvas.putpixel((px, py), (*[round(channel * brightness) for channel in rgba[:3]], rgba[3]))
                        depth[py][px] = z

        for element in elements:
            x0, y0, z0 = element["from"]
            x1, y1, z1 = element["to"]
            faces = {
                "up": ([(x0, y1, z1), (x1, y1, z1), (x1, y1, z0), (x0, y1, z0)], 1.0),
                "north": ([(x1, y1, z0), (x0, y1, z0), (x0, y0, z0), (x1, y0, z0)], 0.83),
                "east": ([(x1, y1, z1), (x1, y1, z0), (x1, y0, z0), (x1, y0, z1)], 0.67),
            }
            for face, (vertices, brightness) in faces.items():
                detail = element.get("faces", {}).get(face)
                if not detail:
                    continue
                texture = resolve(detail["texture"])
                u0, v0, u1, v1 = detail.get("uv", [0, 0, 16, 16])
                uv = [(u0, v0), (u1, v0), (u1, v1), (u0, v1)]
                rotation = (detail.get("rotation", 0) // 90) % 4
                uv = uv[rotation:] + uv[:rotation]
                points = [project(vertex) for vertex in vertices]
                for triangle in ((0, 1, 2), (0, 2, 3)):
                    draw_triangle([points[i] for i in triangle], [uv[i] for i in triangle], texture, brightness)
        return canvas


def slot_position(slot: int, style: dict) -> tuple[int, int]:
    return (slot % 9 * style["column-spacing"] + style["left-padding"],
            style["top-padding"] + slot // 9 * style["row-spacing"])


def load_styles(path: Path) -> dict:
    defaults = yaml.safe_load((ROOT / "src/main/resources/ui.yml").read_text(encoding="utf-8-sig"))
    own = yaml.safe_load(path.read_text(encoding="utf-8-sig"))

    def merge(base, extra):
        result = dict(base)
        for key, value in extra.items():
            result[key] = merge(base.get(key, {}), value) if isinstance(value, dict) else value
        return result

    styles = merge(defaults, own)["presets"]
    ranges = {"width": (180, 360), "height": (153, 360), "node-size": (16, 40),
              "column-spacing": (18, 40), "row-spacing": (27, 63), "left-padding": (0, 40), "top-padding": (0, 54)}
    for name, style in styles.items():
        if not re.fullmatch(r"[a-z0-9_-]{1,32}", name):
            raise ValueError(f"UI 预设 ID 无效：{name}")
        for key, (low, high) in ranges.items():
            value = style[key]
            if isinstance(value, bool) or not isinstance(value, int) or not low <= value <= high:
                raise ValueError(f"UI 选项 {name}.{key} 须为 {low}~{high} 整数")
        width, height, size = style["width"], style["height"], style["node-size"]
        if (height % 9 or style["top-padding"] % 9 or style["row-spacing"] % 9
                or style["column-spacing"] < size or style["row-spacing"] < size
                or style["left-padding"] + 8 * style["column-spacing"] + size > width
                or style["top-padding"] + 4 * style["row-spacing"] + size > height):
            raise ValueError(f"预设 {name} 无法容纳 9×5 节点，或纵向位置不是 9 的倍数")
        values = [str(style[key]) for key in ranges]

        def color(container, key):
            value = str(container[key]).lower()
            if not re.fullmatch(r"#[0-9a-f]{6}", value):
                raise ValueError(f"预设 {name} 的颜色 {key} 必须是 '#RRGGBB'")
            container[key] = value
            return value

        values.append(color(style, "background"))
        for value in (style["border"], style["lines"]["enabled"]):
            if not isinstance(value, bool):
                raise ValueError(f"预设 {name} 的开关必须为 true / false")
            values.append(str(value).lower())
        values += [color(style["lines"], "color"), color(style["lines"], "outline")]
        for state in STATES:
            values += [color(style["states"][state], part) for part in ("fill", "light", "shadow")]
        style["signature"] = hashlib.sha256("|".join(values).encode()).hexdigest()
    return styles


def write_layout(path: Path, manifest: dict) -> None:
    lines = ["# LiTechTree 图形科技树资源清单，由 tools/build_tree_pack.py 生成；不要手工编辑。",
             "# 修改 tree.yml 的布局、图标或 ui.yml 的预设参数后，必须同时更新此清单与资源包。",
             "# 格式版本，当前固定为 2。", "format: 2",
             "# 预设 ID 与 ui.yml 对应；已打包预设可重载切换。", "presets:"]
    for name, preset in manifest["presets"].items():
        lines += [f"  # {name} 预设的已验证像素尺寸与字体资源。", f"  {name}:"]
        for key, comment in (("width", "画布宽度，GUI 像素，整数 180~360。"),
                             ("height", "画布高度，GUI 像素，整数 153~360。"),
                             ("line-height", "原生文本行高，固定为 9。"),
                             ("background-advance", "背景字形的实际字体占位宽度，等于画布宽度+1。"),
                             ("signature", "预设尺寸与配色 SHA-256；防止资源包与 ui.yml 不匹配。")):
            lines += [f"    # {comment}", f"    {key}: {preset[key]}"]
        lines += ["    # 章节字体与节点清单。", "    chapters:"]
        for chapter, page in preset["chapters"].items():
            lines += [f"      # {chapter} 章节资源。", f"      {chapter}:",
                      "        # 本章预设字体命名空间键。", f"        font: '{page['font']}'",
                      "        # 节点 ID 必须与 tree.yml 完全一致。", "        nodes:" if page["nodes"] else "        nodes: {}"]
            for node_id, node in page["nodes"].items():
                lines += [f"          # {node_id} 节点布局与状态字形。", f"          {node_id}:"]
                for key, comment in (("slot", "配置坐标，整数 0~44，9 列×5 行。"),
                                     ("icon", "Bukkit 物品材质名，与 tree.yml 保持一致。"),
                                     ("glyph-base", "可研究字形码位；未开放+1，已完成+2。"),
                                     ("x", "节点左端像素坐标，非负整数。"),
                                     ("y", "节点顶端像素坐标，9 的非负整数倍。"),
                                     ("advance", "节点字形实际占位宽度，节点边长+1。")):
                    lines += [f"            # {comment}", f"            {key}: {node[key]}"]
                lines += ["            # 全部前置节点 ID，包含跨章节前置；用于核验连线。",
                          "            parents: [" + ", ".join(f"'{parent}'" for parent in node["parents"]) + "]"]
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def verify_bitmap_metrics(output: Path, definitions: dict[str, list], styles: dict) -> int:
    """按客户端 BitmapProvider 的裁边规则核对每个字形的实际 advance。"""
    count = 0
    for font, providers in definitions.items():
        style = styles[font.split("/")[0]]
        for provider in providers:
            file_key = provider["file"]
            texture = Image.open(output / resource_path("textures", file_key, "png")).convert("RGBA")
            rows, columns = len(provider["chars"]), len(provider["chars"][0])
            width, height = texture.width // columns, texture.height // rows
            if width > 256 or height > 256:
                raise ValueError(f"字形超过客户端 256×256 图集上限：{file_key}")
            for row, chars in enumerate(provider["chars"]):
                if len(chars) != columns:
                    raise ValueError(f"字体字符行列不一致：{file_key}")
                for column, char in enumerate(chars):
                    cell = texture.crop((column * width, row * height, (column + 1) * width, (row + 1) * height))
                    box = cell.getchannel("A").getbbox()
                    occupied_width = box[2] if box else 0
                    advance = int(occupied_width * provider["height"] / height + 0.5) + 1
                    expected = style["width"] + 1 if char == "\ue000" else style["node-size"] + 1
                    if advance != expected:
                        raise ValueError(f"字体 {font} U+{ord(char):04X} advance={advance}，期望 {expected}")
                    count += 1
    return count


def panel(chapter: str, nodes: dict, style: dict) -> Image.Image:
    width, height = style["width"], style["height"]
    # 大于 256 的画布须以精确同比例源图存储，保证点击字形宽度与清单一致。
    divisor = math.gcd(width, height)
    unit_width, unit_height = width // divisor, height // divisor
    factor = min(divisor, 256 // max(unit_width, unit_height))
    if factor < 1:
        raise ValueError(f"画布 {width}×{height} 无法精确装入字体图集；请使用具有公约数的尺寸")
    source_width, source_height = unit_width * factor, unit_height * factor
    image = Image.new("RGBA", (source_width, source_height), style["background"])
    draw = ImageDraw.Draw(image)
    if style["border"]:
        colors = ["#222222", "#f1f1f1", "#dedede", "#aaaaaa", "#555555", "#424242"]
        for index, color in enumerate(colors):
            draw.line((index, 0, index, source_height - 1), fill=color)
            draw.line((source_width - index - 1, 0, source_width - index - 1, source_height - 1), fill=color)
        draw.line((6, 0, source_width - 7, 0), fill="#969696")
        draw.line((6, source_height - 1, source_width - 7, source_height - 1), fill="#5c5c5c")
    edges = []
    size = style["node-size"]
    if style["lines"]["enabled"]:
        for node in nodes.values():
            if node["chapter"] != chapter:
                continue
            cx, cy = slot_position(node["slot"], style)
            for parent_id in node.get("parents", []):
                parent = nodes[parent_id]
                if parent["chapter"] != chapter:
                    continue
                px, py = slot_position(parent["slot"], style)
                if py == cy:
                    # 同行分支从相邻侧边相连，避免绕到节点内部。
                    start = (px + size - 1 if px < cx else px, py + size // 2)
                    end = (cx if px < cx else cx + size - 1, cy + size // 2)
                    edges.append([start, end])
                    continue
                start = (px + size // 2, py + size - 1 if py < cy else py)
                end = (cx + size // 2, cy if py < cy else cy + size - 1)
                if start[0] == end[0]:
                    edges.append([start, end])
                else:
                    middle = round((start[1] + end[1]) / 2)
                    edges.append([start, (start[0], middle), (end[0], middle), end])
        scaled = [[(round(x * source_width / width), round(y * source_height / height)) for x, y in points] for points in edges]
        for points in scaled:
            draw.line(points, fill=style["lines"]["outline"], width=3, joint="curve")
        for points in scaled:
            draw.line(points, fill=style["lines"]["color"], width=1, joint="curve")
    return image


def node_icon(icon: Image.Image, state: str, style: dict) -> Image.Image:
    # 先在 28 像素母版绘制，再最近邻缩放；保留右端像素以固定字形 advance。
    image = Image.new("RGBA", (28, 28))
    draw = ImageDraw.Draw(image)
    outline = [(2, 0), (5, 0), (9, 3), (19, 3), (23, 0), (26, 0), (27, 3), (25, 7),
               (24, 10), (24, 18), (27, 23), (27, 25), (25, 27), (21, 26), (18, 24),
               (9, 24), (5, 27), (2, 27), (0, 25), (1, 21), (3, 18), (3, 9), (0, 4), (0, 2)]
    colors = style["states"][state]
    draw.polygon(outline, fill=colors["fill"], outline="#101010")
    draw.line([(2, 2), (4, 2), (8, 5), (20, 5), (24, 2), (25, 2)], fill=colors["light"])
    draw.line([(2, 3), (5, 9), (5, 19), (2, 24)], fill=colors["light"])
    draw.line([(25, 4), (22, 10), (22, 19), (25, 24)], fill=colors["shadow"])
    draw.line([(4, 25), (9, 22), (19, 22), (24, 25)], fill=colors["shadow"])
    icon = icon.copy()
    if max(icon.size) > 20:
        icon.thumbnail((20, 20), Image.Resampling.NEAREST)
    elif max(icon.size) < 16:
        icon = icon.resize((16, 16), Image.Resampling.NEAREST)
    if state == "locked":
        alpha = icon.getchannel("A")
        icon = ImageEnhance.Color(icon).enhance(0.30)
        icon = ImageEnhance.Brightness(icon).enhance(0.73)
        icon.putalpha(alpha)
    image.alpha_composite(icon, ((28 - icon.width) // 2, (28 - icon.height) // 2))
    if state == "done":
        draw.rectangle((20, 20, 26, 26), fill="#30372e", outline="#101610")
        draw.line([(21, 23), (23, 25), (26, 21)], fill="#a6e1a0", width=1)
    size = style["node-size"]
    image = image.resize((size, size), Image.Resampling.NEAREST)
    if image.getchannel("A").getbbox()[2] != size:
        image.putpixel((size - 1, size // 2), (16, 16, 16, 255))
    return image


def build(args: argparse.Namespace) -> None:
    tree_path, ui_path, output = Path(args.tree).resolve(), Path(args.ui).resolve(), Path(args.output).resolve()
    tree = yaml.safe_load(tree_path.read_text(encoding="utf-8-sig"))
    chapters, nodes, styles = tree["chapters"], tree["nodes"], load_styles(ui_path)
    if len(nodes) > (0xF8FF - 0xE100) // 3:
        raise ValueError("节点数量超过字体私人码位范围")
    for chapter in chapters:
        if not VALID_ID.fullmatch(chapter):
            raise ValueError(f"非法章节 ID：{chapter}")
    occupied = set()
    for node_id, node in nodes.items():
        if not VALID_ID.fullmatch(node_id) or node["chapter"] not in chapters:
            raise ValueError(f"非法节点 ID 或章节：{node_id}")
        if isinstance(node["slot"], bool) or not isinstance(node["slot"], int) or not 0 <= node["slot"] <= 44:
            raise ValueError(f"节点 {node_id} 的 slot 必须为 0~44 整数")
        position = (node["chapter"], node["slot"])
        if position in occupied:
            raise ValueError(f"节点位置重复：{position}")
        occupied.add(position)
        if any(parent not in nodes for parent in node.get("parents", [])):
            raise ValueError(f"节点 {node_id} 存在无效前置")
    icons = VanillaIcons(find_client(args.client))
    previews = output.parent / "previews"
    previews.mkdir(parents=True, exist_ok=True)
    asset_root = output / "assets/litechtree"
    font_root, texture_root = asset_root / "font", asset_root / "textures/tree"
    texture_root.mkdir(parents=True, exist_ok=True)
    providers, expected_files = {}, []
    manifest = {"schema": 2, "presets": {}, "tree_sha256": hashlib.sha256(tree_path.read_bytes()).hexdigest()}
    try:
        base_icons = {node_id: icons.get(node["icon"]) for node_id, node in nodes.items()}
        for preset, style in styles.items():
            size = style["node-size"]
            layout = {"width": style["width"], "height": style["height"], "line-height": 9,
                      "background-advance": style["width"] + 1, "signature": style["signature"], "chapters": {}}
            manifest["presets"][preset] = layout
            composed = {}
            (texture_root / preset).mkdir(parents=True, exist_ok=True)
            for chapter in chapters:
                font = f"{preset}/{chapter}"
                background = panel(chapter, nodes, style)
                path = texture_root / preset / f"panel_{chapter}.png"
                background.save(path)
                expected_files.append(path)
                composed[chapter] = background.resize((style["width"], style["height"]), Image.Resampling.NEAREST)
                providers[font] = [{"type": "bitmap", "file": f"litechtree:tree/{preset}/panel_{chapter}.png",
                                    "ascent": 7, "height": style["height"], "chars": ["\ue000"]}]
                layout["chapters"][chapter] = {"font": f"litechtree:tree/{font}", "nodes": {}}
            for index, (node_id, node) in enumerate(nodes.items()):
                chapter, font = node["chapter"], f"{preset}/{node['chapter']}"
                variants = [node_icon(base_icons[node_id], state, style) for state in STATES]
                atlas = Image.new("RGBA", (size * 3, size))
                for column, variant in enumerate(variants):
                    atlas.alpha_composite(variant, (column * size, 0))
                path = texture_root / preset / f"node_{node_id}.png"
                atlas.save(path)
                expected_files.append(path)
                codepoints = [0xE100 + index * 3 + offset for offset in range(3)]
                providers[font].append({"type": "bitmap", "file": f"litechtree:tree/{preset}/node_{node_id}.png",
                                        "ascent": 7, "height": size, "chars": ["".join(chr(point) for point in codepoints)]})
                x, y = slot_position(node["slot"], style)
                composed[chapter].alpha_composite(variants[0], (x, y))
                layout["chapters"][chapter]["nodes"][node_id] = {
                    "slot": node["slot"], "icon": node["icon"], "glyph-base": codepoints[0], "x": x, "y": y,
                    "advance": size + 1, "parents": node.get("parents", [])}
            for chapter, composite in composed.items():
                composite.save(previews / f"{preset}-{chapter}.png")
                composite.resize((style["width"] * 3, style["height"] * 3), Image.Resampling.NEAREST).save(previews / f"{preset}-{chapter}@3x.png")
    finally:
        icons.close()
    write_json(UI_ROOT / "sources.json", {
        "source": "Minecraft Java Edition 26.2 client assets", "owner": "Mojang Studios / Microsoft",
        "note": "原版物品与方块贴图版权属于其权利人。投影和预览仅供 UI 使用，不代表客户端实拍。", "icons": icons.sources})
    for font, values in providers.items():
        path = font_root / "tree" / f"{font}.json"
        write_json(path, {"providers": values})
        expected_files.append(path)
    advances = {chr(0xF0000 + value): value for value in range(1, 601)}
    advances.update({chr(0xF1000 + value): -value for value in range(1, 601)})
    path = font_root / "space.json"
    write_json(path, {"providers": [{"type": "space", "advances": advances}]})
    expected_files.append(path)
    path = output / "pack.mcmeta"
    write_json(path, {"pack": {"description": "LiTechTree 可定制图形科技树 · Paper / Folia 26.2",
                                "min_format": [88, 0], "max_format": [88, 0]}})
    expected_files.append(path)
    path = output / "asset-sources.json"
    write_json(path, json.loads((UI_ROOT / "sources.json").read_text(encoding="utf-8")))
    expected_files.append(path)
    path = output / "tree-ui-manifest.json"
    write_json(path, manifest)
    expected_files.append(path)
    write_layout(output.parent / "ui-layout.yml", manifest)
    # 管理员自定义构建不修改项目默认布局，避免意外污染发布包。
    if tree_path == (ROOT / "src/main/resources/tree.yml").resolve() and ui_path == (ROOT / "src/main/resources/ui.yml").resolve():
        write_json(UI_ROOT / "manifest.json", manifest)
        write_layout(UI_ROOT / "layout.yml", manifest)
    checked_glyphs = verify_bitmap_metrics(output, providers, styles)
    zip_path = output.parent / "LiTechTree-UI.zip"
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(expected_files):
            info = zipfile.ZipInfo(path.relative_to(output).as_posix(), date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            archive.writestr(info, path.read_bytes())
    print(json.dumps({"chapters": len(chapters), "nodes": len(nodes), "presets": list(styles), "files": len(expected_files),
                      "verified_bitmap_glyphs": checked_glyphs, "zip": str(zip_path),
                      "sha1": hashlib.sha1(zip_path.read_bytes()).hexdigest(), "previews": str(previews)}, ensure_ascii=False, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tree", default=str(ROOT / "src/main/resources/tree.yml"), help="科技树配置路径")
    parser.add_argument("--ui", default=str(ROOT / "src/main/resources/ui.yml"), help="布局与配色配置路径")
    parser.add_argument("--output", default=str(ROOT / "resourcepack/pack"), help="资源包根目录")
    parser.add_argument("--client", help="首次提取图标所用的原版 26.2 客户端 Jar；已有缓存时可省略")
    try:
        build(parser.parse_args())
    except (OSError, ValueError, KeyError, yaml.YAMLError) as error:
        parser.exit(1, f"资源包生成失败：{error}\n")


if __name__ == "__main__":
    main()
